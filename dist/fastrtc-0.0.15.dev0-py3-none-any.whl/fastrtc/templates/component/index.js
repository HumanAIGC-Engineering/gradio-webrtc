var u7 = Object.defineProperty;
var n2 = (r) => {
  throw TypeError(r);
};
var c7 = (r, e, t) => e in r ? u7(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var nt = (r, e, t) => c7(r, typeof e != "symbol" ? e + "" : e, t), h7 = (r, e, t) => e.has(r) || n2("Cannot " + t);
var r2 = (r, e, t) => e.has(r) ? n2("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var vl = (r, e, t) => (h7(r, e, "access private method"), t);
const {
  SvelteComponent: d7,
  assign: f7,
  children: m7,
  claim_element: _7,
  create_slot: p7,
  detach: a2,
  element: g7,
  get_all_dirty_from_scope: v7,
  get_slot_changes: b7,
  get_spread_update: y7,
  init: w7,
  insert_hydration: k7,
  safe_not_equal: D7,
  set_dynamic_element_data: i2,
  set_style: Pt,
  toggle_class: an,
  transition_in: t6,
  transition_out: n6,
  update_slot_base: S7
} = window.__gradio__svelte__internal;
function E7(r) {
  let e, t, n;
  const a = (
    /*#slots*/
    r[22].default
  ), i = p7(
    a,
    r,
    /*$$scope*/
    r[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      r[10]
    ) },
    { id: (
      /*elem_id*/
      r[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      r[6].join(" ") + " svelte-1ezsyiy"
    }
  ], o = {};
  for (let s = 0; s < l.length; s += 1)
    o = f7(o, l[s]);
  return {
    c() {
      e = g7(
        /*tag*/
        r[18]
      ), i && i.c(), this.h();
    },
    l(s) {
      e = _7(
        s,
        /*tag*/
        (r[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var u = m7(e);
      i && i.l(u), u.forEach(a2), this.h();
    },
    h() {
      i2(
        /*tag*/
        r[18]
      )(e, o), an(
        e,
        "hidden",
        /*visible*/
        r[13] === !1
      ), an(
        e,
        "padded",
        /*padding*/
        r[9]
      ), an(
        e,
        "flex",
        /*flex*/
        r[0]
      ), an(
        e,
        "border_focus",
        /*border_mode*/
        r[8] === "focus"
      ), an(
        e,
        "border_contrast",
        /*border_mode*/
        r[8] === "contrast"
      ), an(e, "hide-container", !/*explicit_call*/
      r[11] && !/*container*/
      r[12]), Pt(
        e,
        "height",
        /*get_dimension*/
        r[19](
          /*height*/
          r[1]
        )
      ), Pt(
        e,
        "min-height",
        /*get_dimension*/
        r[19](
          /*min_height*/
          r[2]
        )
      ), Pt(
        e,
        "max-height",
        /*get_dimension*/
        r[19](
          /*max_height*/
          r[3]
        )
      ), Pt(e, "width", typeof /*width*/
      r[4] == "number" ? `calc(min(${/*width*/
      r[4]}px, 100%))` : (
        /*get_dimension*/
        r[19](
          /*width*/
          r[4]
        )
      )), Pt(
        e,
        "border-style",
        /*variant*/
        r[7]
      ), Pt(
        e,
        "overflow",
        /*allow_overflow*/
        r[14] ? (
          /*overflow_behavior*/
          r[15]
        ) : "hidden"
      ), Pt(
        e,
        "flex-grow",
        /*scale*/
        r[16]
      ), Pt(e, "min-width", `calc(min(${/*min_width*/
      r[17]}px, 100%))`), Pt(e, "border-width", "var(--block-border-width)");
    },
    m(s, u) {
      k7(s, e, u), i && i.m(e, null), n = !0;
    },
    p(s, u) {
      i && i.p && (!n || u & /*$$scope*/
      2097152) && S7(
        i,
        a,
        s,
        /*$$scope*/
        s[21],
        n ? b7(
          a,
          /*$$scope*/
          s[21],
          u,
          null
        ) : v7(
          /*$$scope*/
          s[21]
        ),
        null
      ), i2(
        /*tag*/
        s[18]
      )(e, o = y7(l, [
        (!n || u & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          s[10]
        ) },
        (!n || u & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          s[5]
        ) },
        (!n || u & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        s[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), an(
        e,
        "hidden",
        /*visible*/
        s[13] === !1
      ), an(
        e,
        "padded",
        /*padding*/
        s[9]
      ), an(
        e,
        "flex",
        /*flex*/
        s[0]
      ), an(
        e,
        "border_focus",
        /*border_mode*/
        s[8] === "focus"
      ), an(
        e,
        "border_contrast",
        /*border_mode*/
        s[8] === "contrast"
      ), an(e, "hide-container", !/*explicit_call*/
      s[11] && !/*container*/
      s[12]), u & /*height*/
      2 && Pt(
        e,
        "height",
        /*get_dimension*/
        s[19](
          /*height*/
          s[1]
        )
      ), u & /*min_height*/
      4 && Pt(
        e,
        "min-height",
        /*get_dimension*/
        s[19](
          /*min_height*/
          s[2]
        )
      ), u & /*max_height*/
      8 && Pt(
        e,
        "max-height",
        /*get_dimension*/
        s[19](
          /*max_height*/
          s[3]
        )
      ), u & /*width*/
      16 && Pt(e, "width", typeof /*width*/
      s[4] == "number" ? `calc(min(${/*width*/
      s[4]}px, 100%))` : (
        /*get_dimension*/
        s[19](
          /*width*/
          s[4]
        )
      )), u & /*variant*/
      128 && Pt(
        e,
        "border-style",
        /*variant*/
        s[7]
      ), u & /*allow_overflow, overflow_behavior*/
      49152 && Pt(
        e,
        "overflow",
        /*allow_overflow*/
        s[14] ? (
          /*overflow_behavior*/
          s[15]
        ) : "hidden"
      ), u & /*scale*/
      65536 && Pt(
        e,
        "flex-grow",
        /*scale*/
        s[16]
      ), u & /*min_width*/
      131072 && Pt(e, "min-width", `calc(min(${/*min_width*/
      s[17]}px, 100%))`);
    },
    i(s) {
      n || (t6(i, s), n = !0);
    },
    o(s) {
      n6(i, s), n = !1;
    },
    d(s) {
      s && a2(e), i && i.d(s);
    }
  };
}
function A7(r) {
  let e, t = (
    /*tag*/
    r[18] && E7(r)
  );
  return {
    c() {
      t && t.c();
    },
    l(n) {
      t && t.l(n);
    },
    m(n, a) {
      t && t.m(n, a), e = !0;
    },
    p(n, [a]) {
      /*tag*/
      n[18] && t.p(n, a);
    },
    i(n) {
      e || (t6(t, n), e = !0);
    },
    o(n) {
      n6(t, n), e = !1;
    },
    d(n) {
      t && t.d(n);
    }
  };
}
function F7(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: d = "solid" } = e, { border_mode: h = "base" } = e, { padding: _ = !0 } = e, { type: g = "normal" } = e, { test_id: b = void 0 } = e, { explicit_call: y = !1 } = e, { container: D = !0 } = e, { visible: k = !0 } = e, { allow_overflow: p = !0 } = e, { overflow_behavior: S = "auto" } = e, { scale: E = null } = e, { min_width: F = 0 } = e, { flex: $ = !1 } = e;
  k || ($ = !1);
  let B = g === "fieldset" ? "fieldset" : "div";
  const T = (x) => {
    if (x !== void 0) {
      if (typeof x == "number")
        return x + "px";
      if (typeof x == "string")
        return x;
    }
  };
  return r.$$set = (x) => {
    "height" in x && t(1, i = x.height), "min_height" in x && t(2, l = x.min_height), "max_height" in x && t(3, o = x.max_height), "width" in x && t(4, s = x.width), "elem_id" in x && t(5, u = x.elem_id), "elem_classes" in x && t(6, c = x.elem_classes), "variant" in x && t(7, d = x.variant), "border_mode" in x && t(8, h = x.border_mode), "padding" in x && t(9, _ = x.padding), "type" in x && t(20, g = x.type), "test_id" in x && t(10, b = x.test_id), "explicit_call" in x && t(11, y = x.explicit_call), "container" in x && t(12, D = x.container), "visible" in x && t(13, k = x.visible), "allow_overflow" in x && t(14, p = x.allow_overflow), "overflow_behavior" in x && t(15, S = x.overflow_behavior), "scale" in x && t(16, E = x.scale), "min_width" in x && t(17, F = x.min_width), "flex" in x && t(0, $ = x.flex), "$$scope" in x && t(21, a = x.$$scope);
  }, [
    $,
    i,
    l,
    o,
    s,
    u,
    c,
    d,
    h,
    _,
    b,
    y,
    D,
    k,
    p,
    S,
    E,
    F,
    B,
    T,
    g,
    a,
    n
  ];
}
class r6 extends d7 {
  constructor(e) {
    super(), w7(this, e, F7, A7, D7, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
const C7 = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], l2 = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
C7.reduce(
  (r, { color: e, primary: t, secondary: n }) => ({
    ...r,
    [e]: {
      primary: l2[e][t],
      secondary: l2[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: jy,
  append_hydration: Uy,
  attr: Gy,
  children: Wy,
  claim_svg_element: Zy,
  detach: Yy,
  init: Xy,
  insert_hydration: Ky,
  noop: Jy,
  safe_not_equal: ew,
  svg_element: tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: nw,
  append_hydration: rw,
  attr: aw,
  children: iw,
  claim_svg_element: lw,
  detach: ow,
  init: sw,
  insert_hydration: uw,
  noop: cw,
  safe_not_equal: hw,
  svg_element: dw
} = window.__gradio__svelte__internal, {
  SvelteComponent: fw,
  append_hydration: mw,
  attr: _w,
  children: pw,
  claim_svg_element: gw,
  detach: vw,
  init: bw,
  insert_hydration: yw,
  noop: ww,
  safe_not_equal: kw,
  svg_element: Dw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sw,
  append_hydration: Ew,
  attr: Aw,
  children: Fw,
  claim_svg_element: Cw,
  detach: xw,
  init: Tw,
  insert_hydration: $w,
  noop: Qw,
  safe_not_equal: Mw,
  svg_element: Bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: zw,
  append_hydration: Iw,
  attr: Lw,
  children: qw,
  claim_svg_element: Nw,
  detach: Rw,
  init: Ow,
  insert_hydration: Pw,
  noop: Hw,
  safe_not_equal: Vw,
  svg_element: jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uw,
  append_hydration: Gw,
  attr: Ww,
  children: Zw,
  claim_svg_element: Yw,
  detach: Xw,
  init: Kw,
  insert_hydration: Jw,
  noop: ek,
  safe_not_equal: tk,
  svg_element: nk
} = window.__gradio__svelte__internal, {
  SvelteComponent: rk,
  append_hydration: ak,
  attr: ik,
  children: lk,
  claim_svg_element: ok,
  detach: sk,
  init: uk,
  insert_hydration: ck,
  noop: hk,
  safe_not_equal: dk,
  svg_element: fk
} = window.__gradio__svelte__internal, {
  SvelteComponent: mk,
  append_hydration: _k,
  attr: pk,
  children: gk,
  claim_svg_element: vk,
  detach: bk,
  init: yk,
  insert_hydration: wk,
  noop: kk,
  safe_not_equal: Dk,
  svg_element: Sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ek,
  append_hydration: Ak,
  attr: Fk,
  children: Ck,
  claim_svg_element: xk,
  detach: Tk,
  init: $k,
  insert_hydration: Qk,
  noop: Mk,
  safe_not_equal: Bk,
  svg_element: zk
} = window.__gradio__svelte__internal, {
  SvelteComponent: x7,
  append_hydration: T7,
  attr: kn,
  children: o2,
  claim_svg_element: s2,
  detach: no,
  init: $7,
  insert_hydration: Q7,
  noop: ro,
  safe_not_equal: M7,
  svg_element: u2
} = window.__gradio__svelte__internal;
function B7(r) {
  let e, t;
  return {
    c() {
      e = u2("svg"), t = u2("circle"), this.h();
    },
    l(n) {
      e = s2(n, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = o2(e);
      t = s2(a, "circle", { cx: !0, cy: !0, r: !0 }), o2(t).forEach(no), a.forEach(no), this.h();
    },
    h() {
      kn(t, "cx", "12"), kn(t, "cy", "12"), kn(t, "r", "10"), kn(e, "xmlns", "http://www.w3.org/2000/svg"), kn(e, "width", "100%"), kn(e, "height", "100%"), kn(e, "viewBox", "0 0 24 24"), kn(e, "stroke-width", "1.5"), kn(e, "stroke-linecap", "round"), kn(e, "stroke-linejoin", "round"), kn(e, "class", "feather feather-circle");
    },
    m(n, a) {
      Q7(n, e, a), T7(e, t);
    },
    p: ro,
    i: ro,
    o: ro,
    d(n) {
      n && no(e);
    }
  };
}
class L1 extends x7 {
  constructor(e) {
    super(), $7(this, e, null, B7, M7, {});
  }
}
const {
  SvelteComponent: z7,
  append_hydration: ao,
  attr: Dn,
  children: bl,
  claim_svg_element: yl,
  detach: mi,
  init: I7,
  insert_hydration: L7,
  noop: io,
  safe_not_equal: q7,
  set_style: Zn,
  svg_element: wl
} = window.__gradio__svelte__internal;
function N7(r) {
  let e, t, n, a;
  return {
    c() {
      e = wl("svg"), t = wl("g"), n = wl("path"), a = wl("path"), this.h();
    },
    l(i) {
      e = yl(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = bl(e);
      t = yl(l, "g", { transform: !0 });
      var o = bl(t);
      n = yl(o, "path", { d: !0, style: !0 }), bl(n).forEach(mi), o.forEach(mi), a = yl(l, "path", { d: !0, style: !0 }), bl(a).forEach(mi), l.forEach(mi), this.h();
    },
    h() {
      Dn(n, "d", "M18,6L6.087,17.913"), Zn(n, "fill", "none"), Zn(n, "fill-rule", "nonzero"), Zn(n, "stroke-width", "2px"), Dn(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Dn(a, "d", "M4.364,4.364L19.636,19.636"), Zn(a, "fill", "none"), Zn(a, "fill-rule", "nonzero"), Zn(a, "stroke-width", "2px"), Dn(e, "width", "100%"), Dn(e, "height", "100%"), Dn(e, "viewBox", "0 0 24 24"), Dn(e, "version", "1.1"), Dn(e, "xmlns", "http://www.w3.org/2000/svg"), Dn(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Dn(e, "xml:space", "preserve"), Dn(e, "stroke", "currentColor"), Zn(e, "fill-rule", "evenodd"), Zn(e, "clip-rule", "evenodd"), Zn(e, "stroke-linecap", "round"), Zn(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      L7(i, e, l), ao(e, t), ao(t, n), ao(e, a);
    },
    p: io,
    i: io,
    o: io,
    d(i) {
      i && mi(e);
    }
  };
}
class R7 extends z7 {
  constructor(e) {
    super(), I7(this, e, null, N7, q7, {});
  }
}
const {
  SvelteComponent: Ik,
  append_hydration: Lk,
  attr: qk,
  children: Nk,
  claim_svg_element: Rk,
  detach: Ok,
  init: Pk,
  insert_hydration: Hk,
  noop: Vk,
  safe_not_equal: jk,
  svg_element: Uk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gk,
  append_hydration: Wk,
  attr: Zk,
  children: Yk,
  claim_svg_element: Xk,
  detach: Kk,
  init: Jk,
  insert_hydration: eD,
  noop: tD,
  safe_not_equal: nD,
  svg_element: rD
} = window.__gradio__svelte__internal, {
  SvelteComponent: aD,
  append_hydration: iD,
  attr: lD,
  children: oD,
  claim_svg_element: sD,
  detach: uD,
  init: cD,
  insert_hydration: hD,
  noop: dD,
  safe_not_equal: fD,
  svg_element: mD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: pD,
  attr: gD,
  children: vD,
  claim_svg_element: bD,
  detach: yD,
  init: wD,
  insert_hydration: kD,
  noop: DD,
  safe_not_equal: SD,
  svg_element: ED
} = window.__gradio__svelte__internal, {
  SvelteComponent: AD,
  append_hydration: FD,
  attr: CD,
  children: xD,
  claim_svg_element: TD,
  detach: $D,
  init: QD,
  insert_hydration: MD,
  noop: BD,
  safe_not_equal: zD,
  svg_element: ID
} = window.__gradio__svelte__internal, {
  SvelteComponent: LD,
  append_hydration: qD,
  attr: ND,
  children: RD,
  claim_svg_element: OD,
  detach: PD,
  init: HD,
  insert_hydration: VD,
  noop: jD,
  safe_not_equal: UD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: O7,
  append_hydration: P7,
  attr: qa,
  children: c2,
  claim_svg_element: h2,
  detach: lo,
  init: H7,
  insert_hydration: V7,
  noop: oo,
  safe_not_equal: j7,
  svg_element: d2
} = window.__gradio__svelte__internal;
function U7(r) {
  let e, t;
  return {
    c() {
      e = d2("svg"), t = d2("path"), this.h();
    },
    l(n) {
      e = h2(n, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var a = c2(e);
      t = h2(a, "path", { d: !0 }), c2(t).forEach(lo), a.forEach(lo), this.h();
    },
    h() {
      qa(t, "d", "M5 8l4 4 4-4z"), qa(e, "class", "dropdown-arrow svelte-145leq6"), qa(e, "xmlns", "http://www.w3.org/2000/svg"), qa(e, "width", "100%"), qa(e, "height", "100%"), qa(e, "viewBox", "0 0 18 18");
    },
    m(n, a) {
      V7(n, e, a), P7(e, t);
    },
    p: oo,
    i: oo,
    o: oo,
    d(n) {
      n && lo(e);
    }
  };
}
class q1 extends O7 {
  constructor(e) {
    super(), H7(this, e, null, U7, j7, {});
  }
}
const {
  SvelteComponent: WD,
  append_hydration: ZD,
  attr: YD,
  children: XD,
  claim_svg_element: KD,
  detach: JD,
  init: eS,
  insert_hydration: tS,
  noop: nS,
  safe_not_equal: rS,
  svg_element: aS
} = window.__gradio__svelte__internal, {
  SvelteComponent: iS,
  append_hydration: lS,
  attr: oS,
  children: sS,
  claim_svg_element: uS,
  detach: cS,
  init: hS,
  insert_hydration: dS,
  noop: fS,
  safe_not_equal: mS,
  svg_element: _S
} = window.__gradio__svelte__internal, {
  SvelteComponent: pS,
  append_hydration: gS,
  attr: vS,
  children: bS,
  claim_svg_element: yS,
  detach: wS,
  init: kS,
  insert_hydration: DS,
  noop: SS,
  safe_not_equal: ES,
  svg_element: AS
} = window.__gradio__svelte__internal, {
  SvelteComponent: FS,
  append_hydration: CS,
  attr: xS,
  children: TS,
  claim_svg_element: $S,
  detach: QS,
  init: MS,
  insert_hydration: BS,
  noop: zS,
  safe_not_equal: IS,
  svg_element: LS
} = window.__gradio__svelte__internal, {
  SvelteComponent: qS,
  append_hydration: NS,
  attr: RS,
  children: OS,
  claim_svg_element: PS,
  detach: HS,
  init: VS,
  insert_hydration: jS,
  noop: US,
  safe_not_equal: GS,
  svg_element: WS
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZS,
  append_hydration: YS,
  attr: XS,
  children: KS,
  claim_svg_element: JS,
  detach: eE,
  init: tE,
  insert_hydration: nE,
  noop: rE,
  safe_not_equal: aE,
  svg_element: iE
} = window.__gradio__svelte__internal, {
  SvelteComponent: lE,
  append_hydration: oE,
  attr: sE,
  children: uE,
  claim_svg_element: cE,
  detach: hE,
  init: dE,
  insert_hydration: fE,
  noop: mE,
  safe_not_equal: _E,
  svg_element: pE
} = window.__gradio__svelte__internal, {
  SvelteComponent: gE,
  append_hydration: vE,
  attr: bE,
  children: yE,
  claim_svg_element: wE,
  detach: kE,
  init: DE,
  insert_hydration: SE,
  noop: EE,
  safe_not_equal: AE,
  svg_element: FE
} = window.__gradio__svelte__internal, {
  SvelteComponent: CE,
  append_hydration: xE,
  attr: TE,
  children: $E,
  claim_svg_element: QE,
  detach: ME,
  init: BE,
  insert_hydration: zE,
  noop: IE,
  safe_not_equal: LE,
  svg_element: qE
} = window.__gradio__svelte__internal, {
  SvelteComponent: G7,
  append_hydration: W7,
  attr: kl,
  children: f2,
  claim_svg_element: m2,
  detach: so,
  init: Z7,
  insert_hydration: Y7,
  noop: uo,
  safe_not_equal: X7,
  svg_element: _2
} = window.__gradio__svelte__internal;
function K7(r) {
  let e, t;
  return {
    c() {
      e = _2("svg"), t = _2("path"), this.h();
    },
    l(n) {
      e = m2(n, "svg", { xmlns: !0, viewBox: !0 });
      var a = f2(e);
      t = m2(a, "path", { fill: !0, d: !0 }), f2(t).forEach(so), a.forEach(so), this.h();
    },
    h() {
      kl(t, "fill", "currentColor"), kl(t, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a4 4 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2zm2.245 2.096L16 4.25q0-.078-.005-.154M13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5M15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3zm0 11a3 3 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A3 3 0 0 1 20 23zm5-7a1 1 0 1 1 0-2 1 1 0 0 1 0 2"), kl(e, "xmlns", "http://www.w3.org/2000/svg"), kl(e, "viewBox", "0 0 24 24");
    },
    m(n, a) {
      Y7(n, e, a), W7(e, t);
    },
    p: uo,
    i: uo,
    o: uo,
    d(n) {
      n && so(e);
    }
  };
}
class J7 extends G7 {
  constructor(e) {
    super(), Z7(this, e, null, K7, X7, {});
  }
}
const {
  SvelteComponent: NE,
  append_hydration: RE,
  attr: OE,
  children: PE,
  claim_svg_element: HE,
  detach: VE,
  init: jE,
  insert_hydration: UE,
  noop: GE,
  safe_not_equal: WE,
  svg_element: ZE
} = window.__gradio__svelte__internal, {
  SvelteComponent: YE,
  append_hydration: XE,
  attr: KE,
  children: JE,
  claim_svg_element: eA,
  detach: tA,
  init: nA,
  insert_hydration: rA,
  noop: aA,
  safe_not_equal: iA,
  svg_element: lA
} = window.__gradio__svelte__internal, {
  SvelteComponent: oA,
  append_hydration: sA,
  attr: uA,
  children: cA,
  claim_svg_element: hA,
  detach: dA,
  init: fA,
  insert_hydration: mA,
  noop: _A,
  safe_not_equal: pA,
  svg_element: gA
} = window.__gradio__svelte__internal, {
  SvelteComponent: vA,
  append_hydration: bA,
  attr: yA,
  children: wA,
  claim_svg_element: kA,
  detach: DA,
  init: SA,
  insert_hydration: EA,
  noop: AA,
  safe_not_equal: FA,
  svg_element: CA
} = window.__gradio__svelte__internal, {
  SvelteComponent: e9,
  append_hydration: Dl,
  attr: St,
  children: _i,
  claim_svg_element: pi,
  detach: Na,
  init: t9,
  insert_hydration: n9,
  noop: co,
  safe_not_equal: r9,
  svg_element: gi
} = window.__gradio__svelte__internal;
function a9(r) {
  let e, t, n, a, i;
  return {
    c() {
      e = gi("svg"), t = gi("path"), n = gi("path"), a = gi("line"), i = gi("line"), this.h();
    },
    l(l) {
      e = pi(l, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = _i(e);
      t = pi(o, "path", { d: !0 }), _i(t).forEach(Na), n = pi(o, "path", { d: !0 }), _i(n).forEach(Na), a = pi(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), _i(a).forEach(Na), i = pi(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), _i(i).forEach(Na), o.forEach(Na), this.h();
    },
    h() {
      St(t, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), St(n, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), St(a, "x1", "12"), St(a, "y1", "19"), St(a, "x2", "12"), St(a, "y2", "23"), St(i, "x1", "8"), St(i, "y1", "23"), St(i, "x2", "16"), St(i, "y2", "23"), St(e, "xmlns", "http://www.w3.org/2000/svg"), St(e, "width", "100%"), St(e, "height", "100%"), St(e, "viewBox", "0 0 24 24"), St(e, "fill", "none"), St(e, "stroke", "currentColor"), St(e, "stroke-width", "2"), St(e, "stroke-linecap", "round"), St(e, "stroke-linejoin", "round"), St(e, "class", "feather feather-mic");
    },
    m(l, o) {
      n9(l, e, o), Dl(e, t), Dl(e, n), Dl(e, a), Dl(e, i);
    },
    p: co,
    i: co,
    o: co,
    d(l) {
      l && Na(e);
    }
  };
}
class h1 extends e9 {
  constructor(e) {
    super(), t9(this, e, null, a9, r9, {});
  }
}
const {
  SvelteComponent: xA,
  append_hydration: TA,
  attr: $A,
  children: QA,
  claim_svg_element: MA,
  detach: BA,
  init: zA,
  insert_hydration: IA,
  noop: LA,
  safe_not_equal: qA,
  svg_element: NA
} = window.__gradio__svelte__internal, {
  SvelteComponent: i9,
  append_hydration: ho,
  attr: Ht,
  children: Sl,
  claim_svg_element: El,
  detach: vi,
  init: l9,
  insert_hydration: o9,
  noop: fo,
  safe_not_equal: s9,
  svg_element: Al
} = window.__gradio__svelte__internal;
function u9(r) {
  let e, t, n, a;
  return {
    c() {
      e = Al("svg"), t = Al("path"), n = Al("circle"), a = Al("circle"), this.h();
    },
    l(i) {
      e = El(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = Sl(e);
      t = El(l, "path", { d: !0 }), Sl(t).forEach(vi), n = El(l, "circle", { cx: !0, cy: !0, r: !0 }), Sl(n).forEach(vi), a = El(l, "circle", { cx: !0, cy: !0, r: !0 }), Sl(a).forEach(vi), l.forEach(vi), this.h();
    },
    h() {
      Ht(t, "d", "M9 18V5l12-2v13"), Ht(n, "cx", "6"), Ht(n, "cy", "18"), Ht(n, "r", "3"), Ht(a, "cx", "18"), Ht(a, "cy", "16"), Ht(a, "r", "3"), Ht(e, "xmlns", "http://www.w3.org/2000/svg"), Ht(e, "width", "100%"), Ht(e, "height", "100%"), Ht(e, "viewBox", "0 0 24 24"), Ht(e, "fill", "none"), Ht(e, "stroke", "currentColor"), Ht(e, "stroke-width", "1.5"), Ht(e, "stroke-linecap", "round"), Ht(e, "stroke-linejoin", "round"), Ht(e, "class", "feather feather-music");
    },
    m(i, l) {
      o9(i, e, l), ho(e, t), ho(e, n), ho(e, a);
    },
    p: fo,
    i: fo,
    o: fo,
    d(i) {
      i && vi(e);
    }
  };
}
class i5 extends i9 {
  constructor(e) {
    super(), l9(this, e, null, u9, s9, {});
  }
}
const {
  SvelteComponent: RA,
  append_hydration: OA,
  attr: PA,
  children: HA,
  claim_svg_element: VA,
  detach: jA,
  init: UA,
  insert_hydration: GA,
  noop: WA,
  safe_not_equal: ZA,
  svg_element: YA
} = window.__gradio__svelte__internal, {
  SvelteComponent: XA,
  append_hydration: KA,
  attr: JA,
  children: eF,
  claim_svg_element: tF,
  detach: nF,
  init: rF,
  insert_hydration: aF,
  noop: iF,
  safe_not_equal: lF,
  svg_element: oF
} = window.__gradio__svelte__internal, {
  SvelteComponent: sF,
  append_hydration: uF,
  attr: cF,
  children: hF,
  claim_svg_element: dF,
  detach: fF,
  init: mF,
  insert_hydration: _F,
  noop: pF,
  safe_not_equal: gF,
  svg_element: vF
} = window.__gradio__svelte__internal, {
  SvelteComponent: bF,
  append_hydration: yF,
  attr: wF,
  children: kF,
  claim_svg_element: DF,
  detach: SF,
  init: EF,
  insert_hydration: AF,
  noop: FF,
  safe_not_equal: CF,
  svg_element: xF
} = window.__gradio__svelte__internal, {
  SvelteComponent: TF,
  append_hydration: $F,
  attr: QF,
  children: MF,
  claim_svg_element: BF,
  detach: zF,
  init: IF,
  insert_hydration: LF,
  noop: qF,
  safe_not_equal: NF,
  svg_element: RF
} = window.__gradio__svelte__internal, {
  SvelteComponent: OF,
  append_hydration: PF,
  attr: HF,
  children: VF,
  claim_svg_element: jF,
  detach: UF,
  init: GF,
  insert_hydration: WF,
  noop: ZF,
  safe_not_equal: YF,
  set_style: XF,
  svg_element: KF
} = window.__gradio__svelte__internal, {
  SvelteComponent: JF,
  append_hydration: eC,
  attr: tC,
  children: nC,
  claim_svg_element: rC,
  detach: aC,
  init: iC,
  insert_hydration: lC,
  noop: oC,
  safe_not_equal: sC,
  svg_element: uC
} = window.__gradio__svelte__internal, {
  SvelteComponent: cC,
  append_hydration: hC,
  attr: dC,
  children: fC,
  claim_svg_element: mC,
  detach: _C,
  init: pC,
  insert_hydration: gC,
  noop: vC,
  safe_not_equal: bC,
  svg_element: yC
} = window.__gradio__svelte__internal, {
  SvelteComponent: wC,
  append_hydration: kC,
  attr: DC,
  children: SC,
  claim_svg_element: EC,
  detach: AC,
  init: FC,
  insert_hydration: CC,
  noop: xC,
  safe_not_equal: TC,
  svg_element: $C
} = window.__gradio__svelte__internal, {
  SvelteComponent: QC,
  append_hydration: MC,
  attr: BC,
  children: zC,
  claim_svg_element: IC,
  detach: LC,
  init: qC,
  insert_hydration: NC,
  noop: RC,
  safe_not_equal: OC,
  svg_element: PC
} = window.__gradio__svelte__internal, {
  SvelteComponent: HC,
  append_hydration: VC,
  attr: jC,
  children: UC,
  claim_svg_element: GC,
  detach: WC,
  init: ZC,
  insert_hydration: YC,
  noop: XC,
  safe_not_equal: KC,
  svg_element: JC
} = window.__gradio__svelte__internal, {
  SvelteComponent: c9,
  append_hydration: h9,
  attr: Tt,
  children: p2,
  claim_svg_element: g2,
  detach: mo,
  init: d9,
  insert_hydration: f9,
  noop: v2,
  safe_not_equal: m9,
  svg_element: b2
} = window.__gradio__svelte__internal;
function _9(r) {
  let e, t, n;
  return {
    c() {
      e = b2("svg"), t = b2("rect"), this.h();
    },
    l(a) {
      e = g2(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = p2(e);
      t = g2(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), p2(t).forEach(mo), i.forEach(mo), this.h();
    },
    h() {
      Tt(t, "x", "3"), Tt(t, "y", "3"), Tt(t, "width", "18"), Tt(t, "height", "18"), Tt(t, "rx", "2"), Tt(t, "ry", "2"), Tt(e, "xmlns", "http://www.w3.org/2000/svg"), Tt(e, "width", "100%"), Tt(e, "height", "100%"), Tt(e, "viewBox", "0 0 24 24"), Tt(
        e,
        "fill",
        /*fill*/
        r[0]
      ), Tt(e, "stroke", "currentColor"), Tt(e, "stroke-width", n = `${/*stroke_width*/
      r[1]}`), Tt(e, "stroke-linecap", "round"), Tt(e, "stroke-linejoin", "round"), Tt(e, "class", "feather feather-square");
    },
    m(a, i) {
      f9(a, e, i), h9(e, t);
    },
    p(a, [i]) {
      i & /*fill*/
      1 && Tt(
        e,
        "fill",
        /*fill*/
        a[0]
      ), i & /*stroke_width*/
      2 && n !== (n = `${/*stroke_width*/
      a[1]}`) && Tt(e, "stroke-width", n);
    },
    i: v2,
    o: v2,
    d(a) {
      a && mo(e);
    }
  };
}
function p9(r, e, t) {
  let { fill: n = "currentColor" } = e, { stroke_width: a = 1.5 } = e;
  return r.$$set = (i) => {
    "fill" in i && t(0, n = i.fill), "stroke_width" in i && t(1, a = i.stroke_width);
  }, [n, a];
}
class g9 extends c9 {
  constructor(e) {
    super(), d9(this, e, p9, _9, m9, { fill: 0, stroke_width: 1 });
  }
}
const {
  SvelteComponent: ex,
  append_hydration: tx,
  attr: nx,
  children: rx,
  claim_svg_element: ax,
  detach: ix,
  init: lx,
  insert_hydration: ox,
  noop: sx,
  safe_not_equal: ux,
  svg_element: cx
} = window.__gradio__svelte__internal, {
  SvelteComponent: hx,
  append_hydration: dx,
  attr: fx,
  children: mx,
  claim_svg_element: _x,
  detach: px,
  init: gx,
  insert_hydration: vx,
  noop: bx,
  safe_not_equal: yx,
  svg_element: wx
} = window.__gradio__svelte__internal, {
  SvelteComponent: kx,
  append_hydration: Dx,
  attr: Sx,
  children: Ex,
  claim_svg_element: Ax,
  claim_text: Fx,
  detach: Cx,
  init: xx,
  insert_hydration: Tx,
  noop: $x,
  safe_not_equal: Qx,
  svg_element: Mx,
  text: Bx
} = window.__gradio__svelte__internal, {
  SvelteComponent: zx,
  append_hydration: Ix,
  attr: Lx,
  children: qx,
  claim_svg_element: Nx,
  detach: Rx,
  init: Ox,
  insert_hydration: Px,
  noop: Hx,
  safe_not_equal: Vx,
  svg_element: jx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ux,
  append_hydration: Gx,
  attr: Wx,
  children: Zx,
  claim_svg_element: Yx,
  detach: Xx,
  init: Kx,
  insert_hydration: Jx,
  noop: eT,
  safe_not_equal: tT,
  svg_element: nT
} = window.__gradio__svelte__internal, {
  SvelteComponent: rT,
  append_hydration: aT,
  attr: iT,
  children: lT,
  claim_svg_element: oT,
  detach: sT,
  init: uT,
  insert_hydration: cT,
  noop: hT,
  safe_not_equal: dT,
  svg_element: fT
} = window.__gradio__svelte__internal, {
  SvelteComponent: v9,
  append_hydration: _o,
  attr: n0,
  children: Fl,
  claim_svg_element: Cl,
  detach: bi,
  init: b9,
  insert_hydration: y9,
  noop: po,
  safe_not_equal: w9,
  svg_element: xl
} = window.__gradio__svelte__internal;
function k9(r) {
  let e, t, n, a;
  return {
    c() {
      e = xl("svg"), t = xl("path"), n = xl("polyline"), a = xl("line"), this.h();
    },
    l(i) {
      e = Cl(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = Fl(e);
      t = Cl(l, "path", { d: !0 }), Fl(t).forEach(bi), n = Cl(l, "polyline", { points: !0 }), Fl(n).forEach(bi), a = Cl(l, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Fl(a).forEach(bi), l.forEach(bi), this.h();
    },
    h() {
      n0(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), n0(n, "points", "17 8 12 3 7 8"), n0(a, "x1", "12"), n0(a, "y1", "3"), n0(a, "x2", "12"), n0(a, "y2", "15"), n0(e, "xmlns", "http://www.w3.org/2000/svg"), n0(e, "width", "90%"), n0(e, "height", "90%"), n0(e, "viewBox", "0 0 24 24"), n0(e, "fill", "none"), n0(e, "stroke", "currentColor"), n0(e, "stroke-width", "2"), n0(e, "stroke-linecap", "round"), n0(e, "stroke-linejoin", "round"), n0(e, "class", "feather feather-upload");
    },
    m(i, l) {
      y9(i, e, l), _o(e, t), _o(e, n), _o(e, a);
    },
    p: po,
    i: po,
    o: po,
    d(i) {
      i && bi(e);
    }
  };
}
class D9 extends v9 {
  constructor(e) {
    super(), b9(this, e, null, k9, w9, {});
  }
}
const {
  SvelteComponent: S9,
  append_hydration: y2,
  attr: Vt,
  children: go,
  claim_svg_element: vo,
  detach: Tl,
  init: E9,
  insert_hydration: A9,
  noop: bo,
  safe_not_equal: F9,
  svg_element: yo
} = window.__gradio__svelte__internal;
function C9(r) {
  let e, t, n;
  return {
    c() {
      e = yo("svg"), t = yo("polygon"), n = yo("rect"), this.h();
    },
    l(a) {
      e = vo(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = go(e);
      t = vo(i, "polygon", { points: !0 }), go(t).forEach(Tl), n = vo(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), go(n).forEach(Tl), i.forEach(Tl), this.h();
    },
    h() {
      Vt(t, "points", "23 7 16 12 23 17 23 7"), Vt(n, "x", "1"), Vt(n, "y", "5"), Vt(n, "width", "15"), Vt(n, "height", "14"), Vt(n, "rx", "2"), Vt(n, "ry", "2"), Vt(e, "xmlns", "http://www.w3.org/2000/svg"), Vt(e, "width", "100%"), Vt(e, "height", "100%"), Vt(e, "viewBox", "0 0 24 24"), Vt(e, "fill", "none"), Vt(e, "stroke", "currentColor"), Vt(e, "stroke-width", "1.5"), Vt(e, "stroke-linecap", "round"), Vt(e, "stroke-linejoin", "round"), Vt(e, "class", "feather feather-video");
    },
    m(a, i) {
      A9(a, e, i), y2(e, t), y2(e, n);
    },
    p: bo,
    i: bo,
    o: bo,
    d(a) {
      a && Tl(e);
    }
  };
}
class l5 extends S9 {
  constructor(e) {
    super(), E9(this, e, null, C9, F9, {});
  }
}
const {
  SvelteComponent: mT,
  append_hydration: _T,
  attr: pT,
  children: gT,
  claim_svg_element: vT,
  claim_text: bT,
  detach: yT,
  init: wT,
  insert_hydration: kT,
  noop: DT,
  safe_not_equal: ST,
  svg_element: ET,
  text: AT
} = window.__gradio__svelte__internal, {
  SvelteComponent: x9,
  append_hydration: yi,
  attr: $t,
  children: wi,
  claim_svg_element: ki,
  claim_text: T9,
  detach: Ra,
  init: $9,
  insert_hydration: Q9,
  noop: wo,
  safe_not_equal: M9,
  svg_element: Di,
  text: B9
} = window.__gradio__svelte__internal;
function z9(r) {
  let e, t, n, a, i, l;
  return {
    c() {
      e = Di("svg"), t = Di("title"), n = B9("High volume"), a = Di("path"), i = Di("path"), l = Di("path"), this.h();
    },
    l(o) {
      e = ki(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        stroke: !0,
        xmlns: !0,
        color: !0
      });
      var s = wi(e);
      t = ki(s, "title", {});
      var u = wi(t);
      n = T9(u, "High volume"), u.forEach(Ra), a = ki(s, "path", { d: !0, "stroke-width": !0 }), wi(a).forEach(Ra), i = ki(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), wi(i).forEach(Ra), l = ki(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), wi(l).forEach(Ra), s.forEach(Ra), this.h();
    },
    h() {
      $t(a, "d", "M1 13.8571V10.1429C1 9.03829 1.89543 8.14286 3 8.14286H5.9C6.09569 8.14286 6.28708 8.08544 6.45046 7.97772L12.4495 4.02228C13.1144 3.5839 14 4.06075 14 4.85714V19.1429C14 19.9392 13.1144 20.4161 12.4495 19.9777L6.45046 16.0223C6.28708 15.9146 6.09569 15.8571 5.9 15.8571H3C1.89543 15.8571 1 14.9617 1 13.8571Z"), $t(a, "stroke-width", "1.5"), $t(i, "d", "M17.5 7.5C17.5 7.5 19 9 19 11.5C19 14 17.5 15.5 17.5 15.5"), $t(i, "stroke-width", "1.5"), $t(i, "stroke-linecap", "round"), $t(i, "stroke-linejoin", "round"), $t(l, "d", "M20.5 4.5C20.5 4.5 23 7 23 11.5C23 16 20.5 18.5 20.5 18.5"), $t(l, "stroke-width", "1.5"), $t(l, "stroke-linecap", "round"), $t(l, "stroke-linejoin", "round"), $t(e, "width", "100%"), $t(e, "height", "100%"), $t(e, "viewBox", "0 0 24 24"), $t(e, "stroke-width", "1.5"), $t(e, "fill", "none"), $t(e, "stroke", "currentColor"), $t(e, "xmlns", "http://www.w3.org/2000/svg"), $t(e, "color", "currentColor");
    },
    m(o, s) {
      Q9(o, e, s), yi(e, t), yi(t, n), yi(e, a), yi(e, i), yi(e, l);
    },
    p: wo,
    i: wo,
    o: wo,
    d(o) {
      o && Ra(e);
    }
  };
}
class I9 extends x9 {
  constructor(e) {
    super(), $9(this, e, null, z9, M9, {});
  }
}
const {
  SvelteComponent: L9,
  append_hydration: Lr,
  attr: Ft,
  children: qr,
  claim_svg_element: Nr,
  claim_text: q9,
  detach: gr,
  init: N9,
  insert_hydration: R9,
  noop: ko,
  safe_not_equal: O9,
  svg_element: Rr,
  text: P9
} = window.__gradio__svelte__internal;
function H9(r) {
  let e, t, n, a, i, l, o, s, u;
  return {
    c() {
      e = Rr("svg"), t = Rr("title"), n = P9("Muted volume"), a = Rr("g"), i = Rr("path"), l = Rr("path"), o = Rr("defs"), s = Rr("clipPath"), u = Rr("rect"), this.h();
    },
    l(c) {
      e = Nr(c, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        xmlns: !0,
        stroke: !0,
        color: !0
      });
      var d = qr(e);
      t = Nr(d, "title", {});
      var h = qr(t);
      n = q9(h, "Muted volume"), h.forEach(gr), a = Nr(d, "g", { "clip-path": !0 });
      var _ = qr(a);
      i = Nr(_, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), qr(i).forEach(gr), l = Nr(_, "path", { d: !0, "stroke-width": !0 }), qr(l).forEach(gr), _.forEach(gr), o = Nr(d, "defs", {});
      var g = qr(o);
      s = Nr(g, "clipPath", { id: !0 });
      var b = qr(s);
      u = Nr(b, "rect", { width: !0, height: !0, fill: !0 }), qr(u).forEach(gr), b.forEach(gr), g.forEach(gr), d.forEach(gr), this.h();
    },
    h() {
      Ft(i, "d", "M18 14L20.0005 12M22 10L20.0005 12M20.0005 12L18 10M20.0005 12L22 14"), Ft(i, "stroke-width", "1.5"), Ft(i, "stroke-linecap", "round"), Ft(i, "stroke-linejoin", "round"), Ft(l, "d", "M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z"), Ft(l, "stroke-width", "1.5"), Ft(a, "clip-path", "url(#clip0_3173_16686)"), Ft(u, "width", "24"), Ft(u, "height", "24"), Ft(u, "fill", "white"), Ft(s, "id", "clip0_3173_16686"), Ft(e, "width", "100%"), Ft(e, "height", "100%"), Ft(e, "viewBox", "0 0 24 24"), Ft(e, "stroke-width", "1.5"), Ft(e, "fill", "none"), Ft(e, "xmlns", "http://www.w3.org/2000/svg"), Ft(e, "stroke", "currentColor"), Ft(e, "color", "currentColor");
    },
    m(c, d) {
      R9(c, e, d), Lr(e, t), Lr(t, n), Lr(e, a), Lr(a, i), Lr(a, l), Lr(e, o), Lr(o, s), Lr(s, u);
    },
    p: ko,
    i: ko,
    o: ko,
    d(c) {
      c && gr(e);
    }
  };
}
class V9 extends L9 {
  constructor(e) {
    super(), N9(this, e, null, H9, O9, {});
  }
}
const {
  SvelteComponent: FT,
  append_hydration: CT,
  attr: xT,
  children: TT,
  claim_svg_element: $T,
  detach: QT,
  init: MT,
  insert_hydration: BT,
  noop: zT,
  safe_not_equal: IT,
  svg_element: LT
} = window.__gradio__svelte__internal, {
  SvelteComponent: j9,
  append_hydration: w2,
  attr: Or,
  children: Do,
  claim_svg_element: So,
  detach: $l,
  init: U9,
  insert_hydration: G9,
  noop: Eo,
  safe_not_equal: W9,
  svg_element: Ao
} = window.__gradio__svelte__internal;
function Z9(r) {
  let e, t, n;
  return {
    c() {
      e = Ao("svg"), t = Ao("path"), n = Ao("path"), this.h();
    },
    l(a) {
      e = So(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = Do(e);
      t = So(i, "path", { fill: !0, d: !0 }), Do(t).forEach($l), n = So(i, "path", { fill: !0, d: !0 }), Do(n).forEach($l), i.forEach($l), this.h();
    },
    h() {
      Or(t, "fill", "currentColor"), Or(t, "d", "M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"), Or(n, "fill", "currentColor"), Or(n, "d", "M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"), Or(e, "xmlns", "http://www.w3.org/2000/svg"), Or(e, "width", "100%"), Or(e, "height", "100%"), Or(e, "viewBox", "0 0 24 24");
    },
    m(a, i) {
      G9(a, e, i), w2(e, t), w2(e, n);
    },
    p: Eo,
    i: Eo,
    o: Eo,
    d(a) {
      a && $l(e);
    }
  };
}
let k2 = class extends j9 {
  constructor(e) {
    super(), U9(this, e, null, Z9, W9, {});
  }
};
const {
  SvelteComponent: Y9,
  append_hydration: D2,
  attr: Qt,
  children: Fo,
  claim_svg_element: Co,
  detach: Ql,
  init: X9,
  insert_hydration: K9,
  noop: xo,
  safe_not_equal: J9,
  svg_element: To
} = window.__gradio__svelte__internal;
function e8(r) {
  let e, t, n;
  return {
    c() {
      e = To("svg"), t = To("circle"), n = To("animateTransform"), this.h();
    },
    l(a) {
      e = Co(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        class: !0
      });
      var i = Fo(e);
      t = Co(i, "circle", {
        cx: !0,
        cy: !0,
        r: !0,
        fill: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-dasharray": !0,
        "stroke-dashoffset": !0
      });
      var l = Fo(t);
      n = Co(l, "animateTransform", {
        attributeName: !0,
        type: !0,
        from: !0,
        to: !0,
        repeatCount: !0
      }), Fo(n).forEach(Ql), l.forEach(Ql), i.forEach(Ql), this.h();
    },
    h() {
      Qt(n, "attributeName", "transform"), Qt(n, "type", "rotate"), Qt(n, "from", "0 25 25"), Qt(n, "to", "360 25 25"), Qt(n, "repeatCount", "indefinite"), Qt(t, "cx", "25"), Qt(t, "cy", "25"), Qt(t, "r", "20"), Qt(t, "fill", "none"), Qt(t, "stroke-width", "3.0"), Qt(t, "stroke-linecap", "round"), Qt(t, "stroke-dasharray", "94.2477796076938 94.2477796076938"), Qt(t, "stroke-dashoffset", "0"), Qt(e, "xmlns", "http://www.w3.org/2000/svg"), Qt(e, "width", "100%"), Qt(e, "height", "100%"), Qt(e, "viewBox", "0 0 50 50"), Qt(e, "class", "svelte-pb9pol");
    },
    m(a, i) {
      K9(a, e, i), D2(e, t), D2(t, n);
    },
    p: xo,
    i: xo,
    o: xo,
    d(a) {
      a && Ql(e);
    }
  };
}
class o5 extends Y9 {
  constructor(e) {
    super(), X9(this, e, null, e8, J9, {});
  }
}
const {
  SvelteComponent: NT,
  append_hydration: RT,
  attr: OT,
  children: PT,
  claim_svg_element: HT,
  detach: VT,
  init: jT,
  insert_hydration: UT,
  noop: GT,
  safe_not_equal: WT,
  svg_element: ZT
} = window.__gradio__svelte__internal, {
  SvelteComponent: YT,
  append_hydration: XT,
  attr: KT,
  children: JT,
  claim_svg_element: e$,
  detach: t$,
  init: n$,
  insert_hydration: r$,
  noop: a$,
  safe_not_equal: i$,
  svg_element: l$
} = window.__gradio__svelte__internal;
class s5 {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, n) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = n;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new s5(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class u5 {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new u5(t, s5.range(this, e));
  }
}
class re {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var n = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var o = l.lexer.input;
      a = l.start, i = l.end, a === o.length ? n += " at end of input: " : n += " at position " + (a + 1) + ": ";
      var s = o.slice(a, i).replace(/[^]/g, "$&̲"), u;
      a > 15 ? u = "…" + o.slice(a - 15, a) : u = o.slice(0, a);
      var c;
      i + 15 < o.length ? c = o.slice(i, i + 15) + "…" : c = o.slice(i), n += u + s + c;
    }
    var d = new Error(n);
    return d.name = "ParseError", d.__proto__ = re.prototype, d.position = a, a != null && i != null && (d.length = i - a), d.rawMessage = e, d;
  }
}
re.prototype.__proto__ = Error.prototype;
var t8 = function(e, t) {
  return e.indexOf(t) !== -1;
}, n8 = function(e, t) {
  return e === void 0 ? t : e;
}, r8 = /([A-Z])/g, a8 = function(e) {
  return e.replace(r8, "-$1").toLowerCase();
}, i8 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, l8 = /[&><"']/g;
function o8(r) {
  return String(r).replace(l8, (e) => i8[e]);
}
var a6 = function r(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? r(e.body[0]) : e : e.type === "font" ? r(e.body) : e;
}, s8 = function(e) {
  var t = a6(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, u8 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, c8 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, ue = {
  contains: t8,
  deflt: n8,
  escape: o8,
  hyphenate: a8,
  getBaseElem: a6,
  isCharacterBox: s8,
  protocolFromUrl: c8
};
class Pr {
  constructor(e, t, n) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = n;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return tr[h8[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return tr[d8[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return tr[f8[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return tr[m8[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return tr[_8[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return tr[p8[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var c5 = 0, d1 = 1, ei = 2, Ar = 3, ji = 4, hn = 5, ri = 6, x0 = 7, tr = [new Pr(c5, 0, !1), new Pr(d1, 0, !0), new Pr(ei, 1, !1), new Pr(Ar, 1, !0), new Pr(ji, 2, !1), new Pr(hn, 2, !0), new Pr(ri, 3, !1), new Pr(x0, 3, !0)], h8 = [ji, hn, ji, hn, ri, x0, ri, x0], d8 = [hn, hn, hn, hn, x0, x0, x0, x0], f8 = [ei, Ar, ji, hn, ri, x0, ri, x0], m8 = [Ar, Ar, hn, hn, x0, x0, x0, x0], _8 = [d1, d1, Ar, Ar, hn, hn, x0, x0], p8 = [c5, d1, ei, Ar, ei, Ar, ei, Ar], ce = {
  DISPLAY: tr[c5],
  TEXT: tr[ei],
  SCRIPT: tr[ji],
  SCRIPTSCRIPT: tr[ri]
}, $s = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function g8(r) {
  for (var e = 0; e < $s.length; e++)
    for (var t = $s[e], n = 0; n < t.blocks.length; n++) {
      var a = t.blocks[n];
      if (r >= a[0] && r <= a[1])
        return t.name;
    }
  return null;
}
var o1 = [];
$s.forEach((r) => r.blocks.forEach((e) => o1.push(...e)));
function v8(r) {
  for (var e = 0; e < o1.length; e += 2)
    if (r >= o1[e] && r <= o1[e + 1])
      return !0;
  return !1;
}
var Oa = 80, b8 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, y8 = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, w8 = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, k8 = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, D8 = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, S8 = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, E8 = function(e, t, n) {
  var a = n - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, A8 = function(e, t, n) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = b8(t, Oa);
      break;
    case "sqrtSize1":
      a = y8(t, Oa);
      break;
    case "sqrtSize2":
      a = w8(t, Oa);
      break;
    case "sqrtSize3":
      a = k8(t, Oa);
      break;
    case "sqrtSize4":
      a = D8(t, Oa);
      break;
    case "sqrtTall":
      a = E8(t, Oa, n);
  }
  return a;
}, F8 = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, S2 = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, C8 = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class el {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return ue.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var Er = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, E2 = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function h5(r, e, t) {
  if (!Er[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var n = r.charCodeAt(0), a = Er[e][n];
  if (!a && r[0] in E2 && (n = E2[r[0]].charCodeAt(0), a = Er[e][n]), !a && t === "text" && v8(n) && (a = Er[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var Qs = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, x8 = {
  ex: !0,
  em: !0,
  mu: !0
}, T8 = function(e) {
  return typeof e != "string" && (e = e.unit), e in Qs || e in x8 || e === "ex";
}, dt = function(e, t) {
  var n;
  if (e.unit in Qs)
    n = Qs[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    n = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      n = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      n = a.fontMetrics().quad;
    else
      throw new re("Invalid unit: '" + e.unit + "'");
    a !== t && (n *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * n, t.maxSize);
}, W = function(e) {
  return +e.toFixed(4) + "em";
}, ea = function(e) {
  return e.filter((t) => t).join(" ");
}, i6 = function(e, t, n) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, l6 = function(e) {
  var t = document.createElement(e);
  t.className = ea(this.classes);
  for (var n in this.style)
    this.style.hasOwnProperty(n) && (t.style[n] = this.style[n]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, $8 = /[\s"'>/=\x00-\x1f]/, o6 = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + ue.escape(ea(this.classes)) + '"');
  var n = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (n += ue.hyphenate(a) + ":" + this.style[a] + ";");
  n && (t += ' style="' + ue.escape(n) + '"');
  for (var i in this.attributes)
    if (this.attributes.hasOwnProperty(i)) {
      if ($8.test(i))
        throw new re("Invalid attribute name '" + i + "'");
      t += " " + i + '="' + ue.escape(this.attributes[i]) + '"';
    }
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class N1 {
  constructor(e, t, n, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, i6.call(this, e, n, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return ue.contains(this.classes, e);
  }
  toNode() {
    return l6.call(this, "span");
  }
  toMarkup() {
    return o6.call(this, "span");
  }
}
class s6 {
  constructor(e, t, n, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, i6.call(this, t, a), this.children = n || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return ue.contains(this.classes, e);
  }
  toNode() {
    return l6.call(this, "a");
  }
  toMarkup() {
    return o6.call(this, "a");
  }
}
class Q8 {
  constructor(e, t, n) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = n;
  }
  hasClass(e) {
    return ue.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + ue.escape(this.src) + '"' + (' alt="' + ue.escape(this.alt) + '"'), t = "";
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (t += ue.hyphenate(n) + ":" + this.style[n] + ";");
    return t && (e += ' style="' + ue.escape(t) + '"'), e += "'/>", e;
  }
}
var M8 = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class dr {
  constructor(e, t, n, a, i, l, o, s) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = n || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
    var u = g8(this.text.charCodeAt(0));
    u && this.classes.push(u + "_fallback"), /[îïíì]/.test(this.text) && (this.text = M8[this.text]);
  }
  hasClass(e) {
    return ue.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = W(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = ea(this.classes));
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (t = t || document.createElement("span"), t.style[n] = this.style[n]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += ue.escape(ea(this.classes)), t += '"');
    var n = "";
    this.italic > 0 && (n += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (n += ue.hyphenate(a) + ":" + this.style[a] + ";");
    n && (e = !0, t += ' style="' + ue.escape(n) + '"');
    var i = ue.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class ta {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var n in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, n) && t.setAttribute(n, this.attributes[n]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + ue.escape(this.attributes[t]) + '"');
    e += ">";
    for (var n = 0; n < this.children.length; n++)
      e += this.children[n].toMarkup();
    return e += "</svg>", e;
  }
}
class Sa {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", S2[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + ue.escape(this.alternate) + '"/>' : '<path d="' + ue.escape(S2[this.pathName]) + '"/>';
  }
}
class A2 {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var n in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, n) && t.setAttribute(n, this.attributes[n]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + ue.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function F2(r) {
  if (r instanceof dr)
    return r;
  throw new Error("Expected symbolNode but got " + String(r) + ".");
}
function B8(r) {
  if (r instanceof N1)
    return r;
  throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
}
var z8 = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, yt = {
  math: {},
  text: {}
};
function f(r, e, t, n, a, i) {
  yt[r][a] = {
    font: e,
    group: t,
    replace: n
  }, i && n && (yt[r][n] = yt[r][a]);
}
var m = "math", O = "text", v = "main", A = "ams", lt = "accent-token", X = "bin", Q0 = "close", li = "inner", se = "mathord", At = "op-token", en = "open", R1 = "punct", C = "rel", Tr = "spacing", Q = "textord";
f(m, v, C, "≡", "\\equiv", !0);
f(m, v, C, "≺", "\\prec", !0);
f(m, v, C, "≻", "\\succ", !0);
f(m, v, C, "∼", "\\sim", !0);
f(m, v, C, "⊥", "\\perp");
f(m, v, C, "⪯", "\\preceq", !0);
f(m, v, C, "⪰", "\\succeq", !0);
f(m, v, C, "≃", "\\simeq", !0);
f(m, v, C, "∣", "\\mid", !0);
f(m, v, C, "≪", "\\ll", !0);
f(m, v, C, "≫", "\\gg", !0);
f(m, v, C, "≍", "\\asymp", !0);
f(m, v, C, "∥", "\\parallel");
f(m, v, C, "⋈", "\\bowtie", !0);
f(m, v, C, "⌣", "\\smile", !0);
f(m, v, C, "⊑", "\\sqsubseteq", !0);
f(m, v, C, "⊒", "\\sqsupseteq", !0);
f(m, v, C, "≐", "\\doteq", !0);
f(m, v, C, "⌢", "\\frown", !0);
f(m, v, C, "∋", "\\ni", !0);
f(m, v, C, "∝", "\\propto", !0);
f(m, v, C, "⊢", "\\vdash", !0);
f(m, v, C, "⊣", "\\dashv", !0);
f(m, v, C, "∋", "\\owns");
f(m, v, R1, ".", "\\ldotp");
f(m, v, R1, "⋅", "\\cdotp");
f(m, v, Q, "#", "\\#");
f(O, v, Q, "#", "\\#");
f(m, v, Q, "&", "\\&");
f(O, v, Q, "&", "\\&");
f(m, v, Q, "ℵ", "\\aleph", !0);
f(m, v, Q, "∀", "\\forall", !0);
f(m, v, Q, "ℏ", "\\hbar", !0);
f(m, v, Q, "∃", "\\exists", !0);
f(m, v, Q, "∇", "\\nabla", !0);
f(m, v, Q, "♭", "\\flat", !0);
f(m, v, Q, "ℓ", "\\ell", !0);
f(m, v, Q, "♮", "\\natural", !0);
f(m, v, Q, "♣", "\\clubsuit", !0);
f(m, v, Q, "℘", "\\wp", !0);
f(m, v, Q, "♯", "\\sharp", !0);
f(m, v, Q, "♢", "\\diamondsuit", !0);
f(m, v, Q, "ℜ", "\\Re", !0);
f(m, v, Q, "♡", "\\heartsuit", !0);
f(m, v, Q, "ℑ", "\\Im", !0);
f(m, v, Q, "♠", "\\spadesuit", !0);
f(m, v, Q, "§", "\\S", !0);
f(O, v, Q, "§", "\\S");
f(m, v, Q, "¶", "\\P", !0);
f(O, v, Q, "¶", "\\P");
f(m, v, Q, "†", "\\dag");
f(O, v, Q, "†", "\\dag");
f(O, v, Q, "†", "\\textdagger");
f(m, v, Q, "‡", "\\ddag");
f(O, v, Q, "‡", "\\ddag");
f(O, v, Q, "‡", "\\textdaggerdbl");
f(m, v, Q0, "⎱", "\\rmoustache", !0);
f(m, v, en, "⎰", "\\lmoustache", !0);
f(m, v, Q0, "⟯", "\\rgroup", !0);
f(m, v, en, "⟮", "\\lgroup", !0);
f(m, v, X, "∓", "\\mp", !0);
f(m, v, X, "⊖", "\\ominus", !0);
f(m, v, X, "⊎", "\\uplus", !0);
f(m, v, X, "⊓", "\\sqcap", !0);
f(m, v, X, "∗", "\\ast");
f(m, v, X, "⊔", "\\sqcup", !0);
f(m, v, X, "◯", "\\bigcirc", !0);
f(m, v, X, "∙", "\\bullet", !0);
f(m, v, X, "‡", "\\ddagger");
f(m, v, X, "≀", "\\wr", !0);
f(m, v, X, "⨿", "\\amalg");
f(m, v, X, "&", "\\And");
f(m, v, C, "⟵", "\\longleftarrow", !0);
f(m, v, C, "⇐", "\\Leftarrow", !0);
f(m, v, C, "⟸", "\\Longleftarrow", !0);
f(m, v, C, "⟶", "\\longrightarrow", !0);
f(m, v, C, "⇒", "\\Rightarrow", !0);
f(m, v, C, "⟹", "\\Longrightarrow", !0);
f(m, v, C, "↔", "\\leftrightarrow", !0);
f(m, v, C, "⟷", "\\longleftrightarrow", !0);
f(m, v, C, "⇔", "\\Leftrightarrow", !0);
f(m, v, C, "⟺", "\\Longleftrightarrow", !0);
f(m, v, C, "↦", "\\mapsto", !0);
f(m, v, C, "⟼", "\\longmapsto", !0);
f(m, v, C, "↗", "\\nearrow", !0);
f(m, v, C, "↩", "\\hookleftarrow", !0);
f(m, v, C, "↪", "\\hookrightarrow", !0);
f(m, v, C, "↘", "\\searrow", !0);
f(m, v, C, "↼", "\\leftharpoonup", !0);
f(m, v, C, "⇀", "\\rightharpoonup", !0);
f(m, v, C, "↙", "\\swarrow", !0);
f(m, v, C, "↽", "\\leftharpoondown", !0);
f(m, v, C, "⇁", "\\rightharpoondown", !0);
f(m, v, C, "↖", "\\nwarrow", !0);
f(m, v, C, "⇌", "\\rightleftharpoons", !0);
f(m, A, C, "≮", "\\nless", !0);
f(m, A, C, "", "\\@nleqslant");
f(m, A, C, "", "\\@nleqq");
f(m, A, C, "⪇", "\\lneq", !0);
f(m, A, C, "≨", "\\lneqq", !0);
f(m, A, C, "", "\\@lvertneqq");
f(m, A, C, "⋦", "\\lnsim", !0);
f(m, A, C, "⪉", "\\lnapprox", !0);
f(m, A, C, "⊀", "\\nprec", !0);
f(m, A, C, "⋠", "\\npreceq", !0);
f(m, A, C, "⋨", "\\precnsim", !0);
f(m, A, C, "⪹", "\\precnapprox", !0);
f(m, A, C, "≁", "\\nsim", !0);
f(m, A, C, "", "\\@nshortmid");
f(m, A, C, "∤", "\\nmid", !0);
f(m, A, C, "⊬", "\\nvdash", !0);
f(m, A, C, "⊭", "\\nvDash", !0);
f(m, A, C, "⋪", "\\ntriangleleft");
f(m, A, C, "⋬", "\\ntrianglelefteq", !0);
f(m, A, C, "⊊", "\\subsetneq", !0);
f(m, A, C, "", "\\@varsubsetneq");
f(m, A, C, "⫋", "\\subsetneqq", !0);
f(m, A, C, "", "\\@varsubsetneqq");
f(m, A, C, "≯", "\\ngtr", !0);
f(m, A, C, "", "\\@ngeqslant");
f(m, A, C, "", "\\@ngeqq");
f(m, A, C, "⪈", "\\gneq", !0);
f(m, A, C, "≩", "\\gneqq", !0);
f(m, A, C, "", "\\@gvertneqq");
f(m, A, C, "⋧", "\\gnsim", !0);
f(m, A, C, "⪊", "\\gnapprox", !0);
f(m, A, C, "⊁", "\\nsucc", !0);
f(m, A, C, "⋡", "\\nsucceq", !0);
f(m, A, C, "⋩", "\\succnsim", !0);
f(m, A, C, "⪺", "\\succnapprox", !0);
f(m, A, C, "≆", "\\ncong", !0);
f(m, A, C, "", "\\@nshortparallel");
f(m, A, C, "∦", "\\nparallel", !0);
f(m, A, C, "⊯", "\\nVDash", !0);
f(m, A, C, "⋫", "\\ntriangleright");
f(m, A, C, "⋭", "\\ntrianglerighteq", !0);
f(m, A, C, "", "\\@nsupseteqq");
f(m, A, C, "⊋", "\\supsetneq", !0);
f(m, A, C, "", "\\@varsupsetneq");
f(m, A, C, "⫌", "\\supsetneqq", !0);
f(m, A, C, "", "\\@varsupsetneqq");
f(m, A, C, "⊮", "\\nVdash", !0);
f(m, A, C, "⪵", "\\precneqq", !0);
f(m, A, C, "⪶", "\\succneqq", !0);
f(m, A, C, "", "\\@nsubseteqq");
f(m, A, X, "⊴", "\\unlhd");
f(m, A, X, "⊵", "\\unrhd");
f(m, A, C, "↚", "\\nleftarrow", !0);
f(m, A, C, "↛", "\\nrightarrow", !0);
f(m, A, C, "⇍", "\\nLeftarrow", !0);
f(m, A, C, "⇏", "\\nRightarrow", !0);
f(m, A, C, "↮", "\\nleftrightarrow", !0);
f(m, A, C, "⇎", "\\nLeftrightarrow", !0);
f(m, A, C, "△", "\\vartriangle");
f(m, A, Q, "ℏ", "\\hslash");
f(m, A, Q, "▽", "\\triangledown");
f(m, A, Q, "◊", "\\lozenge");
f(m, A, Q, "Ⓢ", "\\circledS");
f(m, A, Q, "®", "\\circledR");
f(O, A, Q, "®", "\\circledR");
f(m, A, Q, "∡", "\\measuredangle", !0);
f(m, A, Q, "∄", "\\nexists");
f(m, A, Q, "℧", "\\mho");
f(m, A, Q, "Ⅎ", "\\Finv", !0);
f(m, A, Q, "⅁", "\\Game", !0);
f(m, A, Q, "‵", "\\backprime");
f(m, A, Q, "▲", "\\blacktriangle");
f(m, A, Q, "▼", "\\blacktriangledown");
f(m, A, Q, "■", "\\blacksquare");
f(m, A, Q, "⧫", "\\blacklozenge");
f(m, A, Q, "★", "\\bigstar");
f(m, A, Q, "∢", "\\sphericalangle", !0);
f(m, A, Q, "∁", "\\complement", !0);
f(m, A, Q, "ð", "\\eth", !0);
f(O, v, Q, "ð", "ð");
f(m, A, Q, "╱", "\\diagup");
f(m, A, Q, "╲", "\\diagdown");
f(m, A, Q, "□", "\\square");
f(m, A, Q, "□", "\\Box");
f(m, A, Q, "◊", "\\Diamond");
f(m, A, Q, "¥", "\\yen", !0);
f(O, A, Q, "¥", "\\yen", !0);
f(m, A, Q, "✓", "\\checkmark", !0);
f(O, A, Q, "✓", "\\checkmark");
f(m, A, Q, "ℶ", "\\beth", !0);
f(m, A, Q, "ℸ", "\\daleth", !0);
f(m, A, Q, "ℷ", "\\gimel", !0);
f(m, A, Q, "ϝ", "\\digamma", !0);
f(m, A, Q, "ϰ", "\\varkappa");
f(m, A, en, "┌", "\\@ulcorner", !0);
f(m, A, Q0, "┐", "\\@urcorner", !0);
f(m, A, en, "└", "\\@llcorner", !0);
f(m, A, Q0, "┘", "\\@lrcorner", !0);
f(m, A, C, "≦", "\\leqq", !0);
f(m, A, C, "⩽", "\\leqslant", !0);
f(m, A, C, "⪕", "\\eqslantless", !0);
f(m, A, C, "≲", "\\lesssim", !0);
f(m, A, C, "⪅", "\\lessapprox", !0);
f(m, A, C, "≊", "\\approxeq", !0);
f(m, A, X, "⋖", "\\lessdot");
f(m, A, C, "⋘", "\\lll", !0);
f(m, A, C, "≶", "\\lessgtr", !0);
f(m, A, C, "⋚", "\\lesseqgtr", !0);
f(m, A, C, "⪋", "\\lesseqqgtr", !0);
f(m, A, C, "≑", "\\doteqdot");
f(m, A, C, "≓", "\\risingdotseq", !0);
f(m, A, C, "≒", "\\fallingdotseq", !0);
f(m, A, C, "∽", "\\backsim", !0);
f(m, A, C, "⋍", "\\backsimeq", !0);
f(m, A, C, "⫅", "\\subseteqq", !0);
f(m, A, C, "⋐", "\\Subset", !0);
f(m, A, C, "⊏", "\\sqsubset", !0);
f(m, A, C, "≼", "\\preccurlyeq", !0);
f(m, A, C, "⋞", "\\curlyeqprec", !0);
f(m, A, C, "≾", "\\precsim", !0);
f(m, A, C, "⪷", "\\precapprox", !0);
f(m, A, C, "⊲", "\\vartriangleleft");
f(m, A, C, "⊴", "\\trianglelefteq");
f(m, A, C, "⊨", "\\vDash", !0);
f(m, A, C, "⊪", "\\Vvdash", !0);
f(m, A, C, "⌣", "\\smallsmile");
f(m, A, C, "⌢", "\\smallfrown");
f(m, A, C, "≏", "\\bumpeq", !0);
f(m, A, C, "≎", "\\Bumpeq", !0);
f(m, A, C, "≧", "\\geqq", !0);
f(m, A, C, "⩾", "\\geqslant", !0);
f(m, A, C, "⪖", "\\eqslantgtr", !0);
f(m, A, C, "≳", "\\gtrsim", !0);
f(m, A, C, "⪆", "\\gtrapprox", !0);
f(m, A, X, "⋗", "\\gtrdot");
f(m, A, C, "⋙", "\\ggg", !0);
f(m, A, C, "≷", "\\gtrless", !0);
f(m, A, C, "⋛", "\\gtreqless", !0);
f(m, A, C, "⪌", "\\gtreqqless", !0);
f(m, A, C, "≖", "\\eqcirc", !0);
f(m, A, C, "≗", "\\circeq", !0);
f(m, A, C, "≜", "\\triangleq", !0);
f(m, A, C, "∼", "\\thicksim");
f(m, A, C, "≈", "\\thickapprox");
f(m, A, C, "⫆", "\\supseteqq", !0);
f(m, A, C, "⋑", "\\Supset", !0);
f(m, A, C, "⊐", "\\sqsupset", !0);
f(m, A, C, "≽", "\\succcurlyeq", !0);
f(m, A, C, "⋟", "\\curlyeqsucc", !0);
f(m, A, C, "≿", "\\succsim", !0);
f(m, A, C, "⪸", "\\succapprox", !0);
f(m, A, C, "⊳", "\\vartriangleright");
f(m, A, C, "⊵", "\\trianglerighteq");
f(m, A, C, "⊩", "\\Vdash", !0);
f(m, A, C, "∣", "\\shortmid");
f(m, A, C, "∥", "\\shortparallel");
f(m, A, C, "≬", "\\between", !0);
f(m, A, C, "⋔", "\\pitchfork", !0);
f(m, A, C, "∝", "\\varpropto");
f(m, A, C, "◀", "\\blacktriangleleft");
f(m, A, C, "∴", "\\therefore", !0);
f(m, A, C, "∍", "\\backepsilon");
f(m, A, C, "▶", "\\blacktriangleright");
f(m, A, C, "∵", "\\because", !0);
f(m, A, C, "⋘", "\\llless");
f(m, A, C, "⋙", "\\gggtr");
f(m, A, X, "⊲", "\\lhd");
f(m, A, X, "⊳", "\\rhd");
f(m, A, C, "≂", "\\eqsim", !0);
f(m, v, C, "⋈", "\\Join");
f(m, A, C, "≑", "\\Doteq", !0);
f(m, A, X, "∔", "\\dotplus", !0);
f(m, A, X, "∖", "\\smallsetminus");
f(m, A, X, "⋒", "\\Cap", !0);
f(m, A, X, "⋓", "\\Cup", !0);
f(m, A, X, "⩞", "\\doublebarwedge", !0);
f(m, A, X, "⊟", "\\boxminus", !0);
f(m, A, X, "⊞", "\\boxplus", !0);
f(m, A, X, "⋇", "\\divideontimes", !0);
f(m, A, X, "⋉", "\\ltimes", !0);
f(m, A, X, "⋊", "\\rtimes", !0);
f(m, A, X, "⋋", "\\leftthreetimes", !0);
f(m, A, X, "⋌", "\\rightthreetimes", !0);
f(m, A, X, "⋏", "\\curlywedge", !0);
f(m, A, X, "⋎", "\\curlyvee", !0);
f(m, A, X, "⊝", "\\circleddash", !0);
f(m, A, X, "⊛", "\\circledast", !0);
f(m, A, X, "⋅", "\\centerdot");
f(m, A, X, "⊺", "\\intercal", !0);
f(m, A, X, "⋒", "\\doublecap");
f(m, A, X, "⋓", "\\doublecup");
f(m, A, X, "⊠", "\\boxtimes", !0);
f(m, A, C, "⇢", "\\dashrightarrow", !0);
f(m, A, C, "⇠", "\\dashleftarrow", !0);
f(m, A, C, "⇇", "\\leftleftarrows", !0);
f(m, A, C, "⇆", "\\leftrightarrows", !0);
f(m, A, C, "⇚", "\\Lleftarrow", !0);
f(m, A, C, "↞", "\\twoheadleftarrow", !0);
f(m, A, C, "↢", "\\leftarrowtail", !0);
f(m, A, C, "↫", "\\looparrowleft", !0);
f(m, A, C, "⇋", "\\leftrightharpoons", !0);
f(m, A, C, "↶", "\\curvearrowleft", !0);
f(m, A, C, "↺", "\\circlearrowleft", !0);
f(m, A, C, "↰", "\\Lsh", !0);
f(m, A, C, "⇈", "\\upuparrows", !0);
f(m, A, C, "↿", "\\upharpoonleft", !0);
f(m, A, C, "⇃", "\\downharpoonleft", !0);
f(m, v, C, "⊶", "\\origof", !0);
f(m, v, C, "⊷", "\\imageof", !0);
f(m, A, C, "⊸", "\\multimap", !0);
f(m, A, C, "↭", "\\leftrightsquigarrow", !0);
f(m, A, C, "⇉", "\\rightrightarrows", !0);
f(m, A, C, "⇄", "\\rightleftarrows", !0);
f(m, A, C, "↠", "\\twoheadrightarrow", !0);
f(m, A, C, "↣", "\\rightarrowtail", !0);
f(m, A, C, "↬", "\\looparrowright", !0);
f(m, A, C, "↷", "\\curvearrowright", !0);
f(m, A, C, "↻", "\\circlearrowright", !0);
f(m, A, C, "↱", "\\Rsh", !0);
f(m, A, C, "⇊", "\\downdownarrows", !0);
f(m, A, C, "↾", "\\upharpoonright", !0);
f(m, A, C, "⇂", "\\downharpoonright", !0);
f(m, A, C, "⇝", "\\rightsquigarrow", !0);
f(m, A, C, "⇝", "\\leadsto");
f(m, A, C, "⇛", "\\Rrightarrow", !0);
f(m, A, C, "↾", "\\restriction");
f(m, v, Q, "‘", "`");
f(m, v, Q, "$", "\\$");
f(O, v, Q, "$", "\\$");
f(O, v, Q, "$", "\\textdollar");
f(m, v, Q, "%", "\\%");
f(O, v, Q, "%", "\\%");
f(m, v, Q, "_", "\\_");
f(O, v, Q, "_", "\\_");
f(O, v, Q, "_", "\\textunderscore");
f(m, v, Q, "∠", "\\angle", !0);
f(m, v, Q, "∞", "\\infty", !0);
f(m, v, Q, "′", "\\prime");
f(m, v, Q, "△", "\\triangle");
f(m, v, Q, "Γ", "\\Gamma", !0);
f(m, v, Q, "Δ", "\\Delta", !0);
f(m, v, Q, "Θ", "\\Theta", !0);
f(m, v, Q, "Λ", "\\Lambda", !0);
f(m, v, Q, "Ξ", "\\Xi", !0);
f(m, v, Q, "Π", "\\Pi", !0);
f(m, v, Q, "Σ", "\\Sigma", !0);
f(m, v, Q, "Υ", "\\Upsilon", !0);
f(m, v, Q, "Φ", "\\Phi", !0);
f(m, v, Q, "Ψ", "\\Psi", !0);
f(m, v, Q, "Ω", "\\Omega", !0);
f(m, v, Q, "A", "Α");
f(m, v, Q, "B", "Β");
f(m, v, Q, "E", "Ε");
f(m, v, Q, "Z", "Ζ");
f(m, v, Q, "H", "Η");
f(m, v, Q, "I", "Ι");
f(m, v, Q, "K", "Κ");
f(m, v, Q, "M", "Μ");
f(m, v, Q, "N", "Ν");
f(m, v, Q, "O", "Ο");
f(m, v, Q, "P", "Ρ");
f(m, v, Q, "T", "Τ");
f(m, v, Q, "X", "Χ");
f(m, v, Q, "¬", "\\neg", !0);
f(m, v, Q, "¬", "\\lnot");
f(m, v, Q, "⊤", "\\top");
f(m, v, Q, "⊥", "\\bot");
f(m, v, Q, "∅", "\\emptyset");
f(m, A, Q, "∅", "\\varnothing");
f(m, v, se, "α", "\\alpha", !0);
f(m, v, se, "β", "\\beta", !0);
f(m, v, se, "γ", "\\gamma", !0);
f(m, v, se, "δ", "\\delta", !0);
f(m, v, se, "ϵ", "\\epsilon", !0);
f(m, v, se, "ζ", "\\zeta", !0);
f(m, v, se, "η", "\\eta", !0);
f(m, v, se, "θ", "\\theta", !0);
f(m, v, se, "ι", "\\iota", !0);
f(m, v, se, "κ", "\\kappa", !0);
f(m, v, se, "λ", "\\lambda", !0);
f(m, v, se, "μ", "\\mu", !0);
f(m, v, se, "ν", "\\nu", !0);
f(m, v, se, "ξ", "\\xi", !0);
f(m, v, se, "ο", "\\omicron", !0);
f(m, v, se, "π", "\\pi", !0);
f(m, v, se, "ρ", "\\rho", !0);
f(m, v, se, "σ", "\\sigma", !0);
f(m, v, se, "τ", "\\tau", !0);
f(m, v, se, "υ", "\\upsilon", !0);
f(m, v, se, "ϕ", "\\phi", !0);
f(m, v, se, "χ", "\\chi", !0);
f(m, v, se, "ψ", "\\psi", !0);
f(m, v, se, "ω", "\\omega", !0);
f(m, v, se, "ε", "\\varepsilon", !0);
f(m, v, se, "ϑ", "\\vartheta", !0);
f(m, v, se, "ϖ", "\\varpi", !0);
f(m, v, se, "ϱ", "\\varrho", !0);
f(m, v, se, "ς", "\\varsigma", !0);
f(m, v, se, "φ", "\\varphi", !0);
f(m, v, X, "∗", "*", !0);
f(m, v, X, "+", "+");
f(m, v, X, "−", "-", !0);
f(m, v, X, "⋅", "\\cdot", !0);
f(m, v, X, "∘", "\\circ", !0);
f(m, v, X, "÷", "\\div", !0);
f(m, v, X, "±", "\\pm", !0);
f(m, v, X, "×", "\\times", !0);
f(m, v, X, "∩", "\\cap", !0);
f(m, v, X, "∪", "\\cup", !0);
f(m, v, X, "∖", "\\setminus", !0);
f(m, v, X, "∧", "\\land");
f(m, v, X, "∨", "\\lor");
f(m, v, X, "∧", "\\wedge", !0);
f(m, v, X, "∨", "\\vee", !0);
f(m, v, Q, "√", "\\surd");
f(m, v, en, "⟨", "\\langle", !0);
f(m, v, en, "∣", "\\lvert");
f(m, v, en, "∥", "\\lVert");
f(m, v, Q0, "?", "?");
f(m, v, Q0, "!", "!");
f(m, v, Q0, "⟩", "\\rangle", !0);
f(m, v, Q0, "∣", "\\rvert");
f(m, v, Q0, "∥", "\\rVert");
f(m, v, C, "=", "=");
f(m, v, C, ":", ":");
f(m, v, C, "≈", "\\approx", !0);
f(m, v, C, "≅", "\\cong", !0);
f(m, v, C, "≥", "\\ge");
f(m, v, C, "≥", "\\geq", !0);
f(m, v, C, "←", "\\gets");
f(m, v, C, ">", "\\gt", !0);
f(m, v, C, "∈", "\\in", !0);
f(m, v, C, "", "\\@not");
f(m, v, C, "⊂", "\\subset", !0);
f(m, v, C, "⊃", "\\supset", !0);
f(m, v, C, "⊆", "\\subseteq", !0);
f(m, v, C, "⊇", "\\supseteq", !0);
f(m, A, C, "⊈", "\\nsubseteq", !0);
f(m, A, C, "⊉", "\\nsupseteq", !0);
f(m, v, C, "⊨", "\\models");
f(m, v, C, "←", "\\leftarrow", !0);
f(m, v, C, "≤", "\\le");
f(m, v, C, "≤", "\\leq", !0);
f(m, v, C, "<", "\\lt", !0);
f(m, v, C, "→", "\\rightarrow", !0);
f(m, v, C, "→", "\\to");
f(m, A, C, "≱", "\\ngeq", !0);
f(m, A, C, "≰", "\\nleq", !0);
f(m, v, Tr, " ", "\\ ");
f(m, v, Tr, " ", "\\space");
f(m, v, Tr, " ", "\\nobreakspace");
f(O, v, Tr, " ", "\\ ");
f(O, v, Tr, " ", " ");
f(O, v, Tr, " ", "\\space");
f(O, v, Tr, " ", "\\nobreakspace");
f(m, v, Tr, null, "\\nobreak");
f(m, v, Tr, null, "\\allowbreak");
f(m, v, R1, ",", ",");
f(m, v, R1, ";", ";");
f(m, A, X, "⊼", "\\barwedge", !0);
f(m, A, X, "⊻", "\\veebar", !0);
f(m, v, X, "⊙", "\\odot", !0);
f(m, v, X, "⊕", "\\oplus", !0);
f(m, v, X, "⊗", "\\otimes", !0);
f(m, v, Q, "∂", "\\partial", !0);
f(m, v, X, "⊘", "\\oslash", !0);
f(m, A, X, "⊚", "\\circledcirc", !0);
f(m, A, X, "⊡", "\\boxdot", !0);
f(m, v, X, "△", "\\bigtriangleup");
f(m, v, X, "▽", "\\bigtriangledown");
f(m, v, X, "†", "\\dagger");
f(m, v, X, "⋄", "\\diamond");
f(m, v, X, "⋆", "\\star");
f(m, v, X, "◃", "\\triangleleft");
f(m, v, X, "▹", "\\triangleright");
f(m, v, en, "{", "\\{");
f(O, v, Q, "{", "\\{");
f(O, v, Q, "{", "\\textbraceleft");
f(m, v, Q0, "}", "\\}");
f(O, v, Q, "}", "\\}");
f(O, v, Q, "}", "\\textbraceright");
f(m, v, en, "{", "\\lbrace");
f(m, v, Q0, "}", "\\rbrace");
f(m, v, en, "[", "\\lbrack", !0);
f(O, v, Q, "[", "\\lbrack", !0);
f(m, v, Q0, "]", "\\rbrack", !0);
f(O, v, Q, "]", "\\rbrack", !0);
f(m, v, en, "(", "\\lparen", !0);
f(m, v, Q0, ")", "\\rparen", !0);
f(O, v, Q, "<", "\\textless", !0);
f(O, v, Q, ">", "\\textgreater", !0);
f(m, v, en, "⌊", "\\lfloor", !0);
f(m, v, Q0, "⌋", "\\rfloor", !0);
f(m, v, en, "⌈", "\\lceil", !0);
f(m, v, Q0, "⌉", "\\rceil", !0);
f(m, v, Q, "\\", "\\backslash");
f(m, v, Q, "∣", "|");
f(m, v, Q, "∣", "\\vert");
f(O, v, Q, "|", "\\textbar", !0);
f(m, v, Q, "∥", "\\|");
f(m, v, Q, "∥", "\\Vert");
f(O, v, Q, "∥", "\\textbardbl");
f(O, v, Q, "~", "\\textasciitilde");
f(O, v, Q, "\\", "\\textbackslash");
f(O, v, Q, "^", "\\textasciicircum");
f(m, v, C, "↑", "\\uparrow", !0);
f(m, v, C, "⇑", "\\Uparrow", !0);
f(m, v, C, "↓", "\\downarrow", !0);
f(m, v, C, "⇓", "\\Downarrow", !0);
f(m, v, C, "↕", "\\updownarrow", !0);
f(m, v, C, "⇕", "\\Updownarrow", !0);
f(m, v, At, "∐", "\\coprod");
f(m, v, At, "⋁", "\\bigvee");
f(m, v, At, "⋀", "\\bigwedge");
f(m, v, At, "⨄", "\\biguplus");
f(m, v, At, "⋂", "\\bigcap");
f(m, v, At, "⋃", "\\bigcup");
f(m, v, At, "∫", "\\int");
f(m, v, At, "∫", "\\intop");
f(m, v, At, "∬", "\\iint");
f(m, v, At, "∭", "\\iiint");
f(m, v, At, "∏", "\\prod");
f(m, v, At, "∑", "\\sum");
f(m, v, At, "⨂", "\\bigotimes");
f(m, v, At, "⨁", "\\bigoplus");
f(m, v, At, "⨀", "\\bigodot");
f(m, v, At, "∮", "\\oint");
f(m, v, At, "∯", "\\oiint");
f(m, v, At, "∰", "\\oiiint");
f(m, v, At, "⨆", "\\bigsqcup");
f(m, v, At, "∫", "\\smallint");
f(O, v, li, "…", "\\textellipsis");
f(m, v, li, "…", "\\mathellipsis");
f(O, v, li, "…", "\\ldots", !0);
f(m, v, li, "…", "\\ldots", !0);
f(m, v, li, "⋯", "\\@cdots", !0);
f(m, v, li, "⋱", "\\ddots", !0);
f(m, v, Q, "⋮", "\\varvdots");
f(O, v, Q, "⋮", "\\varvdots");
f(m, v, lt, "ˊ", "\\acute");
f(m, v, lt, "ˋ", "\\grave");
f(m, v, lt, "¨", "\\ddot");
f(m, v, lt, "~", "\\tilde");
f(m, v, lt, "ˉ", "\\bar");
f(m, v, lt, "˘", "\\breve");
f(m, v, lt, "ˇ", "\\check");
f(m, v, lt, "^", "\\hat");
f(m, v, lt, "⃗", "\\vec");
f(m, v, lt, "˙", "\\dot");
f(m, v, lt, "˚", "\\mathring");
f(m, v, se, "", "\\@imath");
f(m, v, se, "", "\\@jmath");
f(m, v, Q, "ı", "ı");
f(m, v, Q, "ȷ", "ȷ");
f(O, v, Q, "ı", "\\i", !0);
f(O, v, Q, "ȷ", "\\j", !0);
f(O, v, Q, "ß", "\\ss", !0);
f(O, v, Q, "æ", "\\ae", !0);
f(O, v, Q, "œ", "\\oe", !0);
f(O, v, Q, "ø", "\\o", !0);
f(O, v, Q, "Æ", "\\AE", !0);
f(O, v, Q, "Œ", "\\OE", !0);
f(O, v, Q, "Ø", "\\O", !0);
f(O, v, lt, "ˊ", "\\'");
f(O, v, lt, "ˋ", "\\`");
f(O, v, lt, "ˆ", "\\^");
f(O, v, lt, "˜", "\\~");
f(O, v, lt, "ˉ", "\\=");
f(O, v, lt, "˘", "\\u");
f(O, v, lt, "˙", "\\.");
f(O, v, lt, "¸", "\\c");
f(O, v, lt, "˚", "\\r");
f(O, v, lt, "ˇ", "\\v");
f(O, v, lt, "¨", '\\"');
f(O, v, lt, "˝", "\\H");
f(O, v, lt, "◯", "\\textcircled");
var u6 = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
f(O, v, Q, "–", "--", !0);
f(O, v, Q, "–", "\\textendash");
f(O, v, Q, "—", "---", !0);
f(O, v, Q, "—", "\\textemdash");
f(O, v, Q, "‘", "`", !0);
f(O, v, Q, "‘", "\\textquoteleft");
f(O, v, Q, "’", "'", !0);
f(O, v, Q, "’", "\\textquoteright");
f(O, v, Q, "“", "``", !0);
f(O, v, Q, "“", "\\textquotedblleft");
f(O, v, Q, "”", "''", !0);
f(O, v, Q, "”", "\\textquotedblright");
f(m, v, Q, "°", "\\degree", !0);
f(O, v, Q, "°", "\\degree");
f(O, v, Q, "°", "\\textdegree", !0);
f(m, v, Q, "£", "\\pounds");
f(m, v, Q, "£", "\\mathsterling", !0);
f(O, v, Q, "£", "\\pounds");
f(O, v, Q, "£", "\\textsterling", !0);
f(m, A, Q, "✠", "\\maltese");
f(O, A, Q, "✠", "\\maltese");
var C2 = '0123456789/@."';
for (var $o = 0; $o < C2.length; $o++) {
  var x2 = C2.charAt($o);
  f(m, v, Q, x2, x2);
}
var T2 = '0123456789!@*()-=+";:?/.,';
for (var Qo = 0; Qo < T2.length; Qo++) {
  var $2 = T2.charAt(Qo);
  f(O, v, Q, $2, $2);
}
var f1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Mo = 0; Mo < f1.length; Mo++) {
  var Ml = f1.charAt(Mo);
  f(m, v, se, Ml, Ml), f(O, v, Q, Ml, Ml);
}
f(m, A, Q, "C", "ℂ");
f(O, A, Q, "C", "ℂ");
f(m, A, Q, "H", "ℍ");
f(O, A, Q, "H", "ℍ");
f(m, A, Q, "N", "ℕ");
f(O, A, Q, "N", "ℕ");
f(m, A, Q, "P", "ℙ");
f(O, A, Q, "P", "ℙ");
f(m, A, Q, "Q", "ℚ");
f(O, A, Q, "Q", "ℚ");
f(m, A, Q, "R", "ℝ");
f(O, A, Q, "R", "ℝ");
f(m, A, Q, "Z", "ℤ");
f(O, A, Q, "Z", "ℤ");
f(m, v, se, "h", "ℎ");
f(O, v, se, "h", "ℎ");
var de = "";
for (var w0 = 0; w0 < f1.length; w0++) {
  var pt = f1.charAt(w0);
  de = String.fromCharCode(55349, 56320 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56372 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56424 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56580 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56684 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56736 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56788 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56840 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56944 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), w0 < 26 && (de = String.fromCharCode(55349, 56632 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de), de = String.fromCharCode(55349, 56476 + w0), f(m, v, se, pt, de), f(O, v, Q, pt, de));
}
de = "𝕜";
f(m, v, se, "k", de);
f(O, v, Q, "k", de);
for (var sa = 0; sa < 10; sa++) {
  var Hr = sa.toString();
  de = String.fromCharCode(55349, 57294 + sa), f(m, v, se, Hr, de), f(O, v, Q, Hr, de), de = String.fromCharCode(55349, 57314 + sa), f(m, v, se, Hr, de), f(O, v, Q, Hr, de), de = String.fromCharCode(55349, 57324 + sa), f(m, v, se, Hr, de), f(O, v, Q, Hr, de), de = String.fromCharCode(55349, 57334 + sa), f(m, v, se, Hr, de), f(O, v, Q, Hr, de);
}
var Q2 = "ÐÞþ";
for (var Bo = 0; Bo < Q2.length; Bo++) {
  var Bl = Q2.charAt(Bo);
  f(m, v, se, Bl, Bl), f(O, v, Q, Bl, Bl);
}
var zl = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], M2 = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], I8 = function(e, t) {
  var n = e.charCodeAt(0), a = e.charCodeAt(1), i = (n - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var o = Math.floor((i - 119808) / 26);
    return [zl[o][2], zl[o][l]];
  } else if (120782 <= i && i <= 120831) {
    var s = Math.floor((i - 120782) / 10);
    return [M2[s][2], M2[s][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [zl[0][2], zl[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new re("Unsupported character: " + e);
  }
}, O1 = function(e, t, n) {
  return yt[n][e] && yt[n][e].replace && (e = yt[n][e].replace), {
    value: e,
    metrics: h5(e, t, n)
  };
}, Ln = function(e, t, n, a, i) {
  var l = O1(e, t, n), o = l.metrics;
  e = l.value;
  var s;
  if (o) {
    var u = o.italic;
    (n === "text" || a && a.font === "mathit") && (u = 0), s = new dr(e, o.height, o.depth, u, o.skew, o.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + n + "'")), s = new dr(e, 0, 0, 0, 0, 0, i);
  if (a) {
    s.maxFontSize = a.sizeMultiplier, a.style.isTight() && s.classes.push("mtight");
    var c = a.getColor();
    c && (s.style.color = c);
  }
  return s;
}, L8 = function(e, t, n, a) {
  return a === void 0 && (a = []), n.font === "boldsymbol" && O1(e, "Main-Bold", t).metrics ? Ln(e, "Main-Bold", t, n, a.concat(["mathbf"])) : e === "\\" || yt[t][e].font === "main" ? Ln(e, "Main-Regular", t, n, a) : Ln(e, "AMS-Regular", t, n, a.concat(["amsrm"]));
}, q8 = function(e, t, n, a, i) {
  return i !== "textord" && O1(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, N8 = function(e, t, n) {
  var a = e.mode, i = e.text, l = ["mord"], o = a === "math" || a === "text" && t.font, s = o ? t.font : t.fontFamily, u = "", c = "";
  if (i.charCodeAt(0) === 55349 && ([u, c] = I8(i, a)), u.length > 0)
    return Ln(i, u, a, t, l.concat(c));
  if (s) {
    var d, h;
    if (s === "boldsymbol") {
      var _ = q8(i, a, t, l, n);
      d = _.fontName, h = [_.fontClass];
    } else o ? (d = d6[s].fontName, h = [s]) : (d = Il(s, t.fontWeight, t.fontShape), h = [s, t.fontWeight, t.fontShape]);
    if (O1(i, d, a).metrics)
      return Ln(i, d, a, t, l.concat(h));
    if (u6.hasOwnProperty(i) && d.slice(0, 10) === "Typewriter") {
      for (var g = [], b = 0; b < i.length; b++)
        g.push(Ln(i[b], d, a, t, l.concat(h)));
      return h6(g);
    }
  }
  if (n === "mathord")
    return Ln(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (n === "textord") {
    var y = yt[a][i] && yt[a][i].font;
    if (y === "ams") {
      var D = Il("amsrm", t.fontWeight, t.fontShape);
      return Ln(i, D, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (y === "main" || !y) {
      var k = Il("textrm", t.fontWeight, t.fontShape);
      return Ln(i, k, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var p = Il(y, t.fontWeight, t.fontShape);
      return Ln(i, p, a, t, l.concat(p, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + n + " in makeOrd");
}, R8 = (r, e) => {
  if (ea(r.classes) !== ea(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize)
    return !1;
  if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var n in r.style)
    if (r.style.hasOwnProperty(n) && r.style[n] !== e.style[n])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && r.style[a] !== e.style[a])
      return !1;
  return !0;
}, O8 = (r) => {
  for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], n = r[e + 1];
    t instanceof dr && n instanceof dr && R8(t, n) && (t.text += n.text, t.height = Math.max(t.height, n.height), t.depth = Math.max(t.depth, n.depth), t.italic = n.italic, r.splice(e + 1, 1), e--);
  }
  return r;
}, d5 = function(e) {
  for (var t = 0, n = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > n && (n = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = n, e.maxFontSize = a;
}, L0 = function(e, t, n, a) {
  var i = new N1(e, t, n, a);
  return d5(i), i;
}, c6 = (r, e, t, n) => new N1(r, e, t, n), P8 = function(e, t, n) {
  var a = L0([e], [], t);
  return a.height = Math.max(n || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = W(a.height), a.maxFontSize = 1, a;
}, H8 = function(e, t, n, a) {
  var i = new s6(e, t, n, a);
  return d5(i), i;
}, h6 = function(e) {
  var t = new el(e);
  return d5(t), t;
}, V8 = function(e, t) {
  return e instanceof el ? L0([], [e], t) : e;
}, j8 = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, n = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var o = -t[l].shift - i - t[l].elem.depth, s = o - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + o, n.push({
        type: "kern",
        size: s
      }), n.push(t[l]);
    }
    return {
      children: n,
      depth: a
    };
  }
  var u;
  if (e.positionType === "top") {
    for (var c = e.positionData, d = 0; d < e.children.length; d++) {
      var h = e.children[d];
      c -= h.type === "kern" ? h.size : h.elem.height + h.elem.depth;
    }
    u = c;
  } else if (e.positionType === "bottom")
    u = -e.positionData;
  else {
    var _ = e.children[0];
    if (_.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      u = -_.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      u = -_.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: u
  };
}, U8 = function(e, t) {
  for (var {
    children: n,
    depth: a
  } = j8(e), i = 0, l = 0; l < n.length; l++) {
    var o = n[l];
    if (o.type === "elem") {
      var s = o.elem;
      i = Math.max(i, s.maxFontSize, s.height);
    }
  }
  i += 2;
  var u = L0(["pstrut"], []);
  u.style.height = W(i);
  for (var c = [], d = a, h = a, _ = a, g = 0; g < n.length; g++) {
    var b = n[g];
    if (b.type === "kern")
      _ += b.size;
    else {
      var y = b.elem, D = b.wrapperClasses || [], k = b.wrapperStyle || {}, p = L0(D, [u, y], void 0, k);
      p.style.top = W(-i - _ - y.depth), b.marginLeft && (p.style.marginLeft = b.marginLeft), b.marginRight && (p.style.marginRight = b.marginRight), c.push(p), _ += y.height + y.depth;
    }
    d = Math.min(d, _), h = Math.max(h, _);
  }
  var S = L0(["vlist"], c);
  S.style.height = W(h);
  var E;
  if (d < 0) {
    var F = L0([], []), $ = L0(["vlist"], [F]);
    $.style.height = W(-d);
    var B = L0(["vlist-s"], [new dr("​")]);
    E = [L0(["vlist-r"], [S, B]), L0(["vlist-r"], [$])];
  } else
    E = [L0(["vlist-r"], [S])];
  var T = L0(["vlist-t"], E);
  return E.length === 2 && T.classes.push("vlist-t2"), T.height = h, T.depth = -d, T;
}, G8 = (r, e) => {
  var t = L0(["mspace"], [], e), n = dt(r, e);
  return t.style.marginRight = W(n), t;
}, Il = function(e, t, n) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && n === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, d6 = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  mathsfit: {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, f6 = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, W8 = function(e, t) {
  var [n, a, i] = f6[e], l = new Sa(n), o = new ta([l], {
    width: W(a),
    height: W(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + W(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), s = c6(["overlay"], [o], t);
  return s.height = i, s.style.height = W(i), s.style.width = W(a), s;
}, I = {
  fontMap: d6,
  makeSymbol: Ln,
  mathsym: L8,
  makeSpan: L0,
  makeSvgSpan: c6,
  makeLineSpan: P8,
  makeAnchor: H8,
  makeFragment: h6,
  wrapFragment: V8,
  makeVList: U8,
  makeOrd: N8,
  makeGlue: G8,
  staticSvg: W8,
  svgData: f6,
  tryCombineChars: O8
}, ut = {
  number: 3,
  unit: "mu"
}, ua = {
  number: 4,
  unit: "mu"
}, vr = {
  number: 5,
  unit: "mu"
}, Z8 = {
  mord: {
    mop: ut,
    mbin: ua,
    mrel: vr,
    minner: ut
  },
  mop: {
    mord: ut,
    mop: ut,
    mrel: vr,
    minner: ut
  },
  mbin: {
    mord: ua,
    mop: ua,
    mopen: ua,
    minner: ua
  },
  mrel: {
    mord: vr,
    mop: vr,
    mopen: vr,
    minner: vr
  },
  mopen: {},
  mclose: {
    mop: ut,
    mbin: ua,
    mrel: vr,
    minner: ut
  },
  mpunct: {
    mord: ut,
    mop: ut,
    mrel: vr,
    mopen: ut,
    mclose: ut,
    mpunct: ut,
    minner: ut
  },
  minner: {
    mord: ut,
    mop: ut,
    mbin: ua,
    mrel: vr,
    mopen: ut,
    mpunct: ut,
    minner: ut
  }
}, Y8 = {
  mord: {
    mop: ut
  },
  mop: {
    mord: ut,
    mop: ut
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: ut
  },
  mpunct: {},
  minner: {
    mop: ut
  }
}, m6 = {}, m1 = {}, _1 = {};
function Y(r) {
  for (var {
    type: e,
    names: t,
    props: n,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, o = {
    type: e,
    numArgs: n.numArgs,
    argTypes: n.argTypes,
    allowedInArgument: !!n.allowedInArgument,
    allowedInText: !!n.allowedInText,
    allowedInMath: n.allowedInMath === void 0 ? !0 : n.allowedInMath,
    numOptionalArgs: n.numOptionalArgs || 0,
    infix: !!n.infix,
    primitive: !!n.primitive,
    handler: a
  }, s = 0; s < t.length; ++s)
    m6[t[s]] = o;
  e && (i && (m1[e] = i), l && (_1[e] = l));
}
function $a(r) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: n
  } = r;
  Y({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: n
  });
}
var p1 = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, bt = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, ai = I.makeSpan, X8 = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], K8 = ["rightmost", "mrel", "mclose", "mpunct"], J8 = {
  display: ce.DISPLAY,
  text: ce.TEXT,
  script: ce.SCRIPT,
  scriptscript: ce.SCRIPTSCRIPT
}, eh = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, Xt = function(e, t, n, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var o = Re(e[l], t);
    if (o instanceof el) {
      var s = o.children;
      i.push(...s);
    } else
      i.push(o);
  }
  if (I.tryCombineChars(i), !n)
    return i;
  var u = t;
  if (e.length === 1) {
    var c = e[0];
    c.type === "sizing" ? u = t.havingSize(c.size) : c.type === "styling" && (u = t.havingStyle(J8[c.style]));
  }
  var d = ai([a[0] || "leftmost"], [], t), h = ai([a[1] || "rightmost"], [], t), _ = n === "root";
  return B2(i, (g, b) => {
    var y = b.classes[0], D = g.classes[0];
    y === "mbin" && ue.contains(K8, D) ? b.classes[0] = "mord" : D === "mbin" && ue.contains(X8, y) && (g.classes[0] = "mord");
  }, {
    node: d
  }, h, _), B2(i, (g, b) => {
    var y = Ms(b), D = Ms(g), k = y && D ? g.hasClass("mtight") ? Y8[y][D] : Z8[y][D] : null;
    if (k)
      return I.makeGlue(k, u);
  }, {
    node: d
  }, h, _), i;
}, B2 = function r(e, t, n, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var o = e[l], s = _6(o);
    if (s) {
      r(s.children, t, n, null, i);
      continue;
    }
    var u = !o.hasClass("mspace");
    if (u) {
      var c = t(o, n.node);
      c && (n.insertAfter ? n.insertAfter(c) : (e.unshift(c), l++));
    }
    u ? n.node = o : i && o.hasClass("newline") && (n.node = ai(["leftmost"])), n.insertAfter = /* @__PURE__ */ ((d) => (h) => {
      e.splice(d + 1, 0, h), l++;
    })(l);
  }
  a && e.pop();
}, _6 = function(e) {
  return e instanceof el || e instanceof s6 || e instanceof N1 && e.hasClass("enclosing") ? e : null;
}, th = function r(e, t) {
  var n = _6(e);
  if (n) {
    var a = n.children;
    if (a.length) {
      if (t === "right")
        return r(a[a.length - 1], "right");
      if (t === "left")
        return r(a[0], "left");
    }
  }
  return e;
}, Ms = function(e, t) {
  return e ? (t && (e = th(e, t)), eh[e.classes[0]] || null) : null;
}, Ui = function(e, t) {
  var n = ["nulldelimiter"].concat(e.baseSizingClasses());
  return ai(t.concat(n));
}, Re = function(e, t, n) {
  if (!e)
    return ai();
  if (m1[e.type]) {
    var a = m1[e.type](e, t);
    if (n && t.size !== n.size) {
      a = ai(t.sizingClasses(n), [a], t);
      var i = t.sizeMultiplier / n.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new re("Got group of unknown type: '" + e.type + "'");
};
function p6(r) {
  return new el(r);
}
class cn {
  constructor(e, t, n) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = n || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = ea(this.classes));
    for (var n = 0; n < this.children.length; n++)
      if (this.children[n] instanceof nr && this.children[n + 1] instanceof nr) {
        for (var a = this.children[n].toText() + this.children[++n].toText(); this.children[n + 1] instanceof nr; )
          a += this.children[++n].toText();
        e.appendChild(new nr(a).toNode());
      } else
        e.appendChild(this.children[n].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += ue.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + ue.escape(ea(this.classes)) + '"'), e += ">";
    for (var n = 0; n < this.children.length; n++)
      e += this.children[n].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class nr {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return ue.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class nh {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", W(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + W(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var j = {
  MathNode: cn,
  TextNode: nr,
  SpaceNode: nh,
  newDocumentFragment: p6
}, gn = function(e, t, n) {
  return yt[t][e] && yt[t][e].replace && e.charCodeAt(0) !== 55349 && !(u6.hasOwnProperty(e) && n && (n.fontFamily && n.fontFamily.slice(4, 6) === "tt" || n.font && n.font.slice(4, 6) === "tt")) && (e = yt[t][e].replace), new j.TextNode(e);
}, f5 = function(e) {
  return e.length === 1 ? e[0] : new j.MathNode("mrow", e);
}, m5 = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var n = t.font;
  if (!n || n === "mathnormal")
    return null;
  var a = e.mode;
  if (n === "mathit")
    return "italic";
  if (n === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (n === "mathbf")
    return "bold";
  if (n === "mathbb")
    return "double-struck";
  if (n === "mathsfit")
    return "sans-serif-italic";
  if (n === "mathfrak")
    return "fraktur";
  if (n === "mathscr" || n === "mathcal")
    return "script";
  if (n === "mathsf")
    return "sans-serif";
  if (n === "mathtt")
    return "monospace";
  var i = e.text;
  if (ue.contains(["\\imath", "\\jmath"], i))
    return null;
  yt[a][i] && yt[a][i].replace && (i = yt[a][i].replace);
  var l = I.fontMap[n].fontName;
  return h5(i, l, a) ? I.fontMap[n].variant : null;
};
function zo(r) {
  if (!r)
    return !1;
  if (r.type === "mi" && r.children.length === 1) {
    var e = r.children[0];
    return e instanceof nr && e.text === ".";
  } else if (r.type === "mo" && r.children.length === 1 && r.getAttribute("separator") === "true" && r.getAttribute("lspace") === "0em" && r.getAttribute("rspace") === "0em") {
    var t = r.children[0];
    return t instanceof nr && t.text === ",";
  } else
    return !1;
}
var tn = function(e, t, n) {
  if (e.length === 1) {
    var a = Xe(e[0], t);
    return n && a instanceof cn && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, o = 0; o < e.length; o++) {
    var s = Xe(e[o], t);
    if (s instanceof cn && l instanceof cn) {
      if (s.type === "mtext" && l.type === "mtext" && s.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mn" && l.type === "mn") {
        l.children.push(...s.children);
        continue;
      } else if (zo(s) && l.type === "mn") {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mn" && zo(l))
        s.children = [...l.children, ...s.children], i.pop();
      else if ((s.type === "msup" || s.type === "msub") && s.children.length >= 1 && (l.type === "mn" || zo(l))) {
        var u = s.children[0];
        u instanceof cn && u.type === "mn" && (u.children = [...l.children, ...u.children], i.pop());
      } else if (l.type === "mi" && l.children.length === 1) {
        var c = l.children[0];
        if (c instanceof nr && c.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
          var d = s.children[0];
          d instanceof nr && d.text.length > 0 && (d.text = d.text.slice(0, 1) + "̸" + d.text.slice(1), i.pop());
        }
      }
    }
    i.push(s), l = s;
  }
  return i;
}, na = function(e, t, n) {
  return f5(tn(e, t, n));
}, Xe = function(e, t) {
  if (!e)
    return new j.MathNode("mrow");
  if (_1[e.type]) {
    var n = _1[e.type](e, t);
    return n;
  } else
    throw new re("Got group of unknown type: '" + e.type + "'");
}, rh = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, ah = function(e) {
  var t = new j.MathNode("mo", [new j.TextNode(rh[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, ih = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, lh = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, oh = function(e, t) {
  function n() {
    var o = 4e5, s = e.label.slice(1);
    if (ue.contains(["widehat", "widecheck", "widetilde", "utilde"], s)) {
      var u = e, c = lh(u.base), d, h, _;
      if (c > 5)
        s === "widehat" || s === "widecheck" ? (d = 420, o = 2364, _ = 0.42, h = s + "4") : (d = 312, o = 2340, _ = 0.34, h = "tilde4");
      else {
        var g = [1, 1, 2, 2, 3, 3][c];
        s === "widehat" || s === "widecheck" ? (o = [0, 1062, 2364, 2364, 2364][g], d = [0, 239, 300, 360, 420][g], _ = [0, 0.24, 0.3, 0.3, 0.36, 0.42][g], h = s + g) : (o = [0, 600, 1033, 2339, 2340][g], d = [0, 260, 286, 306, 312][g], _ = [0, 0.26, 0.286, 0.3, 0.306, 0.34][g], h = "tilde" + g);
      }
      var b = new Sa(h), y = new ta([b], {
        width: "100%",
        height: W(_),
        viewBox: "0 0 " + o + " " + d,
        preserveAspectRatio: "none"
      });
      return {
        span: I.makeSvgSpan([], [y], t),
        minWidth: 0,
        height: _
      };
    } else {
      var D = [], k = ih[s], [p, S, E] = k, F = E / 1e3, $ = p.length, B, T;
      if ($ === 1) {
        var x = k[3];
        B = ["hide-tail"], T = [x];
      } else if ($ === 2)
        B = ["halfarrow-left", "halfarrow-right"], T = ["xMinYMin", "xMaxYMin"];
      else if ($ === 3)
        B = ["brace-left", "brace-center", "brace-right"], T = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + $ + " children.");
      for (var L = 0; L < $; L++) {
        var P = new Sa(p[L]), ae = new ta([P], {
          width: "400em",
          height: W(F),
          viewBox: "0 0 " + o + " " + E,
          preserveAspectRatio: T[L] + " slice"
        }), R = I.makeSvgSpan([B[L]], [ae], t);
        if ($ === 1)
          return {
            span: R,
            minWidth: S,
            height: F
          };
        R.style.height = W(F), D.push(R);
      }
      return {
        span: I.makeSpan(["stretchy"], D, t),
        minWidth: S,
        height: F
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = n();
  return a.height = l, a.style.height = W(l), i > 0 && (a.style.minWidth = W(i)), a;
}, sh = function(e, t, n, a, i) {
  var l, o = e.height + e.depth + n + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = I.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var s = i.color && i.getColor();
      s && (l.style.borderColor = s);
    }
  } else {
    var u = [];
    /^[bx]cancel$/.test(t) && u.push(new A2({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && u.push(new A2({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var c = new ta(u, {
      width: "100%",
      height: W(o)
    });
    l = I.makeSvgSpan([], [c], i);
  }
  return l.height = o, l.style.height = W(o), l;
}, xr = {
  encloseSpan: sh,
  mathMLnode: ah,
  svgSpan: oh
};
function ye(r, e) {
  if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
  return r;
}
function _5(r) {
  var e = P1(r);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
  return e;
}
function P1(r) {
  return r && (r.type === "atom" || z8.hasOwnProperty(r.type)) ? r : null;
}
var p5 = (r, e) => {
  var t, n, a;
  r && r.type === "supsub" ? (n = ye(r.base, "accent"), t = n.base, r.base = t, a = B8(Re(r, e)), r.base = n) : (n = ye(r, "accent"), t = n.base);
  var i = Re(t, e.havingCrampedStyle()), l = n.isShifty && ue.isCharacterBox(t), o = 0;
  if (l) {
    var s = ue.getBaseElem(t), u = Re(s, e.havingCrampedStyle());
    o = F2(u).skew;
  }
  var c = n.label === "\\c", d = c ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), h;
  if (n.isStretchy)
    h = xr.svgSpan(n, e), h = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: h,
        wrapperClasses: ["svg-align"],
        wrapperStyle: o > 0 ? {
          width: "calc(100% - " + W(2 * o) + ")",
          marginLeft: W(2 * o)
        } : void 0
      }]
    }, e);
  else {
    var _, g;
    n.label === "\\vec" ? (_ = I.staticSvg("vec", e), g = I.svgData.vec[1]) : (_ = I.makeOrd({
      mode: n.mode,
      text: n.label
    }, e, "textord"), _ = F2(_), _.italic = 0, g = _.width, c && (d += _.depth)), h = I.makeSpan(["accent-body"], [_]);
    var b = n.label === "\\textcircled";
    b && (h.classes.push("accent-full"), d = i.height);
    var y = o;
    b || (y -= g / 2), h.style.left = W(y), n.label === "\\textcircled" && (h.style.top = ".2em"), h = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -d
      }, {
        type: "elem",
        elem: h
      }]
    }, e);
  }
  var D = I.makeSpan(["mord", "accent"], [h], e);
  return a ? (a.children[0] = D, a.height = Math.max(D.height, a.height), a.classes[0] = "mord", a) : D;
}, g6 = (r, e) => {
  var t = r.isStretchy ? xr.mathMLnode(r.label) : new j.MathNode("mo", [gn(r.label, r.mode)]), n = new j.MathNode("mover", [Xe(r.base, e), t]);
  return n.setAttribute("accent", "true"), n;
}, uh = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((r) => "\\" + r).join("|"));
Y({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var t = p1(e[0]), n = !uh.test(r.funcName), a = !n || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: r.parser.mode,
      label: r.funcName,
      isStretchy: n,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: p5,
  mathmlBuilder: g6
});
Y({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = e[0], n = r.parser.mode;
    return n === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), n = "text"), {
      type: "accent",
      mode: n,
      label: r.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: p5,
  mathmlBuilder: g6
});
Y({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: n,
      base: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = Re(r.base, e), n = xr.svgSpan(r, e), a = r.label === "\\utilde" ? 0.12 : 0, i = I.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: n,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = xr.mathMLnode(r.label), n = new j.MathNode("munder", [Xe(r.base, e), t]);
    return n.setAttribute("accentunder", "true"), n;
  }
});
var Ll = (r) => {
  var e = new j.MathNode("mpadded", r ? [r] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
Y({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r;
    return {
      type: "xArrow",
      mode: n.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(r, e) {
    var t = e.style, n = e.havingStyle(t.sup()), a = I.wrapFragment(Re(r.body, n, e), e), i = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    r.below && (n = e.havingStyle(t.sub()), l = I.wrapFragment(Re(r.below, n, e), e), l.classes.push(i + "-arrow-pad"));
    var o = xr.svgSpan(r, e), s = -e.fontMetrics().axisHeight + 0.5 * o.height, u = -e.fontMetrics().axisHeight - 0.5 * o.height - 0.111;
    (a.depth > 0.25 || r.label === "\\xleftequilibrium") && (u -= a.depth);
    var c;
    if (l) {
      var d = -e.fontMetrics().axisHeight + l.height + 0.5 * o.height + 0.111;
      c = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }, {
          type: "elem",
          elem: l,
          shift: d
        }]
      }, e);
    } else
      c = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }]
      }, e);
    return c.children[0].children[0].children[1].classes.push("svg-align"), I.makeSpan(["mrel", "x-arrow"], [c], e);
  },
  mathmlBuilder(r, e) {
    var t = xr.mathMLnode(r.label);
    t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var n;
    if (r.body) {
      var a = Ll(Xe(r.body, e));
      if (r.below) {
        var i = Ll(Xe(r.below, e));
        n = new j.MathNode("munderover", [t, i, a]);
      } else
        n = new j.MathNode("mover", [t, a]);
    } else if (r.below) {
      var l = Ll(Xe(r.below, e));
      n = new j.MathNode("munder", [t, l]);
    } else
      n = Ll(), n = new j.MathNode("mover", [t, n]);
    return n;
  }
});
var ch = I.makeSpan;
function v6(r, e) {
  var t = Xt(r.body, e, !0);
  return ch([r.mclass], t, e);
}
function b6(r, e) {
  var t, n = tn(r.body, e);
  return r.mclass === "minner" ? t = new j.MathNode("mpadded", n) : r.mclass === "mord" ? r.isCharacterBox ? (t = n[0], t.type = "mi") : t = new j.MathNode("mi", n) : (r.isCharacterBox ? (t = n[0], t.type = "mo") : t = new j.MathNode("mo", n), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
Y({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + n.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: bt(a),
      isCharacterBox: ue.isCharacterBox(a)
    };
  },
  htmlBuilder: v6,
  mathmlBuilder: b6
});
var H1 = (r) => {
  var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
Y({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: H1(e[0]),
      body: bt(e[1]),
      isCharacterBox: ue.isCharacterBox(e[1])
    };
  }
});
Y({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[1], i = e[0], l;
    n !== "\\stackrel" ? l = H1(a) : l = "mrel";
    var o = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: n !== "\\stackrel",
      body: bt(a)
    }, s = {
      type: "supsub",
      mode: i.mode,
      base: o,
      sup: n === "\\underset" ? null : i,
      sub: n === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [s],
      isCharacterBox: ue.isCharacterBox(s)
    };
  },
  htmlBuilder: v6,
  mathmlBuilder: b6
});
Y({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: H1(e[0]),
      body: bt(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = Xt(r.body, e, !0), n = I.makeSpan([r.mclass], t, e);
    return n.style.textShadow = "0.02em 0.01em 0.04px", n;
  },
  mathmlBuilder(r, e) {
    var t = tn(r.body, e), n = new j.MathNode("mstyle", t);
    return n.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), n;
  }
});
var hh = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, z2 = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), I2 = (r) => r.type === "textord" && r.text === "@", dh = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function fh(r, e, t) {
  var n = hh[r];
  switch (n) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(n, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: n,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), o = t.callFunction("\\\\cdright", [e[1]], []), s = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, o]
      };
      return t.callFunction("\\\\cdparent", [s], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var u = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [u], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function mh(r) {
  var e = [];
  for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
      r.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new re("Expected \\\\ or \\cr or \\end", r.nextToken);
  }
  for (var n = [], a = [n], i = 0; i < e.length; i++) {
    for (var l = e[i], o = z2(), s = 0; s < l.length; s++)
      if (!I2(l[s]))
        o.body.push(l[s]);
      else {
        n.push(o), s += 1;
        var u = _5(l[s]).text, c = new Array(2);
        if (c[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, c[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(u) > -1)) if ("<>AV".indexOf(u) > -1)
          for (var d = 0; d < 2; d++) {
            for (var h = !0, _ = s + 1; _ < l.length; _++) {
              if (dh(l[_], u)) {
                h = !1, s = _;
                break;
              }
              if (I2(l[_]))
                throw new re("Missing a " + u + " character to complete a CD arrow.", l[_]);
              c[d].body.push(l[_]);
            }
            if (h)
              throw new re("Missing a " + u + " character to complete a CD arrow.", l[s]);
          }
        else
          throw new re('Expected one of "<>AV=|." after @', l[s]);
        var g = fh(u, c, r), b = {
          type: "styling",
          body: [g],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        n.push(b), o = z2();
      }
    i % 2 === 0 ? n.push(o) : n.shift(), n = [], a.push(n);
  }
  r.gullet.endGroup(), r.gullet.endGroup();
  var y = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: y,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
Y({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: n.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = e.havingStyle(e.style.sup()), n = I.wrapFragment(Re(r.label, t, e), e);
    return n.classes.push("cd-label-" + r.side), n.style.bottom = W(0.8 - n.depth), n.height = 0, n.depth = 0, n;
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mrow", [Xe(r.label, e)]);
    return t = new j.MathNode("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new j.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
Y({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = I.wrapFragment(Re(r.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(r, e) {
    return new j.MathNode("mrow", [Xe(r.fragment, e)]);
  }
});
Y({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    for (var {
      parser: t
    } = r, n = ye(e[0], "ordgroup"), a = n.body, i = "", l = 0; l < a.length; l++) {
      var o = ye(a[l], "textord");
      i += o.text;
    }
    var s = parseInt(i), u;
    if (isNaN(s))
      throw new re("\\@char has non-numeric argument " + i);
    if (s < 0 || s >= 1114111)
      throw new re("\\@char with invalid code point " + i);
    return s <= 65535 ? u = String.fromCharCode(s) : (s -= 65536, u = String.fromCharCode((s >> 10) + 55296, (s & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: u
    };
  }
});
var y6 = (r, e) => {
  var t = Xt(r.body, e.withColor(r.color), !1);
  return I.makeFragment(t);
}, w6 = (r, e) => {
  var t = tn(r.body, e.withColor(r.color)), n = new j.MathNode("mstyle", t);
  return n.setAttribute("mathcolor", r.color), n;
};
Y({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = ye(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: n,
      body: bt(a)
    };
  },
  htmlBuilder: y6,
  mathmlBuilder: w6
});
Y({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(r, e) {
    var {
      parser: t,
      breakOnTokenText: n
    } = r, a = ye(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, n);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: y6,
  mathmlBuilder: w6
});
Y({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = n.gullet.future().text === "[" ? n.parseSizeGroup(!0) : null, i = !n.settings.displayMode || !n.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: n.mode,
      newLine: i,
      size: a && ye(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(r, e) {
    var t = I.makeSpan(["mspace"], [], e);
    return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = W(dt(r.size, e)))), t;
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mspace");
    return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", W(dt(r.size, e)))), t;
  }
});
var Bs = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, k6 = (r) => {
  var e = r.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new re("Expected a control sequence", r);
  return e;
}, _h = (r) => {
  var e = r.gullet.popToken();
  return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
}, D6 = (r, e, t, n) => {
  var a = r.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !r.gullet.isExpandable(t.text)
  }), r.gullet.macros.set(e, a, n);
};
Y({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    e.consumeSpaces();
    var n = e.fetch();
    if (Bs[n.text])
      return (t === "\\global" || t === "\\\\globallong") && (n.text = Bs[n.text]), ye(e.parseFunction(), "internal");
    throw new re("Invalid token after macro prefix", n);
  }
});
Y({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = e.gullet.popToken(), a = n.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new re("Expected a control sequence", n);
    for (var i = 0, l, o = [[]]; e.gullet.future().text !== "{"; )
      if (n = e.gullet.popToken(), n.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), o[i].push("{");
          break;
        }
        if (n = e.gullet.popToken(), !/^[1-9]$/.test(n.text))
          throw new re('Invalid argument number "' + n.text + '"');
        if (parseInt(n.text) !== i + 1)
          throw new re('Argument number "' + n.text + '" out of order');
        i++, o.push([]);
      } else {
        if (n.text === "EOF")
          throw new re("Expected a macro definition");
        o[i].push(n.text);
      }
    var {
      tokens: s
    } = e.gullet.consumeArg();
    return l && s.unshift(l), (t === "\\edef" || t === "\\xdef") && (s = e.gullet.expandTokens(s), s.reverse()), e.gullet.macros.set(a, {
      tokens: s,
      numArgs: i,
      delimiters: o
    }, t === Bs[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
Y({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = k6(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = _h(e);
    return D6(e, n, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
Y({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = k6(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return D6(e, n, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var zi = function(e, t, n) {
  var a = yt.math[e] && yt.math[e].replace, i = h5(a || e, t, n);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, g5 = function(e, t, n, a) {
  var i = n.havingBaseStyle(t), l = I.makeSpan(a.concat(i.sizingClasses(n)), [e], n), o = i.sizeMultiplier / n.sizeMultiplier;
  return l.height *= o, l.depth *= o, l.maxFontSize = i.sizeMultiplier, l;
}, S6 = function(e, t, n) {
  var a = t.havingBaseStyle(n), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = W(i), e.height -= i, e.depth += i;
}, ph = function(e, t, n, a, i, l) {
  var o = I.makeSymbol(e, "Main-Regular", i, a), s = g5(o, t, a, l);
  return n && S6(s, a, t), s;
}, gh = function(e, t, n, a) {
  return I.makeSymbol(e, "Size" + t + "-Regular", n, a);
}, E6 = function(e, t, n, a, i, l) {
  var o = gh(e, t, i, a), s = g5(I.makeSpan(["delimsizing", "size" + t], [o], a), ce.TEXT, a, l);
  return n && S6(s, a, ce.TEXT), s;
}, Io = function(e, t, n) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = I.makeSpan(["delimsizinginner", a], [I.makeSpan([], [I.makeSymbol(e, t, n)])]);
  return {
    type: "elem",
    elem: i
  };
}, Lo = function(e, t, n) {
  var a = Er["Size4-Regular"][e.charCodeAt(0)] ? Er["Size4-Regular"][e.charCodeAt(0)][4] : Er["Size1-Regular"][e.charCodeAt(0)][4], i = new Sa("inner", F8(e, Math.round(1e3 * t))), l = new ta([i], {
    width: W(a),
    height: W(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + W(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), o = I.makeSvgSpan([], [l], n);
  return o.height = t, o.style.height = W(t), o.style.width = W(a), {
    type: "elem",
    elem: o
  };
}, zs = 8e-3, ql = {
  type: "kern",
  size: -1 * zs
}, vh = ["|", "\\lvert", "\\rvert", "\\vert"], bh = ["\\|", "\\lVert", "\\rVert", "\\Vert"], A6 = function(e, t, n, a, i, l) {
  var o, s, u, c, d = "", h = 0;
  o = u = c = e, s = null;
  var _ = "Size1-Regular";
  e === "\\uparrow" ? u = c = "⏐" : e === "\\Uparrow" ? u = c = "‖" : e === "\\downarrow" ? o = u = "⏐" : e === "\\Downarrow" ? o = u = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", u = "⏐", c = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", u = "‖", c = "\\Downarrow") : ue.contains(vh, e) ? (u = "∣", d = "vert", h = 333) : ue.contains(bh, e) ? (u = "∥", d = "doublevert", h = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", u = "⎢", c = "⎣", _ = "Size4-Regular", d = "lbrack", h = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", u = "⎥", c = "⎦", _ = "Size4-Regular", d = "rbrack", h = 667) : e === "\\lfloor" || e === "⌊" ? (u = o = "⎢", c = "⎣", _ = "Size4-Regular", d = "lfloor", h = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", u = c = "⎢", _ = "Size4-Regular", d = "lceil", h = 667) : e === "\\rfloor" || e === "⌋" ? (u = o = "⎥", c = "⎦", _ = "Size4-Regular", d = "rfloor", h = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", u = c = "⎥", _ = "Size4-Regular", d = "rceil", h = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", u = "⎜", c = "⎝", _ = "Size4-Regular", d = "lparen", h = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", u = "⎟", c = "⎠", _ = "Size4-Regular", d = "rparen", h = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", c = "⎩", u = "⎪", _ = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", c = "⎭", u = "⎪", _ = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", c = "⎩", u = "⎪", _ = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", c = "⎭", u = "⎪", _ = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", c = "⎭", u = "⎪", _ = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", c = "⎩", u = "⎪", _ = "Size4-Regular");
  var g = zi(o, _, i), b = g.height + g.depth, y = zi(u, _, i), D = y.height + y.depth, k = zi(c, _, i), p = k.height + k.depth, S = 0, E = 1;
  if (s !== null) {
    var F = zi(s, _, i);
    S = F.height + F.depth, E = 2;
  }
  var $ = b + p + S, B = Math.max(0, Math.ceil((t - $) / (E * D))), T = $ + B * E * D, x = a.fontMetrics().axisHeight;
  n && (x *= a.sizeMultiplier);
  var L = T / 2 - x, P = [];
  if (d.length > 0) {
    var ae = T - b - p, R = Math.round(T * 1e3), ee = C8(d, Math.round(ae * 1e3)), Z = new Sa(d, ee), ze = (h / 1e3).toFixed(3) + "em", oe = (R / 1e3).toFixed(3) + "em", ge = new ta([Z], {
      width: ze,
      height: oe,
      viewBox: "0 0 " + h + " " + R
    }), N = I.makeSvgSpan([], [ge], a);
    N.height = R / 1e3, N.style.width = ze, N.style.height = oe, P.push({
      type: "elem",
      elem: N
    });
  } else {
    if (P.push(Io(c, _, i)), P.push(ql), s === null) {
      var H = T - b - p + 2 * zs;
      P.push(Lo(u, H, a));
    } else {
      var te = (T - b - p - S) / 2 + 2 * zs;
      P.push(Lo(u, te, a)), P.push(ql), P.push(Io(s, _, i)), P.push(ql), P.push(Lo(u, te, a));
    }
    P.push(ql), P.push(Io(o, _, i));
  }
  var he = a.havingBaseStyle(ce.TEXT), Ie = I.makeVList({
    positionType: "bottom",
    positionData: L,
    children: P
  }, he);
  return g5(I.makeSpan(["delimsizing", "mult"], [Ie], he), ce.TEXT, a, l);
}, qo = 80, No = 0.08, Ro = function(e, t, n, a, i) {
  var l = A8(e, a, n), o = new Sa(e, l), s = new ta([o], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: W(t),
    viewBox: "0 0 400000 " + n,
    preserveAspectRatio: "xMinYMin slice"
  });
  return I.makeSvgSpan(["hide-tail"], [s], i);
}, yh = function(e, t) {
  var n = t.havingBaseSizing(), a = T6("\\surd", e * n.sizeMultiplier, x6, n), i = n.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s = 0, u = 0, c = 0, d;
  return a.type === "small" ? (c = 1e3 + 1e3 * l + qo, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), s = (1 + l + No) / i, u = (1 + l) / i, o = Ro("sqrtMain", s, c, l, t), o.style.minWidth = "0.853em", d = 0.833 / i) : a.type === "large" ? (c = (1e3 + qo) * Ii[a.size], u = (Ii[a.size] + l) / i, s = (Ii[a.size] + l + No) / i, o = Ro("sqrtSize" + a.size, s, c, l, t), o.style.minWidth = "1.02em", d = 1 / i) : (s = e + l + No, u = e + l, c = Math.floor(1e3 * e + l) + qo, o = Ro("sqrtTall", s, c, l, t), o.style.minWidth = "0.742em", d = 1.056), o.height = u, o.style.height = W(s), {
    span: o,
    advanceWidth: d,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, F6 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], wh = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], C6 = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], Ii = [0, 1.2, 1.8, 2.4, 3], kh = function(e, t, n, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), ue.contains(F6, e) || ue.contains(C6, e))
    return E6(e, t, !1, n, a, i);
  if (ue.contains(wh, e))
    return A6(e, Ii[t], !1, n, a, i);
  throw new re("Illegal delimiter: '" + e + "'");
}, Dh = [{
  type: "small",
  style: ce.SCRIPTSCRIPT
}, {
  type: "small",
  style: ce.SCRIPT
}, {
  type: "small",
  style: ce.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], Sh = [{
  type: "small",
  style: ce.SCRIPTSCRIPT
}, {
  type: "small",
  style: ce.SCRIPT
}, {
  type: "small",
  style: ce.TEXT
}, {
  type: "stack"
}], x6 = [{
  type: "small",
  style: ce.SCRIPTSCRIPT
}, {
  type: "small",
  style: ce.SCRIPT
}, {
  type: "small",
  style: ce.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], Eh = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, T6 = function(e, t, n, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < n.length && n[l].type !== "stack"; l++) {
    var o = zi(e, Eh(n[l]), "math"), s = o.height + o.depth;
    if (n[l].type === "small") {
      var u = a.havingBaseStyle(n[l].style);
      s *= u.sizeMultiplier;
    }
    if (s > t)
      return n[l];
  }
  return n[n.length - 1];
}, $6 = function(e, t, n, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var o;
  ue.contains(C6, e) ? o = Dh : ue.contains(F6, e) ? o = x6 : o = Sh;
  var s = T6(e, t, o, a);
  return s.type === "small" ? ph(e, s.style, n, a, i, l) : s.type === "large" ? E6(e, s.size, n, a, i, l) : A6(e, t, n, a, i, l);
}, Ah = function(e, t, n, a, i, l) {
  var o = a.fontMetrics().axisHeight * a.sizeMultiplier, s = 901, u = 5 / a.fontMetrics().ptPerEm, c = Math.max(t - o, n + o), d = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    c / 500 * s,
    2 * c - u
  );
  return $6(e, d, !0, a, i, l);
}, Fr = {
  sqrtImage: yh,
  sizedDelim: kh,
  sizeToMaxHeight: Ii,
  customSizedDelim: $6,
  leftRightDelim: Ah
}, L2 = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, Fh = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function V1(r, e) {
  var t = P1(r);
  if (t && ue.contains(Fh, t.text))
    return t;
  throw t ? new re("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new re("Invalid delimiter type '" + r.type + "'", r);
}
Y({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = V1(e[0], r);
    return {
      type: "delimsizing",
      mode: r.parser.mode,
      size: L2[r.funcName].size,
      mclass: L2[r.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => r.delim === "." ? I.makeSpan([r.mclass]) : Fr.sizedDelim(r.delim, r.size, e, r.mode, [r.mclass]),
  mathmlBuilder: (r) => {
    var e = [];
    r.delim !== "." && e.push(gn(r.delim, r.mode));
    var t = new j.MathNode("mo", e);
    r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var n = W(Fr.sizeToMaxHeight[r.size]);
    return t.setAttribute("minsize", n), t.setAttribute("maxsize", n), t;
  }
});
function q2(r) {
  if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
Y({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = r.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new re("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: r.parser.mode,
      delim: V1(e[0], r).text,
      color: t
      // undefined if not set via \color
    };
  }
});
Y({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = V1(e[0], r), n = r.parser;
    ++n.leftrightDepth;
    var a = n.parseExpression(!1);
    --n.leftrightDepth, n.expect("\\right", !1);
    var i = ye(n.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: n.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (r, e) => {
    q2(r);
    for (var t = Xt(r.body, e, !0, ["mopen", "mclose"]), n = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (n = Math.max(t[l].height, n), a = Math.max(t[l].depth, a));
    n *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var o;
    if (r.left === "." ? o = Ui(e, ["mopen"]) : o = Fr.leftRightDelim(r.left, n, a, e, r.mode, ["mopen"]), t.unshift(o), i)
      for (var s = 1; s < t.length; s++) {
        var u = t[s], c = u.isMiddle;
        c && (t[s] = Fr.leftRightDelim(c.delim, n, a, c.options, r.mode, []));
      }
    var d;
    if (r.right === ".")
      d = Ui(e, ["mclose"]);
    else {
      var h = r.rightColor ? e.withColor(r.rightColor) : e;
      d = Fr.leftRightDelim(r.right, n, a, h, r.mode, ["mclose"]);
    }
    return t.push(d), I.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (r, e) => {
    q2(r);
    var t = tn(r.body, e);
    if (r.left !== ".") {
      var n = new j.MathNode("mo", [gn(r.left, r.mode)]);
      n.setAttribute("fence", "true"), t.unshift(n);
    }
    if (r.right !== ".") {
      var a = new j.MathNode("mo", [gn(r.right, r.mode)]);
      a.setAttribute("fence", "true"), r.rightColor && a.setAttribute("mathcolor", r.rightColor), t.push(a);
    }
    return f5(t);
  }
});
Y({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = V1(e[0], r);
    if (!r.parser.leftrightDepth)
      throw new re("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: r.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    if (r.delim === ".")
      t = Ui(e, []);
    else {
      t = Fr.sizedDelim(r.delim, 1, e, r.mode, []);
      var n = {
        delim: r.delim,
        options: e
      };
      t.isMiddle = n;
    }
    return t;
  },
  mathmlBuilder: (r, e) => {
    var t = r.delim === "\\vert" || r.delim === "|" ? gn("|", "text") : gn(r.delim, r.mode), n = new j.MathNode("mo", [t]);
    return n.setAttribute("fence", "true"), n.setAttribute("lspace", "0.05em"), n.setAttribute("rspace", "0.05em"), n;
  }
});
var v5 = (r, e) => {
  var t = I.wrapFragment(Re(r.body, e), e), n = r.label.slice(1), a = e.sizeMultiplier, i, l = 0, o = ue.isCharacterBox(r.body);
  if (n === "sout")
    i = I.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (n === "phase") {
    var s = dt({
      number: 0.6,
      unit: "pt"
    }, e), u = dt({
      number: 0.35,
      unit: "ex"
    }, e), c = e.havingBaseSizing();
    a = a / c.sizeMultiplier;
    var d = t.height + t.depth + s + u;
    t.style.paddingLeft = W(d / 2 + s);
    var h = Math.floor(1e3 * d * a), _ = S8(h), g = new ta([new Sa("phase", _)], {
      width: "400em",
      height: W(h / 1e3),
      viewBox: "0 0 400000 " + h,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = I.makeSvgSpan(["hide-tail"], [g], e), i.style.height = W(d), l = t.depth + s + u;
  } else {
    /cancel/.test(n) ? o || t.classes.push("cancel-pad") : n === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var b = 0, y = 0, D = 0;
    /box/.test(n) ? (D = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), b = e.fontMetrics().fboxsep + (n === "colorbox" ? 0 : D), y = b) : n === "angl" ? (D = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), b = 4 * D, y = Math.max(0, 0.25 - t.depth)) : (b = o ? 0.2 : 0, y = b), i = xr.encloseSpan(t, n, b, y, e), /fbox|boxed|fcolorbox/.test(n) ? (i.style.borderStyle = "solid", i.style.borderWidth = W(D)) : n === "angl" && D !== 0.049 && (i.style.borderTopWidth = W(D), i.style.borderRightWidth = W(D)), l = t.depth + y, r.backgroundColor && (i.style.backgroundColor = r.backgroundColor, r.borderColor && (i.style.borderColor = r.borderColor));
  }
  var k;
  if (r.backgroundColor)
    k = I.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var p = /cancel|phase/.test(n) ? ["svg-align"] : [];
    k = I.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: p
        }
      ]
    }, e);
  }
  return /cancel/.test(n) && (k.height = t.height, k.depth = t.depth), /cancel/.test(n) && !o ? I.makeSpan(["mord", "cancel-lap"], [k], e) : I.makeSpan(["mord"], [k], e);
}, b5 = (r, e) => {
  var t = 0, n = new j.MathNode(r.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [Xe(r.body, e)]);
  switch (r.label) {
    case "\\cancel":
      n.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      n.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      n.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      n.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      n.setAttribute("notation", "box");
      break;
    case "\\angl":
      n.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, n.setAttribute("width", "+" + 2 * t + "pt"), n.setAttribute("height", "+" + 2 * t + "pt"), n.setAttribute("lspace", t + "pt"), n.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        n.setAttribute("style", "border: " + a + "em solid " + String(r.borderColor));
      }
      break;
    case "\\xcancel":
      n.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return r.backgroundColor && n.setAttribute("mathbackground", r.backgroundColor), n;
};
Y({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r, i = ye(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: n.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: v5,
  mathmlBuilder: b5
});
Y({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r, i = ye(e[0], "color-token").color, l = ye(e[1], "color-token").color, o = e[2];
    return {
      type: "enclose",
      mode: n.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: o
    };
  },
  htmlBuilder: v5,
  mathmlBuilder: b5
});
Y({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
Y({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: n,
      body: a
    };
  },
  htmlBuilder: v5,
  mathmlBuilder: b5
});
Y({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var Q6 = {};
function fr(r) {
  for (var {
    type: e,
    names: t,
    props: n,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, o = {
    type: e,
    numArgs: n.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, s = 0; s < t.length; ++s)
    Q6[t[s]] = o;
  i && (m1[e] = i), l && (_1[e] = l);
}
var Ch = {};
function w(r, e) {
  Ch[r] = e;
}
function N2(r) {
  var e = [];
  r.consumeSpaces();
  var t = r.fetch().text;
  for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
  return e;
}
var j1 = (r) => {
  var e = r.parser.settings;
  if (!e.displayMode)
    throw new re("{" + r.envName + "} can be used only in display mode.");
};
function y5(r) {
  if (r.indexOf("ed") === -1)
    return r.indexOf("*") === -1;
}
function ra(r, e, t) {
  var {
    hskipBeforeAndAfter: n,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: o,
    autoTag: s,
    singleRow: u,
    emptySingleRow: c,
    maxNumCols: d,
    leqno: h
  } = e;
  if (r.gullet.beginGroup(), u || r.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var _ = r.gullet.expandMacroAsText("\\arraystretch");
    if (_ == null)
      l = 1;
    else if (l = parseFloat(_), !l || l < 0)
      throw new re("Invalid \\arraystretch: " + _);
  }
  r.gullet.beginGroup();
  var g = [], b = [g], y = [], D = [], k = s != null ? [] : void 0;
  function p() {
    s && r.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function S() {
    k && (r.gullet.macros.get("\\df@tag") ? (k.push(r.subparse([new u5("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : k.push(!!s && r.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (p(), D.push(N2(r)); ; ) {
    var E = r.parseExpression(!1, u ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup(), E = {
      type: "ordgroup",
      mode: r.mode,
      body: E
    }, t && (E = {
      type: "styling",
      mode: r.mode,
      style: t,
      body: [E]
    }), g.push(E);
    var F = r.fetch().text;
    if (F === "&") {
      if (d && g.length === d) {
        if (u || o)
          throw new re("Too many tab characters: &", r.nextToken);
        r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      r.consume();
    } else if (F === "\\end") {
      S(), g.length === 1 && E.type === "styling" && E.body[0].body.length === 0 && (b.length > 1 || !c) && b.pop(), D.length < b.length + 1 && D.push([]);
      break;
    } else if (F === "\\\\") {
      r.consume();
      var $ = void 0;
      r.gullet.future().text !== " " && ($ = r.parseSizeGroup(!0)), y.push($ ? $.value : null), S(), D.push(N2(r)), g = [], b.push(g), p();
    } else
      throw new re("Expected & or \\\\ or \\cr or \\end", r.nextToken);
  }
  return r.gullet.endGroup(), r.gullet.endGroup(), {
    type: "array",
    mode: r.mode,
    addJot: a,
    arraystretch: l,
    body: b,
    cols: i,
    rowGaps: y,
    hskipBeforeAndAfter: n,
    hLinesBeforeRow: D,
    colSeparationType: o,
    tags: k,
    leqno: h
  };
}
function w5(r) {
  return r.slice(0, 1) === "d" ? "display" : "text";
}
var mr = function(e, t) {
  var n, a, i = e.body.length, l = e.hLinesBeforeRow, o = 0, s = new Array(i), u = [], c = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), d = 1 / t.fontMetrics().ptPerEm, h = 5 * d;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var _ = t.havingStyle(ce.SCRIPT).sizeMultiplier;
    h = 0.2778 * (_ / t.sizeMultiplier);
  }
  var g = e.colSeparationType === "CD" ? dt({
    number: 3,
    unit: "ex"
  }, t) : 12 * d, b = 3 * d, y = e.arraystretch * g, D = 0.7 * y, k = 0.3 * y, p = 0;
  function S(Ve) {
    for (var K = 0; K < Ve.length; ++K)
      K > 0 && (p += 0.25), u.push({
        pos: p,
        isDashed: Ve[K]
      });
  }
  for (S(l[0]), n = 0; n < e.body.length; ++n) {
    var E = e.body[n], F = D, $ = k;
    o < E.length && (o = E.length);
    var B = new Array(E.length);
    for (a = 0; a < E.length; ++a) {
      var T = Re(E[a], t);
      $ < T.depth && ($ = T.depth), F < T.height && (F = T.height), B[a] = T;
    }
    var x = e.rowGaps[n], L = 0;
    x && (L = dt(x, t), L > 0 && (L += k, $ < L && ($ = L), L = 0)), e.addJot && ($ += b), B.height = F, B.depth = $, p += F, B.pos = p, p += $ + L, s[n] = B, S(l[n + 1]);
  }
  var P = p / 2 + t.fontMetrics().axisHeight, ae = e.cols || [], R = [], ee, Z, ze = [];
  if (e.tags && e.tags.some((Ve) => Ve))
    for (n = 0; n < i; ++n) {
      var oe = s[n], ge = oe.pos - P, N = e.tags[n], H = void 0;
      N === !0 ? H = I.makeSpan(["eqn-num"], [], t) : N === !1 ? H = I.makeSpan([], [], t) : H = I.makeSpan([], Xt(N, t, !0), t), H.depth = oe.depth, H.height = oe.height, ze.push({
        type: "elem",
        elem: H,
        shift: ge
      });
    }
  for (
    a = 0, Z = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < o || Z < ae.length;
    ++a, ++Z
  ) {
    for (var te = ae[Z] || {}, he = !0; te.type === "separator"; ) {
      if (he || (ee = I.makeSpan(["arraycolsep"], []), ee.style.width = W(t.fontMetrics().doubleRuleSep), R.push(ee)), te.separator === "|" || te.separator === ":") {
        var Ie = te.separator === "|" ? "solid" : "dashed", z = I.makeSpan(["vertical-separator"], [], t);
        z.style.height = W(p), z.style.borderRightWidth = W(c), z.style.borderRightStyle = Ie, z.style.margin = "0 " + W(-c / 2);
        var xe = p - P;
        xe && (z.style.verticalAlign = W(-xe)), R.push(z);
      } else
        throw new re("Invalid separator type: " + te.separator);
      Z++, te = ae[Z] || {}, he = !1;
    }
    if (!(a >= o)) {
      var pe = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (pe = ue.deflt(te.pregap, h), pe !== 0 && (ee = I.makeSpan(["arraycolsep"], []), ee.style.width = W(pe), R.push(ee)));
      var Te = [];
      for (n = 0; n < i; ++n) {
        var ot = s[n], Ue = ot[a];
        if (Ue) {
          var qe = ot.pos - P;
          Ue.depth = ot.depth, Ue.height = ot.height, Te.push({
            type: "elem",
            elem: Ue,
            shift: qe
          });
        }
      }
      Te = I.makeVList({
        positionType: "individualShift",
        children: Te
      }, t), Te = I.makeSpan(["col-align-" + (te.align || "c")], [Te]), R.push(Te), (a < o - 1 || e.hskipBeforeAndAfter) && (pe = ue.deflt(te.postgap, h), pe !== 0 && (ee = I.makeSpan(["arraycolsep"], []), ee.style.width = W(pe), R.push(ee)));
    }
  }
  if (s = I.makeSpan(["mtable"], R), u.length > 0) {
    for (var fe = I.makeLineSpan("hline", t, c), tt = I.makeLineSpan("hdashline", t, c), Qe = [{
      type: "elem",
      elem: s,
      shift: 0
    }]; u.length > 0; ) {
      var He = u.pop(), ve = He.pos - P;
      He.isDashed ? Qe.push({
        type: "elem",
        elem: tt,
        shift: ve
      }) : Qe.push({
        type: "elem",
        elem: fe,
        shift: ve
      });
    }
    s = I.makeVList({
      positionType: "individualShift",
      children: Qe
    }, t);
  }
  if (ze.length === 0)
    return I.makeSpan(["mord"], [s], t);
  var G = I.makeVList({
    positionType: "individualShift",
    children: ze
  }, t);
  return G = I.makeSpan(["tag"], [G], t), I.makeFragment([s, G]);
}, xh = {
  c: "center ",
  l: "left ",
  r: "right "
}, _r = function(e, t) {
  for (var n = [], a = new j.MathNode("mtd", [], ["mtr-glue"]), i = new j.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var o = e.body[l], s = [], u = 0; u < o.length; u++)
      s.push(new j.MathNode("mtd", [Xe(o[u], t)]));
    e.tags && e.tags[l] && (s.unshift(a), s.push(a), e.leqno ? s.unshift(i) : s.push(i)), n.push(new j.MathNode("mtr", s));
  }
  var c = new j.MathNode("mtable", n), d = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  c.setAttribute("rowspacing", W(d));
  var h = "", _ = "";
  if (e.cols && e.cols.length > 0) {
    var g = e.cols, b = "", y = !1, D = 0, k = g.length;
    g[0].type === "separator" && (h += "top ", D = 1), g[g.length - 1].type === "separator" && (h += "bottom ", k -= 1);
    for (var p = D; p < k; p++)
      g[p].type === "align" ? (_ += xh[g[p].align], y && (b += "none "), y = !0) : g[p].type === "separator" && y && (b += g[p].separator === "|" ? "solid " : "dashed ", y = !1);
    c.setAttribute("columnalign", _.trim()), /[sd]/.test(b) && c.setAttribute("columnlines", b.trim());
  }
  if (e.colSeparationType === "align") {
    for (var S = e.cols || [], E = "", F = 1; F < S.length; F++)
      E += F % 2 ? "0em " : "1em ";
    c.setAttribute("columnspacing", E.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? c.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? c.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? c.setAttribute("columnspacing", "0.5em") : c.setAttribute("columnspacing", "1em");
  var $ = "", B = e.hLinesBeforeRow;
  h += B[0].length > 0 ? "left " : "", h += B[B.length - 1].length > 0 ? "right " : "";
  for (var T = 1; T < B.length - 1; T++)
    $ += B[T].length === 0 ? "none " : B[T][0] ? "dashed " : "solid ";
  return /[sd]/.test($) && c.setAttribute("rowlines", $.trim()), h !== "" && (c = new j.MathNode("menclose", [c]), c.setAttribute("notation", h.trim())), e.arraystretch && e.arraystretch < 1 && (c = new j.MathNode("mstyle", [c]), c.setAttribute("scriptlevel", "1")), c;
}, M6 = function(e, t) {
  e.envName.indexOf("ed") === -1 && j1(e);
  var n = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = ra(e.parser, {
    cols: n,
    addJot: !0,
    autoTag: i ? void 0 : y5(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), o, s = 0, u = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var c = "", d = 0; d < t[0].body.length; d++) {
      var h = ye(t[0].body[d], "textord");
      c += h.text;
    }
    o = Number(c), s = o * 2;
  }
  var _ = !s;
  l.body.forEach(function(D) {
    for (var k = 1; k < D.length; k += 2) {
      var p = ye(D[k], "styling"), S = ye(p.body[0], "ordgroup");
      S.body.unshift(u);
    }
    if (_)
      s < D.length && (s = D.length);
    else {
      var E = D.length / 2;
      if (o < E)
        throw new re("Too many math in a row: " + ("expected " + o + ", but got " + E), D[0]);
    }
  });
  for (var g = 0; g < s; ++g) {
    var b = "r", y = 0;
    g % 2 === 1 ? b = "l" : g > 0 && _ && (y = 1), n[g] = {
      type: "align",
      align: b,
      pregap: y,
      postgap: 0
    };
  }
  return l.colSeparationType = _ ? "align" : "alignat", l;
};
fr({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = P1(e[0]), n = t ? [e[0]] : ye(e[0], "ordgroup").body, a = n.map(function(l) {
      var o = _5(l), s = o.text;
      if ("lcr".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      if (s === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (s === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new re("Unknown column alignment: " + s, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return ra(r.parser, i, w5(r.envName));
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[r.envName.replace("*", "")], t = "c", n = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (r.envName.charAt(r.envName.length - 1) === "*") {
      var a = r.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new re("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), n.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = ra(r.parser, n, w5(r.envName)), l = Math.max(0, ...i.body.map((o) => o.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: r.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 0.5
    }, t = ra(r.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = P1(e[0]), n = t ? [e[0]] : ye(e[0], "ordgroup").body, a = n.map(function(l) {
      var o = _5(l), s = o.text;
      if ("lc".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      throw new re("Unknown column alignment: " + s, l);
    });
    if (a.length > 1)
      throw new re("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = ra(r.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new re("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = ra(r.parser, e, w5(r.envName));
    return {
      type: "leftright",
      mode: r.mode,
      body: [t],
      left: r.envName.indexOf("r") > -1 ? "." : "\\{",
      right: r.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: M6,
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    ue.contains(["gather", "gather*"], r.envName) && j1(r);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: y5(r.envName),
      emptySingleRow: !0,
      leqno: r.parser.settings.leqno
    };
    return ra(r.parser, e, "display");
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: M6,
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    j1(r);
    var e = {
      autoTag: y5(r.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: r.parser.settings.leqno
    };
    return ra(r.parser, e, "display");
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
fr({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(r) {
    return j1(r), mh(r.parser);
  },
  htmlBuilder: mr,
  mathmlBuilder: _r
});
w("\\nonumber", "\\gdef\\@eqnsw{0}");
w("\\notag", "\\nonumber");
Y({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(r, e) {
    throw new re(r.funcName + " valid only within array environment");
  }
});
var R2 = Q6;
Y({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    if (a.type !== "ordgroup")
      throw new re("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += ye(a.body[l], "textord").text;
    if (n === "\\begin") {
      if (!R2.hasOwnProperty(i))
        throw new re("No such environment: " + i, a);
      var o = R2[i], {
        args: s,
        optArgs: u
      } = t.parseArguments("\\begin{" + i + "}", o), c = {
        mode: t.mode,
        envName: i,
        parser: t
      }, d = o.handler(c, s, u);
      t.expect("\\end", !1);
      var h = t.nextToken, _ = ye(t.parseFunction(), "environment");
      if (_.name !== i)
        throw new re("Mismatch: \\begin{" + i + "} matched by \\end{" + _.name + "}", h);
      return d;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var B6 = (r, e) => {
  var t = r.font, n = e.withFont(t);
  return Re(r.body, n);
}, z6 = (r, e) => {
  var t = r.font, n = e.withFont(t);
  return Xe(r.body, n);
}, O2 = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
Y({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = p1(e[0]), i = n;
    return i in O2 && (i = O2[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: B6,
  mathmlBuilder: z6
});
Y({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0], a = ue.isCharacterBox(n);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: H1(n),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: n
      }],
      isCharacterBox: a
    };
  }
});
Y({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n,
      breakOnTokenText: a
    } = r, {
      mode: i
    } = t, l = t.parseExpression(!0, a), o = "math" + n.slice(1);
    return {
      type: "font",
      mode: i,
      font: o,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: B6,
  mathmlBuilder: z6
});
var I6 = (r, e) => {
  var t = e;
  return r === "display" ? t = t.id >= ce.SCRIPT.id ? t.text() : ce.DISPLAY : r === "text" && t.size === ce.DISPLAY.size ? t = ce.TEXT : r === "script" ? t = ce.SCRIPT : r === "scriptscript" && (t = ce.SCRIPTSCRIPT), t;
}, k5 = (r, e) => {
  var t = I6(r.size, e.style), n = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(n);
  var l = Re(r.numer, i, e);
  if (r.continued) {
    var o = 8.5 / e.fontMetrics().ptPerEm, s = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < o ? o : l.height, l.depth = l.depth < s ? s : l.depth;
  }
  i = e.havingStyle(a);
  var u = Re(r.denom, i, e), c, d, h;
  r.hasBarLine ? (r.barSize ? (d = dt(r.barSize, e), c = I.makeLineSpan("frac-line", e, d)) : c = I.makeLineSpan("frac-line", e), d = c.height, h = c.height) : (c = null, d = 0, h = e.fontMetrics().defaultRuleThickness);
  var _, g, b;
  t.size === ce.DISPLAY.size || r.size === "display" ? (_ = e.fontMetrics().num1, d > 0 ? g = 3 * h : g = 7 * h, b = e.fontMetrics().denom1) : (d > 0 ? (_ = e.fontMetrics().num2, g = h) : (_ = e.fontMetrics().num3, g = 3 * h), b = e.fontMetrics().denom2);
  var y;
  if (c) {
    var k = e.fontMetrics().axisHeight;
    _ - l.depth - (k + 0.5 * d) < g && (_ += g - (_ - l.depth - (k + 0.5 * d))), k - 0.5 * d - (u.height - b) < g && (b += g - (k - 0.5 * d - (u.height - b)));
    var p = -(k - 0.5 * d);
    y = I.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: b
      }, {
        type: "elem",
        elem: c,
        shift: p
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  } else {
    var D = _ - l.depth - (u.height - b);
    D < g && (_ += 0.5 * (g - D), b += 0.5 * (g - D)), y = I.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: b
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  }
  i = e.havingStyle(t), y.height *= i.sizeMultiplier / e.sizeMultiplier, y.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var S;
  t.size === ce.DISPLAY.size ? S = e.fontMetrics().delim1 : t.size === ce.SCRIPTSCRIPT.size ? S = e.havingStyle(ce.SCRIPT).fontMetrics().delim2 : S = e.fontMetrics().delim2;
  var E, F;
  return r.leftDelim == null ? E = Ui(e, ["mopen"]) : E = Fr.customSizedDelim(r.leftDelim, S, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? F = I.makeSpan([]) : r.rightDelim == null ? F = Ui(e, ["mclose"]) : F = Fr.customSizedDelim(r.rightDelim, S, !0, e.havingStyle(t), r.mode, ["mclose"]), I.makeSpan(["mord"].concat(i.sizingClasses(e)), [E, I.makeSpan(["mfrac"], [y]), F], e);
}, D5 = (r, e) => {
  var t = new j.MathNode("mfrac", [Xe(r.numer, e), Xe(r.denom, e)]);
  if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (r.barSize) {
    var n = dt(r.barSize, e);
    t.setAttribute("linethickness", W(n));
  }
  var a = I6(r.size, e.style);
  if (a.size !== e.style.size) {
    t = new j.MathNode("mstyle", [t]);
    var i = a.size === ce.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (r.leftDelim != null || r.rightDelim != null) {
    var l = [];
    if (r.leftDelim != null) {
      var o = new j.MathNode("mo", [new j.TextNode(r.leftDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    if (l.push(t), r.rightDelim != null) {
      var s = new j.MathNode("mo", [new j.TextNode(r.rightDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    return f5(l);
  }
  return t;
};
Y({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = e[1], l, o = null, s = null, u = "auto";
    switch (n) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, o = "(", s = ")";
        break;
      case "\\\\bracefrac":
        l = !1, o = "\\{", s = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, o = "[", s = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (n) {
      case "\\dfrac":
      case "\\dbinom":
        u = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        u = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: o,
      rightDelim: s,
      size: u,
      barSize: null
    };
  },
  htmlBuilder: k5,
  mathmlBuilder: D5
});
Y({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
Y({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t,
      token: n
    } = r, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: n
    };
  }
});
var P2 = ["display", "text", "script", "scriptscript"], H2 = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
Y({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = e[4], a = e[5], i = p1(e[0]), l = i.type === "atom" && i.family === "open" ? H2(i.text) : null, o = p1(e[1]), s = o.type === "atom" && o.family === "close" ? H2(o.text) : null, u = ye(e[2], "size"), c, d = null;
    u.isBlank ? c = !0 : (d = u.value, c = d.number > 0);
    var h = "auto", _ = e[3];
    if (_.type === "ordgroup") {
      if (_.body.length > 0) {
        var g = ye(_.body[0], "textord");
        h = P2[Number(g.text)];
      }
    } else
      _ = ye(_, "textord"), h = P2[Number(_.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: n,
      denom: a,
      continued: !1,
      hasBarLine: c,
      barSize: d,
      leftDelim: l,
      rightDelim: s,
      size: h
    };
  },
  htmlBuilder: k5,
  mathmlBuilder: D5
});
Y({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n,
      token: a
    } = r;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: ye(e[0], "size").value,
      token: a
    };
  }
});
Y({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = u8(ye(e[1], "infix").size), l = e[2], o = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: o,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: k5,
  mathmlBuilder: D5
});
var L6 = (r, e) => {
  var t = e.style, n, a;
  r.type === "supsub" ? (n = r.sup ? Re(r.sup, e.havingStyle(t.sup()), e) : Re(r.sub, e.havingStyle(t.sub()), e), a = ye(r.base, "horizBrace")) : a = ye(r, "horizBrace");
  var i = Re(a.base, e.havingBaseStyle(ce.DISPLAY)), l = xr.svgSpan(a, e), o;
  if (a.isOver ? (o = I.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), o.children[0].children[0].children[1].classes.push("svg-align")) : (o = I.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), o.children[0].children[0].children[0].classes.push("svg-align")), n) {
    var s = I.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
    a.isOver ? o = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: n
      }]
    }, e) : o = I.makeVList({
      positionType: "bottom",
      positionData: s.depth + 0.2 + n.height + n.depth,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: s
      }]
    }, e);
  }
  return I.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
}, Th = (r, e) => {
  var t = xr.mathMLnode(r.label);
  return new j.MathNode(r.isOver ? "mover" : "munder", [Xe(r.base, e), t]);
};
Y({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: n,
      isOver: /^\\over/.test(n),
      base: e[0]
    };
  },
  htmlBuilder: L6,
  mathmlBuilder: Th
});
Y({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[1], a = ye(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: bt(n)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (r, e) => {
    var t = Xt(r.body, e, !1);
    return I.makeAnchor(r.href, [], t, e);
  },
  mathmlBuilder: (r, e) => {
    var t = na(r.body, e);
    return t instanceof cn || (t = new cn("mrow", [t])), t.setAttribute("href", r.href), t;
  }
});
Y({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = ye(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: n
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < n.length; i++) {
      var l = n[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var o = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: n,
      body: bt(o)
    };
  }
});
Y({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "hbox",
      mode: t.mode,
      body: bt(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = Xt(r.body, e, !1);
    return I.makeFragment(t);
  },
  mathmlBuilder(r, e) {
    return new j.MathNode("mrow", tn(r.body, e));
  }
});
Y({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n,
      token: a
    } = r, i = ye(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var o, s = {};
    switch (n) {
      case "\\htmlClass":
        s.class = i, o = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        s.id = i, o = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        s.style = i, o = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var u = i.split(","), c = 0; c < u.length; c++) {
          var d = u[c].split("=");
          if (d.length !== 2)
            throw new re("Error parsing key-value for \\htmlData");
          s["data-" + d[0].trim()] = d[1].trim();
        }
        o = {
          command: "\\htmlData",
          attributes: s
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(o) ? {
      type: "html",
      mode: t.mode,
      attributes: s,
      body: bt(l)
    } : t.formatUnsupportedCmd(n);
  },
  htmlBuilder: (r, e) => {
    var t = Xt(r.body, e, !1), n = ["enclosing"];
    r.attributes.class && n.push(...r.attributes.class.trim().split(/\s+/));
    var a = I.makeSpan(n, t, e);
    for (var i in r.attributes)
      i !== "class" && r.attributes.hasOwnProperty(i) && a.setAttribute(i, r.attributes[i]);
    return a;
  },
  mathmlBuilder: (r, e) => na(r.body, e)
});
Y({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: bt(e[0]),
      mathml: bt(e[1])
    };
  },
  htmlBuilder: (r, e) => {
    var t = Xt(r.html, e, !1);
    return I.makeFragment(t);
  },
  mathmlBuilder: (r, e) => na(r.mathml, e)
});
var Oo = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new re("Invalid size: '" + e + "' in \\includegraphics");
  var n = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!T8(n))
    throw new re("Invalid unit: '" + n.unit + "' in \\includegraphics.");
  return n;
};
Y({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (r, e, t) => {
    var {
      parser: n
    } = r, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, o = "";
    if (t[0])
      for (var s = ye(t[0], "raw").string, u = s.split(","), c = 0; c < u.length; c++) {
        var d = u[c].split("=");
        if (d.length === 2) {
          var h = d[1].trim();
          switch (d[0].trim()) {
            case "alt":
              o = h;
              break;
            case "width":
              a = Oo(h);
              break;
            case "height":
              i = Oo(h);
              break;
            case "totalheight":
              l = Oo(h);
              break;
            default:
              throw new re("Invalid key: '" + d[0] + "' in \\includegraphics.");
          }
        }
      }
    var _ = ye(e[0], "url").url;
    return o === "" && (o = _, o = o.replace(/^.*[\\/]/, ""), o = o.substring(0, o.lastIndexOf("."))), n.settings.isTrusted({
      command: "\\includegraphics",
      url: _
    }) ? {
      type: "includegraphics",
      mode: n.mode,
      alt: o,
      width: a,
      height: i,
      totalheight: l,
      src: _
    } : n.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (r, e) => {
    var t = dt(r.height, e), n = 0;
    r.totalheight.number > 0 && (n = dt(r.totalheight, e) - t);
    var a = 0;
    r.width.number > 0 && (a = dt(r.width, e));
    var i = {
      height: W(t + n)
    };
    a > 0 && (i.width = W(a)), n > 0 && (i.verticalAlign = W(-n));
    var l = new Q8(r.src, r.alt, i);
    return l.height = t, l.depth = n, l;
  },
  mathmlBuilder: (r, e) => {
    var t = new j.MathNode("mglyph", []);
    t.setAttribute("alt", r.alt);
    var n = dt(r.height, e), a = 0;
    if (r.totalheight.number > 0 && (a = dt(r.totalheight, e) - n, t.setAttribute("valign", W(-a))), t.setAttribute("height", W(n + a)), r.width.number > 0) {
      var i = dt(r.width, e);
      t.setAttribute("width", W(i));
    }
    return t.setAttribute("src", r.src), t;
  }
});
Y({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = ye(e[0], "size");
    if (t.settings.strict) {
      var i = n[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(r, e) {
    return I.makeGlue(r.dimension, e);
  },
  mathmlBuilder(r, e) {
    var t = dt(r.dimension, e);
    return new j.SpaceNode(t);
  }
});
Y({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: n.slice(5),
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    r.alignment === "clap" ? (t = I.makeSpan([], [Re(r.body, e)]), t = I.makeSpan(["inner"], [t], e)) : t = I.makeSpan(["inner"], [Re(r.body, e)]);
    var n = I.makeSpan(["fix"], []), a = I.makeSpan([r.alignment], [t, n], e), i = I.makeSpan(["strut"]);
    return i.style.height = W(a.height + a.depth), a.depth && (i.style.verticalAlign = W(-a.depth)), a.children.unshift(i), a = I.makeSpan(["thinbox"], [a], e), I.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new j.MathNode("mpadded", [Xe(r.body, e)]);
    if (r.alignment !== "rlap") {
      var n = r.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", n + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
Y({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    var {
      funcName: t,
      parser: n
    } = r, a = n.mode;
    n.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = n.parseExpression(!1, i);
    return n.expect(i), n.switchMode(a), {
      type: "styling",
      mode: n.mode,
      style: "text",
      body: l
    };
  }
});
Y({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    throw new re("Mismatched " + r.funcName);
  }
});
var V2 = (r, e) => {
  switch (e.style.size) {
    case ce.DISPLAY.size:
      return r.display;
    case ce.TEXT.size:
      return r.text;
    case ce.SCRIPT.size:
      return r.script;
    case ce.SCRIPTSCRIPT.size:
      return r.scriptscript;
    default:
      return r.text;
  }
};
Y({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: bt(e[0]),
      text: bt(e[1]),
      script: bt(e[2]),
      scriptscript: bt(e[3])
    };
  },
  htmlBuilder: (r, e) => {
    var t = V2(r, e), n = Xt(t, e, !1);
    return I.makeFragment(n);
  },
  mathmlBuilder: (r, e) => {
    var t = V2(r, e);
    return na(t, e);
  }
});
var q6 = (r, e, t, n, a, i, l) => {
  r = I.makeSpan([], [r]);
  var o = t && ue.isCharacterBox(t), s, u;
  if (e) {
    var c = Re(e, n.havingStyle(a.sup()), n);
    u = {
      elem: c,
      kern: Math.max(n.fontMetrics().bigOpSpacing1, n.fontMetrics().bigOpSpacing3 - c.depth)
    };
  }
  if (t) {
    var d = Re(t, n.havingStyle(a.sub()), n);
    s = {
      elem: d,
      kern: Math.max(n.fontMetrics().bigOpSpacing2, n.fontMetrics().bigOpSpacing4 - d.height)
    };
  }
  var h;
  if (u && s) {
    var _ = n.fontMetrics().bigOpSpacing5 + s.elem.height + s.elem.depth + s.kern + r.depth + l;
    h = I.makeVList({
      positionType: "bottom",
      positionData: _,
      children: [{
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: W(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: W(i)
      }, {
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }]
    }, n);
  } else if (s) {
    var g = r.height - l;
    h = I.makeVList({
      positionType: "top",
      positionData: g,
      children: [{
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: W(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: r
      }]
    }, n);
  } else if (u) {
    var b = r.depth + l;
    h = I.makeVList({
      positionType: "bottom",
      positionData: b,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: W(i)
      }, {
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }]
    }, n);
  } else
    return r;
  var y = [h];
  if (s && i !== 0 && !o) {
    var D = I.makeSpan(["mspace"], [], n);
    D.style.marginRight = W(i), y.unshift(D);
  }
  return I.makeSpan(["mop", "op-limits"], y, n);
}, N6 = ["\\smallint"], oi = (r, e) => {
  var t, n, a = !1, i;
  r.type === "supsub" ? (t = r.sup, n = r.sub, i = ye(r.base, "op"), a = !0) : i = ye(r, "op");
  var l = e.style, o = !1;
  l.size === ce.DISPLAY.size && i.symbol && !ue.contains(N6, i.name) && (o = !0);
  var s;
  if (i.symbol) {
    var u = o ? "Size2-Regular" : "Size1-Regular", c = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (c = i.name.slice(1), i.name = c === "oiint" ? "\\iint" : "\\iiint"), s = I.makeSymbol(i.name, u, "math", e, ["mop", "op-symbol", o ? "large-op" : "small-op"]), c.length > 0) {
      var d = s.italic, h = I.staticSvg(c + "Size" + (o ? "2" : "1"), e);
      s = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: s,
          shift: 0
        }, {
          type: "elem",
          elem: h,
          shift: o ? 0.08 : 0
        }]
      }, e), i.name = "\\" + c, s.classes.unshift("mop"), s.italic = d;
    }
  } else if (i.body) {
    var _ = Xt(i.body, e, !0);
    _.length === 1 && _[0] instanceof dr ? (s = _[0], s.classes[0] = "mop") : s = I.makeSpan(["mop"], _, e);
  } else {
    for (var g = [], b = 1; b < i.name.length; b++)
      g.push(I.mathsym(i.name[b], i.mode, e));
    s = I.makeSpan(["mop"], g, e);
  }
  var y = 0, D = 0;
  return (s instanceof dr || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (y = (s.height - s.depth) / 2 - e.fontMetrics().axisHeight, D = s.italic), a ? q6(s, t, n, e, l, D, y) : (y && (s.style.position = "relative", s.style.top = W(y)), s);
}, tl = (r, e) => {
  var t;
  if (r.symbol)
    t = new cn("mo", [gn(r.name, r.mode)]), ue.contains(N6, r.name) && t.setAttribute("largeop", "false");
  else if (r.body)
    t = new cn("mo", tn(r.body, e));
  else {
    t = new cn("mi", [new nr(r.name.slice(1))]);
    var n = new cn("mo", [gn("⁡", "text")]);
    r.parentIsSupSub ? t = new cn("mrow", [t, n]) : t = p6([t, n]);
  }
  return t;
}, $h = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
Y({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = n;
    return a.length === 1 && (a = $h[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: oi,
  mathmlBuilder: tl
});
Y({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: bt(n)
    };
  },
  htmlBuilder: oi,
  mathmlBuilder: tl
});
var Qh = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
Y({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: oi,
  mathmlBuilder: tl
});
Y({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: oi,
  mathmlBuilder: tl
});
Y({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = t;
    return n.length === 1 && (n = Qh[n]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: n
    };
  },
  htmlBuilder: oi,
  mathmlBuilder: tl
});
var R6 = (r, e) => {
  var t, n, a = !1, i;
  r.type === "supsub" ? (t = r.sup, n = r.sub, i = ye(r.base, "operatorname"), a = !0) : i = ye(r, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var o = i.body.map((d) => {
      var h = d.text;
      return typeof h == "string" ? {
        type: "textord",
        mode: d.mode,
        text: h
      } : d;
    }), s = Xt(o, e.withFont("mathrm"), !0), u = 0; u < s.length; u++) {
      var c = s[u];
      c instanceof dr && (c.text = c.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = I.makeSpan(["mop"], s, e);
  } else
    l = I.makeSpan(["mop"], [], e);
  return a ? q6(l, t, n, e, e.style, 0, 0) : l;
}, Mh = (r, e) => {
  for (var t = tn(r.body, e.withFont("mathrm")), n = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof j.SpaceNode)) if (i instanceof j.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof j.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : n = !1;
          break;
        }
        default:
          n = !1;
      }
    else
      n = !1;
  }
  if (n) {
    var o = t.map((c) => c.toText()).join("");
    t = [new j.TextNode(o)];
  }
  var s = new j.MathNode("mi", t);
  s.setAttribute("mathvariant", "normal");
  var u = new j.MathNode("mo", [gn("⁡", "text")]);
  return r.parentIsSupSub ? new j.MathNode("mrow", [s, u]) : j.newDocumentFragment([s, u]);
};
Y({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: bt(a),
      alwaysHandleSupSub: n === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: R6,
  mathmlBuilder: Mh
});
w("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
$a({
  type: "ordgroup",
  htmlBuilder(r, e) {
    return r.semisimple ? I.makeFragment(Xt(r.body, e, !1)) : I.makeSpan(["mord"], Xt(r.body, e, !0), e);
  },
  mathmlBuilder(r, e) {
    return na(r.body, e, !0);
  }
});
Y({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder(r, e) {
    var t = Re(r.body, e.havingCrampedStyle()), n = I.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return I.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mo", [new j.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var n = new j.MathNode("mover", [Xe(r.body, e), t]);
    return n.setAttribute("accent", "true"), n;
  }
});
Y({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: bt(n)
    };
  },
  htmlBuilder: (r, e) => {
    var t = Xt(r.body, e.withPhantom(), !1);
    return I.makeFragment(t);
  },
  mathmlBuilder: (r, e) => {
    var t = tn(r.body, e);
    return new j.MathNode("mphantom", t);
  }
});
Y({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = I.makeSpan([], [Re(r.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var n = 0; n < t.children.length; n++)
        t.children[n].height = 0, t.children[n].depth = 0;
    return t = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), I.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (r, e) => {
    var t = tn(bt(r.body), e), n = new j.MathNode("mphantom", t), a = new j.MathNode("mpadded", [n]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
Y({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = I.makeSpan(["inner"], [Re(r.body, e.withPhantom())]), n = I.makeSpan(["fix"], []);
    return I.makeSpan(["mord", "rlap"], [t, n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = tn(bt(r.body), e), n = new j.MathNode("mphantom", t), a = new j.MathNode("mpadded", [n]);
    return a.setAttribute("width", "0px"), a;
  }
});
Y({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = ye(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: n,
      body: a
    };
  },
  htmlBuilder(r, e) {
    var t = Re(r.body, e), n = dt(r.dy, e);
    return I.makeVList({
      positionType: "shift",
      positionData: -n,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mpadded", [Xe(r.body, e)]), n = r.dy.number + r.dy.unit;
    return t.setAttribute("voffset", n), t;
  }
});
Y({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e
    } = r;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
Y({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    argTypes: ["size", "size", "size"]
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = t[0], i = ye(e[0], "size"), l = ye(e[1], "size");
    return {
      type: "rule",
      mode: n.mode,
      shift: a && ye(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(r, e) {
    var t = I.makeSpan(["mord", "rule"], [], e), n = dt(r.width, e), a = dt(r.height, e), i = r.shift ? dt(r.shift, e) : 0;
    return t.style.borderRightWidth = W(n), t.style.borderTopWidth = W(a), t.style.bottom = W(i), t.width = n, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(r, e) {
    var t = dt(r.width, e), n = dt(r.height, e), a = r.shift ? dt(r.shift, e) : 0, i = e.color && e.getColor() || "black", l = new j.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", W(t)), l.setAttribute("height", W(n));
    var o = new j.MathNode("mpadded", [l]);
    return a >= 0 ? o.setAttribute("height", W(a)) : (o.setAttribute("height", W(a)), o.setAttribute("depth", W(-a))), o.setAttribute("voffset", W(a)), o;
  }
});
function O6(r, e, t) {
  for (var n = Xt(r, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < n.length; i++) {
    var l = n[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(n[i].classes, e.sizingClasses(t)) : n[i].classes[l + 1] === "reset-size" + e.size && (n[i].classes[l + 1] = "reset-size" + t.size), n[i].height *= a, n[i].depth *= a;
  }
  return I.makeFragment(n);
}
var j2 = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], Bh = (r, e) => {
  var t = e.havingSize(r.size);
  return O6(r.body, t, e);
};
Y({
  type: "sizing",
  names: j2,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      breakOnTokenText: t,
      funcName: n,
      parser: a
    } = r, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: j2.indexOf(n) + 1,
      body: i
    };
  },
  htmlBuilder: Bh,
  mathmlBuilder: (r, e) => {
    var t = e.havingSize(r.size), n = tn(r.body, t), a = new j.MathNode("mstyle", n);
    return a.setAttribute("mathsize", W(t.sizeMultiplier)), a;
  }
});
Y({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (r, e, t) => {
    var {
      parser: n
    } = r, a = !1, i = !1, l = t[0] && ye(t[0], "ordgroup");
    if (l)
      for (var o = "", s = 0; s < l.body.length; ++s) {
        var u = l.body[s];
        if (o = u.text, o === "t")
          a = !0;
        else if (o === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var c = e[0];
    return {
      type: "smash",
      mode: n.mode,
      body: c,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (r, e) => {
    var t = I.makeSpan([], [Re(r.body, e)]);
    if (!r.smashHeight && !r.smashDepth)
      return t;
    if (r.smashHeight && (t.height = 0, t.children))
      for (var n = 0; n < t.children.length; n++)
        t.children[n].height = 0;
    if (r.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new j.MathNode("mpadded", [Xe(r.body, e)]);
    return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
Y({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: n.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(r, e) {
    var t = Re(r.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = I.wrapFragment(t, e);
    var n = e.fontMetrics(), a = n.defaultRuleThickness, i = a;
    e.style.id < ce.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, o = t.height + t.depth + l + a, {
      span: s,
      ruleWidth: u,
      advanceWidth: c
    } = Fr.sqrtImage(o, e), d = s.height - u;
    d > t.height + t.depth + l && (l = (l + d - t.height - t.depth) / 2);
    var h = s.height - t.height - l - u;
    t.style.paddingLeft = W(c);
    var _ = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + h)
      }, {
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: u
      }]
    }, e);
    if (r.index) {
      var g = e.havingStyle(ce.SCRIPTSCRIPT), b = Re(r.index, g, e), y = 0.6 * (_.height - _.depth), D = I.makeVList({
        positionType: "shift",
        positionData: -y,
        children: [{
          type: "elem",
          elem: b
        }]
      }, e), k = I.makeSpan(["root"], [D]);
      return I.makeSpan(["mord", "sqrt"], [k, _], e);
    } else
      return I.makeSpan(["mord", "sqrt"], [_], e);
  },
  mathmlBuilder(r, e) {
    var {
      body: t,
      index: n
    } = r;
    return n ? new j.MathNode("mroot", [Xe(t, e), Xe(n, e)]) : new j.MathNode("msqrt", [Xe(t, e)]);
  }
});
var U2 = {
  display: ce.DISPLAY,
  text: ce.TEXT,
  script: ce.SCRIPT,
  scriptscript: ce.SCRIPTSCRIPT
};
Y({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      breakOnTokenText: t,
      funcName: n,
      parser: a
    } = r, i = a.parseExpression(!0, t), l = n.slice(1, n.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(r, e) {
    var t = U2[r.style], n = e.havingStyle(t).withFont("");
    return O6(r.body, n, e);
  },
  mathmlBuilder(r, e) {
    var t = U2[r.style], n = e.havingStyle(t), a = tn(r.body, n), i = new j.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, o = l[r.style];
    return i.setAttribute("scriptlevel", o[0]), i.setAttribute("displaystyle", o[1]), i;
  }
});
var zh = function(e, t) {
  var n = e.base;
  if (n)
    if (n.type === "op") {
      var a = n.limits && (t.style.size === ce.DISPLAY.size || n.alwaysHandleSupSub);
      return a ? oi : null;
    } else if (n.type === "operatorname") {
      var i = n.alwaysHandleSupSub && (t.style.size === ce.DISPLAY.size || n.limits);
      return i ? R6 : null;
    } else {
      if (n.type === "accent")
        return ue.isCharacterBox(n.base) ? p5 : null;
      if (n.type === "horizBrace") {
        var l = !e.sub;
        return l === n.isOver ? L6 : null;
      } else
        return null;
    }
  else return null;
};
$a({
  type: "supsub",
  htmlBuilder(r, e) {
    var t = zh(r, e);
    if (t)
      return t(r, e);
    var {
      base: n,
      sup: a,
      sub: i
    } = r, l = Re(n, e), o, s, u = e.fontMetrics(), c = 0, d = 0, h = n && ue.isCharacterBox(n);
    if (a) {
      var _ = e.havingStyle(e.style.sup());
      o = Re(a, _, e), h || (c = l.height - _.fontMetrics().supDrop * _.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var g = e.havingStyle(e.style.sub());
      s = Re(i, g, e), h || (d = l.depth + g.fontMetrics().subDrop * g.sizeMultiplier / e.sizeMultiplier);
    }
    var b;
    e.style === ce.DISPLAY ? b = u.sup1 : e.style.cramped ? b = u.sup3 : b = u.sup2;
    var y = e.sizeMultiplier, D = W(0.5 / u.ptPerEm / y), k = null;
    if (s) {
      var p = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
      (l instanceof dr || p) && (k = W(-l.italic));
    }
    var S;
    if (o && s) {
      c = Math.max(c, b, o.depth + 0.25 * u.xHeight), d = Math.max(d, u.sub2);
      var E = u.defaultRuleThickness, F = 4 * E;
      if (c - o.depth - (s.height - d) < F) {
        d = F - (c - o.depth) + s.height;
        var $ = 0.8 * u.xHeight - (c - o.depth);
        $ > 0 && (c += $, d -= $);
      }
      var B = [{
        type: "elem",
        elem: s,
        shift: d,
        marginRight: D,
        marginLeft: k
      }, {
        type: "elem",
        elem: o,
        shift: -c,
        marginRight: D
      }];
      S = I.makeVList({
        positionType: "individualShift",
        children: B
      }, e);
    } else if (s) {
      d = Math.max(d, u.sub1, s.height - 0.8 * u.xHeight);
      var T = [{
        type: "elem",
        elem: s,
        marginLeft: k,
        marginRight: D
      }];
      S = I.makeVList({
        positionType: "shift",
        positionData: d,
        children: T
      }, e);
    } else if (o)
      c = Math.max(c, b, o.depth + 0.25 * u.xHeight), S = I.makeVList({
        positionType: "shift",
        positionData: -c,
        children: [{
          type: "elem",
          elem: o,
          marginRight: D
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var x = Ms(l, "right") || "mord";
    return I.makeSpan([x], [l, I.makeSpan(["msupsub"], [S])], e);
  },
  mathmlBuilder(r, e) {
    var t = !1, n, a;
    r.base && r.base.type === "horizBrace" && (a = !!r.sup, a === r.base.isOver && (t = !0, n = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0);
    var i = [Xe(r.base, e)];
    r.sub && i.push(Xe(r.sub, e)), r.sup && i.push(Xe(r.sup, e));
    var l;
    if (t)
      l = n ? "mover" : "munder";
    else if (r.sub)
      if (r.sup) {
        var u = r.base;
        u && u.type === "op" && u.limits && e.style === ce.DISPLAY || u && u.type === "operatorname" && u.alwaysHandleSupSub && (e.style === ce.DISPLAY || u.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var s = r.base;
        s && s.type === "op" && s.limits && (e.style === ce.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === ce.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var o = r.base;
      o && o.type === "op" && o.limits && (e.style === ce.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === ce.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new j.MathNode(l, i);
  }
});
$a({
  type: "atom",
  htmlBuilder(r, e) {
    return I.mathsym(r.text, r.mode, e, ["m" + r.family]);
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mo", [gn(r.text, r.mode)]);
    if (r.family === "bin") {
      var n = m5(r, e);
      n === "bold-italic" && t.setAttribute("mathvariant", n);
    } else r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var P6 = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
$a({
  type: "mathord",
  htmlBuilder(r, e) {
    return I.makeOrd(r, e, "mathord");
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mi", [gn(r.text, r.mode, e)]), n = m5(r, e) || "italic";
    return n !== P6[t.type] && t.setAttribute("mathvariant", n), t;
  }
});
$a({
  type: "textord",
  htmlBuilder(r, e) {
    return I.makeOrd(r, e, "textord");
  },
  mathmlBuilder(r, e) {
    var t = gn(r.text, r.mode, e), n = m5(r, e) || "normal", a;
    return r.mode === "text" ? a = new j.MathNode("mtext", [t]) : /[0-9]/.test(r.text) ? a = new j.MathNode("mn", [t]) : r.text === "\\prime" ? a = new j.MathNode("mo", [t]) : a = new j.MathNode("mi", [t]), n !== P6[a.type] && a.setAttribute("mathvariant", n), a;
  }
});
var Po = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, Ho = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
$a({
  type: "spacing",
  htmlBuilder(r, e) {
    if (Ho.hasOwnProperty(r.text)) {
      var t = Ho[r.text].className || "";
      if (r.mode === "text") {
        var n = I.makeOrd(r, e, "textord");
        return n.classes.push(t), n;
      } else
        return I.makeSpan(["mspace", t], [I.mathsym(r.text, r.mode, e)], e);
    } else {
      if (Po.hasOwnProperty(r.text))
        return I.makeSpan(["mspace", Po[r.text]], [], e);
      throw new re('Unknown type of space "' + r.text + '"');
    }
  },
  mathmlBuilder(r, e) {
    var t;
    if (Ho.hasOwnProperty(r.text))
      t = new j.MathNode("mtext", [new j.TextNode(" ")]);
    else {
      if (Po.hasOwnProperty(r.text))
        return new j.MathNode("mspace");
      throw new re('Unknown type of space "' + r.text + '"');
    }
    return t;
  }
});
var G2 = () => {
  var r = new j.MathNode("mtd", []);
  return r.setAttribute("width", "50%"), r;
};
$a({
  type: "tag",
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mtable", [new j.MathNode("mtr", [G2(), new j.MathNode("mtd", [na(r.body, e)]), G2(), new j.MathNode("mtd", [na(r.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var W2 = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Z2 = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, Ih = {
  "\\textit": "textit",
  "\\textup": "textup"
}, Y2 = (r, e) => {
  var t = r.font;
  if (t) {
    if (W2[t])
      return e.withTextFontFamily(W2[t]);
    if (Z2[t])
      return e.withTextFontWeight(Z2[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(Ih[t]);
};
Y({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: bt(a),
      font: n
    };
  },
  htmlBuilder(r, e) {
    var t = Y2(r, e), n = Xt(r.body, t, !0);
    return I.makeSpan(["mord", "text"], n, t);
  },
  mathmlBuilder(r, e) {
    var t = Y2(r, e);
    return na(r.body, t);
  }
});
Y({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = Re(r.body, e), n = I.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = I.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new j.MathNode("mo", [new j.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var n = new j.MathNode("munder", [Xe(r.body, e), t]);
    return n.setAttribute("accentunder", "true"), n;
  }
});
Y({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = Re(r.body, e), n = e.fontMetrics().axisHeight, a = 0.5 * (t.height - n - (t.depth + n));
    return I.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    return new j.MathNode("mpadded", [Xe(r.body, e)], ["vcenter"]);
  }
});
Y({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    throw new re("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(r, e) {
    for (var t = X2(r), n = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), n.push(I.makeSymbol(l, "Typewriter-Regular", r.mode, a, ["mord", "texttt"]));
    }
    return I.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), I.tryCombineChars(n), a);
  },
  mathmlBuilder(r, e) {
    var t = new j.TextNode(X2(r)), n = new j.MathNode("mtext", [t]);
    return n.setAttribute("mathvariant", "monospace"), n;
  }
});
var X2 = (r) => r.body.replace(/ /g, r.star ? "␣" : " "), Lh = m6;
w("\\noexpand", function(r) {
  var e = r.popToken();
  return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
w("\\expandafter", function(r) {
  var e = r.popToken();
  return r.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
w("\\@firstoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
w("\\@secondoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
w("\\@ifnextchar", function(r) {
  var e = r.consumeArgs(3);
  r.consumeSpaces();
  var t = r.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
w("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
w("\\TextOrMath", function(r) {
  var e = r.consumeArgs(2);
  return r.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var K2 = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
w("\\char", function(r) {
  var e = r.popToken(), t, n = "";
  if (e.text === "'")
    t = 8, e = r.popToken();
  else if (e.text === '"')
    t = 16, e = r.popToken();
  else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
      n = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new re("\\char` missing argument");
      n = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (n = K2[e.text], n == null || n >= t)
      throw new re("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = K2[r.future().text]) != null && a < t; )
      n *= t, n += a, r.popToken();
  }
  return "\\@char{" + n + "}";
});
var S5 = (r, e, t, n) => {
  var a = r.consumeArg().tokens;
  if (a.length !== 1)
    throw new re("\\newcommand's first argument must be a macro name");
  var i = a[0].text, l = r.isDefined(i);
  if (l && !e)
    throw new re("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!l && !t)
    throw new re("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var o = 0;
  if (a = r.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var s = "", u = r.expandNextToken(); u.text !== "]" && u.text !== "EOF"; )
      s += u.text, u = r.expandNextToken();
    if (!s.match(/^\s*[0-9]+\s*$/))
      throw new re("Invalid number of arguments: " + s);
    o = parseInt(s), a = r.consumeArg().tokens;
  }
  return l && n || r.macros.set(i, {
    tokens: a,
    numArgs: o
  }), "";
};
w("\\newcommand", (r) => S5(r, !1, !0, !1));
w("\\renewcommand", (r) => S5(r, !0, !1, !1));
w("\\providecommand", (r) => S5(r, !0, !0, !0));
w("\\message", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
w("\\errmessage", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
w("\\show", (r) => {
  var e = r.popToken(), t = e.text;
  return console.log(e, r.macros.get(t), Lh[t], yt.math[t], yt.text[t]), "";
});
w("\\bgroup", "{");
w("\\egroup", "}");
w("~", "\\nobreakspace");
w("\\lq", "`");
w("\\rq", "'");
w("\\aa", "\\r a");
w("\\AA", "\\r A");
w("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
w("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
w("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
w("ℬ", "\\mathscr{B}");
w("ℰ", "\\mathscr{E}");
w("ℱ", "\\mathscr{F}");
w("ℋ", "\\mathscr{H}");
w("ℐ", "\\mathscr{I}");
w("ℒ", "\\mathscr{L}");
w("ℳ", "\\mathscr{M}");
w("ℛ", "\\mathscr{R}");
w("ℭ", "\\mathfrak{C}");
w("ℌ", "\\mathfrak{H}");
w("ℨ", "\\mathfrak{Z}");
w("\\Bbbk", "\\Bbb{k}");
w("·", "\\cdotp");
w("\\llap", "\\mathllap{\\textrm{#1}}");
w("\\rlap", "\\mathrlap{\\textrm{#1}}");
w("\\clap", "\\mathclap{\\textrm{#1}}");
w("\\mathstrut", "\\vphantom{(}");
w("\\underbar", "\\underline{\\text{#1}}");
w("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
w("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
w("\\ne", "\\neq");
w("≠", "\\neq");
w("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
w("∉", "\\notin");
w("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
w("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
w("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
w("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
w("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
w("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
w("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
w("⟂", "\\perp");
w("‼", "\\mathclose{!\\mkern-0.8mu!}");
w("∌", "\\notni");
w("⌜", "\\ulcorner");
w("⌝", "\\urcorner");
w("⌞", "\\llcorner");
w("⌟", "\\lrcorner");
w("©", "\\copyright");
w("®", "\\textregistered");
w("️", "\\textregistered");
w("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
w("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
w("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
w("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
w("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
w("⋮", "\\vdots");
w("\\varGamma", "\\mathit{\\Gamma}");
w("\\varDelta", "\\mathit{\\Delta}");
w("\\varTheta", "\\mathit{\\Theta}");
w("\\varLambda", "\\mathit{\\Lambda}");
w("\\varXi", "\\mathit{\\Xi}");
w("\\varPi", "\\mathit{\\Pi}");
w("\\varSigma", "\\mathit{\\Sigma}");
w("\\varUpsilon", "\\mathit{\\Upsilon}");
w("\\varPhi", "\\mathit{\\Phi}");
w("\\varPsi", "\\mathit{\\Psi}");
w("\\varOmega", "\\mathit{\\Omega}");
w("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
w("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
w("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
w("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
w("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
w("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
w("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
w("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var J2 = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
w("\\dots", function(r) {
  var e = "\\dotso", t = r.expandAfterFuture().text;
  return t in J2 ? e = J2[t] : (t.slice(0, 4) === "\\not" || t in yt.math && ue.contains(["bin", "rel"], yt.math[t].group)) && (e = "\\dotsb"), e;
});
var E5 = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
w("\\dotso", function(r) {
  var e = r.future().text;
  return e in E5 ? "\\ldots\\," : "\\ldots";
});
w("\\dotsc", function(r) {
  var e = r.future().text;
  return e in E5 && e !== "," ? "\\ldots\\," : "\\ldots";
});
w("\\cdots", function(r) {
  var e = r.future().text;
  return e in E5 ? "\\@cdots\\," : "\\@cdots";
});
w("\\dotsb", "\\cdots");
w("\\dotsm", "\\cdots");
w("\\dotsi", "\\!\\cdots");
w("\\dotsx", "\\ldots\\,");
w("\\DOTSI", "\\relax");
w("\\DOTSB", "\\relax");
w("\\DOTSX", "\\relax");
w("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
w("\\,", "\\tmspace+{3mu}{.1667em}");
w("\\thinspace", "\\,");
w("\\>", "\\mskip{4mu}");
w("\\:", "\\tmspace+{4mu}{.2222em}");
w("\\medspace", "\\:");
w("\\;", "\\tmspace+{5mu}{.2777em}");
w("\\thickspace", "\\;");
w("\\!", "\\tmspace-{3mu}{.1667em}");
w("\\negthinspace", "\\!");
w("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
w("\\negthickspace", "\\tmspace-{5mu}{.277em}");
w("\\enspace", "\\kern.5em ");
w("\\enskip", "\\hskip.5em\\relax");
w("\\quad", "\\hskip1em\\relax");
w("\\qquad", "\\hskip2em\\relax");
w("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
w("\\tag@paren", "\\tag@literal{({#1})}");
w("\\tag@literal", (r) => {
  if (r.macros.get("\\df@tag"))
    throw new re("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
w("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
w("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
w("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
w("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
w("\\newline", "\\\\\\relax");
w("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var H6 = W(Er["Main-Regular"][84][1] - 0.7 * Er["Main-Regular"][65][1]);
w("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + H6 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
w("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + H6 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
w("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
w("\\@hspace", "\\hskip #1\\relax");
w("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
w("\\ordinarycolon", ":");
w("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
w("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
w("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
w("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
w("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
w("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
w("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
w("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
w("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
w("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
w("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
w("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
w("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
w("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
w("∷", "\\dblcolon");
w("∹", "\\eqcolon");
w("≔", "\\coloneqq");
w("≕", "\\eqqcolon");
w("⩴", "\\Coloneqq");
w("\\ratio", "\\vcentcolon");
w("\\coloncolon", "\\dblcolon");
w("\\colonequals", "\\coloneqq");
w("\\coloncolonequals", "\\Coloneqq");
w("\\equalscolon", "\\eqqcolon");
w("\\equalscoloncolon", "\\Eqqcolon");
w("\\colonminus", "\\coloneq");
w("\\coloncolonminus", "\\Coloneq");
w("\\minuscolon", "\\eqcolon");
w("\\minuscoloncolon", "\\Eqcolon");
w("\\coloncolonapprox", "\\Colonapprox");
w("\\coloncolonsim", "\\Colonsim");
w("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
w("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
w("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
w("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
w("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
w("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
w("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
w("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
w("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
w("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
w("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
w("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
w("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
w("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
w("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
w("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
w("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
w("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
w("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
w("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
w("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
w("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
w("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
w("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
w("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
w("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
w("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
w("\\imath", "\\html@mathml{\\@imath}{ı}");
w("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
w("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
w("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
w("⟦", "\\llbracket");
w("⟧", "\\rrbracket");
w("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
w("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
w("⦃", "\\lBrace");
w("⦄", "\\rBrace");
w("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
w("⦵", "\\minuso");
w("\\darr", "\\downarrow");
w("\\dArr", "\\Downarrow");
w("\\Darr", "\\Downarrow");
w("\\lang", "\\langle");
w("\\rang", "\\rangle");
w("\\uarr", "\\uparrow");
w("\\uArr", "\\Uparrow");
w("\\Uarr", "\\Uparrow");
w("\\N", "\\mathbb{N}");
w("\\R", "\\mathbb{R}");
w("\\Z", "\\mathbb{Z}");
w("\\alef", "\\aleph");
w("\\alefsym", "\\aleph");
w("\\Alpha", "\\mathrm{A}");
w("\\Beta", "\\mathrm{B}");
w("\\bull", "\\bullet");
w("\\Chi", "\\mathrm{X}");
w("\\clubs", "\\clubsuit");
w("\\cnums", "\\mathbb{C}");
w("\\Complex", "\\mathbb{C}");
w("\\Dagger", "\\ddagger");
w("\\diamonds", "\\diamondsuit");
w("\\empty", "\\emptyset");
w("\\Epsilon", "\\mathrm{E}");
w("\\Eta", "\\mathrm{H}");
w("\\exist", "\\exists");
w("\\harr", "\\leftrightarrow");
w("\\hArr", "\\Leftrightarrow");
w("\\Harr", "\\Leftrightarrow");
w("\\hearts", "\\heartsuit");
w("\\image", "\\Im");
w("\\infin", "\\infty");
w("\\Iota", "\\mathrm{I}");
w("\\isin", "\\in");
w("\\Kappa", "\\mathrm{K}");
w("\\larr", "\\leftarrow");
w("\\lArr", "\\Leftarrow");
w("\\Larr", "\\Leftarrow");
w("\\lrarr", "\\leftrightarrow");
w("\\lrArr", "\\Leftrightarrow");
w("\\Lrarr", "\\Leftrightarrow");
w("\\Mu", "\\mathrm{M}");
w("\\natnums", "\\mathbb{N}");
w("\\Nu", "\\mathrm{N}");
w("\\Omicron", "\\mathrm{O}");
w("\\plusmn", "\\pm");
w("\\rarr", "\\rightarrow");
w("\\rArr", "\\Rightarrow");
w("\\Rarr", "\\Rightarrow");
w("\\real", "\\Re");
w("\\reals", "\\mathbb{R}");
w("\\Reals", "\\mathbb{R}");
w("\\Rho", "\\mathrm{P}");
w("\\sdot", "\\cdot");
w("\\sect", "\\S");
w("\\spades", "\\spadesuit");
w("\\sub", "\\subset");
w("\\sube", "\\subseteq");
w("\\supe", "\\supseteq");
w("\\Tau", "\\mathrm{T}");
w("\\thetasym", "\\vartheta");
w("\\weierp", "\\wp");
w("\\Zeta", "\\mathrm{Z}");
w("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
w("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
w("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
w("\\bra", "\\mathinner{\\langle{#1}|}");
w("\\ket", "\\mathinner{|{#1}\\rangle}");
w("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
w("\\Bra", "\\left\\langle#1\\right|");
w("\\Ket", "\\left|#1\\right\\rangle");
var V6 = (r) => (e) => {
  var t = e.consumeArg().tokens, n = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), o = e.macros.get("\\|");
  e.macros.beginGroup();
  var s = (d) => (h) => {
    r && (h.macros.set("|", l), a.length && h.macros.set("\\|", o));
    var _ = d;
    if (!d && a.length) {
      var g = h.future();
      g.text === "|" && (h.popToken(), _ = !0);
    }
    return {
      tokens: _ ? a : n,
      numArgs: 0
    };
  };
  e.macros.set("|", s(!1)), a.length && e.macros.set("\\|", s(!0));
  var u = e.consumeArg().tokens, c = e.expandTokens([
    ...i,
    ...u,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: c.reverse(),
    numArgs: 0
  };
};
w("\\bra@ket", V6(!1));
w("\\bra@set", V6(!0));
w("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
w("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
w("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
w("\\angln", "{\\angl n}");
w("\\blue", "\\textcolor{##6495ed}{#1}");
w("\\orange", "\\textcolor{##ffa500}{#1}");
w("\\pink", "\\textcolor{##ff00af}{#1}");
w("\\red", "\\textcolor{##df0030}{#1}");
w("\\green", "\\textcolor{##28ae7b}{#1}");
w("\\gray", "\\textcolor{gray}{#1}");
w("\\purple", "\\textcolor{##9d38bd}{#1}");
w("\\blueA", "\\textcolor{##ccfaff}{#1}");
w("\\blueB", "\\textcolor{##80f6ff}{#1}");
w("\\blueC", "\\textcolor{##63d9ea}{#1}");
w("\\blueD", "\\textcolor{##11accd}{#1}");
w("\\blueE", "\\textcolor{##0c7f99}{#1}");
w("\\tealA", "\\textcolor{##94fff5}{#1}");
w("\\tealB", "\\textcolor{##26edd5}{#1}");
w("\\tealC", "\\textcolor{##01d1c1}{#1}");
w("\\tealD", "\\textcolor{##01a995}{#1}");
w("\\tealE", "\\textcolor{##208170}{#1}");
w("\\greenA", "\\textcolor{##b6ffb0}{#1}");
w("\\greenB", "\\textcolor{##8af281}{#1}");
w("\\greenC", "\\textcolor{##74cf70}{#1}");
w("\\greenD", "\\textcolor{##1fab54}{#1}");
w("\\greenE", "\\textcolor{##0d923f}{#1}");
w("\\goldA", "\\textcolor{##ffd0a9}{#1}");
w("\\goldB", "\\textcolor{##ffbb71}{#1}");
w("\\goldC", "\\textcolor{##ff9c39}{#1}");
w("\\goldD", "\\textcolor{##e07d10}{#1}");
w("\\goldE", "\\textcolor{##a75a05}{#1}");
w("\\redA", "\\textcolor{##fca9a9}{#1}");
w("\\redB", "\\textcolor{##ff8482}{#1}");
w("\\redC", "\\textcolor{##f9685d}{#1}");
w("\\redD", "\\textcolor{##e84d39}{#1}");
w("\\redE", "\\textcolor{##bc2612}{#1}");
w("\\maroonA", "\\textcolor{##ffbde0}{#1}");
w("\\maroonB", "\\textcolor{##ff92c6}{#1}");
w("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
w("\\maroonD", "\\textcolor{##ca337c}{#1}");
w("\\maroonE", "\\textcolor{##9e034e}{#1}");
w("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
w("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
w("\\purpleC", "\\textcolor{##aa87ff}{#1}");
w("\\purpleD", "\\textcolor{##7854ab}{#1}");
w("\\purpleE", "\\textcolor{##543b78}{#1}");
w("\\mintA", "\\textcolor{##f5f9e8}{#1}");
w("\\mintB", "\\textcolor{##edf2df}{#1}");
w("\\mintC", "\\textcolor{##e0e5cc}{#1}");
w("\\grayA", "\\textcolor{##f6f7f7}{#1}");
w("\\grayB", "\\textcolor{##f0f1f2}{#1}");
w("\\grayC", "\\textcolor{##e3e5e6}{#1}");
w("\\grayD", "\\textcolor{##d6d8da}{#1}");
w("\\grayE", "\\textcolor{##babec2}{#1}");
w("\\grayF", "\\textcolor{##888d93}{#1}");
w("\\grayG", "\\textcolor{##626569}{#1}");
w("\\grayH", "\\textcolor{##3b3e40}{#1}");
w("\\grayI", "\\textcolor{##21242c}{#1}");
w("\\kaBlue", "\\textcolor{##314453}{#1}");
w("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function A5() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Qa = A5();
function j6(r) {
  Qa = r;
}
const U6 = /[&<>"']/, qh = new RegExp(U6.source, "g"), G6 = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Nh = new RegExp(G6.source, "g"), Rh = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, eu = (r) => Rh[r];
function W0(r, e) {
  if (e) {
    if (U6.test(r))
      return r.replace(qh, eu);
  } else if (G6.test(r))
    return r.replace(Nh, eu);
  return r;
}
const Oh = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Ph(r) {
  return r.replace(Oh, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Hh = /(^|[^\[])\^/g;
function Ze(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const n = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(Hh, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function tu(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const Li = { exec: () => null };
function nu(r, e) {
  const t = r.replace(/\|/g, (i, l, o) => {
    let s = !1, u = l;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function Nl(r, e, t) {
  const n = r.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && r.charAt(n - a - 1) === e; )
    a++;
  return r.slice(0, n - a);
}
function Vh(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < r.length; n++)
    if (r[n] === "\\")
      n++;
    else if (r[n] === e[0])
      t++;
    else if (r[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function ru(r, e, t, n) {
  const a = e.href, i = e.title ? W0(e.title) : null, l = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: W0(l)
  };
}
function jh(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class g1 {
  // set by the lexer
  constructor(e) {
    nt(this, "options");
    nt(this, "rules");
    // set by the lexer
    nt(this, "lexer");
    this.options = e || Qa;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Nl(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = jh(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = Nl(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Nl(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (D) => " ".repeat(3 * D.length)), h = e.split(`
`, 1)[0], _ = 0;
        this.options.pedantic ? (_ = 2, s = d.trimStart()) : (_ = t[2].search(/[^ ]/), _ = _ > 4 ? 1 : _, s = d.slice(_), _ += t[1].length);
        let g = !1;
        if (!d && /^ *$/.test(h) && (o += h + `
`, e = e.substring(h.length + 1), c = !0), !c) {
          const D = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), k = new RegExp(`^ {0,${Math.min(3, _ - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), p = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:\`\`\`|~~~)`), S = new RegExp(`^ {0,${Math.min(3, _ - 1)}}#`);
          for (; e; ) {
            const E = e.split(`
`, 1)[0];
            if (h = E, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), p.test(h) || S.test(h) || D.test(h) || k.test(e))
              break;
            if (h.search(/[^ ]/) >= _ || !h.trim())
              s += `
` + h.slice(_);
            else {
              if (g || d.search(/[^ ]/) >= 4 || p.test(d) || S.test(d) || k.test(d))
                break;
              s += `
` + h;
            }
            !g && !h.trim() && (g = !0), o += E + `
`, e = e.substring(E.length + 1), d = h.slice(_);
          }
        }
        i.loose || (u ? i.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let b = null, y;
        this.options.gfm && (b = /^\[[ xX]\] /.exec(s), b && (y = b[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: o,
          task: !!b,
          checked: y,
          loose: !1,
          text: s,
          tokens: []
        }), i.raw += o;
      }
      i.items[i.items.length - 1].raw = o.trimEnd(), i.items[i.items.length - 1].text = s.trimEnd(), i.raw = i.raw.trimEnd();
      for (let c = 0; c < i.items.length; c++)
        if (this.lexer.state.top = !1, i.items[c].tokens = this.lexer.blockTokens(i.items[c].text, []), !i.loose) {
          const d = i.items[c].tokens.filter((_) => _.type === "space"), h = d.length > 0 && d.some((_) => /\n.*\n/.test(_.raw));
          i.loose = h;
        }
      if (i.loose)
        for (let c = 0; c < i.items.length; c++)
          i.items[c].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = nu(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const o of a)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of n)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of i)
        l.rows.push(nu(o, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: W0(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = Nl(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Vh(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), ru(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return ru(n, i, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let o, s, u = l, c = 0;
      const d = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = d.exec(t)) != null; ) {
        if (o = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !o)
          continue;
        if (s = [...o].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const h = [...a[0]][0].length, _ = e.slice(0, l + a.index + h + s);
        if (Math.min(l, s) % 2) {
          const b = _.slice(1, -1);
          return {
            type: "em",
            raw: _,
            text: b,
            tokens: this.lexer.inlineTokens(b)
          };
        }
        const g = _.slice(2, -2);
        return {
          type: "strong",
          raw: _,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), i = /^ /.test(n) && / $/.test(n);
      return a && i && (n = n.substring(1, n.length - 1)), n = W0(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = W0(t[1]), a = "mailto:" + n) : (n = W0(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = W0(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = W0(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = W0(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Uh = /^(?: *(?:\n|$))+/, Gh = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Wh = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, nl = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Zh = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, W6 = /(?:[*+-]|\d{1,9}[.)])/, Z6 = Ze(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, W6).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), F5 = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Yh = /^[^\n]+/, C5 = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Xh = Ze(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", C5).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Kh = Ze(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, W6).getRegex(), U1 = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", x5 = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Jh = Ze("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", x5).replace("tag", U1).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Y6 = Ze(F5).replace("hr", nl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", U1).getRegex(), ed = Ze(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Y6).getRegex(), T5 = {
  blockquote: ed,
  code: Gh,
  def: Xh,
  fences: Wh,
  heading: Zh,
  hr: nl,
  html: Jh,
  lheading: Z6,
  list: Kh,
  newline: Uh,
  paragraph: Y6,
  table: Li,
  text: Yh
}, au = Ze("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", nl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", U1).getRegex(), td = {
  ...T5,
  table: au,
  paragraph: Ze(F5).replace("hr", nl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", au).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", U1).getRegex()
}, nd = {
  ...T5,
  html: Ze(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", x5).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Li,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Ze(F5).replace("hr", nl).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Z6).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, X6 = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, rd = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, K6 = /^( {2,}|\\)\n(?!\s*$)/, ad = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, rl = "\\p{P}\\p{S}", id = Ze(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, rl).getRegex(), ld = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, od = Ze(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, rl).getRegex(), sd = Ze("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, rl).getRegex(), ud = Ze("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, rl).getRegex(), cd = Ze(/\\([punct])/, "gu").replace(/punct/g, rl).getRegex(), hd = Ze(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), dd = Ze(x5).replace("(?:-->|$)", "-->").getRegex(), fd = Ze("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", dd).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), v1 = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, md = Ze(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", v1).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), J6 = Ze(/^!?\[(label)\]\[(ref)\]/).replace("label", v1).replace("ref", C5).getRegex(), ec = Ze(/^!?\[(ref)\](?:\[\])?/).replace("ref", C5).getRegex(), _d = Ze("reflink|nolink(?!\\()", "g").replace("reflink", J6).replace("nolink", ec).getRegex(), $5 = {
  _backpedal: Li,
  // only used for GFM url
  anyPunctuation: cd,
  autolink: hd,
  blockSkip: ld,
  br: K6,
  code: rd,
  del: Li,
  emStrongLDelim: od,
  emStrongRDelimAst: sd,
  emStrongRDelimUnd: ud,
  escape: X6,
  link: md,
  nolink: ec,
  punctuation: id,
  reflink: J6,
  reflinkSearch: _d,
  tag: fd,
  text: ad,
  url: Li
}, pd = {
  ...$5,
  link: Ze(/^!?\[(label)\]\((.*?)\)/).replace("label", v1).getRegex(),
  reflink: Ze(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", v1).getRegex()
}, Is = {
  ...$5,
  escape: Ze(X6).replace("])", "~|])").getRegex(),
  url: Ze(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, gd = {
  ...Is,
  br: Ze(K6).replace("{2,}", "*").getRegex(),
  text: Ze(Is.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Rl = {
  normal: T5,
  gfm: td,
  pedantic: nd
}, Si = {
  normal: $5,
  gfm: Is,
  breaks: gd,
  pedantic: pd
};
class rr {
  constructor(e) {
    nt(this, "tokens");
    nt(this, "options");
    nt(this, "state");
    nt(this, "tokenizer");
    nt(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Qa, this.options.tokenizer = this.options.tokenizer || new g1(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Rl.normal,
      inline: Si.normal
    };
    this.options.pedantic ? (t.block = Rl.pedantic, t.inline = Si.pedantic) : this.options.gfm && (t.block = Rl.gfm, this.options.breaks ? t.inline = Si.breaks : t.inline = Si.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Rl,
      inline: Si
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new rr(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new rr(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let n, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (n = o.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (i = e.substring(0, o + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = i.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, i, l = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const d = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((_) => {
            h = _.call({ lexer: this }, d), typeof h == "number" && h >= 0 && (c = Math.min(c, h));
          }), c < 1 / 0 && c >= 0 && (i = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(i)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class b1 {
  constructor(e) {
    nt(this, "options");
    this.options = e || Qa;
  }
  code(e, t, n) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + W0(a) + '">' + (n ? e : W0(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : W0(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", i = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = tu(e);
    if (a === null)
      return n;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + n + "</a>", i;
  }
  image(e, t, n) {
    const a = tu(e);
    if (a === null)
      return n;
    e = a;
    let i = `<img src="${e}" alt="${n}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class Q5 {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class ar {
  constructor(e) {
    nt(this, "options");
    nt(this, "renderer");
    nt(this, "textRenderer");
    this.options = e || Qa, this.options.renderer = this.options.renderer || new b1(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Q5();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new ar(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new ar(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += o || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, Ph(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let o = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const d = l.rows[c];
            s = "";
            for (let h = 0; h < d.length; h++)
              s += this.renderer.tablecell(this.parseInline(d[h].tokens), { header: !1, align: l.align[h] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const l = i, o = this.parse(l.tokens);
          n += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = i, o = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let d = 0; d < l.items.length; d++) {
            const h = l.items[d], _ = h.checked, g = h.task;
            let b = "";
            if (h.task) {
              const y = this.renderer.checkbox(!!_);
              u ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = y + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = y + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: y + " "
              }) : b += y + " ";
            }
            b += this.parse(h.tokens, u), c += this.renderer.listitem(b, g, !!_);
          }
          n += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const l = i;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          n += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = i;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class qi {
  constructor(e) {
    nt(this, "options");
    this.options = e || Qa;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
nt(qi, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Ta, Ls, tc;
class vd {
  constructor(...e) {
    r2(this, Ta);
    nt(this, "defaults", A5());
    nt(this, "options", this.setOptions);
    nt(this, "parse", vl(this, Ta, Ls).call(this, rr.lex, ar.parse));
    nt(this, "parseInline", vl(this, Ta, Ls).call(this, rr.lexInline, ar.parseInline));
    nt(this, "Parser", ar);
    nt(this, "Renderer", b1);
    nt(this, "TextRenderer", Q5);
    nt(this, "Lexer", rr);
    nt(this, "Tokenizer", g1);
    nt(this, "Hooks", qi);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const s of o.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          n = n.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : o.tokens && (n = n.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...o) {
            let s = i.renderer.apply(this, o);
            return s === !1 && (s = l.apply(this, o)), s;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), n.renderer) {
        const i = this.defaults.renderer || new b1(this.defaults);
        for (const l in n.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.renderer[o], u = i[o];
          i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d || "";
          };
        }
        a.renderer = i;
      }
      if (n.tokenizer) {
        const i = this.defaults.tokenizer || new g1(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, s = n.tokenizer[o], u = i[o];
          i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d;
          };
        }
        a.tokenizer = i;
      }
      if (n.hooks) {
        const i = this.defaults.hooks || new qi();
        for (const l in n.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.hooks[o], u = i[o];
          qi.passThroughHooks.has(l) ? i[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(i, c)).then((h) => u.call(i, h));
            const d = s.call(i, c);
            return u.call(i, d);
          } : i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d;
          };
        }
        a.hooks = i;
      }
      if (n.walkTokens) {
        const i = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(o) {
          let s = [];
          return s.push(l.call(this, o)), i && (s = s.concat(i.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return rr.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ar.parse(e, t ?? this.defaults);
  }
}
Ta = new WeakSet(), Ls = function(e, t) {
  return (n, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = vl(this, Ta, tc).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(o);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, tc = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + W0(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ea = new vd();
function We(r, e) {
  return Ea.parse(r, e);
}
We.options = We.setOptions = function(r) {
  return Ea.setOptions(r), We.defaults = Ea.defaults, j6(We.defaults), We;
};
We.getDefaults = A5;
We.defaults = Qa;
We.use = function(...r) {
  return Ea.use(...r), We.defaults = Ea.defaults, j6(We.defaults), We;
};
We.walkTokens = function(r, e) {
  return Ea.walkTokens(r, e);
};
We.parseInline = Ea.parseInline;
We.Parser = ar;
We.parser = ar.parse;
We.Renderer = b1;
We.TextRenderer = Q5;
We.Lexer = rr;
We.lexer = rr.lex;
We.Tokenizer = g1;
We.Hooks = qi;
We.parse = We;
We.options;
We.setOptions;
We.use;
We.walkTokens;
We.parseInline;
ar.parse;
rr.lex;
const bd = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, yd = Object.hasOwnProperty;
class nc {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = wd(e, t === !0);
    const i = a;
    for (; yd.call(n.occurrences, a); )
      n.occurrences[i]++, a = i + "-" + n.occurrences[i];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function wd(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(bd, "").replace(/ /g, "-"));
}
new nc();
var iu = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, kd = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function k(p) {
          return p instanceof s ? new s(p.type, k(p.content), p.alias) : Array.isArray(p) ? p.map(k) : p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(k) {
          return Object.prototype.toString.call(k).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(k) {
          return k.__id || Object.defineProperty(k, "__id", { value: ++i }), k.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function k(p, S) {
          S = S || {};
          var E, F;
          switch (o.util.type(p)) {
            case "Object":
              if (F = o.util.objId(p), S[F])
                return S[F];
              E = /** @type {Record<string, any>} */
              {}, S[F] = E;
              for (var $ in p)
                p.hasOwnProperty($) && (E[$] = k(p[$], S));
              return (
                /** @type {any} */
                E
              );
            case "Array":
              return F = o.util.objId(p), S[F] ? S[F] : (E = [], S[F] = E, /** @type {Array} */
              /** @type {any} */
              p.forEach(function(B, T) {
                E[T] = k(B, S);
              }), /** @type {any} */
              E);
            default:
              return p;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(k) {
          for (; k; ) {
            var p = a.exec(k.className);
            if (p)
              return p[1].toLowerCase();
            k = k.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(k, p) {
          k.className = k.className.replace(RegExp(a, "gi"), ""), k.classList.add("language-" + p);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (E) {
            var k = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(E.stack) || [])[1];
            if (k) {
              var p = document.getElementsByTagName("script");
              for (var S in p)
                if (p[S].src == k)
                  return p[S];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(k, p, S) {
          for (var E = "no-" + p; k; ) {
            var F = k.classList;
            if (F.contains(p))
              return !0;
            if (F.contains(E))
              return !1;
            k = k.parentElement;
          }
          return !!S;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(k, p) {
          var S = o.util.clone(o.languages[k]);
          for (var E in p)
            S[E] = p[E];
          return S;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(k, p, S, E) {
          E = E || /** @type {any} */
          o.languages;
          var F = E[k], $ = {};
          for (var B in F)
            if (F.hasOwnProperty(B)) {
              if (B == p)
                for (var T in S)
                  S.hasOwnProperty(T) && ($[T] = S[T]);
              S.hasOwnProperty(B) || ($[B] = F[B]);
            }
          var x = E[k];
          return E[k] = $, o.languages.DFS(o.languages, function(L, P) {
            P === x && L != k && (this[L] = $);
          }), $;
        },
        // Traverse a language definition with Depth First Search
        DFS: function k(p, S, E, F) {
          F = F || {};
          var $ = o.util.objId;
          for (var B in p)
            if (p.hasOwnProperty(B)) {
              S.call(p, B, p[B], E || B);
              var T = p[B], x = o.util.type(T);
              x === "Object" && !F[$(T)] ? (F[$(T)] = !0, k(T, S, null, F)) : x === "Array" && !F[$(T)] && (F[$(T)] = !0, k(T, S, B, F));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(k, p) {
        o.highlightAllUnder(document, k, p);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(k, p, S) {
        var E = {
          callback: S,
          container: k,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", E), E.elements = Array.prototype.slice.apply(E.container.querySelectorAll(E.selector)), o.hooks.run("before-all-elements-highlight", E);
        for (var F = 0, $; $ = E.elements[F++]; )
          o.highlightElement($, p === !0, E.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(k, p, S) {
        var E = o.util.getLanguage(k), F = o.languages[E];
        o.util.setLanguage(k, E);
        var $ = k.parentElement;
        $ && $.nodeName.toLowerCase() === "pre" && o.util.setLanguage($, E);
        var B = k.textContent, T = {
          element: k,
          language: E,
          grammar: F,
          code: B
        };
        function x(P) {
          T.highlightedCode = P, o.hooks.run("before-insert", T), T.element.innerHTML = T.highlightedCode, o.hooks.run("after-highlight", T), o.hooks.run("complete", T), S && S.call(T.element);
        }
        if (o.hooks.run("before-sanity-check", T), $ = T.element.parentElement, $ && $.nodeName.toLowerCase() === "pre" && !$.hasAttribute("tabindex") && $.setAttribute("tabindex", "0"), !T.code) {
          o.hooks.run("complete", T), S && S.call(T.element);
          return;
        }
        if (o.hooks.run("before-highlight", T), !T.grammar) {
          x(o.util.encode(T.code));
          return;
        }
        if (p && n.Worker) {
          var L = new Worker(o.filename);
          L.onmessage = function(P) {
            x(P.data);
          }, L.postMessage(JSON.stringify({
            language: T.language,
            code: T.code,
            immediateClose: !0
          }));
        } else
          x(o.highlight(T.code, T.grammar, T.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(k, p, S) {
        var E = {
          code: k,
          grammar: p,
          language: S
        };
        if (o.hooks.run("before-tokenize", E), !E.grammar)
          throw new Error('The language "' + E.language + '" has no grammar.');
        return E.tokens = o.tokenize(E.code, E.grammar), o.hooks.run("after-tokenize", E), s.stringify(o.util.encode(E.tokens), E.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(k, p) {
        var S = p.rest;
        if (S) {
          for (var E in S)
            p[E] = S[E];
          delete p.rest;
        }
        var F = new d();
        return h(F, F.head, k), c(k, F, p, F.head, 0), g(F);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(k, p) {
          var S = o.hooks.all;
          S[k] = S[k] || [], S[k].push(p);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(k, p) {
          var S = o.hooks.all[k];
          if (!(!S || !S.length))
            for (var E = 0, F; F = S[E++]; )
              F(p);
        }
      },
      Token: s
    };
    n.Prism = o;
    function s(k, p, S, E) {
      this.type = k, this.content = p, this.alias = S, this.length = (E || "").length | 0;
    }
    s.stringify = function k(p, S) {
      if (typeof p == "string")
        return p;
      if (Array.isArray(p)) {
        var E = "";
        return p.forEach(function(x) {
          E += k(x, S);
        }), E;
      }
      var F = {
        type: p.type,
        content: k(p.content, S),
        tag: "span",
        classes: ["token", p.type],
        attributes: {},
        language: S
      }, $ = p.alias;
      $ && (Array.isArray($) ? Array.prototype.push.apply(F.classes, $) : F.classes.push($)), o.hooks.run("wrap", F);
      var B = "";
      for (var T in F.attributes)
        B += " " + T + '="' + (F.attributes[T] || "").replace(/"/g, "&quot;") + '"';
      return "<" + F.tag + ' class="' + F.classes.join(" ") + '"' + B + ">" + F.content + "</" + F.tag + ">";
    };
    function u(k, p, S, E) {
      k.lastIndex = p;
      var F = k.exec(S);
      if (F && E && F[1]) {
        var $ = F[1].length;
        F.index += $, F[0] = F[0].slice($);
      }
      return F;
    }
    function c(k, p, S, E, F, $) {
      for (var B in S)
        if (!(!S.hasOwnProperty(B) || !S[B])) {
          var T = S[B];
          T = Array.isArray(T) ? T : [T];
          for (var x = 0; x < T.length; ++x) {
            if ($ && $.cause == B + "," + x)
              return;
            var L = T[x], P = L.inside, ae = !!L.lookbehind, R = !!L.greedy, ee = L.alias;
            if (R && !L.pattern.global) {
              var Z = L.pattern.toString().match(/[imsuy]*$/)[0];
              L.pattern = RegExp(L.pattern.source, Z + "g");
            }
            for (var ze = L.pattern || L, oe = E.next, ge = F; oe !== p.tail && !($ && ge >= $.reach); ge += oe.value.length, oe = oe.next) {
              var N = oe.value;
              if (p.length > k.length)
                return;
              if (!(N instanceof s)) {
                var H = 1, te;
                if (R) {
                  if (te = u(ze, ge, k, ae), !te || te.index >= k.length)
                    break;
                  var xe = te.index, he = te.index + te[0].length, Ie = ge;
                  for (Ie += oe.value.length; xe >= Ie; )
                    oe = oe.next, Ie += oe.value.length;
                  if (Ie -= oe.value.length, ge = Ie, oe.value instanceof s)
                    continue;
                  for (var z = oe; z !== p.tail && (Ie < he || typeof z.value == "string"); z = z.next)
                    H++, Ie += z.value.length;
                  H--, N = k.slice(ge, Ie), te.index -= ge;
                } else if (te = u(ze, 0, N, ae), !te)
                  continue;
                var xe = te.index, pe = te[0], Te = N.slice(0, xe), ot = N.slice(xe + pe.length), Ue = ge + N.length;
                $ && Ue > $.reach && ($.reach = Ue);
                var qe = oe.prev;
                Te && (qe = h(p, qe, Te), ge += Te.length), _(p, qe, H);
                var fe = new s(B, P ? o.tokenize(pe, P) : pe, ee, pe);
                if (oe = h(p, qe, fe), ot && h(p, oe, ot), H > 1) {
                  var tt = {
                    cause: B + "," + x,
                    reach: Ue
                  };
                  c(k, p, S, oe.prev, ge, tt), $ && tt.reach > $.reach && ($.reach = tt.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var k = { value: null, prev: null, next: null }, p = { value: null, prev: k, next: null };
      k.next = p, this.head = k, this.tail = p, this.length = 0;
    }
    function h(k, p, S) {
      var E = p.next, F = { value: S, prev: p, next: E };
      return p.next = F, E.prev = F, k.length++, F;
    }
    function _(k, p, S) {
      for (var E = p.next, F = 0; F < S && E !== k.tail; F++)
        E = E.next;
      p.next = E, E.prev = p, k.length -= F;
    }
    function g(k) {
      for (var p = [], S = k.head.next; S !== k.tail; )
        p.push(S.value), S = S.next;
      return p;
    }
    if (!n.document)
      return n.addEventListener && (o.disableWorkerMessageHandler || n.addEventListener("message", function(k) {
        var p = JSON.parse(k.data), S = p.language, E = p.code, F = p.immediateClose;
        n.postMessage(o.highlight(E, o.languages[S], S)), F && n.close();
      }, !1)), o;
    var b = o.util.currentScript();
    b && (o.filename = b.src, b.hasAttribute("data-manual") && (o.manual = !0));
    function y() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var D = document.readyState;
      D === "loading" || D === "interactive" && b && b.defer ? document.addEventListener("DOMContentLoaded", y) : window.requestAnimationFrame ? window.requestAnimationFrame(y) : window.setTimeout(y, 16);
    }
    return o;
  }(e);
  r.exports && (r.exports = t), typeof iu < "u" && (iu.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var i = n.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(b, y) {
      return "✖ Error " + b + " while fetching file: " + y;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", d = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function h(b, y, D) {
      var k = new XMLHttpRequest();
      k.open("GET", b, !0), k.onreadystatechange = function() {
        k.readyState == 4 && (k.status < 400 && k.responseText ? y(k.responseText) : k.status >= 400 ? D(a(k.status, k.statusText)) : D(i));
      }, k.send(null);
    }
    function _(b) {
      var y = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(b || "");
      if (y) {
        var D = Number(y[1]), k = y[2], p = y[3];
        return k ? p ? [D, Number(p)] : [D, void 0] : [D, D];
      }
    }
    t.hooks.add("before-highlightall", function(b) {
      b.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(b) {
      var y = (
        /** @type {HTMLPreElement} */
        b.element
      );
      if (y.matches(d)) {
        b.code = "", y.setAttribute(o, s);
        var D = y.appendChild(document.createElement("CODE"));
        D.textContent = n;
        var k = y.getAttribute("data-src"), p = b.language;
        if (p === "none") {
          var S = (/\.(\w+)$/.exec(k) || [, "none"])[1];
          p = l[S] || S;
        }
        t.util.setLanguage(D, p), t.util.setLanguage(y, p);
        var E = t.plugins.autoloader;
        E && E.loadLanguages(p), h(
          k,
          function(F) {
            y.setAttribute(o, u);
            var $ = _(y.getAttribute("data-range"));
            if ($) {
              var B = F.split(/\r\n?|\n/g), T = $[0], x = $[1] == null ? B.length : $[1];
              T < 0 && (T += B.length), T = Math.max(0, Math.min(T - 1, B.length)), x < 0 && (x += B.length), x = Math.max(0, Math.min(x, B.length)), F = B.slice(T, x).join(`
`), y.hasAttribute("data-start") || y.setAttribute("data-start", String(T + 1));
            }
            D.textContent = F, t.highlightElement(D);
          },
          function(F) {
            y.setAttribute(o, c), D.textContent = F;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(y) {
        for (var D = (y || document).querySelectorAll(d), k = 0, p; p = D[k++]; )
          t.highlightElement(p);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(kd);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = n.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = r.languages.bash[a[l]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
new nc();
const Dd = (r) => {
  const e = {};
  for (let t = 0, n = r.length; t < n; t++) {
    const a = r[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, Sd = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Ed = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Ad = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Dd([
  Object.fromEntries(Sd.map((r) => [r, ["*"]])),
  Object.fromEntries(Ed.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(Ad.map((r) => [r, ["math:*"]]))
]);
const {
  HtmlTagHydration: o$,
  SvelteComponent: s$,
  attr: u$,
  binding_callbacks: c$,
  children: h$,
  claim_element: d$,
  claim_html_tag: f$,
  detach: m$,
  element: _$,
  init: p$,
  insert_hydration: g$,
  noop: v$,
  safe_not_equal: b$,
  toggle_class: y$
} = window.__gradio__svelte__internal, { afterUpdate: w$ } = window.__gradio__svelte__internal, {
  SvelteComponent: k$,
  action_destroyer: D$,
  append_hydration: S$,
  attr: E$,
  check_outros: A$,
  children: F$,
  claim_component: C$,
  claim_element: x$,
  claim_space: T$,
  create_component: $$,
  destroy_component: Q$,
  detach: M$,
  element: B$,
  group_outros: z$,
  init: I$,
  insert_hydration: L$,
  mount_component: q$,
  safe_not_equal: N$,
  set_style: R$,
  space: O$,
  toggle_class: P$,
  transition_in: H$,
  transition_out: V$
} = window.__gradio__svelte__internal, { createEventDispatcher: j$ } = window.__gradio__svelte__internal;
function Ya(r) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; r > 1e3 && t < e.length - 1; )
    r /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(r) ? r : r.toFixed(1)) + n;
}
function s1() {
}
const Fd = (r) => r;
function Cd(r, e) {
  return r != r ? e == e : r !== e || r && typeof r == "object" || typeof r == "function";
}
const rc = typeof window < "u";
let lu = rc ? () => window.performance.now() : () => Date.now(), ac = rc ? (r) => requestAnimationFrame(r) : s1;
const ti = /* @__PURE__ */ new Set();
function ic(r) {
  ti.forEach((e) => {
    e.c(r) || (ti.delete(e), e.f());
  }), ti.size !== 0 && ac(ic);
}
function xd(r) {
  let e;
  return ti.size === 0 && ac(ic), {
    promise: new Promise((t) => {
      ti.add(e = { c: r, f: t });
    }),
    abort() {
      ti.delete(e);
    }
  };
}
function M5(r, { delay: e = 0, duration: t = 400, easing: n = Fd } = {}) {
  const a = +getComputedStyle(r).opacity;
  return {
    delay: e,
    duration: t,
    easing: n,
    css: (i) => `opacity: ${i * a}`
  };
}
const Pa = [];
function Td(r, e = s1) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(o) {
    if (Cd(r, o) && (r = o, t)) {
      const s = !Pa.length;
      for (const u of n)
        u[1](), Pa.push(u, r);
      if (s) {
        for (let u = 0; u < Pa.length; u += 2)
          Pa[u][0](Pa[u + 1]);
        Pa.length = 0;
      }
    }
  }
  function i(o) {
    a(o(r));
  }
  function l(o, s = s1) {
    const u = [o, s];
    return n.add(u), n.size === 1 && (t = e(a, i) || s1), o(r), () => {
      n.delete(u), n.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function ou(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function qs(r, e, t, n) {
  if (typeof t == "number" || ou(t)) {
    const a = n - t, i = (t - e) / (r.dt || 1 / 60), l = r.opts.stiffness * a, o = r.opts.damping * i, s = (l - o) * r.inv_mass, u = (i + s) * r.dt;
    return Math.abs(u) < r.opts.precision && Math.abs(a) < r.opts.precision ? n : (r.settled = !1, ou(t) ? new Date(t.getTime() + u) : t + u);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => qs(r, e[i], t[i], n[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = qs(r, e[i], t[i], n[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function su(r, e = {}) {
  const t = Td(r), { stiffness: n = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, o, s, u = r, c = r, d = 1, h = 0, _ = !1;
  function g(y, D = {}) {
    c = y;
    const k = s = {};
    return r == null || D.hard || b.stiffness >= 1 && b.damping >= 1 ? (_ = !0, l = lu(), u = y, t.set(r = c), Promise.resolve()) : (D.soft && (h = 1 / ((D.soft === !0 ? 0.5 : +D.soft) * 60), d = 0), o || (l = lu(), _ = !1, o = xd((p) => {
      if (_)
        return _ = !1, o = null, !1;
      d = Math.min(d + h, 1);
      const S = {
        inv_mass: d,
        opts: b,
        settled: !0,
        dt: (p - l) * 60 / 1e3
      }, E = qs(S, u, r, c);
      return l = p, u = r, t.set(r = E), S.settled && (o = null), !S.settled;
    })), new Promise((p) => {
      o.promise.then(() => {
        k === s && p();
      });
    }));
  }
  const b = {
    set: g,
    update: (y, D) => g(y(c, r), D),
    subscribe: t.subscribe,
    stiffness: n,
    damping: a,
    precision: i
  };
  return b;
}
const {
  SvelteComponent: $d,
  append_hydration: Sn,
  attr: Ne,
  children: ln,
  claim_element: Qd,
  claim_svg_element: En,
  component_subscribe: uu,
  detach: G0,
  element: Md,
  init: Bd,
  insert_hydration: zd,
  noop: cu,
  safe_not_equal: Id,
  set_style: Ol,
  svg_element: An,
  toggle_class: hu
} = window.__gradio__svelte__internal, { onMount: Ld } = window.__gradio__svelte__internal;
function qd(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h;
  return {
    c() {
      e = Md("div"), t = An("svg"), n = An("g"), a = An("path"), i = An("path"), l = An("path"), o = An("path"), s = An("g"), u = An("path"), c = An("path"), d = An("path"), h = An("path"), this.h();
    },
    l(_) {
      e = Qd(_, "DIV", { class: !0 });
      var g = ln(e);
      t = En(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var b = ln(t);
      n = En(b, "g", { style: !0 });
      var y = ln(n);
      a = En(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ln(a).forEach(G0), i = En(y, "path", { d: !0, fill: !0, class: !0 }), ln(i).forEach(G0), l = En(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ln(l).forEach(G0), o = En(y, "path", { d: !0, fill: !0, class: !0 }), ln(o).forEach(G0), y.forEach(G0), s = En(b, "g", { style: !0 });
      var D = ln(s);
      u = En(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ln(u).forEach(G0), c = En(D, "path", { d: !0, fill: !0, class: !0 }), ln(c).forEach(G0), d = En(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ln(d).forEach(G0), h = En(D, "path", { d: !0, fill: !0, class: !0 }), ln(h).forEach(G0), D.forEach(G0), b.forEach(G0), g.forEach(G0), this.h();
    },
    h() {
      Ne(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Ne(a, "fill", "#FF7C00"), Ne(a, "fill-opacity", "0.4"), Ne(a, "class", "svelte-43sxxs"), Ne(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Ne(i, "fill", "#FF7C00"), Ne(i, "class", "svelte-43sxxs"), Ne(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Ne(l, "fill", "#FF7C00"), Ne(l, "fill-opacity", "0.4"), Ne(l, "class", "svelte-43sxxs"), Ne(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Ne(o, "fill", "#FF7C00"), Ne(o, "class", "svelte-43sxxs"), Ol(n, "transform", "translate(" + /*$top*/
      r[1][0] + "px, " + /*$top*/
      r[1][1] + "px)"), Ne(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Ne(u, "fill", "#FF7C00"), Ne(u, "fill-opacity", "0.4"), Ne(u, "class", "svelte-43sxxs"), Ne(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Ne(c, "fill", "#FF7C00"), Ne(c, "class", "svelte-43sxxs"), Ne(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Ne(d, "fill", "#FF7C00"), Ne(d, "fill-opacity", "0.4"), Ne(d, "class", "svelte-43sxxs"), Ne(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Ne(h, "fill", "#FF7C00"), Ne(h, "class", "svelte-43sxxs"), Ol(s, "transform", "translate(" + /*$bottom*/
      r[2][0] + "px, " + /*$bottom*/
      r[2][1] + "px)"), Ne(t, "viewBox", "-1200 -1200 3000 3000"), Ne(t, "fill", "none"), Ne(t, "xmlns", "http://www.w3.org/2000/svg"), Ne(t, "class", "svelte-43sxxs"), Ne(e, "class", "svelte-43sxxs"), hu(
        e,
        "margin",
        /*margin*/
        r[0]
      );
    },
    m(_, g) {
      zd(_, e, g), Sn(e, t), Sn(t, n), Sn(n, a), Sn(n, i), Sn(n, l), Sn(n, o), Sn(t, s), Sn(s, u), Sn(s, c), Sn(s, d), Sn(s, h);
    },
    p(_, [g]) {
      g & /*$top*/
      2 && Ol(n, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), g & /*$bottom*/
      4 && Ol(s, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), g & /*margin*/
      1 && hu(
        e,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: cu,
    o: cu,
    d(_) {
      _ && G0(e);
    }
  };
}
function Nd(r, e, t) {
  let n, a;
  var i = this && this.__awaiter || function(_, g, b, y) {
    function D(k) {
      return k instanceof b ? k : new b(function(p) {
        p(k);
      });
    }
    return new (b || (b = Promise))(function(k, p) {
      function S($) {
        try {
          F(y.next($));
        } catch (B) {
          p(B);
        }
      }
      function E($) {
        try {
          F(y.throw($));
        } catch (B) {
          p(B);
        }
      }
      function F($) {
        $.done ? k($.value) : D($.value).then(S, E);
      }
      F((y = y.apply(_, g || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const o = su([0, 0]);
  uu(r, o, (_) => t(1, n = _));
  const s = su([0, 0]);
  uu(r, s, (_) => t(2, a = _));
  let u;
  function c() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function d() {
    return i(this, void 0, void 0, function* () {
      yield c(), u || d();
    });
  }
  function h() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), d();
    });
  }
  return Ld(() => (h(), () => u = !0)), r.$$set = (_) => {
    "margin" in _ && t(0, l = _.margin);
  }, [l, n, a, o, s];
}
class Rd extends $d {
  constructor(e) {
    super(), Bd(this, e, Nd, qd, Id, { margin: 0 });
  }
}
const {
  SvelteComponent: Od,
  append_hydration: ga,
  attr: Rn,
  binding_callbacks: du,
  check_outros: Ns,
  children: ir,
  claim_component: lc,
  claim_element: lr,
  claim_space: dn,
  claim_text: ft,
  create_component: oc,
  create_slot: sc,
  destroy_component: uc,
  destroy_each: cc,
  detach: le,
  element: or,
  empty: vn,
  ensure_array_like: y1,
  get_all_dirty_from_scope: hc,
  get_slot_changes: dc,
  group_outros: Rs,
  init: Pd,
  insert_hydration: _e,
  mount_component: fc,
  noop: Os,
  safe_not_equal: Hd,
  set_data: bn,
  set_style: Yr,
  space: fn,
  text: mt,
  toggle_class: un,
  transition_in: Nn,
  transition_out: sr,
  update_slot_base: mc
} = window.__gradio__svelte__internal, { tick: Vd } = window.__gradio__svelte__internal, { onDestroy: jd } = window.__gradio__svelte__internal, { createEventDispatcher: Ud } = window.__gradio__svelte__internal, Gd = (r) => ({}), fu = (r) => ({}), Wd = (r) => ({}), mu = (r) => ({});
function _u(r, e, t) {
  const n = r.slice();
  return n[41] = e[t], n[43] = t, n;
}
function pu(r, e, t) {
  const n = r.slice();
  return n[41] = e[t], n;
}
function Zd(r) {
  let e, t, n, a, i = (
    /*i18n*/
    r[1]("common.error") + ""
  ), l, o, s;
  t = new ym({
    props: {
      Icon: R7,
      label: (
        /*i18n*/
        r[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    r[32]
  );
  const u = (
    /*#slots*/
    r[30].error
  ), c = sc(
    u,
    r,
    /*$$scope*/
    r[29],
    fu
  );
  return {
    c() {
      e = or("div"), oc(t.$$.fragment), n = fn(), a = or("span"), l = mt(i), o = fn(), c && c.c(), this.h();
    },
    l(d) {
      e = lr(d, "DIV", { class: !0 });
      var h = ir(e);
      lc(t.$$.fragment, h), h.forEach(le), n = dn(d), a = lr(d, "SPAN", { class: !0 });
      var _ = ir(a);
      l = ft(_, i), _.forEach(le), o = dn(d), c && c.l(d), this.h();
    },
    h() {
      Rn(e, "class", "clear-status svelte-17v219f"), Rn(a, "class", "error svelte-17v219f");
    },
    m(d, h) {
      _e(d, e, h), fc(t, e, null), _e(d, n, h), _e(d, a, h), ga(a, l), _e(d, o, h), c && c.m(d, h), s = !0;
    },
    p(d, h) {
      const _ = {};
      h[0] & /*i18n*/
      2 && (_.label = /*i18n*/
      d[1]("common.clear")), t.$set(_), (!s || h[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      d[1]("common.error") + "") && bn(l, i), c && c.p && (!s || h[0] & /*$$scope*/
      536870912) && mc(
        c,
        u,
        d,
        /*$$scope*/
        d[29],
        s ? dc(
          u,
          /*$$scope*/
          d[29],
          h,
          Gd
        ) : hc(
          /*$$scope*/
          d[29]
        ),
        fu
      );
    },
    i(d) {
      s || (Nn(t.$$.fragment, d), Nn(c, d), s = !0);
    },
    o(d) {
      sr(t.$$.fragment, d), sr(c, d), s = !1;
    },
    d(d) {
      d && (le(e), le(n), le(a), le(o)), uc(t), c && c.d(d);
    }
  };
}
function Yd(r) {
  let e, t, n, a, i, l, o, s, u, c = (
    /*variant*/
    r[8] === "default" && /*show_eta_bar*/
    r[18] && /*show_progress*/
    r[6] === "full" && gu(r)
  );
  function d(p, S) {
    if (
      /*progress*/
      p[7]
    ) return Jd;
    if (
      /*queue_position*/
      p[2] !== null && /*queue_size*/
      p[3] !== void 0 && /*queue_position*/
      p[2] >= 0
    ) return Kd;
    if (
      /*queue_position*/
      p[2] === 0
    ) return Xd;
  }
  let h = d(r), _ = h && h(r), g = (
    /*timer*/
    r[5] && yu(r)
  );
  const b = [rf, nf], y = [];
  function D(p, S) {
    return (
      /*last_progress_level*/
      p[15] != null ? 0 : (
        /*show_progress*/
        p[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = D(r)) && (l = y[i] = b[i](r));
  let k = !/*timer*/
  r[5] && Fu(r);
  return {
    c() {
      c && c.c(), e = fn(), t = or("div"), _ && _.c(), n = fn(), g && g.c(), a = fn(), l && l.c(), o = fn(), k && k.c(), s = vn(), this.h();
    },
    l(p) {
      c && c.l(p), e = dn(p), t = lr(p, "DIV", { class: !0 });
      var S = ir(t);
      _ && _.l(S), n = dn(S), g && g.l(S), S.forEach(le), a = dn(p), l && l.l(p), o = dn(p), k && k.l(p), s = vn(), this.h();
    },
    h() {
      Rn(t, "class", "progress-text svelte-17v219f"), un(
        t,
        "meta-text-center",
        /*variant*/
        r[8] === "center"
      ), un(
        t,
        "meta-text",
        /*variant*/
        r[8] === "default"
      );
    },
    m(p, S) {
      c && c.m(p, S), _e(p, e, S), _e(p, t, S), _ && _.m(t, null), ga(t, n), g && g.m(t, null), _e(p, a, S), ~i && y[i].m(p, S), _e(p, o, S), k && k.m(p, S), _e(p, s, S), u = !0;
    },
    p(p, S) {
      /*variant*/
      p[8] === "default" && /*show_eta_bar*/
      p[18] && /*show_progress*/
      p[6] === "full" ? c ? c.p(p, S) : (c = gu(p), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), h === (h = d(p)) && _ ? _.p(p, S) : (_ && _.d(1), _ = h && h(p), _ && (_.c(), _.m(t, n))), /*timer*/
      p[5] ? g ? g.p(p, S) : (g = yu(p), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!u || S[0] & /*variant*/
      256) && un(
        t,
        "meta-text-center",
        /*variant*/
        p[8] === "center"
      ), (!u || S[0] & /*variant*/
      256) && un(
        t,
        "meta-text",
        /*variant*/
        p[8] === "default"
      );
      let E = i;
      i = D(p), i === E ? ~i && y[i].p(p, S) : (l && (Rs(), sr(y[E], 1, 1, () => {
        y[E] = null;
      }), Ns()), ~i ? (l = y[i], l ? l.p(p, S) : (l = y[i] = b[i](p), l.c()), Nn(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      p[5] ? k && (Rs(), sr(k, 1, 1, () => {
        k = null;
      }), Ns()) : k ? (k.p(p, S), S[0] & /*timer*/
      32 && Nn(k, 1)) : (k = Fu(p), k.c(), Nn(k, 1), k.m(s.parentNode, s));
    },
    i(p) {
      u || (Nn(l), Nn(k), u = !0);
    },
    o(p) {
      sr(l), sr(k), u = !1;
    },
    d(p) {
      p && (le(e), le(t), le(a), le(o), le(s)), c && c.d(p), _ && _.d(), g && g.d(), ~i && y[i].d(p), k && k.d(p);
    }
  };
}
function gu(r) {
  let e, t = `translateX(${/*eta_level*/
  (r[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = or("div"), this.h();
    },
    l(n) {
      e = lr(n, "DIV", { class: !0 }), ir(e).forEach(le), this.h();
    },
    h() {
      Rn(e, "class", "eta-bar svelte-17v219f"), Yr(e, "transform", t);
    },
    m(n, a) {
      _e(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Yr(e, "transform", t);
    },
    d(n) {
      n && le(e);
    }
  };
}
function Xd(r) {
  let e;
  return {
    c() {
      e = mt("processing |");
    },
    l(t) {
      e = ft(t, "processing |");
    },
    m(t, n) {
      _e(t, e, n);
    },
    p: Os,
    d(t) {
      t && le(e);
    }
  };
}
function Kd(r) {
  let e, t = (
    /*queue_position*/
    r[2] + 1 + ""
  ), n, a, i, l;
  return {
    c() {
      e = mt("queue: "), n = mt(t), a = mt("/"), i = mt(
        /*queue_size*/
        r[3]
      ), l = mt(" |");
    },
    l(o) {
      e = ft(o, "queue: "), n = ft(o, t), a = ft(o, "/"), i = ft(
        o,
        /*queue_size*/
        r[3]
      ), l = ft(o, " |");
    },
    m(o, s) {
      _e(o, e, s), _e(o, n, s), _e(o, a, s), _e(o, i, s), _e(o, l, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && bn(n, t), s[0] & /*queue_size*/
      8 && bn(
        i,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (le(e), le(n), le(a), le(i), le(l));
    }
  };
}
function Jd(r) {
  let e, t = y1(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = bu(pu(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = vn();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = vn();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      _e(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = y1(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = pu(a, t, l);
          n[l] ? n[l].p(o, i) : (n[l] = bu(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && le(e), cc(n, a);
    }
  };
}
function vu(r) {
  let e, t = (
    /*p*/
    r[41].unit + ""
  ), n, a, i = " ", l;
  function o(c, d) {
    return (
      /*p*/
      c[41].length != null ? tf : ef
    );
  }
  let s = o(r), u = s(r);
  return {
    c() {
      u.c(), e = fn(), n = mt(t), a = mt(" | "), l = mt(i);
    },
    l(c) {
      u.l(c), e = dn(c), n = ft(c, t), a = ft(c, " | "), l = ft(c, i);
    },
    m(c, d) {
      u.m(c, d), _e(c, e, d), _e(c, n, d), _e(c, a, d), _e(c, l, d);
    },
    p(c, d) {
      s === (s = o(c)) && u ? u.p(c, d) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[41].unit + "") && bn(n, t);
    },
    d(c) {
      c && (le(e), le(n), le(a), le(l)), u.d(c);
    }
  };
}
function ef(r) {
  let e = Ya(
    /*p*/
    r[41].index || 0
  ) + "", t;
  return {
    c() {
      t = mt(e);
    },
    l(n) {
      t = ft(n, e);
    },
    m(n, a) {
      _e(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = Ya(
        /*p*/
        n[41].index || 0
      ) + "") && bn(t, e);
    },
    d(n) {
      n && le(t);
    }
  };
}
function tf(r) {
  let e = Ya(
    /*p*/
    r[41].index || 0
  ) + "", t, n, a = Ya(
    /*p*/
    r[41].length
  ) + "", i;
  return {
    c() {
      t = mt(e), n = mt("/"), i = mt(a);
    },
    l(l) {
      t = ft(l, e), n = ft(l, "/"), i = ft(l, a);
    },
    m(l, o) {
      _e(l, t, o), _e(l, n, o), _e(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      128 && e !== (e = Ya(
        /*p*/
        l[41].index || 0
      ) + "") && bn(t, e), o[0] & /*progress*/
      128 && a !== (a = Ya(
        /*p*/
        l[41].length
      ) + "") && bn(i, a);
    },
    d(l) {
      l && (le(t), le(n), le(i));
    }
  };
}
function bu(r) {
  let e, t = (
    /*p*/
    r[41].index != null && vu(r)
  );
  return {
    c() {
      t && t.c(), e = vn();
    },
    l(n) {
      t && t.l(n), e = vn();
    },
    m(n, a) {
      t && t.m(n, a), _e(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[41].index != null ? t ? t.p(n, a) : (t = vu(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && le(e), t && t.d(n);
    }
  };
}
function yu(r) {
  let e, t = (
    /*eta*/
    r[0] ? `/${/*formatted_eta*/
    r[19]}` : ""
  ), n, a;
  return {
    c() {
      e = mt(
        /*formatted_timer*/
        r[20]
      ), n = mt(t), a = mt("s");
    },
    l(i) {
      e = ft(
        i,
        /*formatted_timer*/
        r[20]
      ), n = ft(i, t), a = ft(i, "s");
    },
    m(i, l) {
      _e(i, e, l), _e(i, n, l), _e(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && bn(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && bn(n, t);
    },
    d(i) {
      i && (le(e), le(n), le(a));
    }
  };
}
function nf(r) {
  let e, t;
  return e = new Rd({
    props: { margin: (
      /*variant*/
      r[8] === "default"
    ) }
  }), {
    c() {
      oc(e.$$.fragment);
    },
    l(n) {
      lc(e.$$.fragment, n);
    },
    m(n, a) {
      fc(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      n[8] === "default"), e.$set(i);
    },
    i(n) {
      t || (Nn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      sr(e.$$.fragment, n), t = !1;
    },
    d(n) {
      uc(e, n);
    }
  };
}
function rf(r) {
  let e, t, n, a, i, l = `${/*last_progress_level*/
  r[15] * 100}%`, o = (
    /*progress*/
    r[7] != null && wu(r)
  );
  return {
    c() {
      e = or("div"), t = or("div"), o && o.c(), n = fn(), a = or("div"), i = or("div"), this.h();
    },
    l(s) {
      e = lr(s, "DIV", { class: !0 });
      var u = ir(e);
      t = lr(u, "DIV", { class: !0 });
      var c = ir(t);
      o && o.l(c), c.forEach(le), n = dn(u), a = lr(u, "DIV", { class: !0 });
      var d = ir(a);
      i = lr(d, "DIV", { class: !0 }), ir(i).forEach(le), d.forEach(le), u.forEach(le), this.h();
    },
    h() {
      Rn(t, "class", "progress-level-inner svelte-17v219f"), Rn(i, "class", "progress-bar svelte-17v219f"), Yr(i, "width", l), Rn(a, "class", "progress-bar-wrap svelte-17v219f"), Rn(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      _e(s, e, u), ga(e, t), o && o.m(t, null), ga(e, n), ga(e, a), ga(a, i), r[31](i);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = wu(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Yr(i, "width", l);
    },
    i: Os,
    o: Os,
    d(s) {
      s && le(e), o && o.d(), r[31](null);
    }
  };
}
function wu(r) {
  let e, t = y1(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Au(_u(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = vn();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = vn();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      _e(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = y1(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = _u(a, t, l);
          n[l] ? n[l].p(o, i) : (n[l] = Au(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && le(e), cc(n, a);
    }
  };
}
function ku(r) {
  let e, t, n, a, i = (
    /*i*/
    r[43] !== 0 && af()
  ), l = (
    /*p*/
    r[41].desc != null && Du(r)
  ), o = (
    /*p*/
    r[41].desc != null && /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[43]
    ] != null && Su()
  ), s = (
    /*progress_level*/
    r[14] != null && Eu(r)
  );
  return {
    c() {
      i && i.c(), e = fn(), l && l.c(), t = fn(), o && o.c(), n = fn(), s && s.c(), a = vn();
    },
    l(u) {
      i && i.l(u), e = dn(u), l && l.l(u), t = dn(u), o && o.l(u), n = dn(u), s && s.l(u), a = vn();
    },
    m(u, c) {
      i && i.m(u, c), _e(u, e, c), l && l.m(u, c), _e(u, t, c), o && o.m(u, c), _e(u, n, c), s && s.m(u, c), _e(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[41].desc != null ? l ? l.p(u, c) : (l = Du(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[41].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[43]
      ] != null ? o || (o = Su(), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Eu(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (le(e), le(t), le(n), le(a)), i && i.d(u), l && l.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function af(r) {
  let e;
  return {
    c() {
      e = mt(" /");
    },
    l(t) {
      e = ft(t, " /");
    },
    m(t, n) {
      _e(t, e, n);
    },
    d(t) {
      t && le(e);
    }
  };
}
function Du(r) {
  let e = (
    /*p*/
    r[41].desc + ""
  ), t;
  return {
    c() {
      t = mt(e);
    },
    l(n) {
      t = ft(n, e);
    },
    m(n, a) {
      _e(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[41].desc + "") && bn(t, e);
    },
    d(n) {
      n && le(t);
    }
  };
}
function Su(r) {
  let e;
  return {
    c() {
      e = mt("-");
    },
    l(t) {
      e = ft(t, "-");
    },
    m(t, n) {
      _e(t, e, n);
    },
    d(t) {
      t && le(e);
    }
  };
}
function Eu(r) {
  let e = (100 * /*progress_level*/
  (r[14][
    /*i*/
    r[43]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = mt(e), n = mt("%");
    },
    l(a) {
      t = ft(a, e), n = ft(a, "%");
    },
    m(a, i) {
      _e(a, t, i), _e(a, n, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[43]
      ] || 0)).toFixed(1) + "") && bn(t, e);
    },
    d(a) {
      a && (le(t), le(n));
    }
  };
}
function Au(r) {
  let e, t = (
    /*p*/
    (r[41].desc != null || /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[43]
    ] != null) && ku(r)
  );
  return {
    c() {
      t && t.c(), e = vn();
    },
    l(n) {
      t && t.l(n), e = vn();
    },
    m(n, a) {
      t && t.m(n, a), _e(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[41].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[43]
      ] != null ? t ? t.p(n, a) : (t = ku(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && le(e), t && t.d(n);
    }
  };
}
function Fu(r) {
  let e, t, n, a;
  const i = (
    /*#slots*/
    r[30]["additional-loading-text"]
  ), l = sc(
    i,
    r,
    /*$$scope*/
    r[29],
    mu
  );
  return {
    c() {
      e = or("p"), t = mt(
        /*loading_text*/
        r[9]
      ), n = fn(), l && l.c(), this.h();
    },
    l(o) {
      e = lr(o, "P", { class: !0 });
      var s = ir(e);
      t = ft(
        s,
        /*loading_text*/
        r[9]
      ), s.forEach(le), n = dn(o), l && l.l(o), this.h();
    },
    h() {
      Rn(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      _e(o, e, s), ga(e, t), _e(o, n, s), l && l.m(o, s), a = !0;
    },
    p(o, s) {
      (!a || s[0] & /*loading_text*/
      512) && bn(
        t,
        /*loading_text*/
        o[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && mc(
        l,
        i,
        o,
        /*$$scope*/
        o[29],
        a ? dc(
          i,
          /*$$scope*/
          o[29],
          s,
          Wd
        ) : hc(
          /*$$scope*/
          o[29]
        ),
        mu
      );
    },
    i(o) {
      a || (Nn(l, o), a = !0);
    },
    o(o) {
      sr(l, o), a = !1;
    },
    d(o) {
      o && (le(e), le(n)), l && l.d(o);
    }
  };
}
function lf(r) {
  let e, t, n, a, i;
  const l = [Yd, Zd], o = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(r)) && (n = o[t] = l[t](r)), {
    c() {
      e = or("div"), n && n.c(), this.h();
    },
    l(u) {
      e = lr(u, "DIV", { class: !0 });
      var c = ir(e);
      n && n.l(c), c.forEach(le), this.h();
    },
    h() {
      Rn(e, "class", a = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-17v219f"), un(e, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden" || /*status*/
      r[4] == "streaming"), un(
        e,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), un(
        e,
        "generating",
        /*status*/
        r[4] === "generating" && /*show_progress*/
        r[6] === "full"
      ), un(
        e,
        "border",
        /*border*/
        r[12]
      ), Yr(
        e,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), Yr(
        e,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      _e(u, e, c), ~t && o[t].m(e, null), r[33](e), i = !0;
    },
    p(u, c) {
      let d = t;
      t = s(u), t === d ? ~t && o[t].p(u, c) : (n && (Rs(), sr(o[d], 1, 1, () => {
        o[d] = null;
      }), Ns()), ~t ? (n = o[t], n ? n.p(u, c) : (n = o[t] = l[t](u), n.c()), Nn(n, 1), n.m(e, null)) : n = null), (!i || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Rn(e, "class", a), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && un(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!i || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && un(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && un(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!i || c[0] & /*variant, show_progress, border*/
      4416) && un(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Yr(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Yr(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      i || (Nn(n), i = !0);
    },
    o(u) {
      sr(n), i = !1;
    },
    d(u) {
      u && le(e), ~t && o[t].d(), r[33](null);
    }
  };
}
var of = function(r, e, t, n) {
  function a(i) {
    return i instanceof t ? i : new t(function(l) {
      l(i);
    });
  }
  return new (t || (t = Promise))(function(i, l) {
    function o(c) {
      try {
        u(n.next(c));
      } catch (d) {
        l(d);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (d) {
        l(d);
      }
    }
    function u(c) {
      c.done ? i(c.value) : a(c.value).then(o, s);
    }
    u((n = n.apply(r, e || [])).next());
  });
};
let Pl = [], Vo = !1;
const sf = typeof window < "u", _c = sf ? window.requestAnimationFrame : (r) => {
};
function uf(r) {
  return of(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Pl.push(e), !Vo) Vo = !0;
      else return;
      yield Vd(), _c(() => {
        let n = [0, 0];
        for (let a = 0; a < Pl.length; a++) {
          const l = Pl[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Vo = !1, Pl = [];
      });
    }
  });
}
function cf(r, e, t) {
  let n, { $$slots: a = {}, $$scope: i } = e;
  this && this.__awaiter;
  const l = Ud();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: d } = e, { scroll_to_output: h = !1 } = e, { timer: _ = !0 } = e, { show_progress: g = "full" } = e, { message: b = null } = e, { progress: y = null } = e, { variant: D = "default" } = e, { loading_text: k = "Loading..." } = e, { absolute: p = !0 } = e, { translucent: S = !1 } = e, { border: E = !1 } = e, { autoscroll: F } = e, $, B = !1, T = 0, x = 0, L = null, P = null, ae = 0, R = null, ee, Z = null, ze = !0;
  const oe = () => {
    t(0, s = t(27, L = t(19, H = null))), t(25, T = performance.now()), t(26, x = 0), B = !0, ge();
  };
  function ge() {
    _c(() => {
      t(26, x = (performance.now() - T) / 1e3), B && ge();
    });
  }
  function N() {
    t(26, x = 0), t(0, s = t(27, L = t(19, H = null))), B && (B = !1);
  }
  jd(() => {
    B && N();
  });
  let H = null;
  function te(z) {
    du[z ? "unshift" : "push"](() => {
      Z = z, t(16, Z), t(7, y), t(14, R), t(15, ee);
    });
  }
  const he = () => {
    l("clear_status");
  };
  function Ie(z) {
    du[z ? "unshift" : "push"](() => {
      $ = z, t(13, $);
    });
  }
  return r.$$set = (z) => {
    "i18n" in z && t(1, o = z.i18n), "eta" in z && t(0, s = z.eta), "queue_position" in z && t(2, u = z.queue_position), "queue_size" in z && t(3, c = z.queue_size), "status" in z && t(4, d = z.status), "scroll_to_output" in z && t(22, h = z.scroll_to_output), "timer" in z && t(5, _ = z.timer), "show_progress" in z && t(6, g = z.show_progress), "message" in z && t(23, b = z.message), "progress" in z && t(7, y = z.progress), "variant" in z && t(8, D = z.variant), "loading_text" in z && t(9, k = z.loading_text), "absolute" in z && t(10, p = z.absolute), "translucent" in z && t(11, S = z.translucent), "border" in z && t(12, E = z.border), "autoscroll" in z && t(24, F = z.autoscroll), "$$scope" in z && t(29, i = z.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = L), s != null && L !== s && (t(28, P = (performance.now() - T) / 1e3 + s), t(19, H = P.toFixed(1)), t(27, L = s))), r.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ae = P === null || P <= 0 || !x ? null : Math.min(x / P, 1)), r.$$.dirty[0] & /*progress*/
    128 && y != null && t(18, ze = !1), r.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (y != null ? t(14, R = y.map((z) => {
      if (z.index != null && z.length != null)
        return z.index / z.length;
      if (z.progress != null)
        return z.progress;
    })) : t(14, R = null), R ? (t(15, ee = R[R.length - 1]), Z && (ee === 0 ? t(16, Z.style.transition = "0", Z) : t(16, Z.style.transition = "150ms", Z))) : t(15, ee = void 0)), r.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? oe() : N()), r.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && $ && h && (d === "pending" || d === "complete") && uf($, F), r.$$.dirty[0] & /*status, message*/
    8388624, r.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = x.toFixed(1));
  }, [
    s,
    o,
    u,
    c,
    d,
    _,
    g,
    y,
    D,
    k,
    p,
    S,
    E,
    $,
    R,
    ee,
    Z,
    ae,
    ze,
    H,
    n,
    l,
    h,
    b,
    F,
    T,
    x,
    L,
    P,
    i,
    a,
    te,
    he,
    Ie
  ];
}
class hf extends Od {
  constructor(e) {
    super(), Pd(
      this,
      e,
      cf,
      lf,
      Hd,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.4 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.4/LICENSE */
const {
  entries: pc,
  setPrototypeOf: Cu,
  isFrozen: df,
  getPrototypeOf: ff,
  getOwnPropertyDescriptor: mf
} = Object;
let {
  freeze: T0,
  seal: yn,
  create: gc
} = Object, {
  apply: Ps,
  construct: Hs
} = typeof Reflect < "u" && Reflect;
T0 || (T0 = function(e) {
  return e;
});
yn || (yn = function(e) {
  return e;
});
Ps || (Ps = function(e, t, n) {
  return e.apply(t, n);
});
Hs || (Hs = function(e, t) {
  return new e(...t);
});
const Hl = $0(Array.prototype.forEach), _f = $0(Array.prototype.lastIndexOf), xu = $0(Array.prototype.pop), Ei = $0(Array.prototype.push), pf = $0(Array.prototype.splice), u1 = $0(String.prototype.toLowerCase), jo = $0(String.prototype.toString), Tu = $0(String.prototype.match), Ai = $0(String.prototype.replace), gf = $0(String.prototype.indexOf), vf = $0(String.prototype.trim), zn = $0(Object.prototype.hasOwnProperty), k0 = $0(RegExp.prototype.test), Fi = bf(TypeError);
function $0(r) {
  return function(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return Ps(r, e, n);
  };
}
function bf(r) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return Hs(r, t);
  };
}
function $e(r, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : u1;
  Cu && Cu(r, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (df(e) || (e[n] = i), a = i);
    }
    r[a] = !0;
  }
  return r;
}
function yf(r) {
  for (let e = 0; e < r.length; e++)
    zn(r, e) || (r[e] = null);
  return r;
}
function _a(r) {
  const e = gc(null);
  for (const [t, n] of pc(r))
    zn(r, t) && (Array.isArray(n) ? e[t] = yf(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = _a(n) : e[t] = n);
  return e;
}
function Ci(r, e) {
  for (; r !== null; ) {
    const n = mf(r, e);
    if (n) {
      if (n.get)
        return $0(n.get);
      if (typeof n.value == "function")
        return $0(n.value);
    }
    r = ff(r);
  }
  function t() {
    return null;
  }
  return t;
}
const $u = T0(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Uo = T0(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Go = T0(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), wf = T0(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Wo = T0(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), kf = T0(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Qu = T0(["#text"]), Mu = T0(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Zo = T0(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Bu = T0(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Vl = T0(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Df = yn(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Sf = yn(/<%[\w\W]*|[\w\W]*%>/gm), Ef = yn(/\$\{[\w\W]*/gm), Af = yn(/^data-[\-\w.\u00B7-\uFFFF]+$/), Ff = yn(/^aria-[\-\w]+$/), vc = yn(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Cf = yn(/^(?:\w+script|data):/i), xf = yn(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), bc = yn(/^html$/i), Tf = yn(/^[a-z][.\w]*(-[.\w]+)+$/i);
var zu = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Ff,
  ATTR_WHITESPACE: xf,
  CUSTOM_ELEMENT: Tf,
  DATA_ATTR: Af,
  DOCTYPE_NAME: bc,
  ERB_EXPR: Sf,
  IS_ALLOWED_URI: vc,
  IS_SCRIPT_OR_DATA: Cf,
  MUSTACHE_EXPR: Df,
  TMPLIT_EXPR: Ef
});
const xi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, $f = function() {
  return typeof window > "u" ? null : window;
}, Qf = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const i = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
}, Iu = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function yc() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : $f();
  const e = (ne) => yc(ne);
  if (e.version = "3.2.4", e.removed = [], !r || !r.document || r.document.nodeType !== xi.document || !r.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = r;
  const n = t, a = n.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: o,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = r.NamedNodeMap || r.MozNamedAttrMap,
    HTMLFormElement: d,
    DOMParser: h,
    trustedTypes: _
  } = r, g = s.prototype, b = Ci(g, "cloneNode"), y = Ci(g, "remove"), D = Ci(g, "nextSibling"), k = Ci(g, "childNodes"), p = Ci(g, "parentNode");
  if (typeof l == "function") {
    const ne = t.createElement("template");
    ne.content && ne.content.ownerDocument && (t = ne.content.ownerDocument);
  }
  let S, E = "";
  const {
    implementation: F,
    createNodeIterator: $,
    createDocumentFragment: B,
    getElementsByTagName: T
  } = t, {
    importNode: x
  } = n;
  let L = Iu();
  e.isSupported = typeof pc == "function" && typeof p == "function" && F && F.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: P,
    ERB_EXPR: ae,
    TMPLIT_EXPR: R,
    DATA_ATTR: ee,
    ARIA_ATTR: Z,
    IS_SCRIPT_OR_DATA: ze,
    ATTR_WHITESPACE: oe,
    CUSTOM_ELEMENT: ge
  } = zu;
  let {
    IS_ALLOWED_URI: N
  } = zu, H = null;
  const te = $e({}, [...$u, ...Uo, ...Go, ...Wo, ...Qu]);
  let he = null;
  const Ie = $e({}, [...Mu, ...Zo, ...Bu, ...Vl]);
  let z = Object.seal(gc(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), xe = null, pe = null, Te = !0, ot = !0, Ue = !1, qe = !0, fe = !1, tt = !0, Qe = !1, He = !1, ve = !1, G = !1, Ve = !1, K = !1, qt = !0, Oe = !1;
  const wn = "user-content-";
  let rn = !0, M0 = !1, B0 = {}, Nt = null;
  const Rt = $e({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Hn = null;
  const Ma = $e({}, ["audio", "video", "img", "source", "image", "track"]);
  let Vn = null;
  const Ba = $e({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), zr = "http://www.w3.org/1998/Math/MathML", q = "http://www.w3.org/2000/svg", v0 = "http://www.w3.org/1999/xhtml";
  let Ir = v0, ui = !1, ci = null;
  const eo = $e({}, [zr, q, v0], jo);
  let za = $e({}, ["mi", "mo", "mn", "ms", "mtext"]), Ia = $e({}, ["annotation-xml"]);
  const V = $e({}, ["title", "style", "font", "a", "script"]);
  let we = null;
  const rt = ["application/xhtml+xml", "text/html"], b0 = "text/html";
  let Fe = null, st = null;
  const jn = t.createElement("form"), pl = function(M) {
    return M instanceof RegExp || M instanceof Function;
  }, hi = function() {
    let M = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(st && st === M)) {
      if ((!M || typeof M != "object") && (M = {}), M = _a(M), we = // eslint-disable-next-line unicorn/prefer-includes
      rt.indexOf(M.PARSER_MEDIA_TYPE) === -1 ? b0 : M.PARSER_MEDIA_TYPE, Fe = we === "application/xhtml+xml" ? jo : u1, H = zn(M, "ALLOWED_TAGS") ? $e({}, M.ALLOWED_TAGS, Fe) : te, he = zn(M, "ALLOWED_ATTR") ? $e({}, M.ALLOWED_ATTR, Fe) : Ie, ci = zn(M, "ALLOWED_NAMESPACES") ? $e({}, M.ALLOWED_NAMESPACES, jo) : eo, Vn = zn(M, "ADD_URI_SAFE_ATTR") ? $e(_a(Ba), M.ADD_URI_SAFE_ATTR, Fe) : Ba, Hn = zn(M, "ADD_DATA_URI_TAGS") ? $e(_a(Ma), M.ADD_DATA_URI_TAGS, Fe) : Ma, Nt = zn(M, "FORBID_CONTENTS") ? $e({}, M.FORBID_CONTENTS, Fe) : Rt, xe = zn(M, "FORBID_TAGS") ? $e({}, M.FORBID_TAGS, Fe) : {}, pe = zn(M, "FORBID_ATTR") ? $e({}, M.FORBID_ATTR, Fe) : {}, B0 = zn(M, "USE_PROFILES") ? M.USE_PROFILES : !1, Te = M.ALLOW_ARIA_ATTR !== !1, ot = M.ALLOW_DATA_ATTR !== !1, Ue = M.ALLOW_UNKNOWN_PROTOCOLS || !1, qe = M.ALLOW_SELF_CLOSE_IN_ATTR !== !1, fe = M.SAFE_FOR_TEMPLATES || !1, tt = M.SAFE_FOR_XML !== !1, Qe = M.WHOLE_DOCUMENT || !1, G = M.RETURN_DOM || !1, Ve = M.RETURN_DOM_FRAGMENT || !1, K = M.RETURN_TRUSTED_TYPE || !1, ve = M.FORCE_BODY || !1, qt = M.SANITIZE_DOM !== !1, Oe = M.SANITIZE_NAMED_PROPS || !1, rn = M.KEEP_CONTENT !== !1, M0 = M.IN_PLACE || !1, N = M.ALLOWED_URI_REGEXP || vc, Ir = M.NAMESPACE || v0, za = M.MATHML_TEXT_INTEGRATION_POINTS || za, Ia = M.HTML_INTEGRATION_POINTS || Ia, z = M.CUSTOM_ELEMENT_HANDLING || {}, M.CUSTOM_ELEMENT_HANDLING && pl(M.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (z.tagNameCheck = M.CUSTOM_ELEMENT_HANDLING.tagNameCheck), M.CUSTOM_ELEMENT_HANDLING && pl(M.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (z.attributeNameCheck = M.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), M.CUSTOM_ELEMENT_HANDLING && typeof M.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (z.allowCustomizedBuiltInElements = M.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), fe && (ot = !1), Ve && (G = !0), B0 && (H = $e({}, Qu), he = [], B0.html === !0 && ($e(H, $u), $e(he, Mu)), B0.svg === !0 && ($e(H, Uo), $e(he, Zo), $e(he, Vl)), B0.svgFilters === !0 && ($e(H, Go), $e(he, Zo), $e(he, Vl)), B0.mathMl === !0 && ($e(H, Wo), $e(he, Bu), $e(he, Vl))), M.ADD_TAGS && (H === te && (H = _a(H)), $e(H, M.ADD_TAGS, Fe)), M.ADD_ATTR && (he === Ie && (he = _a(he)), $e(he, M.ADD_ATTR, Fe)), M.ADD_URI_SAFE_ATTR && $e(Vn, M.ADD_URI_SAFE_ATTR, Fe), M.FORBID_CONTENTS && (Nt === Rt && (Nt = _a(Nt)), $e(Nt, M.FORBID_CONTENTS, Fe)), rn && (H["#text"] = !0), Qe && $e(H, ["html", "head", "body"]), H.table && ($e(H, ["tbody"]), delete xe.tbody), M.TRUSTED_TYPES_POLICY) {
        if (typeof M.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Fi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof M.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Fi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        S = M.TRUSTED_TYPES_POLICY, E = S.createHTML("");
      } else
        S === void 0 && (S = Qf(_, a)), S !== null && typeof E == "string" && (E = S.createHTML(""));
      T0 && T0(M), st = M;
    }
  }, La = $e({}, [...Uo, ...Go, ...wf]), Un = $e({}, [...Wo, ...kf]), di = function(M) {
    let U = p(M);
    (!U || !U.tagName) && (U = {
      namespaceURI: Ir,
      tagName: "template"
    });
    const J = u1(M.tagName), at = u1(U.tagName);
    return ci[M.namespaceURI] ? M.namespaceURI === q ? U.namespaceURI === v0 ? J === "svg" : U.namespaceURI === zr ? J === "svg" && (at === "annotation-xml" || za[at]) : !!La[J] : M.namespaceURI === zr ? U.namespaceURI === v0 ? J === "math" : U.namespaceURI === q ? J === "math" && Ia[at] : !!Un[J] : M.namespaceURI === v0 ? U.namespaceURI === q && !Ia[at] || U.namespaceURI === zr && !za[at] ? !1 : !Un[J] && (V[J] || !La[J]) : !!(we === "application/xhtml+xml" && ci[M.namespaceURI]) : !1;
  }, Gn = function(M) {
    Ei(e.removed, {
      element: M
    });
    try {
      p(M).removeChild(M);
    } catch {
      y(M);
    }
  }, gl = function(M, U) {
    try {
      Ei(e.removed, {
        attribute: U.getAttributeNode(M),
        from: U
      });
    } catch {
      Ei(e.removed, {
        attribute: null,
        from: U
      });
    }
    if (U.removeAttribute(M), M === "is")
      if (G || Ve)
        try {
          Gn(U);
        } catch {
        }
      else
        try {
          U.setAttribute(M, "");
        } catch {
        }
  }, G5 = function(M) {
    let U = null, J = null;
    if (ve)
      M = "<remove></remove>" + M;
    else {
      const Ot = Tu(M, /^[\r\n\t ]+/);
      J = Ot && Ot[0];
    }
    we === "application/xhtml+xml" && Ir === v0 && (M = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + M + "</body></html>");
    const at = S ? S.createHTML(M) : M;
    if (Ir === v0)
      try {
        U = new h().parseFromString(at, we);
      } catch {
      }
    if (!U || !U.documentElement) {
      U = F.createDocument(Ir, "template", null);
      try {
        U.documentElement.innerHTML = ui ? E : at;
      } catch {
      }
    }
    const t0 = U.body || U.documentElement;
    return M && J && t0.insertBefore(t.createTextNode(J), t0.childNodes[0] || null), Ir === v0 ? T.call(U, Qe ? "html" : "body")[0] : Qe ? U.documentElement : t0;
  }, W5 = function(M) {
    return $.call(
      M.ownerDocument || M,
      M,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, to = function(M) {
    return M instanceof d && (typeof M.nodeName != "string" || typeof M.textContent != "string" || typeof M.removeChild != "function" || !(M.attributes instanceof c) || typeof M.removeAttribute != "function" || typeof M.setAttribute != "function" || typeof M.namespaceURI != "string" || typeof M.insertBefore != "function" || typeof M.hasChildNodes != "function");
  }, Z5 = function(M) {
    return typeof o == "function" && M instanceof o;
  };
  function pr(ne, M, U) {
    Hl(ne, (J) => {
      J.call(e, M, U, st);
    });
  }
  const Y5 = function(M) {
    let U = null;
    if (pr(L.beforeSanitizeElements, M, null), to(M))
      return Gn(M), !0;
    const J = Fe(M.nodeName);
    if (pr(L.uponSanitizeElement, M, {
      tagName: J,
      allowedTags: H
    }), M.hasChildNodes() && !Z5(M.firstElementChild) && k0(/<[/\w]/g, M.innerHTML) && k0(/<[/\w]/g, M.textContent) || M.nodeType === xi.progressingInstruction || tt && M.nodeType === xi.comment && k0(/<[/\w]/g, M.data))
      return Gn(M), !0;
    if (!H[J] || xe[J]) {
      if (!xe[J] && K5(J) && (z.tagNameCheck instanceof RegExp && k0(z.tagNameCheck, J) || z.tagNameCheck instanceof Function && z.tagNameCheck(J)))
        return !1;
      if (rn && !Nt[J]) {
        const at = p(M) || M.parentNode, t0 = k(M) || M.childNodes;
        if (t0 && at) {
          const Ot = t0.length;
          for (let z0 = Ot - 1; z0 >= 0; --z0) {
            const Wn = b(t0[z0], !0);
            Wn.__removalCount = (M.__removalCount || 0) + 1, at.insertBefore(Wn, D(M));
          }
        }
      }
      return Gn(M), !0;
    }
    return M instanceof s && !di(M) || (J === "noscript" || J === "noembed" || J === "noframes") && k0(/<\/no(script|embed|frames)/i, M.innerHTML) ? (Gn(M), !0) : (fe && M.nodeType === xi.text && (U = M.textContent, Hl([P, ae, R], (at) => {
      U = Ai(U, at, " ");
    }), M.textContent !== U && (Ei(e.removed, {
      element: M.cloneNode()
    }), M.textContent = U)), pr(L.afterSanitizeElements, M, null), !1);
  }, X5 = function(M, U, J) {
    if (qt && (U === "id" || U === "name") && (J in t || J in jn))
      return !1;
    if (!(ot && !pe[U] && k0(ee, U))) {
      if (!(Te && k0(Z, U))) {
        if (!he[U] || pe[U]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(K5(M) && (z.tagNameCheck instanceof RegExp && k0(z.tagNameCheck, M) || z.tagNameCheck instanceof Function && z.tagNameCheck(M)) && (z.attributeNameCheck instanceof RegExp && k0(z.attributeNameCheck, U) || z.attributeNameCheck instanceof Function && z.attributeNameCheck(U)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            U === "is" && z.allowCustomizedBuiltInElements && (z.tagNameCheck instanceof RegExp && k0(z.tagNameCheck, J) || z.tagNameCheck instanceof Function && z.tagNameCheck(J)))
          ) return !1;
        } else if (!Vn[U]) {
          if (!k0(N, Ai(J, oe, ""))) {
            if (!((U === "src" || U === "xlink:href" || U === "href") && M !== "script" && gf(J, "data:") === 0 && Hn[M])) {
              if (!(Ue && !k0(ze, Ai(J, oe, "")))) {
                if (J)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, K5 = function(M) {
    return M !== "annotation-xml" && Tu(M, ge);
  }, J5 = function(M) {
    pr(L.beforeSanitizeAttributes, M, null);
    const {
      attributes: U
    } = M;
    if (!U || to(M))
      return;
    const J = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: he,
      forceKeepAttr: void 0
    };
    let at = U.length;
    for (; at--; ) {
      const t0 = U[at], {
        name: Ot,
        namespaceURI: z0,
        value: Wn
      } = t0, fi = Fe(Ot);
      let y0 = Ot === "value" ? Wn : vf(Wn);
      if (J.attrName = fi, J.attrValue = y0, J.keepAttr = !0, J.forceKeepAttr = void 0, pr(L.uponSanitizeAttribute, M, J), y0 = J.attrValue, Oe && (fi === "id" || fi === "name") && (gl(Ot, M), y0 = wn + y0), tt && k0(/((--!?|])>)|<\/(style|title)/i, y0)) {
        gl(Ot, M);
        continue;
      }
      if (J.forceKeepAttr || (gl(Ot, M), !J.keepAttr))
        continue;
      if (!qe && k0(/\/>/i, y0)) {
        gl(Ot, M);
        continue;
      }
      fe && Hl([P, ae, R], (t2) => {
        y0 = Ai(y0, t2, " ");
      });
      const e2 = Fe(M.nodeName);
      if (X5(e2, fi, y0)) {
        if (S && typeof _ == "object" && typeof _.getAttributeType == "function" && !z0)
          switch (_.getAttributeType(e2, fi)) {
            case "TrustedHTML": {
              y0 = S.createHTML(y0);
              break;
            }
            case "TrustedScriptURL": {
              y0 = S.createScriptURL(y0);
              break;
            }
          }
        try {
          z0 ? M.setAttributeNS(z0, Ot, y0) : M.setAttribute(Ot, y0), to(M) ? Gn(M) : xu(e.removed);
        } catch {
        }
      }
    }
    pr(L.afterSanitizeAttributes, M, null);
  }, s7 = function ne(M) {
    let U = null;
    const J = W5(M);
    for (pr(L.beforeSanitizeShadowDOM, M, null); U = J.nextNode(); )
      pr(L.uponSanitizeShadowNode, U, null), Y5(U), J5(U), U.content instanceof i && ne(U.content);
    pr(L.afterSanitizeShadowDOM, M, null);
  };
  return e.sanitize = function(ne) {
    let M = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, U = null, J = null, at = null, t0 = null;
    if (ui = !ne, ui && (ne = "<!-->"), typeof ne != "string" && !Z5(ne))
      if (typeof ne.toString == "function") {
        if (ne = ne.toString(), typeof ne != "string")
          throw Fi("dirty is not a string, aborting");
      } else
        throw Fi("toString is not a function");
    if (!e.isSupported)
      return ne;
    if (He || hi(M), e.removed = [], typeof ne == "string" && (M0 = !1), M0) {
      if (ne.nodeName) {
        const Wn = Fe(ne.nodeName);
        if (!H[Wn] || xe[Wn])
          throw Fi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (ne instanceof o)
      U = G5("<!---->"), J = U.ownerDocument.importNode(ne, !0), J.nodeType === xi.element && J.nodeName === "BODY" || J.nodeName === "HTML" ? U = J : U.appendChild(J);
    else {
      if (!G && !fe && !Qe && // eslint-disable-next-line unicorn/prefer-includes
      ne.indexOf("<") === -1)
        return S && K ? S.createHTML(ne) : ne;
      if (U = G5(ne), !U)
        return G ? null : K ? E : "";
    }
    U && ve && Gn(U.firstChild);
    const Ot = W5(M0 ? ne : U);
    for (; at = Ot.nextNode(); )
      Y5(at), J5(at), at.content instanceof i && s7(at.content);
    if (M0)
      return ne;
    if (G) {
      if (Ve)
        for (t0 = B.call(U.ownerDocument); U.firstChild; )
          t0.appendChild(U.firstChild);
      else
        t0 = U;
      return (he.shadowroot || he.shadowrootmode) && (t0 = x.call(n, t0, !0)), t0;
    }
    let z0 = Qe ? U.outerHTML : U.innerHTML;
    return Qe && H["!doctype"] && U.ownerDocument && U.ownerDocument.doctype && U.ownerDocument.doctype.name && k0(bc, U.ownerDocument.doctype.name) && (z0 = "<!DOCTYPE " + U.ownerDocument.doctype.name + `>
` + z0), fe && Hl([P, ae, R], (Wn) => {
      z0 = Ai(z0, Wn, " ");
    }), S && K ? S.createHTML(z0) : z0;
  }, e.setConfig = function() {
    let ne = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    hi(ne), He = !0;
  }, e.clearConfig = function() {
    st = null, He = !1;
  }, e.isValidAttribute = function(ne, M, U) {
    st || hi({});
    const J = Fe(ne), at = Fe(M);
    return X5(J, at, U);
  }, e.addHook = function(ne, M) {
    typeof M == "function" && Ei(L[ne], M);
  }, e.removeHook = function(ne, M) {
    if (M !== void 0) {
      const U = _f(L[ne], M);
      return U === -1 ? void 0 : pf(L[ne], U, 1)[0];
    }
    return xu(L[ne]);
  }, e.removeHooks = function(ne) {
    L[ne] = [];
  }, e.removeAllHooks = function() {
    L = Iu();
  }, e;
}
yc();
const {
  HtmlTagHydration: U$,
  SvelteComponent: G$,
  add_render_callback: W$,
  append_hydration: Z$,
  attr: Y$,
  bubble: X$,
  check_outros: K$,
  children: J$,
  claim_component: eQ,
  claim_element: tQ,
  claim_html_tag: nQ,
  claim_space: rQ,
  claim_text: aQ,
  create_component: iQ,
  create_in_transition: lQ,
  create_out_transition: oQ,
  destroy_component: sQ,
  detach: uQ,
  element: cQ,
  get_svelte_dataset: hQ,
  group_outros: dQ,
  init: fQ,
  insert_hydration: mQ,
  listen: _Q,
  mount_component: pQ,
  run_all: gQ,
  safe_not_equal: vQ,
  set_data: bQ,
  space: yQ,
  stop_propagation: wQ,
  text: kQ,
  toggle_class: DQ,
  transition_in: SQ,
  transition_out: EQ
} = window.__gradio__svelte__internal, { createEventDispatcher: AQ, onMount: FQ } = window.__gradio__svelte__internal, {
  SvelteComponent: CQ,
  append_hydration: xQ,
  attr: TQ,
  bubble: $Q,
  check_outros: QQ,
  children: MQ,
  claim_component: BQ,
  claim_element: zQ,
  claim_space: IQ,
  create_animation: LQ,
  create_component: qQ,
  destroy_component: NQ,
  detach: RQ,
  element: OQ,
  ensure_array_like: PQ,
  fix_and_outro_and_destroy_block: HQ,
  fix_position: VQ,
  group_outros: jQ,
  init: UQ,
  insert_hydration: GQ,
  mount_component: WQ,
  noop: ZQ,
  safe_not_equal: YQ,
  set_style: XQ,
  space: KQ,
  transition_in: JQ,
  transition_out: eM,
  update_keyed_each: tM
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mf,
  attr: Bf,
  children: zf,
  claim_element: If,
  detach: Vs,
  element: Lf,
  empty: Lu,
  init: qf,
  insert_hydration: wc,
  noop: qu,
  safe_not_equal: Nf,
  set_style: Nu
} = window.__gradio__svelte__internal;
function Ru(r) {
  let e, t = `${/*time_limit*/
  r[0]}s`;
  return {
    c() {
      e = Lf("div"), this.h();
    },
    l(n) {
      e = If(n, "DIV", { class: !0 }), zf(e).forEach(Vs), this.h();
    },
    h() {
      Bf(e, "class", "streaming-bar svelte-ga0jj6"), Nu(e, "animation-duration", t);
    },
    m(n, a) {
      wc(n, e, a);
    },
    p(n, a) {
      a & /*time_limit*/
      1 && t !== (t = `${/*time_limit*/
      n[0]}s`) && Nu(e, "animation-duration", t);
    },
    d(n) {
      n && Vs(e);
    }
  };
}
function Rf(r) {
  let e, t = (
    /*time_limit*/
    r[0] && Ru(r)
  );
  return {
    c() {
      t && t.c(), e = Lu();
    },
    l(n) {
      t && t.l(n), e = Lu();
    },
    m(n, a) {
      t && t.m(n, a), wc(n, e, a);
    },
    p(n, [a]) {
      /*time_limit*/
      n[0] ? t ? t.p(n, a) : (t = Ru(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: qu,
    o: qu,
    d(n) {
      n && Vs(e), t && t.d(n);
    }
  };
}
function Of(r, e, t) {
  let { time_limit: n } = e;
  return r.$$set = (a) => {
    "time_limit" in a && t(0, n = a.time_limit);
  }, [n];
}
class kc extends Mf {
  constructor(e) {
    super(), qf(this, e, Of, Rf, Nf, { time_limit: 0 });
  }
}
const {
  SvelteComponent: nM,
  attr: rM,
  children: aM,
  claim_component: iM,
  claim_element: lM,
  create_component: oM,
  destroy_component: sM,
  detach: uM,
  element: cM,
  init: hM,
  insert_hydration: dM,
  mount_component: fM,
  safe_not_equal: mM,
  toggle_class: _M,
  transition_in: pM,
  transition_out: gM
} = window.__gradio__svelte__internal, {
  SvelteComponent: vM,
  assign: bM,
  attr: yM,
  children: wM,
  claim_component: kM,
  claim_element: DM,
  claim_space: SM,
  create_component: EM,
  destroy_component: AM,
  detach: FM,
  element: CM,
  get_spread_object: xM,
  get_spread_update: TM,
  init: $M,
  insert_hydration: QM,
  mount_component: MM,
  safe_not_equal: BM,
  space: zM,
  toggle_class: IM,
  transition_in: LM,
  transition_out: qM
} = window.__gradio__svelte__internal, {
  SvelteComponent: NM,
  attr: RM,
  children: OM,
  claim_component: PM,
  claim_element: HM,
  create_component: VM,
  destroy_component: jM,
  detach: UM,
  element: GM,
  init: WM,
  insert_hydration: ZM,
  mount_component: YM,
  safe_not_equal: XM,
  transition_in: KM,
  transition_out: JM
} = window.__gradio__svelte__internal, {
  SvelteComponent: eB,
  attr: tB,
  check_outros: nB,
  children: rB,
  claim_component: aB,
  claim_element: iB,
  claim_space: lB,
  create_component: oB,
  create_slot: sB,
  destroy_component: uB,
  detach: cB,
  element: hB,
  empty: dB,
  get_all_dirty_from_scope: fB,
  get_slot_changes: mB,
  group_outros: _B,
  init: pB,
  insert_hydration: gB,
  mount_component: vB,
  safe_not_equal: bB,
  space: yB,
  toggle_class: wB,
  transition_in: kB,
  transition_out: DB,
  update_slot_base: SB
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pf,
  append_hydration: Yo,
  attr: jl,
  children: Ou,
  claim_component: Hf,
  claim_element: Pu,
  claim_space: Vf,
  claim_text: jf,
  create_component: Uf,
  destroy_component: Gf,
  detach: Xo,
  element: Hu,
  init: Wf,
  insert_hydration: Zf,
  mount_component: Yf,
  safe_not_equal: Xf,
  set_data: Kf,
  space: Jf,
  text: em,
  toggle_class: Vr,
  transition_in: tm,
  transition_out: nm
} = window.__gradio__svelte__internal;
function rm(r) {
  let e, t, n, a, i, l;
  return n = new /*Icon*/
  r[1]({}), {
    c() {
      e = Hu("label"), t = Hu("span"), Uf(n.$$.fragment), a = Jf(), i = em(
        /*label*/
        r[0]
      ), this.h();
    },
    l(o) {
      e = Pu(o, "LABEL", {
        for: !0,
        "data-testid": !0,
        class: !0
      });
      var s = Ou(e);
      t = Pu(s, "SPAN", { class: !0 });
      var u = Ou(t);
      Hf(n.$$.fragment, u), u.forEach(Xo), a = Vf(s), i = jf(
        s,
        /*label*/
        r[0]
      ), s.forEach(Xo), this.h();
    },
    h() {
      jl(t, "class", "svelte-168uj4v"), jl(e, "for", ""), jl(e, "data-testid", "block-label"), jl(e, "class", "svelte-168uj4v"), Vr(e, "hide", !/*show_label*/
      r[2]), Vr(e, "sr-only", !/*show_label*/
      r[2]), Vr(
        e,
        "float",
        /*float*/
        r[4]
      ), Vr(
        e,
        "hide-label",
        /*disable*/
        r[3]
      );
    },
    m(o, s) {
      Zf(o, e, s), Yo(e, t), Yf(n, t, null), Yo(e, a), Yo(e, i), l = !0;
    },
    p(o, [s]) {
      (!l || s & /*label*/
      1) && Kf(
        i,
        /*label*/
        o[0]
      ), (!l || s & /*show_label*/
      4) && Vr(e, "hide", !/*show_label*/
      o[2]), (!l || s & /*show_label*/
      4) && Vr(e, "sr-only", !/*show_label*/
      o[2]), (!l || s & /*float*/
      16) && Vr(
        e,
        "float",
        /*float*/
        o[4]
      ), (!l || s & /*disable*/
      8) && Vr(
        e,
        "hide-label",
        /*disable*/
        o[3]
      );
    },
    i(o) {
      l || (tm(n.$$.fragment, o), l = !0);
    },
    o(o) {
      nm(n.$$.fragment, o), l = !1;
    },
    d(o) {
      o && Xo(e), Gf(n);
    }
  };
}
function am(r, e, t) {
  let { label: n = null } = e, { Icon: a } = e, { show_label: i = !0 } = e, { disable: l = !1 } = e, { float: o = !0 } = e;
  return r.$$set = (s) => {
    "label" in s && t(0, n = s.label), "Icon" in s && t(1, a = s.Icon), "show_label" in s && t(2, i = s.show_label), "disable" in s && t(3, l = s.disable), "float" in s && t(4, o = s.float);
  }, [n, a, i, l, o];
}
class G1 extends Pf {
  constructor(e) {
    super(), Wf(this, e, am, rm, Xf, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: im,
  append_hydration: js,
  attr: yr,
  bubble: lm,
  check_outros: om,
  children: Us,
  claim_component: sm,
  claim_element: Gs,
  claim_space: um,
  claim_text: cm,
  construct_svelte_component: Vu,
  create_component: ju,
  destroy_component: Uu,
  detach: Ni,
  element: Ws,
  group_outros: hm,
  init: dm,
  insert_hydration: Dc,
  listen: fm,
  mount_component: Gu,
  safe_not_equal: mm,
  set_data: _m,
  set_style: Ul,
  space: pm,
  text: gm,
  toggle_class: I0,
  transition_in: Wu,
  transition_out: Zu
} = window.__gradio__svelte__internal;
function Yu(r) {
  let e, t;
  return {
    c() {
      e = Ws("span"), t = gm(
        /*label*/
        r[1]
      ), this.h();
    },
    l(n) {
      e = Gs(n, "SPAN", { class: !0 });
      var a = Us(e);
      t = cm(
        a,
        /*label*/
        r[1]
      ), a.forEach(Ni), this.h();
    },
    h() {
      yr(e, "class", "svelte-vk34kx");
    },
    m(n, a) {
      Dc(n, e, a), js(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && _m(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Ni(e);
    }
  };
}
function vm(r) {
  let e, t, n, a, i, l, o, s = (
    /*show_label*/
    r[2] && Yu(r)
  );
  var u = (
    /*Icon*/
    r[0]
  );
  function c(d, h) {
    return {};
  }
  return u && (a = Vu(u, c())), {
    c() {
      e = Ws("button"), s && s.c(), t = pm(), n = Ws("div"), a && ju(a.$$.fragment), this.h();
    },
    l(d) {
      e = Gs(d, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var h = Us(e);
      s && s.l(h), t = um(h), n = Gs(h, "DIV", { class: !0 });
      var _ = Us(n);
      a && sm(a.$$.fragment, _), _.forEach(Ni), h.forEach(Ni), this.h();
    },
    h() {
      yr(n, "class", "svelte-vk34kx"), I0(
        n,
        "small",
        /*size*/
        r[4] === "small"
      ), I0(
        n,
        "large",
        /*size*/
        r[4] === "large"
      ), I0(
        n,
        "medium",
        /*size*/
        r[4] === "medium"
      ), e.disabled = /*disabled*/
      r[7], yr(
        e,
        "aria-label",
        /*label*/
        r[1]
      ), yr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), yr(
        e,
        "title",
        /*label*/
        r[1]
      ), yr(e, "class", "svelte-vk34kx"), I0(
        e,
        "pending",
        /*pending*/
        r[3]
      ), I0(
        e,
        "padded",
        /*padded*/
        r[5]
      ), I0(
        e,
        "highlight",
        /*highlight*/
        r[6]
      ), I0(
        e,
        "transparent",
        /*transparent*/
        r[9]
      ), Ul(e, "color", !/*disabled*/
      r[7] && /*_color*/
      r[11] ? (
        /*_color*/
        r[11]
      ) : "var(--block-label-text-color)"), Ul(e, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      ));
    },
    m(d, h) {
      Dc(d, e, h), s && s.m(e, null), js(e, t), js(e, n), a && Gu(a, n, null), i = !0, l || (o = fm(
        e,
        "click",
        /*click_handler*/
        r[13]
      ), l = !0);
    },
    p(d, [h]) {
      if (/*show_label*/
      d[2] ? s ? s.p(d, h) : (s = Yu(d), s.c(), s.m(e, t)) : s && (s.d(1), s = null), h & /*Icon*/
      1 && u !== (u = /*Icon*/
      d[0])) {
        if (a) {
          hm();
          const _ = a;
          Zu(_.$$.fragment, 1, 0, () => {
            Uu(_, 1);
          }), om();
        }
        u ? (a = Vu(u, c()), ju(a.$$.fragment), Wu(a.$$.fragment, 1), Gu(a, n, null)) : a = null;
      }
      (!i || h & /*size*/
      16) && I0(
        n,
        "small",
        /*size*/
        d[4] === "small"
      ), (!i || h & /*size*/
      16) && I0(
        n,
        "large",
        /*size*/
        d[4] === "large"
      ), (!i || h & /*size*/
      16) && I0(
        n,
        "medium",
        /*size*/
        d[4] === "medium"
      ), (!i || h & /*disabled*/
      128) && (e.disabled = /*disabled*/
      d[7]), (!i || h & /*label*/
      2) && yr(
        e,
        "aria-label",
        /*label*/
        d[1]
      ), (!i || h & /*hasPopup*/
      256) && yr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        d[8]
      ), (!i || h & /*label*/
      2) && yr(
        e,
        "title",
        /*label*/
        d[1]
      ), (!i || h & /*pending*/
      8) && I0(
        e,
        "pending",
        /*pending*/
        d[3]
      ), (!i || h & /*padded*/
      32) && I0(
        e,
        "padded",
        /*padded*/
        d[5]
      ), (!i || h & /*highlight*/
      64) && I0(
        e,
        "highlight",
        /*highlight*/
        d[6]
      ), (!i || h & /*transparent*/
      512) && I0(
        e,
        "transparent",
        /*transparent*/
        d[9]
      ), h & /*disabled, _color*/
      2176 && Ul(e, "color", !/*disabled*/
      d[7] && /*_color*/
      d[11] ? (
        /*_color*/
        d[11]
      ) : "var(--block-label-text-color)"), h & /*disabled, background*/
      1152 && Ul(e, "--bg-color", /*disabled*/
      d[7] ? "auto" : (
        /*background*/
        d[10]
      ));
    },
    i(d) {
      i || (a && Wu(a.$$.fragment, d), i = !0);
    },
    o(d) {
      a && Zu(a.$$.fragment, d), i = !1;
    },
    d(d) {
      d && Ni(e), s && s.d(), a && Uu(a), l = !1, o();
    }
  };
}
function bm(r, e, t) {
  let n, { Icon: a } = e, { label: i = "" } = e, { show_label: l = !1 } = e, { pending: o = !1 } = e, { size: s = "small" } = e, { padded: u = !0 } = e, { highlight: c = !1 } = e, { disabled: d = !1 } = e, { hasPopup: h = !1 } = e, { color: _ = "var(--block-label-text-color)" } = e, { transparent: g = !1 } = e, { background: b = "var(--block-background-fill)" } = e;
  function y(D) {
    lm.call(this, r, D);
  }
  return r.$$set = (D) => {
    "Icon" in D && t(0, a = D.Icon), "label" in D && t(1, i = D.label), "show_label" in D && t(2, l = D.show_label), "pending" in D && t(3, o = D.pending), "size" in D && t(4, s = D.size), "padded" in D && t(5, u = D.padded), "highlight" in D && t(6, c = D.highlight), "disabled" in D && t(7, d = D.disabled), "hasPopup" in D && t(8, h = D.hasPopup), "color" in D && t(12, _ = D.color), "transparent" in D && t(9, g = D.transparent), "background" in D && t(10, b = D.background);
  }, r.$$.update = () => {
    r.$$.dirty & /*highlight, color*/
    4160 && t(11, n = c ? "var(--color-accent)" : _);
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    c,
    d,
    h,
    g,
    b,
    n,
    _,
    y
  ];
}
class ym extends im {
  constructor(e) {
    super(), dm(this, e, bm, vm, mm, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: wm,
  append_hydration: km,
  attr: Ko,
  binding_callbacks: Dm,
  children: Xu,
  claim_element: Ku,
  create_slot: Sm,
  detach: Jo,
  element: Ju,
  get_all_dirty_from_scope: Em,
  get_slot_changes: Am,
  init: Fm,
  insert_hydration: Cm,
  safe_not_equal: xm,
  toggle_class: jr,
  transition_in: Tm,
  transition_out: $m,
  update_slot_base: Qm
} = window.__gradio__svelte__internal;
function Mm(r) {
  let e, t, n;
  const a = (
    /*#slots*/
    r[5].default
  ), i = Sm(
    a,
    r,
    /*$$scope*/
    r[4],
    null
  );
  return {
    c() {
      e = Ju("div"), t = Ju("div"), i && i.c(), this.h();
    },
    l(l) {
      e = Ku(l, "DIV", { class: !0, "aria-label": !0 });
      var o = Xu(e);
      t = Ku(o, "DIV", { class: !0 });
      var s = Xu(t);
      i && i.l(s), s.forEach(Jo), o.forEach(Jo), this.h();
    },
    h() {
      Ko(t, "class", "icon svelte-3w3rth"), Ko(e, "class", "empty svelte-3w3rth"), Ko(e, "aria-label", "Empty value"), jr(
        e,
        "small",
        /*size*/
        r[0] === "small"
      ), jr(
        e,
        "large",
        /*size*/
        r[0] === "large"
      ), jr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        r[1]
      ), jr(
        e,
        "small_parent",
        /*parent_height*/
        r[3]
      );
    },
    m(l, o) {
      Cm(l, e, o), km(e, t), i && i.m(t, null), r[6](e), n = !0;
    },
    p(l, [o]) {
      i && i.p && (!n || o & /*$$scope*/
      16) && Qm(
        i,
        a,
        l,
        /*$$scope*/
        l[4],
        n ? Am(
          a,
          /*$$scope*/
          l[4],
          o,
          null
        ) : Em(
          /*$$scope*/
          l[4]
        ),
        null
      ), (!n || o & /*size*/
      1) && jr(
        e,
        "small",
        /*size*/
        l[0] === "small"
      ), (!n || o & /*size*/
      1) && jr(
        e,
        "large",
        /*size*/
        l[0] === "large"
      ), (!n || o & /*unpadded_box*/
      2) && jr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        l[1]
      ), (!n || o & /*parent_height*/
      8) && jr(
        e,
        "small_parent",
        /*parent_height*/
        l[3]
      );
    },
    i(l) {
      n || (Tm(i, l), n = !0);
    },
    o(l) {
      $m(i, l), n = !1;
    },
    d(l) {
      l && Jo(e), i && i.d(l), r[6](null);
    }
  };
}
function Bm(r, e, t) {
  let n, { $$slots: a = {}, $$scope: i } = e, { size: l = "small" } = e, { unpadded_box: o = !1 } = e, s;
  function u(d) {
    var h;
    if (!d) return !1;
    const { height: _ } = d.getBoundingClientRect(), { height: g } = ((h = d.parentElement) === null || h === void 0 ? void 0 : h.getBoundingClientRect()) || { height: _ };
    return _ > g + 2;
  }
  function c(d) {
    Dm[d ? "unshift" : "push"](() => {
      s = d, t(2, s);
    });
  }
  return r.$$set = (d) => {
    "size" in d && t(0, l = d.size), "unpadded_box" in d && t(1, o = d.unpadded_box), "$$scope" in d && t(4, i = d.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*el*/
    4 && t(3, n = u(s));
  }, [l, o, s, n, i, a, c];
}
class Sc extends wm {
  constructor(e) {
    super(), Fm(this, e, Bm, Mm, xm, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: EB,
  claim_component: AB,
  create_component: FB,
  destroy_component: CB,
  init: xB,
  mount_component: TB,
  safe_not_equal: $B,
  transition_in: QB,
  transition_out: MB
} = window.__gradio__svelte__internal, { createEventDispatcher: BB } = window.__gradio__svelte__internal, zm = /^(#\s*)(.+)$/m;
function Im(r) {
  const e = r.trim(), t = e.match(zm);
  if (!t)
    return [!1, e || !1];
  const [n, , a] = t, i = a.trim();
  if (e === n)
    return [i, !1];
  const l = t.index !== void 0 ? t.index + n.length : 0, s = e.substring(l).trim() || !1;
  return [i, s];
}
const {
  SvelteComponent: Lm,
  append_hydration: ya,
  attr: Gi,
  check_outros: qm,
  children: Wi,
  claim_component: Ec,
  claim_element: Zi,
  claim_space: W1,
  claim_text: va,
  create_component: Ac,
  destroy_component: Fc,
  detach: g0,
  element: Yi,
  empty: w1,
  group_outros: Nm,
  init: Rm,
  insert_hydration: On,
  mount_component: Cc,
  safe_not_equal: Om,
  set_data: Xi,
  space: Z1,
  text: ba,
  toggle_class: e3,
  transition_in: k1,
  transition_out: D1
} = window.__gradio__svelte__internal;
function Pm(r) {
  let e, t;
  return e = new D9({}), {
    c() {
      Ac(e.$$.fragment);
    },
    l(n) {
      Ec(e.$$.fragment, n);
    },
    m(n, a) {
      Cc(e, n, a), t = !0;
    },
    i(n) {
      t || (k1(e.$$.fragment, n), t = !0);
    },
    o(n) {
      D1(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Fc(e, n);
    }
  };
}
function Hm(r) {
  let e, t;
  return e = new J7({}), {
    c() {
      Ac(e.$$.fragment);
    },
    l(n) {
      Ec(e.$$.fragment, n);
    },
    m(n, a) {
      Cc(e, n, a), t = !0;
    },
    i(n) {
      t || (k1(e.$$.fragment, n), t = !0);
    },
    o(n) {
      D1(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Fc(e, n);
    }
  };
}
function Vm(r) {
  let e = (
    /*i18n*/
    r[1](
      /*defs*/
      r[7][
        /*type*/
        r[0]
      ] || /*defs*/
      r[7].file
    ) + ""
  ), t, n, a, i = (
    /*mode*/
    r[3] !== "short" && t3(r)
  );
  return {
    c() {
      t = ba(e), n = Z1(), i && i.c(), a = w1();
    },
    l(l) {
      t = va(l, e), n = W1(l), i && i.l(l), a = w1();
    },
    m(l, o) {
      On(l, t, o), On(l, n, o), i && i.m(l, o), On(l, a, o);
    },
    p(l, o) {
      o & /*i18n, type*/
      3 && e !== (e = /*i18n*/
      l[1](
        /*defs*/
        l[7][
          /*type*/
          l[0]
        ] || /*defs*/
        l[7].file
      ) + "") && Xi(t, e), /*mode*/
      l[3] !== "short" ? i ? i.p(l, o) : (i = t3(l), i.c(), i.m(a.parentNode, a)) : i && (i.d(1), i = null);
    },
    d(l) {
      l && (g0(t), g0(n), g0(a)), i && i.d(l);
    }
  };
}
function jm(r) {
  let e, t, n = (
    /*heading*/
    r[6] && n3(r)
  ), a = (
    /*paragraph*/
    r[5] && r3(r)
  );
  return {
    c() {
      n && n.c(), e = Z1(), a && a.c(), t = w1();
    },
    l(i) {
      n && n.l(i), e = W1(i), a && a.l(i), t = w1();
    },
    m(i, l) {
      n && n.m(i, l), On(i, e, l), a && a.m(i, l), On(i, t, l);
    },
    p(i, l) {
      /*heading*/
      i[6] ? n ? n.p(i, l) : (n = n3(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null), /*paragraph*/
      i[5] ? a ? a.p(i, l) : (a = r3(i), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    d(i) {
      i && (g0(e), g0(t)), n && n.d(i), a && a.d(i);
    }
  };
}
function t3(r) {
  let e, t, n = (
    /*i18n*/
    r[1]("common.or") + ""
  ), a, i, l, o = (
    /*message*/
    (r[2] || /*i18n*/
    r[1]("upload_text.click_to_upload")) + ""
  ), s;
  return {
    c() {
      e = Yi("span"), t = ba("- "), a = ba(n), i = ba(" -"), l = Z1(), s = ba(o), this.h();
    },
    l(u) {
      e = Zi(u, "SPAN", { class: !0 });
      var c = Wi(e);
      t = va(c, "- "), a = va(c, n), i = va(c, " -"), c.forEach(g0), l = W1(u), s = va(u, o), this.h();
    },
    h() {
      Gi(e, "class", "or svelte-1xg7h5n");
    },
    m(u, c) {
      On(u, e, c), ya(e, t), ya(e, a), ya(e, i), On(u, l, c), On(u, s, c);
    },
    p(u, c) {
      c & /*i18n*/
      2 && n !== (n = /*i18n*/
      u[1]("common.or") + "") && Xi(a, n), c & /*message, i18n*/
      6 && o !== (o = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && Xi(s, o);
    },
    d(u) {
      u && (g0(e), g0(l), g0(s));
    }
  };
}
function n3(r) {
  let e, t;
  return {
    c() {
      e = Yi("h2"), t = ba(
        /*heading*/
        r[6]
      ), this.h();
    },
    l(n) {
      e = Zi(n, "H2", { class: !0 });
      var a = Wi(e);
      t = va(
        a,
        /*heading*/
        r[6]
      ), a.forEach(g0), this.h();
    },
    h() {
      Gi(e, "class", "svelte-1xg7h5n");
    },
    m(n, a) {
      On(n, e, a), ya(e, t);
    },
    p(n, a) {
      a & /*heading*/
      64 && Xi(
        t,
        /*heading*/
        n[6]
      );
    },
    d(n) {
      n && g0(e);
    }
  };
}
function r3(r) {
  let e, t;
  return {
    c() {
      e = Yi("p"), t = ba(
        /*paragraph*/
        r[5]
      ), this.h();
    },
    l(n) {
      e = Zi(n, "P", { class: !0 });
      var a = Wi(e);
      t = va(
        a,
        /*paragraph*/
        r[5]
      ), a.forEach(g0), this.h();
    },
    h() {
      Gi(e, "class", "svelte-1xg7h5n");
    },
    m(n, a) {
      On(n, e, a), ya(e, t);
    },
    p(n, a) {
      a & /*paragraph*/
      32 && Xi(
        t,
        /*paragraph*/
        n[5]
      );
    },
    d(n) {
      n && g0(e);
    }
  };
}
function Um(r) {
  let e, t, n, a, i, l;
  const o = [Hm, Pm], s = [];
  function u(_, g) {
    return (
      /*type*/
      _[0] === "clipboard" ? 0 : 1
    );
  }
  n = u(r), a = s[n] = o[n](r);
  function c(_, g) {
    return (
      /*heading*/
      _[6] || /*paragraph*/
      _[5] ? jm : Vm
    );
  }
  let d = c(r), h = d(r);
  return {
    c() {
      e = Yi("div"), t = Yi("span"), a.c(), i = Z1(), h.c(), this.h();
    },
    l(_) {
      e = Zi(_, "DIV", { class: !0 });
      var g = Wi(e);
      t = Zi(g, "SPAN", { class: !0 });
      var b = Wi(t);
      a.l(b), b.forEach(g0), i = W1(g), h.l(g), g.forEach(g0), this.h();
    },
    h() {
      Gi(t, "class", "icon-wrap svelte-1xg7h5n"), e3(
        t,
        "hovered",
        /*hovered*/
        r[4]
      ), Gi(e, "class", "wrap svelte-1xg7h5n");
    },
    m(_, g) {
      On(_, e, g), ya(e, t), s[n].m(t, null), ya(e, i), h.m(e, null), l = !0;
    },
    p(_, [g]) {
      let b = n;
      n = u(_), n !== b && (Nm(), D1(s[b], 1, 1, () => {
        s[b] = null;
      }), qm(), a = s[n], a || (a = s[n] = o[n](_), a.c()), k1(a, 1), a.m(t, null)), (!l || g & /*hovered*/
      16) && e3(
        t,
        "hovered",
        /*hovered*/
        _[4]
      ), d === (d = c(_)) && h ? h.p(_, g) : (h.d(1), h = d(_), h && (h.c(), h.m(e, null)));
    },
    i(_) {
      l || (k1(a), l = !0);
    },
    o(_) {
      D1(a), l = !1;
    },
    d(_) {
      _ && g0(e), s[n].d(), h.d();
    }
  };
}
function Gm(r, e, t) {
  let n, a, { type: i = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: s = "full" } = e, { hovered: u = !1 } = e, { placeholder: c = void 0 } = e;
  const d = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return r.$$set = (h) => {
    "type" in h && t(0, i = h.type), "i18n" in h && t(1, l = h.i18n), "message" in h && t(2, o = h.message), "mode" in h && t(3, s = h.mode), "hovered" in h && t(4, u = h.hovered), "placeholder" in h && t(8, c = h.placeholder);
  }, r.$$.update = () => {
    r.$$.dirty & /*placeholder*/
    256 && t(6, [n, a] = c ? Im(c) : [!1, !1], n, (t(5, a), t(8, c)));
  }, [i, l, o, s, u, a, n, d, c];
}
class Wm extends Lm {
  constructor(e) {
    super(), Rm(this, e, Gm, Um, Om, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4,
      placeholder: 8
    });
  }
}
const {
  SvelteComponent: zB,
  attr: IB,
  children: LB,
  claim_element: qB,
  create_slot: NB,
  detach: RB,
  element: OB,
  get_all_dirty_from_scope: PB,
  get_slot_changes: HB,
  init: VB,
  insert_hydration: jB,
  safe_not_equal: UB,
  toggle_class: GB,
  transition_in: WB,
  transition_out: ZB,
  update_slot_base: YB
} = window.__gradio__svelte__internal, {
  SvelteComponent: XB,
  append_hydration: KB,
  attr: JB,
  check_outros: ez,
  children: tz,
  claim_component: nz,
  claim_element: rz,
  claim_space: az,
  create_component: iz,
  destroy_component: lz,
  detach: oz,
  element: sz,
  empty: uz,
  group_outros: cz,
  init: hz,
  insert_hydration: dz,
  listen: fz,
  mount_component: mz,
  safe_not_equal: _z,
  space: pz,
  toggle_class: gz,
  transition_in: vz,
  transition_out: bz
} = window.__gradio__svelte__internal, {
  SvelteComponent: yz,
  attr: wz,
  children: kz,
  claim_element: Dz,
  create_slot: Sz,
  detach: Ez,
  element: Az,
  get_all_dirty_from_scope: Fz,
  get_slot_changes: Cz,
  init: xz,
  insert_hydration: Tz,
  null_to_empty: $z,
  safe_not_equal: Qz,
  transition_in: Mz,
  transition_out: Bz,
  update_slot_base: zz
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zm,
  append_hydration: Gl,
  attr: es,
  check_outros: Ym,
  children: ts,
  claim_component: Xm,
  claim_element: ns,
  claim_space: Km,
  claim_text: Jm,
  construct_svelte_component: a3,
  create_component: i3,
  destroy_component: l3,
  detach: Wl,
  element: rs,
  group_outros: e_,
  init: t_,
  insert_hydration: n_,
  listen: r_,
  mount_component: o3,
  safe_not_equal: a_,
  set_data: i_,
  set_style: l_,
  space: o_,
  text: s_,
  transition_in: s3,
  transition_out: u3
} = window.__gradio__svelte__internal, { createEventDispatcher: u_ } = window.__gradio__svelte__internal;
function c_(r) {
  let e, t, n, a, i, l, o, s, u;
  var c = (
    /*icon*/
    r[0]
  );
  function d(h, _) {
    return {};
  }
  return c && (a = a3(c, d())), {
    c() {
      e = rs("button"), t = rs("div"), n = rs("span"), a && i3(a.$$.fragment), i = o_(), l = s_(
        /*text*/
        r[1]
      ), this.h();
    },
    l(h) {
      e = ns(h, "BUTTON", { class: !0 });
      var _ = ts(e);
      t = ns(_, "DIV", { class: !0 });
      var g = ts(t);
      n = ns(g, "SPAN", { class: !0 });
      var b = ts(n);
      a && Xm(a.$$.fragment, b), b.forEach(Wl), i = Km(g), l = Jm(
        g,
        /*text*/
        r[1]
      ), g.forEach(Wl), _.forEach(Wl), this.h();
    },
    h() {
      es(n, "class", "icon-wrap svelte-1kt44zd"), es(t, "class", "wrap svelte-1kt44zd"), es(e, "class", "svelte-1kt44zd"), l_(e, "height", "100%");
    },
    m(h, _) {
      n_(h, e, _), Gl(e, t), Gl(t, n), a && o3(a, n, null), Gl(t, i), Gl(t, l), o = !0, s || (u = r_(
        e,
        "click",
        /*click_handler*/
        r[3]
      ), s = !0);
    },
    p(h, [_]) {
      if (_ & /*icon*/
      1 && c !== (c = /*icon*/
      h[0])) {
        if (a) {
          e_();
          const g = a;
          u3(g.$$.fragment, 1, 0, () => {
            l3(g, 1);
          }), Ym();
        }
        c ? (a = a3(c, d()), i3(a.$$.fragment), s3(a.$$.fragment, 1), o3(a, n, null)) : a = null;
      }
      (!o || _ & /*text*/
      2) && i_(
        l,
        /*text*/
        h[1]
      );
    },
    i(h) {
      o || (a && s3(a.$$.fragment, h), o = !0);
    },
    o(h) {
      a && u3(a.$$.fragment, h), o = !1;
    },
    d(h) {
      h && Wl(e), a && l3(a), s = !1, u();
    }
  };
}
function h_(r, e, t) {
  let n, { icon: a = k2 } = e;
  const i = u_(), l = () => i("click");
  return r.$$set = (o) => {
    "icon" in o && t(0, a = o.icon);
  }, r.$$.update = () => {
    r.$$.dirty & /*icon*/
    1 && t(1, n = a === k2 ? "Click to Access Webcam" : "Click to Access Microphone");
  }, [a, n, i, l];
}
class B5 extends Zm {
  constructor(e) {
    super(), t_(this, e, h_, c_, a_, { icon: 0 });
  }
}
function xc() {
  return navigator.mediaDevices.enumerateDevices();
}
function d_(r, e) {
  e.srcObject = r, e.muted = !0, e.play();
}
async function c3(r, e, t, n) {
  console.log(n);
  const a = (n == null ? void 0 : n.video) || n || {
    width: { ideal: 500 },
    height: { ideal: 500 }
  }, i = (n == null ? void 0 : n.audio) || n || {
    echoCancellation: !0,
    noiseSuppression: !0,
    autoGainControl: !0
  }, l = {
    video: t ? { deviceId: { exact: t }, ...a } : a,
    audio: typeof r == "object" ? { ...r, ...i } : r
  };
  return navigator.mediaDevices.getUserMedia(l).then((o) => (d_(o, e), o));
}
function Tc(r, e = "videoinput") {
  return r.filter(
    (n) => n.kind === e
  );
}
function f_(r, e) {
  return r.addEventListener(
    "icegatheringstatechange",
    () => {
      console.debug(r.iceGatheringState);
    },
    !1
  ), r.addEventListener(
    "iceconnectionstatechange",
    () => {
      console.debug(r.iceConnectionState);
    },
    !1
  ), r.addEventListener(
    "signalingstatechange",
    () => {
      console.debug(r.signalingState);
    },
    !1
  ), r.addEventListener("track", (t) => {
    console.debug("track event listener"), e && e.srcObject !== t.streams[0] && (console.debug("streams", t.streams), e.srcObject = t.streams[0], console.debug("node.srcOject", e.srcObject), t.track.kind === "audio" && (e.volume = 1, e.muted = !1, e.autoplay = !0, e.play().catch((n) => console.debug("Autoplay failed:", n))));
  }), r;
}
async function al(r, e, t, n, a, i = "video", l = () => {
}, o = {}, s = () => {
}, u = () => {
}) {
  e = f_(e, t);
  const c = e.createDataChannel("text");
  return c.onopen = () => {
    console.debug("Data channel is open"), c.send("handshake");
  }, c.onmessage = (d) => {
    console.debug("Received message:", d.data);
    let h;
    try {
      h = JSON.parse(d.data);
    } catch {
      console.debug("Error parsing JSON");
    }
    (d.data === "change" || d.data === "tick" || d.data === "stopword" || (h == null ? void 0 : h.type) === "warning" || (h == null ? void 0 : h.type) === "error" || (h == null ? void 0 : h.type) === "send_input" || (h == null ? void 0 : h.type) === "fetch_output" || (h == null ? void 0 : h.type) === "stopword") && l(h ?? d.data), s(h ?? d.data);
  }, r ? r.getTracks().forEach(async (d) => {
    console.debug("Track stream callback", d);
    const h = e.addTrack(d, r), g = { ...h.getParameters(), ...o };
    await h.setParameters(g), console.debug("sender params", h.getParameters());
  }) : (console.debug("Creating transceiver!"), e.addTransceiver(i, { direction: "recvonly" })), await __(e, n, a, u), [e, c];
}
function m_(r, e, t = () => {
}) {
  return new Promise((n, a) => {
    r(e).then((i) => {
      console.debug("data", i), (i == null ? void 0 : i.status) === "failed" && (t(i), console.debug("rejecting"), a("error")), n(i);
    });
  });
}
async function __(r, e, t, n = () => {
}) {
  return r.createOffer().then((a) => r.setLocalDescription(a)).then(() => new Promise((a) => {
    if (console.debug("ice gathering state", r.iceGatheringState), r.iceGatheringState === "complete")
      a();
    else {
      const i = () => {
        r.iceGatheringState === "complete" && (console.debug("ice complete"), r.removeEventListener("icegatheringstatechange", i), a());
      };
      r.addEventListener("icecandidate", () => {
        console.debug("ice candidate", r.iceGatheringState), r.iceGatheringState === "complete" && (r.removeEventListener("icegatheringstatechange", i), a());
      }), r.addEventListener("icegatheringstatechange", i), r.addEventListener("icecandidate", () => {
        console.debug("ice candidate", r.iceGatheringState), r.iceGatheringState === "complete" && (r.removeEventListener("icegatheringstatechange", i), a());
      }), navigator.userAgent.includes("Safari") && setTimeout(() => {
        a();
      }, 3e3);
    }
  })).then(() => {
    var a = r.localDescription;
    return m_(
      e,
      {
        sdp: a.sdp,
        type: a.type,
        webrtc_id: t
      },
      n
    );
  }).then((a) => a).then((a) => r.setRemoteDescription(a));
}
function _n(r) {
  console.debug("Stopping peer connection"), r.getTransceivers && r.getTransceivers().forEach((e) => {
    e.stop && e.stop();
  }), r.getSenders() && r.getSenders().forEach((e) => {
    console.log("sender", e), e.track && e.track.stop && e.track.stop();
  }), setTimeout(() => {
    r.close();
  }, 500);
}
const {
  SvelteComponent: p_,
  append_hydration: as,
  attr: Xr,
  check_outros: $c,
  children: ni,
  claim_component: g_,
  claim_element: wa,
  claim_space: v_,
  construct_svelte_component: h3,
  create_component: d3,
  destroy_component: f3,
  destroy_each: b_,
  detach: mn,
  element: ka,
  empty: m3,
  ensure_array_like: _3,
  group_outros: Qc,
  init: y_,
  insert_hydration: si,
  mount_component: p3,
  noop: Ri,
  safe_not_equal: w_,
  set_style: Z0,
  space: k_,
  src_url_equal: g3,
  transition_in: S1,
  transition_out: E1
} = window.__gradio__svelte__internal, { onDestroy: D_ } = window.__gradio__svelte__internal;
function v3(r, e, t) {
  const n = r.slice();
  return n[15] = e[t], n[17] = t, n;
}
function b3(r) {
  let e, t = _3(Array(3)), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = y3(v3(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = m3();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = m3();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      si(a, e, i);
    },
    p(a, i) {
      if (i & /*pulse_color, maxPulseScale, pulseIntensity*/
      84) {
        t = _3(Array(3));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = v3(a, t, l);
          n[l] ? n[l].p(o, i) : (n[l] = y3(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && mn(e), b_(n, a);
    }
  };
}
function y3(r) {
  let e;
  return {
    c() {
      e = ka("div"), this.h();
    },
    l(t) {
      e = wa(t, "DIV", { class: !0 }), ni(e).forEach(mn), this.h();
    },
    h() {
      Xr(e, "class", "pulse-ring svelte-h04ugr"), Z0(
        e,
        "background",
        /*pulse_color*/
        r[2]
      ), Z0(e, "animation-delay", `${/*i*/
      r[17] * 0.4}s`), Z0(
        e,
        "--max-scale",
        /*maxPulseScale*/
        r[6]
      ), Z0(e, "opacity", 0.5 * /*pulseIntensity*/
      r[4]);
    },
    m(t, n) {
      si(t, e, n);
    },
    p(t, n) {
      n & /*pulse_color*/
      4 && Z0(
        e,
        "background",
        /*pulse_color*/
        t[2]
      ), n & /*maxPulseScale*/
      64 && Z0(
        e,
        "--max-scale",
        /*maxPulseScale*/
        t[6]
      ), n & /*pulseIntensity*/
      16 && Z0(e, "opacity", 0.5 * /*pulseIntensity*/
      t[4]);
    },
    d(t) {
      t && mn(e);
    }
  };
}
function S_(r) {
  let e, t, n;
  var a = (
    /*icon*/
    r[0]
  );
  function i(l, o) {
    return {};
  }
  return a && (t = h3(a, i())), {
    c() {
      e = ka("div"), t && d3(t.$$.fragment);
    },
    l(l) {
      e = wa(l, "DIV", {});
      var o = ni(e);
      t && g_(t.$$.fragment, o), o.forEach(mn);
    },
    m(l, o) {
      si(l, e, o), t && p3(t, e, null), n = !0;
    },
    p(l, o) {
      if (o & /*icon*/
      1 && a !== (a = /*icon*/
      l[0])) {
        if (t) {
          Qc();
          const s = t;
          E1(s.$$.fragment, 1, 0, () => {
            f3(s, 1);
          }), $c();
        }
        a ? (t = h3(a, i()), d3(t.$$.fragment), S1(t.$$.fragment, 1), p3(t, e, null)) : t = null;
      }
    },
    i(l) {
      n || (t && S1(t.$$.fragment, l), n = !0);
    },
    o(l) {
      t && E1(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && mn(e), t && f3(t);
    }
  };
}
function E_(r) {
  let e;
  return {
    c() {
      e = ka("div");
    },
    l(t) {
      e = wa(t, "DIV", {}), ni(e).forEach(mn);
    },
    m(t, n) {
      si(t, e, n);
    },
    p: Ri,
    i: Ri,
    o: Ri,
    d(t) {
      t && mn(e);
    }
  };
}
function A_(r) {
  let e, t;
  return {
    c() {
      e = ka("img"), this.h();
    },
    l(n) {
      e = wa(n, "IMG", { src: !0, alt: !0, class: !0 }), this.h();
    },
    h() {
      g3(e.src, t = /*icon*/
      r[0]) || Xr(e, "src", t), Xr(e, "alt", "Audio visualization icon"), Xr(e, "class", "icon-image svelte-h04ugr"), Z0(e, "border-radius", `${/*icon_radius*/
      r[3]}%`);
    },
    m(n, a) {
      si(n, e, a);
    },
    p(n, a) {
      a & /*icon*/
      1 && !g3(e.src, t = /*icon*/
      n[0]) && Xr(e, "src", t), a & /*icon_radius*/
      8 && Z0(e, "border-radius", `${/*icon_radius*/
      n[3]}%`);
    },
    i: Ri,
    o: Ri,
    d(n) {
      n && mn(e);
    }
  };
}
function F_(r) {
  let e, t, n, a, i, l, o, s = (
    /*pulseIntensity*/
    r[4] > 0 && b3(r)
  );
  const u = [A_, E_, S_], c = [];
  function d(h, _) {
    return typeof /*icon*/
    h[0] == "string" ? 0 : (
      /*icon*/
      h[0] === void 0 ? 1 : 2
    );
  }
  return i = d(r), l = c[i] = u[i](r), {
    c() {
      e = ka("div"), t = ka("div"), s && s.c(), n = k_(), a = ka("div"), l.c(), this.h();
    },
    l(h) {
      e = wa(h, "DIV", { class: !0 });
      var _ = ni(e);
      t = wa(_, "DIV", { class: !0 });
      var g = ni(t);
      s && s.l(g), n = v_(g), a = wa(g, "DIV", { class: !0 });
      var b = ni(a);
      l.l(b), b.forEach(mn), g.forEach(mn), _.forEach(mn), this.h();
    },
    h() {
      Xr(a, "class", "gradio-webrtc-pulsing-icon svelte-h04ugr"), Z0(a, "transform", `scale(${/*pulseScale*/
      r[5]})`), Z0(
        a,
        "background",
        /*icon_button_color*/
        r[1]
      ), Xr(t, "class", "gradio-webrtc-pulsing-icon-container svelte-h04ugr"), Xr(e, "class", "gradio-webrtc-icon-wrapper svelte-h04ugr");
    },
    m(h, _) {
      si(h, e, _), as(e, t), s && s.m(t, null), as(t, n), as(t, a), c[i].m(a, null), o = !0;
    },
    p(h, [_]) {
      /*pulseIntensity*/
      h[4] > 0 ? s ? s.p(h, _) : (s = b3(h), s.c(), s.m(t, n)) : s && (s.d(1), s = null);
      let g = i;
      i = d(h), i === g ? c[i].p(h, _) : (Qc(), E1(c[g], 1, 1, () => {
        c[g] = null;
      }), $c(), l = c[i], l ? l.p(h, _) : (l = c[i] = u[i](h), l.c()), S1(l, 1), l.m(a, null)), _ & /*pulseScale*/
      32 && Z0(a, "transform", `scale(${/*pulseScale*/
      h[5]})`), _ & /*icon_button_color*/
      2 && Z0(
        a,
        "background",
        /*icon_button_color*/
        h[1]
      );
    },
    i(h) {
      o || (S1(l), o = !0);
    },
    o(h) {
      E1(l), o = !1;
    },
    d(h) {
      h && mn(e), s && s.d(), c[i].d();
    }
  };
}
function C_(r, e, t) {
  let n, { stream_state: a = "closed" } = e, { audio_source_callback: i } = e, { icon: l = void 0 } = e, { icon_button_color: o = "var(--color-accent)" } = e, { pulse_color: s = "var(--color-accent)" } = e, { icon_radius: u = 50 } = e, c, d, h, _, g = 1, b = 0;
  D_(() => {
    _ && cancelAnimationFrame(_), c && c.close();
  });
  function y() {
    c = new (window.AudioContext || window.webkitAudioContext)(), d = c.createAnalyser(), c.createMediaStreamSource(i()).connect(d), d.fftSize = 64, d.smoothingTimeConstant = 0.8, h = new Uint8Array(d.frequencyBinCount), D();
  }
  function D() {
    d.getByteFrequencyData(h);
    const p = Array.from(h).reduce((S, E) => S + E, 0) / h.length / 255;
    t(5, g = 1 + p * 0.15), t(4, b = p), _ = requestAnimationFrame(D);
  }
  return r.$$set = (k) => {
    "stream_state" in k && t(7, a = k.stream_state), "audio_source_callback" in k && t(8, i = k.audio_source_callback), "icon" in k && t(0, l = k.icon), "icon_button_color" in k && t(1, o = k.icon_button_color), "pulse_color" in k && t(2, s = k.pulse_color), "icon_radius" in k && t(3, u = k.icon_radius);
  }, r.$$.update = () => {
    r.$$.dirty & /*stream_state*/
    128 && a === "open" && y(), r.$$.dirty & /*pulseIntensity*/
    16 && t(6, n = 1 + b * 10);
  }, [
    l,
    o,
    s,
    u,
    b,
    g,
    n,
    a,
    i
  ];
}
class z5 extends p_ {
  constructor(e) {
    super(), y_(this, e, C_, F_, w_, {
      stream_state: 7,
      audio_source_callback: 8,
      icon: 0,
      icon_button_color: 1,
      pulse_color: 2,
      icon_radius: 3
    });
  }
}
const {
  SvelteComponent: x_,
  action_destroyer: T_,
  add_render_callback: $_,
  append_hydration: Et,
  attr: _t,
  binding_callbacks: Q_,
  check_outros: A1,
  children: Kt,
  claim_component: aa,
  claim_element: Jt,
  claim_space: ur,
  claim_text: il,
  create_component: ia,
  create_in_transition: M_,
  destroy_component: la,
  destroy_each: B_,
  detach: je,
  element: e0,
  empty: F1,
  ensure_array_like: w3,
  group_outros: C1,
  init: z_,
  insert_hydration: q0,
  listen: x1,
  mount_component: oa,
  noop: Mc,
  run_all: I_,
  safe_not_equal: L_,
  set_data: ll,
  set_input_value: Zs,
  set_style: q_,
  space: cr,
  stop_propagation: N_,
  text: ol,
  toggle_class: Zl,
  transition_in: xt,
  transition_out: Yt
} = window.__gradio__svelte__internal, { createEventDispatcher: R_, onMount: O_ } = window.__gradio__svelte__internal;
function k3(r, e, t) {
  const n = r.slice();
  return n[41] = e[t], n;
}
function D3(r) {
  let e, t, n;
  return t = new z5({
    props: {
      stream_state: (
        /*stream_state*/
        r[12]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        r[19]
      ),
      icon: (
        /*icon*/
        r[0] || h1
      ),
      icon_button_color: (
        /*icon_button_color*/
        r[1]
      ),
      pulse_color: (
        /*pulse_color*/
        r[3]
      ),
      icon_radius: (
        /*icon_radius*/
        r[2]
      )
    }
  }), {
    c() {
      e = e0("div"), ia(t.$$.fragment), this.h();
    },
    l(a) {
      e = Jt(a, "DIV", { class: !0 });
      var i = Kt(e);
      aa(t.$$.fragment, i), i.forEach(je), this.h();
    },
    h() {
      _t(e, "class", "audio-indicator svelte-1y5s2o2");
    },
    m(a, i) {
      q0(a, e, i), oa(t, e, null), n = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      4096 && (l.stream_state = /*stream_state*/
      a[12]), i[0] & /*icon*/
      1 && (l.icon = /*icon*/
      a[0] || h1), i[0] & /*icon_button_color*/
      2 && (l.icon_button_color = /*icon_button_color*/
      a[1]), i[0] & /*pulse_color*/
      8 && (l.pulse_color = /*pulse_color*/
      a[3]), i[0] & /*icon_radius*/
      4 && (l.icon_radius = /*icon_radius*/
      a[2]), t.$set(l);
    },
    i(a) {
      n || (xt(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Yt(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && je(e), la(t);
    }
  };
}
function P_(r) {
  let e, t, n, a, i, l, o, s, u, c;
  const d = [U_, j_, V_], h = [];
  function _(y, D) {
    return (
      /*stream_state*/
      y[12] === "waiting" ? 0 : (
        /*stream_state*/
        y[12] === "open" ? 1 : 2
      )
    );
  }
  n = _(r), a = h[n] = d[n](r);
  let g = G_(r), b = (
    /*options_open*/
    r[14] && /*selected_device*/
    r[10] && S3(r)
  );
  return {
    c() {
      e = e0("div"), t = e0("button"), a.c(), i = cr(), g && g.c(), l = cr(), b && b.c(), o = F1(), this.h();
    },
    l(y) {
      e = Jt(y, "DIV", { class: !0 });
      var D = Kt(e);
      t = Jt(D, "BUTTON", { "aria-label": !0, class: !0 });
      var k = Kt(t);
      a.l(k), k.forEach(je), i = ur(D), g && g.l(D), D.forEach(je), l = ur(y), b && b.l(y), o = F1(), this.h();
    },
    h() {
      _t(t, "aria-label", "start stream"), _t(t, "class", "svelte-1y5s2o2"), _t(e, "class", "button-wrap svelte-1y5s2o2");
    },
    m(y, D) {
      q0(y, e, D), Et(e, t), h[n].m(t, null), Et(e, i), g && g.m(e, null), q0(y, l, D), b && b.m(y, D), q0(y, o, D), s = !0, u || (c = x1(
        t,
        "click",
        /*start_webrtc*/
        r[17]
      ), u = !0);
    },
    p(y, D) {
      let k = n;
      n = _(y), n === k ? h[n].p(y, D) : (C1(), Yt(h[k], 1, 1, () => {
        h[k] = null;
      }), A1(), a = h[n], a ? a.p(y, D) : (a = h[n] = d[n](y), a.c()), xt(a, 1), a.m(t, null)), g.p(y, D), /*options_open*/
      y[14] && /*selected_device*/
      y[10] ? b ? (b.p(y, D), D[0] & /*options_open, selected_device*/
      17408 && xt(b, 1)) : (b = S3(y), b.c(), xt(b, 1), b.m(o.parentNode, o)) : b && (C1(), Yt(b, 1, 1, () => {
        b = null;
      }), A1());
    },
    i(y) {
      s || (xt(a), xt(g), xt(b), s = !0);
    },
    o(y) {
      Yt(a), Yt(g), Yt(b), s = !1;
    },
    d(y) {
      y && (je(e), je(l), je(o)), h[n].d(), g && g.d(), b && b.d(y), u = !1, c();
    }
  };
}
function H_(r) {
  let e, t, n, a;
  return t = new B5({}), t.$on(
    "click",
    /*click_handler*/
    r[32]
  ), {
    c() {
      e = e0("div"), ia(t.$$.fragment), this.h();
    },
    l(i) {
      e = Jt(i, "DIV", { title: !0, style: !0 });
      var l = Kt(e);
      aa(t.$$.fragment, l), l.forEach(je), this.h();
    },
    h() {
      _t(e, "title", "grant webcam access"), q_(e, "height", "100%");
    },
    m(i, l) {
      q0(i, e, l), oa(t, e, null), a = !0;
    },
    p: Mc,
    i(i) {
      a || (xt(t.$$.fragment, i), i && (n || $_(() => {
        n = M_(e, M5, { delay: 100, duration: 200 }), n.start();
      })), a = !0);
    },
    o(i) {
      Yt(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && je(e), la(t);
    }
  };
}
function V_(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[4].start || /*i18n*/
    r[6]("audio.record")) + ""
  ), l, o;
  return n = new L1({}), {
    c() {
      e = e0("div"), t = e0("div"), ia(n.$$.fragment), a = cr(), l = ol(i), this.h();
    },
    l(s) {
      e = Jt(s, "DIV", { class: !0 });
      var u = Kt(e);
      t = Jt(u, "DIV", { class: !0, title: !0 });
      var c = Kt(t);
      aa(n.$$.fragment, c), c.forEach(je), a = ur(u), l = il(u, i), u.forEach(je), this.h();
    },
    h() {
      _t(t, "class", "icon color-primary svelte-1y5s2o2"), _t(t, "title", "start recording"), _t(e, "class", "icon-with-text svelte-1y5s2o2");
    },
    m(s, u) {
      q0(s, e, u), Et(e, t), oa(n, t, null), Et(e, a), Et(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      80) && i !== (i = /*button_labels*/
      (s[4].start || /*i18n*/
      s[6]("audio.record")) + "") && ll(l, i);
    },
    i(s) {
      o || (xt(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Yt(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && je(e), la(n);
    }
  };
}
function j_(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[4].stop || /*i18n*/
    r[6]("audio.stop")) + ""
  ), l, o;
  return n = new g9({}), {
    c() {
      e = e0("div"), t = e0("div"), ia(n.$$.fragment), a = cr(), l = ol(i), this.h();
    },
    l(s) {
      e = Jt(s, "DIV", { class: !0 });
      var u = Kt(e);
      t = Jt(u, "DIV", { class: !0, title: !0 });
      var c = Kt(t);
      aa(n.$$.fragment, c), c.forEach(je), a = ur(u), l = il(u, i), u.forEach(je), this.h();
    },
    h() {
      _t(t, "class", "icon color-primary svelte-1y5s2o2"), _t(t, "title", "stop recording"), _t(e, "class", "icon-with-text svelte-1y5s2o2");
    },
    m(s, u) {
      q0(s, e, u), Et(e, t), oa(n, t, null), Et(e, a), Et(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      80) && i !== (i = /*button_labels*/
      (s[4].stop || /*i18n*/
      s[6]("audio.stop")) + "") && ll(l, i);
    },
    i(s) {
      o || (xt(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Yt(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && je(e), la(n);
    }
  };
}
function U_(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[4].waiting || /*i18n*/
    r[6]("audio.waiting")) + ""
  ), l, o;
  return n = new o5({}), {
    c() {
      e = e0("div"), t = e0("div"), ia(n.$$.fragment), a = cr(), l = ol(i), this.h();
    },
    l(s) {
      e = Jt(s, "DIV", { class: !0 });
      var u = Kt(e);
      t = Jt(u, "DIV", { class: !0, title: !0 });
      var c = Kt(t);
      aa(n.$$.fragment, c), c.forEach(je), a = ur(u), l = il(u, i), u.forEach(je), this.h();
    },
    h() {
      _t(t, "class", "icon color-primary svelte-1y5s2o2"), _t(t, "title", "spinner"), _t(e, "class", "icon-with-text svelte-1y5s2o2");
    },
    m(s, u) {
      q0(s, e, u), Et(e, t), oa(n, t, null), Et(e, a), Et(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      80) && i !== (i = /*button_labels*/
      (s[4].waiting || /*i18n*/
      s[6]("audio.waiting")) + "") && ll(l, i);
    },
    i(s) {
      o || (xt(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Yt(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && je(e), la(n);
    }
  };
}
function G_(r) {
  let e, t, n, a, i;
  return t = new q1({}), {
    c() {
      e = e0("button"), ia(t.$$.fragment), this.h();
    },
    l(l) {
      e = Jt(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = Kt(e);
      aa(t.$$.fragment, o), o.forEach(je), this.h();
    },
    h() {
      _t(e, "class", "icon svelte-1y5s2o2"), _t(e, "aria-label", "select input source");
    },
    m(l, o) {
      q0(l, e, o), oa(t, e, null), n = !0, a || (i = x1(
        e,
        "click",
        /*click_handler_1*/
        r[33]
      ), a = !0);
    },
    p: Mc,
    i(l) {
      n || (xt(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Yt(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && je(e), la(t), a = !1, i();
    }
  };
}
function S3(r) {
  let e, t, n, a, i, l, o;
  n = new q1({});
  function s(d, h) {
    return (
      /*available_video_devices*/
      d[9].length === 0 ? Z_ : W_
    );
  }
  let u = s(r), c = u(r);
  return {
    c() {
      e = e0("select"), t = e0("button"), ia(n.$$.fragment), a = cr(), c.c(), this.h();
    },
    l(d) {
      e = Jt(d, "SELECT", { class: !0, "aria-label": !0 });
      var h = Kt(e);
      t = Jt(h, "BUTTON", { class: !0 });
      var _ = Kt(t);
      aa(n.$$.fragment, _), a = ur(_), _.forEach(je), c.l(h), h.forEach(je), this.h();
    },
    h() {
      _t(t, "class", "inset-icon svelte-1y5s2o2"), _t(e, "class", "select-wrap svelte-1y5s2o2"), _t(e, "aria-label", "select source");
    },
    m(d, h) {
      q0(d, e, h), Et(e, t), oa(n, t, null), Et(t, a), c.m(e, null), i = !0, l || (o = [
        x1(t, "click", N_(
          /*click_handler_2*/
          r[34]
        )),
        T_(I5.call(
          null,
          e,
          /*handle_click_outside*/
          r[18]
        )),
        x1(
          e,
          "change",
          /*handle_device_change*/
          r[15]
        )
      ], l = !0);
    },
    p(d, h) {
      u === (u = s(d)) && c ? c.p(d, h) : (c.d(1), c = u(d), c && (c.c(), c.m(e, null)));
    },
    i(d) {
      i || (xt(n.$$.fragment, d), i = !0);
    },
    o(d) {
      Yt(n.$$.fragment, d), i = !1;
    },
    d(d) {
      d && je(e), la(n), c.d(), l = !1, I_(o);
    }
  };
}
function W_(r) {
  let e, t = w3(
    /*available_video_devices*/
    r[9]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = E3(k3(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = F1();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = F1();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      q0(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_video_devices, selected_device*/
      1536) {
        t = w3(
          /*available_video_devices*/
          a[9]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = k3(a, t, l);
          n[l] ? n[l].p(o, i) : (n[l] = E3(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && je(e), B_(n, a);
    }
  };
}
function Z_(r) {
  let e, t = (
    /*i18n*/
    r[6]("common.no_devices") + ""
  ), n;
  return {
    c() {
      e = e0("option"), n = ol(t), this.h();
    },
    l(a) {
      e = Jt(a, "OPTION", { class: !0 });
      var i = Kt(e);
      n = il(i, t), i.forEach(je), this.h();
    },
    h() {
      e.__value = "", Zs(e, e.__value), _t(e, "class", "svelte-1y5s2o2");
    },
    m(a, i) {
      q0(a, e, i), Et(e, n);
    },
    p(a, i) {
      i[0] & /*i18n*/
      64 && t !== (t = /*i18n*/
      a[6]("common.no_devices") + "") && ll(n, t);
    },
    d(a) {
      a && je(e);
    }
  };
}
function E3(r) {
  let e, t = (
    /*device*/
    r[41].label + ""
  ), n, a, i, l;
  return {
    c() {
      e = e0("option"), n = ol(t), a = cr(), this.h();
    },
    l(o) {
      e = Jt(o, "OPTION", { class: !0 });
      var s = Kt(e);
      n = il(s, t), a = ur(s), s.forEach(je), this.h();
    },
    h() {
      e.__value = i = /*device*/
      r[41].deviceId, Zs(e, e.__value), e.selected = l = /*selected_device*/
      r[10].deviceId === /*device*/
      r[41].deviceId, _t(e, "class", "svelte-1y5s2o2");
    },
    m(o, s) {
      q0(o, e, s), Et(e, n), Et(e, a);
    },
    p(o, s) {
      s[0] & /*available_video_devices*/
      512 && t !== (t = /*device*/
      o[41].label + "") && ll(n, t), s[0] & /*available_video_devices*/
      512 && i !== (i = /*device*/
      o[41].deviceId) && (e.__value = i, Zs(e, e.__value)), s[0] & /*selected_device, available_video_devices*/
      1536 && l !== (l = /*selected_device*/
      o[10].deviceId === /*device*/
      o[41].deviceId) && (e.selected = l);
    },
    d(o) {
      o && je(e);
    }
  };
}
function Y_(r) {
  let e, t, n, a, i, l, o, s, u;
  t = new kc({
    props: { time_limit: (
      /*_time_limit*/
      r[11]
    ) }
  });
  let c = (
    /*stream_state*/
    r[12] === "open" && /*include_audio*/
    r[5] && D3(r)
  );
  const d = [H_, P_], h = [];
  function _(g, b) {
    return (
      /*webcam_accessed*/
      g[13] ? 1 : 0
    );
  }
  return o = _(r), s = h[o] = d[o](r), {
    c() {
      e = e0("div"), ia(t.$$.fragment), n = cr(), c && c.c(), a = cr(), i = e0("video"), l = cr(), s.c(), this.h();
    },
    l(g) {
      e = Jt(g, "DIV", { class: !0 });
      var b = Kt(e);
      aa(t.$$.fragment, b), n = ur(b), c && c.l(b), a = ur(b), i = Jt(b, "VIDEO", { class: !0 }), Kt(i).forEach(je), l = ur(b), s.l(b), b.forEach(je), this.h();
    },
    h() {
      i.autoplay = !0, i.playsInline = !0, _t(i, "class", "svelte-1y5s2o2"), Zl(i, "hide", !/*webcam_accessed*/
      r[13]), Zl(
        i,
        "flip",
        /*stream_state*/
        r[12] != "open" || /*stream_state*/
        r[12] === "open" && /*include_audio*/
        r[5]
      ), _t(e, "class", "wrap svelte-1y5s2o2");
    },
    m(g, b) {
      q0(g, e, b), oa(t, e, null), Et(e, n), c && c.m(e, null), Et(e, a), Et(e, i), r[31](i), Et(e, l), h[o].m(e, null), u = !0;
    },
    p(g, b) {
      const y = {};
      b[0] & /*_time_limit*/
      2048 && (y.time_limit = /*_time_limit*/
      g[11]), t.$set(y), /*stream_state*/
      g[12] === "open" && /*include_audio*/
      g[5] ? c ? (c.p(g, b), b[0] & /*stream_state, include_audio*/
      4128 && xt(c, 1)) : (c = D3(g), c.c(), xt(c, 1), c.m(e, a)) : c && (C1(), Yt(c, 1, 1, () => {
        c = null;
      }), A1()), (!u || b[0] & /*webcam_accessed*/
      8192) && Zl(i, "hide", !/*webcam_accessed*/
      g[13]), (!u || b[0] & /*stream_state, include_audio*/
      4128) && Zl(
        i,
        "flip",
        /*stream_state*/
        g[12] != "open" || /*stream_state*/
        g[12] === "open" && /*include_audio*/
        g[5]
      );
      let D = o;
      o = _(g), o === D ? h[o].p(g, b) : (C1(), Yt(h[D], 1, 1, () => {
        h[D] = null;
      }), A1(), s = h[o], s ? s.p(g, b) : (s = h[o] = d[o](g), s.c()), xt(s, 1), s.m(e, null));
    },
    i(g) {
      u || (xt(t.$$.fragment, g), xt(c), xt(s), u = !0);
    },
    o(g) {
      Yt(t.$$.fragment, g), Yt(c), Yt(s), u = !1;
    },
    d(g) {
      g && je(e), la(t), c && c.d(), r[31](null), h[o].d();
    }
  };
}
function I5(r, e) {
  const t = (n) => {
    r && !r.contains(n.target) && !n.defaultPrevented && e(n);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function X_(r, e, t) {
  var n = this && this.__awaiter || function(z, xe, pe, Te) {
    function ot(Ue) {
      return Ue instanceof pe ? Ue : new pe(function(qe) {
        qe(Ue);
      });
    }
    return new (pe || (pe = Promise))(function(Ue, qe) {
      function fe(He) {
        try {
          Qe(Te.next(He));
        } catch (ve) {
          qe(ve);
        }
      }
      function tt(He) {
        try {
          Qe(Te.throw(He));
        } catch (ve) {
          qe(ve);
        }
      }
      function Qe(He) {
        He.done ? Ue(He.value) : ot(He.value).then(fe, tt);
      }
      Qe((Te = Te.apply(z, xe || [])).next());
    });
  };
  let a, i = [], l = null, o = null, { time_limit: s = null } = e, u = "closed", { on_change_cb: c } = e, { reject_cb: d } = e, { mode: h } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: _ = {} } = e, { icon: g = void 0 } = e, { icon_button_color: b = "var(--color-accent)" } = e, { icon_radius: y = 50 } = e, { pulse_color: D = "var(--color-accent)" } = e, { button_labels: k } = e;
  const p = (z) => {
    z === "closed" ? (t(11, o = null), t(12, u = "closed")) : z === "waiting" ? t(12, u = "waiting") : t(12, u = "open");
  };
  let { track_constraints: S = null } = e, { rtc_configuration: E } = e, { stream_every: F = 1 } = e, { server: $ } = e, { include_audio: B } = e, { i18n: T } = e;
  const x = R_();
  O_(() => document.createElement("canvas"));
  const L = (z) => n(void 0, void 0, void 0, function* () {
    const pe = z.target.value;
    yield c3(B, a, pe, S).then((Te) => n(void 0, void 0, void 0, function* () {
      ae = Te, t(10, l = i.find((ot) => ot.deviceId === pe) || null), t(14, oe = !1);
    }));
  });
  function P() {
    return n(this, void 0, void 0, function* () {
      try {
        c3(B, a, null, S).then((z) => n(this, void 0, void 0, function* () {
          t(13, R = !0), t(9, i = yield xc()), ae = z;
        })).then(() => Tc(i)).then((z) => {
          t(9, i = z);
          const xe = ae.getTracks().map((pe) => {
            var Te;
            return (Te = pe.getSettings()) === null || Te === void 0 ? void 0 : Te.deviceId;
          })[0];
          t(10, l = xe && z.find((pe) => pe.deviceId === xe) || i[0]);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && x("error", T("image.no_webcam_support"));
      } catch (z) {
        if (z instanceof DOMException && z.name == "NotAllowedError")
          x("error", T("image.allow_webcam_access"));
        else
          throw z;
      }
    });
  }
  let ae, R = !1, ee, { webrtc_id: Z } = e;
  function ze() {
    return n(this, void 0, void 0, function* () {
      if (u === "closed") {
        ee = new RTCPeerConnection(E), ee.addEventListener("connectionstatechange", (xe) => n(this, void 0, void 0, function* () {
          switch (ee.connectionState) {
            case "connected":
              t(12, u = "open"), t(11, o = s), x("tick");
              break;
            case "disconnected":
              t(12, u = "closed"), t(11, o = null), _n(ee), yield P();
              break;
            case "failed":
              t(12, u = "closed"), t(11, o = null), x("error", "Connection failed!"), _n(ee);
              break;
          }
        })), t(12, u = "waiting"), t(20, Z = Math.random().toString(36).substring(2));
        const z = setTimeout(
          () => {
            c({ type: "connection_timeout" });
          },
          5e3
        );
        al(ae, ee, h === "send" ? null : a, $.offer, Z, "video", c, _, void 0, d).then(([xe]) => {
          clearTimeout(z), ee = xe;
        }).catch(() => {
          clearTimeout(z), console.info("catching"), t(12, u = "closed");
        });
      } else
        _n(ee), t(12, u = "closed"), t(11, o = null), yield P();
    });
  }
  let oe = !1;
  function ge(z) {
    z.preventDefault(), z.stopPropagation(), t(14, oe = !1);
  }
  const N = () => a.srcObject;
  function H(z) {
    Q_[z ? "unshift" : "push"](() => {
      a = z, t(8, a);
    });
  }
  const te = async () => P(), he = () => t(14, oe = !0), Ie = () => t(14, oe = !1);
  return r.$$set = (z) => {
    "time_limit" in z && t(21, s = z.time_limit), "on_change_cb" in z && t(22, c = z.on_change_cb), "reject_cb" in z && t(23, d = z.reject_cb), "mode" in z && t(24, h = z.mode), "rtp_params" in z && t(25, _ = z.rtp_params), "icon" in z && t(0, g = z.icon), "icon_button_color" in z && t(1, b = z.icon_button_color), "icon_radius" in z && t(2, y = z.icon_radius), "pulse_color" in z && t(3, D = z.pulse_color), "button_labels" in z && t(4, k = z.button_labels), "track_constraints" in z && t(27, S = z.track_constraints), "rtc_configuration" in z && t(28, E = z.rtc_configuration), "stream_every" in z && t(29, F = z.stream_every), "server" in z && t(30, $ = z.server), "include_audio" in z && t(5, B = z.include_audio), "i18n" in z && t(6, T = z.i18n), "webrtc_id" in z && t(20, Z = z.webrtc_id);
  }, [
    g,
    b,
    y,
    D,
    k,
    B,
    T,
    I5,
    a,
    i,
    l,
    o,
    u,
    R,
    oe,
    L,
    P,
    ze,
    ge,
    N,
    Z,
    s,
    c,
    d,
    h,
    _,
    p,
    S,
    E,
    F,
    $,
    H,
    te,
    he,
    Ie
  ];
}
class K_ extends x_ {
  constructor(e) {
    super(), z_(
      this,
      e,
      X_,
      Y_,
      L_,
      {
        time_limit: 21,
        on_change_cb: 22,
        reject_cb: 23,
        mode: 24,
        rtp_params: 25,
        icon: 0,
        icon_button_color: 1,
        icon_radius: 2,
        pulse_color: 3,
        button_labels: 4,
        modify_stream: 26,
        track_constraints: 27,
        rtc_configuration: 28,
        stream_every: 29,
        server: 30,
        include_audio: 5,
        i18n: 6,
        webrtc_id: 20,
        click_outside: 7
      },
      null,
      [-1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[26];
  }
  get click_outside() {
    return I5;
  }
}
const {
  SvelteComponent: J_,
  add_flush_callback: ep,
  attr: A3,
  bind: tp,
  binding_callbacks: np,
  bubble: Yl,
  children: rp,
  claim_component: F3,
  claim_element: ap,
  claim_space: ip,
  create_component: C3,
  destroy_component: x3,
  detach: is,
  element: lp,
  init: op,
  insert_hydration: T3,
  mount_component: $3,
  safe_not_equal: sp,
  space: up,
  transition_in: Q3,
  transition_out: M3
} = window.__gradio__svelte__internal, { createEventDispatcher: cp } = window.__gradio__svelte__internal;
function hp(r) {
  let e, t, n, a, i, l;
  e = new G1({
    props: {
      show_label: (
        /*show_label*/
        r[2]
      ),
      Icon: l5,
      label: (
        /*label*/
        r[1] || "Video"
      )
    }
  });
  function o(u) {
    r[21](u);
  }
  let s = {
    rtc_configuration: (
      /*rtc_configuration*/
      r[8]
    ),
    include_audio: (
      /*include_audio*/
      r[3]
    ),
    time_limit: (
      /*time_limit*/
      r[5]
    ),
    track_constraints: (
      /*track_constraints*/
      r[9]
    ),
    mode: (
      /*mode*/
      r[10]
    ),
    rtp_params: (
      /*rtp_params*/
      r[13]
    ),
    on_change_cb: (
      /*on_change_cb*/
      r[11]
    ),
    icon: (
      /*icon*/
      r[14]
    ),
    icon_button_color: (
      /*icon_button_color*/
      r[15]
    ),
    pulse_color: (
      /*pulse_color*/
      r[16]
    ),
    icon_radius: (
      /*icon_radius*/
      r[17]
    ),
    button_labels: (
      /*button_labels*/
      r[6]
    ),
    i18n: (
      /*i18n*/
      r[4]
    ),
    stream_every: 0.5,
    server: (
      /*server*/
      r[7]
    ),
    reject_cb: (
      /*reject_cb*/
      r[12]
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (s.webrtc_id = /*value*/
    r[0]), a = new K_({ props: s }), np.push(() => tp(a, "webrtc_id", o)), a.$on(
      "error",
      /*error_handler*/
      r[22]
    ), a.$on(
      "start_recording",
      /*start_recording_handler*/
      r[23]
    ), a.$on(
      "stop_recording",
      /*stop_recording_handler*/
      r[24]
    ), a.$on(
      "tick",
      /*tick_handler*/
      r[25]
    ), {
      c() {
        C3(e.$$.fragment), t = up(), n = lp("div"), C3(a.$$.fragment), this.h();
      },
      l(u) {
        F3(e.$$.fragment, u), t = ip(u), n = ap(u, "DIV", { "data-testid": !0, class: !0 });
        var c = rp(n);
        F3(a.$$.fragment, c), c.forEach(is), this.h();
      },
      h() {
        A3(n, "data-testid", "video"), A3(n, "class", "video-container svelte-dn5v7y");
      },
      m(u, c) {
        $3(e, u, c), T3(u, t, c), T3(u, n, c), $3(a, n, null), l = !0;
      },
      p(u, [c]) {
        const d = {};
        c & /*show_label*/
        4 && (d.show_label = /*show_label*/
        u[2]), c & /*label*/
        2 && (d.label = /*label*/
        u[1] || "Video"), e.$set(d);
        const h = {};
        c & /*rtc_configuration*/
        256 && (h.rtc_configuration = /*rtc_configuration*/
        u[8]), c & /*include_audio*/
        8 && (h.include_audio = /*include_audio*/
        u[3]), c & /*time_limit*/
        32 && (h.time_limit = /*time_limit*/
        u[5]), c & /*track_constraints*/
        512 && (h.track_constraints = /*track_constraints*/
        u[9]), c & /*mode*/
        1024 && (h.mode = /*mode*/
        u[10]), c & /*rtp_params*/
        8192 && (h.rtp_params = /*rtp_params*/
        u[13]), c & /*on_change_cb*/
        2048 && (h.on_change_cb = /*on_change_cb*/
        u[11]), c & /*icon*/
        16384 && (h.icon = /*icon*/
        u[14]), c & /*icon_button_color*/
        32768 && (h.icon_button_color = /*icon_button_color*/
        u[15]), c & /*pulse_color*/
        65536 && (h.pulse_color = /*pulse_color*/
        u[16]), c & /*icon_radius*/
        131072 && (h.icon_radius = /*icon_radius*/
        u[17]), c & /*button_labels*/
        64 && (h.button_labels = /*button_labels*/
        u[6]), c & /*i18n*/
        16 && (h.i18n = /*i18n*/
        u[4]), c & /*server*/
        128 && (h.server = /*server*/
        u[7]), c & /*reject_cb*/
        4096 && (h.reject_cb = /*reject_cb*/
        u[12]), !i && c & /*value*/
        1 && (i = !0, h.webrtc_id = /*value*/
        u[0], ep(() => i = !1)), a.$set(h);
      },
      i(u) {
        l || (Q3(e.$$.fragment, u), Q3(a.$$.fragment, u), l = !0);
      },
      o(u) {
        M3(e.$$.fragment, u), M3(a.$$.fragment, u), l = !1;
      },
      d(u) {
        u && (is(t), is(n)), x3(e, u), x3(a);
      }
    }
  );
}
let dp = !1;
function fp(r, e, t) {
  let { value: n = null } = e, { label: a = void 0 } = e, { show_label: i = !0 } = e, { include_audio: l } = e, { i18n: o } = e, { active_source: s = "webcam" } = e, { handle_reset_value: u = () => {
  } } = e, { stream_handler: c } = e, { time_limit: d = null } = e, { button_labels: h } = e, { server: _ } = e, { rtc_configuration: g } = e, { track_constraints: b = {} } = e, { mode: y } = e, { on_change_cb: D } = e, { reject_cb: k } = e, { rtp_params: p = {} } = e, { icon: S = void 0 } = e, { icon_button_color: E = "var(--color-accent)" } = e, { pulse_color: F = "var(--color-accent)" } = e, { icon_radius: $ = 50 } = e;
  const B = cp();
  function T(R) {
    n = R, t(0, n);
  }
  function x(R) {
    Yl.call(this, r, R);
  }
  function L(R) {
    Yl.call(this, r, R);
  }
  function P(R) {
    Yl.call(this, r, R);
  }
  function ae(R) {
    Yl.call(this, r, R);
  }
  return r.$$set = (R) => {
    "value" in R && t(0, n = R.value), "label" in R && t(1, a = R.label), "show_label" in R && t(2, i = R.show_label), "include_audio" in R && t(3, l = R.include_audio), "i18n" in R && t(4, o = R.i18n), "active_source" in R && t(18, s = R.active_source), "handle_reset_value" in R && t(19, u = R.handle_reset_value), "stream_handler" in R && t(20, c = R.stream_handler), "time_limit" in R && t(5, d = R.time_limit), "button_labels" in R && t(6, h = R.button_labels), "server" in R && t(7, _ = R.server), "rtc_configuration" in R && t(8, g = R.rtc_configuration), "track_constraints" in R && t(9, b = R.track_constraints), "mode" in R && t(10, y = R.mode), "on_change_cb" in R && t(11, D = R.on_change_cb), "reject_cb" in R && t(12, k = R.reject_cb), "rtp_params" in R && t(13, p = R.rtp_params), "icon" in R && t(14, S = R.icon), "icon_button_color" in R && t(15, E = R.icon_button_color), "pulse_color" in R && t(16, F = R.pulse_color), "icon_radius" in R && t(17, $ = R.icon_radius);
  }, B("drag", dp), [
    n,
    a,
    i,
    l,
    o,
    d,
    h,
    _,
    g,
    b,
    y,
    D,
    k,
    p,
    S,
    E,
    F,
    $,
    s,
    u,
    c,
    T,
    x,
    L,
    P,
    ae
  ];
}
class mp extends J_ {
  constructor(e) {
    super(), op(this, e, fp, hp, sp, {
      value: 0,
      label: 1,
      show_label: 2,
      include_audio: 3,
      i18n: 4,
      active_source: 18,
      handle_reset_value: 19,
      stream_handler: 20,
      time_limit: 5,
      button_labels: 6,
      server: 7,
      rtc_configuration: 8,
      track_constraints: 9,
      mode: 10,
      on_change_cb: 11,
      reject_cb: 12,
      rtp_params: 13,
      icon: 14,
      icon_button_color: 15,
      pulse_color: 16,
      icon_radius: 17
    });
  }
}
var B3;
(function(r) {
  r.LOAD = "LOAD", r.EXEC = "EXEC", r.FFPROBE = "FFPROBE", r.WRITE_FILE = "WRITE_FILE", r.READ_FILE = "READ_FILE", r.DELETE_FILE = "DELETE_FILE", r.RENAME = "RENAME", r.CREATE_DIR = "CREATE_DIR", r.LIST_DIR = "LIST_DIR", r.DELETE_DIR = "DELETE_DIR", r.ERROR = "ERROR", r.DOWNLOAD = "DOWNLOAD", r.PROGRESS = "PROGRESS", r.LOG = "LOG", r.MOUNT = "MOUNT", r.UNMOUNT = "UNMOUNT";
})(B3 || (B3 = {}));
var z3;
(function(r) {
  r.MEMFS = "MEMFS", r.NODEFS = "NODEFS", r.NODERAWFS = "NODERAWFS", r.IDBFS = "IDBFS", r.WORKERFS = "WORKERFS", r.PROXYFS = "PROXYFS";
})(z3 || (z3 = {}));
const Iz = (r) => {
  let e = ["B", "KB", "MB", "GB", "PB"], t = 0;
  for (; r > 1024; )
    r /= 1024, t++;
  let n = e[t];
  return r.toFixed(1) + " " + n;
}, Lz = () => !0;
function qz(r, { autoplay: e }) {
  async function t() {
    e && await r.play();
  }
  return r.addEventListener("loadeddata", t), {
    destroy() {
      r.removeEventListener("loadeddata", t);
    }
  };
}
const {
  SvelteComponent: _p,
  append_hydration: pp,
  attr: ls,
  binding_callbacks: gp,
  children: I3,
  claim_element: L3,
  claim_text: Nz,
  detach: Oi,
  element: q3,
  empty: T1,
  init: vp,
  insert_hydration: L5,
  is_function: N3,
  listen: os,
  noop: R3,
  run_all: bp,
  safe_not_equal: yp,
  set_data: Rz,
  src_url_equal: O3,
  text: Oz,
  toggle_class: Ha
} = window.__gradio__svelte__internal;
function P3(r) {
  let e;
  function t(i, l) {
    return wp;
  }
  let a = t()(r);
  return {
    c() {
      a.c(), e = T1();
    },
    l(i) {
      a.l(i), e = T1();
    },
    m(i, l) {
      a.m(i, l), L5(i, e, l);
    },
    p(i, l) {
      a.p(i, l);
    },
    d(i) {
      i && Oi(e), a.d(i);
    }
  };
}
function wp(r) {
  let e, t, n, a, i;
  return {
    c() {
      e = q3("div"), t = q3("video"), this.h();
    },
    l(l) {
      e = L3(l, "DIV", { class: !0 });
      var o = I3(e);
      t = L3(o, "VIDEO", { src: !0 }), I3(t).forEach(Oi), o.forEach(Oi), this.h();
    },
    h() {
      var l;
      O3(t.src, n = /*value*/
      (l = r[2]) == null ? void 0 : l.video.url) || ls(t, "src", n), ls(e, "class", "container svelte-1uoo7dd"), Ha(
        e,
        "table",
        /*type*/
        r[0] === "table"
      ), Ha(
        e,
        "gallery",
        /*type*/
        r[0] === "gallery"
      ), Ha(
        e,
        "selected",
        /*selected*/
        r[1]
      );
    },
    m(l, o) {
      L5(l, e, o), pp(e, t), r[6](t), a || (i = [
        os(
          t,
          "loadeddata",
          /*init*/
          r[4]
        ),
        os(t, "mouseover", function() {
          N3(
            /*video*/
            r[3].play.bind(
              /*video*/
              r[3]
            )
          ) && r[3].play.bind(
            /*video*/
            r[3]
          ).apply(this, arguments);
        }),
        os(t, "mouseout", function() {
          N3(
            /*video*/
            r[3].pause.bind(
              /*video*/
              r[3]
            )
          ) && r[3].pause.bind(
            /*video*/
            r[3]
          ).apply(this, arguments);
        })
      ], a = !0);
    },
    p(l, o) {
      var s;
      r = l, o & /*value*/
      4 && !O3(t.src, n = /*value*/
      (s = r[2]) == null ? void 0 : s.video.url) && ls(t, "src", n), o & /*type*/
      1 && Ha(
        e,
        "table",
        /*type*/
        r[0] === "table"
      ), o & /*type*/
      1 && Ha(
        e,
        "gallery",
        /*type*/
        r[0] === "gallery"
      ), o & /*selected*/
      2 && Ha(
        e,
        "selected",
        /*selected*/
        r[1]
      );
    },
    d(l) {
      l && Oi(e), r[6](null), a = !1, bp(i);
    }
  };
}
function kp(r) {
  let e, t = (
    /*value*/
    r[2] && P3(r)
  );
  return {
    c() {
      t && t.c(), e = T1();
    },
    l(n) {
      t && t.l(n), e = T1();
    },
    m(n, a) {
      t && t.m(n, a), L5(n, e, a);
    },
    p(n, [a]) {
      /*value*/
      n[2] ? t ? t.p(n, a) : (t = P3(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: R3,
    o: R3,
    d(n) {
      n && Oi(e), t && t.d(n);
    }
  };
}
function Dp(r, e, t) {
  var n = this && this.__awaiter || function(d, h, _, g) {
    function b(y) {
      return y instanceof _ ? y : new _(function(D) {
        D(y);
      });
    }
    return new (_ || (_ = Promise))(function(y, D) {
      function k(E) {
        try {
          S(g.next(E));
        } catch (F) {
          D(F);
        }
      }
      function p(E) {
        try {
          S(g.throw(E));
        } catch (F) {
          D(F);
        }
      }
      function S(E) {
        E.done ? y(E.value) : b(E.value).then(k, p);
      }
      S((g = g.apply(d, h || [])).next());
    });
  };
  let { type: a } = e, { selected: i = !1 } = e, { value: l } = e, { loop: o } = e, s;
  function u() {
    return n(this, void 0, void 0, function* () {
      t(3, s.muted = !0, s), t(3, s.playsInline = !0, s), t(3, s.controls = !1, s), s.setAttribute("muted", ""), yield s.play(), s.pause();
    });
  }
  function c(d) {
    gp[d ? "unshift" : "push"](() => {
      s = d, t(3, s);
    });
  }
  return r.$$set = (d) => {
    "type" in d && t(0, a = d.type), "selected" in d && t(1, i = d.selected), "value" in d && t(2, l = d.value), "loop" in d && t(5, o = d.loop);
  }, [a, i, l, s, u, o, c];
}
class Pz extends _p {
  constructor(e) {
    super(), vp(this, e, Dp, kp, yp, { type: 0, selected: 1, value: 2, loop: 5 });
  }
}
const {
  SvelteComponent: Sp,
  append_hydration: H3,
  assign: V3,
  attr: Va,
  binding_callbacks: Ep,
  bubble: Ap,
  check_outros: Fp,
  children: j3,
  claim_component: q5,
  claim_element: ss,
  claim_space: U3,
  create_component: N5,
  destroy_component: R5,
  detach: Ti,
  element: us,
  exclude_internal_props: G3,
  group_outros: Cp,
  init: xp,
  insert_hydration: cs,
  listen: Yn,
  mount_component: O5,
  run_all: Tp,
  safe_not_equal: $p,
  space: W3,
  toggle_class: Z3,
  transition_in: Xa,
  transition_out: Pi
} = window.__gradio__svelte__internal, { createEventDispatcher: Qp } = window.__gradio__svelte__internal;
function Y3(r) {
  let e, t;
  return e = new Sc({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [Mp] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      N5(e.$$.fragment);
    },
    l(n) {
      q5(e.$$.fragment, n);
    },
    m(n, a) {
      O5(e, n, a), t = !0;
    },
    i(n) {
      t || (Xa(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pi(e.$$.fragment, n), t = !1;
    },
    d(n) {
      R5(e, n);
    }
  };
}
function Mp(r) {
  let e, t;
  return e = new l5({}), {
    c() {
      N5(e.$$.fragment);
    },
    l(n) {
      q5(e.$$.fragment, n);
    },
    m(n, a) {
      O5(e, n, a), t = !0;
    },
    i(n) {
      t || (Xa(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pi(e.$$.fragment, n), t = !1;
    },
    d(n) {
      R5(e, n);
    }
  };
}
function Bp(r) {
  let e, t, n, a, i, l, o, s, u, c;
  e = new G1({
    props: {
      show_label: (
        /*show_label*/
        r[2]
      ),
      Icon: l5,
      label: (
        /*label*/
        r[1] || "Video"
      )
    }
  });
  let d = (
    /*value*/
    r[0] === "__webrtc_value__" && Y3(r)
  );
  return {
    c() {
      N5(e.$$.fragment), t = W3(), d && d.c(), n = W3(), a = us("div"), i = us("video"), l = us("track"), this.h();
    },
    l(h) {
      q5(e.$$.fragment, h), t = U3(h), d && d.l(h), n = U3(h), a = ss(h, "DIV", { class: !0 });
      var _ = j3(a);
      i = ss(_, "VIDEO", {
        "data-testid": !0,
        crossorigin: !0,
        class: !0
      });
      var g = j3(i);
      l = ss(g, "TRACK", { kind: !0 }), g.forEach(Ti), _.forEach(Ti), this.h();
    },
    h() {
      Va(l, "kind", "captions"), i.autoplay = !0, Va(i, "data-testid", o = /*$$props*/
      r[5]["data-testid"]), Va(i, "crossorigin", "anonymous"), Va(i, "class", "svelte-1yzqfy6"), Z3(
        i,
        "hidden",
        /*value*/
        r[0] === "__webrtc_value__"
      ), Va(a, "class", "wrap svelte-1yzqfy6");
    },
    m(h, _) {
      O5(e, h, _), cs(h, t, _), d && d.m(h, _), cs(h, n, _), cs(h, a, _), H3(a, i), H3(i, l), r[12](i), s = !0, u || (c = [
        Yn(
          i,
          "loadeddata",
          /*dispatch*/
          r[4].bind(null, "loadeddata")
        ),
        Yn(
          i,
          "click",
          /*dispatch*/
          r[4].bind(null, "click")
        ),
        Yn(
          i,
          "play",
          /*dispatch*/
          r[4].bind(null, "play")
        ),
        Yn(
          i,
          "pause",
          /*dispatch*/
          r[4].bind(null, "pause")
        ),
        Yn(
          i,
          "ended",
          /*dispatch*/
          r[4].bind(null, "ended")
        ),
        Yn(
          i,
          "mouseover",
          /*dispatch*/
          r[4].bind(null, "mouseover")
        ),
        Yn(
          i,
          "mouseout",
          /*dispatch*/
          r[4].bind(null, "mouseout")
        ),
        Yn(
          i,
          "focus",
          /*dispatch*/
          r[4].bind(null, "focus")
        ),
        Yn(
          i,
          "blur",
          /*dispatch*/
          r[4].bind(null, "blur")
        ),
        Yn(
          i,
          "load",
          /*load_handler*/
          r[11]
        )
      ], u = !0);
    },
    p(h, [_]) {
      const g = {};
      _ & /*show_label*/
      4 && (g.show_label = /*show_label*/
      h[2]), _ & /*label*/
      2 && (g.label = /*label*/
      h[1] || "Video"), e.$set(g), /*value*/
      h[0] === "__webrtc_value__" ? d ? _ & /*value*/
      1 && Xa(d, 1) : (d = Y3(h), d.c(), Xa(d, 1), d.m(n.parentNode, n)) : d && (Cp(), Pi(d, 1, 1, () => {
        d = null;
      }), Fp()), (!s || _ & /*$$props*/
      32 && o !== (o = /*$$props*/
      h[5]["data-testid"])) && Va(i, "data-testid", o), (!s || _ & /*value*/
      1) && Z3(
        i,
        "hidden",
        /*value*/
        h[0] === "__webrtc_value__"
      );
    },
    i(h) {
      s || (Xa(e.$$.fragment, h), Xa(d), s = !0);
    },
    o(h) {
      Pi(e.$$.fragment, h), Pi(d), s = !1;
    },
    d(h) {
      h && (Ti(t), Ti(n), Ti(a)), R5(e, h), d && d.d(h), r[12](null), u = !1, Tp(c);
    }
  };
}
function zp(r, e, t) {
  var n = this && this.__awaiter || function(y, D, k, p) {
    function S(E) {
      return E instanceof k ? E : new k(function(F) {
        F(E);
      });
    }
    return new (k || (k = Promise))(function(E, F) {
      function $(x) {
        try {
          T(p.next(x));
        } catch (L) {
          F(L);
        }
      }
      function B(x) {
        try {
          T(p.throw(x));
        } catch (L) {
          F(L);
        }
      }
      function T(x) {
        x.done ? E(x.value) : S(x.value).then($, B);
      }
      T((p = p.apply(y, D || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { on_change_cb: s } = e, { server: u } = e, c, d = Math.random().toString(36).substring(2), h;
  const _ = Qp();
  function g(y) {
    Ap.call(this, r, y);
  }
  function b(y) {
    Ep[y ? "unshift" : "push"](() => {
      c = y, t(3, c);
    });
  }
  return r.$$set = (y) => {
    t(5, e = V3(V3({}, e), G3(y))), "value" in y && t(0, a = y.value), "label" in y && t(1, i = y.label), "show_label" in y && t(2, l = y.show_label), "rtc_configuration" in y && t(6, o = y.rtc_configuration), "on_change_cb" in y && t(7, s = y.on_change_cb), "server" in y && t(8, u = y.server);
  }, r.$$.update = () => {
    if (r.$$.dirty & /*value, _webrtc_id, rtc_configuration, pc, on_change_cb, video_element, server*/
    1993 && a === "start_webrtc_stream") {
      t(9, d = Math.random().toString(36).substring(2)), t(0, a = d), t(10, h = new RTCPeerConnection(o)), h.addEventListener("connectionstatechange", (D) => n(void 0, void 0, void 0, function* () {
        switch (h.connectionState) {
          case "connected":
            _("tick");
            break;
          case "disconnected":
            _n(h);
            break;
          case "failed":
            _("error", "Connection failed!"), _n(h);
            break;
        }
      }));
      const y = setTimeout(
        () => {
          s({ type: "connection_timeout" });
        },
        5e3
      );
      al(null, h, c, u.offer, d, "video", s).then(([D]) => {
        clearTimeout(y), t(10, h = D);
      }).catch(() => {
        clearTimeout(y), _("error", "Too many concurrent users. Come back later!");
      });
    }
  }, e = G3(e), [
    a,
    i,
    l,
    c,
    _,
    e,
    o,
    s,
    u,
    d,
    h,
    g,
    b
  ];
}
class Ip extends Sp {
  constructor(e) {
    super(), xp(this, e, zp, Bp, $p, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 6,
      on_change_cb: 7,
      server: 8
    });
  }
}
const {
  SvelteComponent: Lp,
  append_hydration: c1,
  attr: Aa,
  check_outros: qp,
  children: Fa,
  claim_component: Np,
  claim_element: Ca,
  claim_space: X3,
  create_component: Rp,
  destroy_component: Op,
  destroy_each: K3,
  detach: pn,
  element: xa,
  ensure_array_like: Xl,
  group_outros: Pp,
  init: Hp,
  insert_hydration: sl,
  mount_component: Vp,
  noop: $1,
  safe_not_equal: jp,
  set_style: Ka,
  space: J3,
  transition_in: Ys,
  transition_out: Xs
} = window.__gradio__svelte__internal, { onDestroy: Up } = window.__gradio__svelte__internal;
function e4(r, e, t) {
  const n = r.slice();
  return n[15] = e[t], n;
}
function t4(r, e, t) {
  const n = r.slice();
  return n[15] = e[t], n;
}
function Gp(r) {
  let e, t, n, a, i = Xl(Array(
    /*numBars*/
    r[0] / 2
  )), l = [];
  for (let u = 0; u < i.length; u += 1)
    l[u] = n4(t4(r, i, u));
  let o = Xl(Array(
    /*numBars*/
    r[0] / 2
  )), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = r4(e4(r, o, u));
  return {
    c() {
      e = xa("div");
      for (let u = 0; u < l.length; u += 1)
        l[u].c();
      t = J3(), n = xa("div"), a = J3();
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      this.h();
    },
    l(u) {
      e = Ca(u, "DIV", { class: !0 });
      var c = Fa(e);
      for (let d = 0; d < l.length; d += 1)
        l[d].l(c);
      t = X3(c), n = Ca(c, "DIV", { class: !0 }), Fa(n).forEach(pn), a = X3(c);
      for (let d = 0; d < s.length; d += 1)
        s[d].l(c);
      c.forEach(pn), this.h();
    },
    h() {
      Aa(n, "class", "split-container svelte-68mmig"), Aa(e, "class", "gradio-webrtc-boxContainer svelte-68mmig"), Ka(
        e,
        "width",
        /*containerWidth*/
        r[7]
      );
    },
    m(u, c) {
      sl(u, e, c);
      for (let d = 0; d < l.length; d += 1)
        l[d] && l[d].m(e, null);
      c1(e, t), c1(e, n), c1(e, a);
      for (let d = 0; d < s.length; d += 1)
        s[d] && s[d].m(e, null);
    },
    p(u, c) {
      if (c & /*numBars*/
      1) {
        i = Xl(Array(
          /*numBars*/
          u[0] / 2
        ));
        let d;
        for (d = 0; d < i.length; d += 1) {
          const h = t4(u, i, d);
          l[d] ? l[d].p(h, c) : (l[d] = n4(), l[d].c(), l[d].m(e, t));
        }
        for (; d < l.length; d += 1)
          l[d].d(1);
        l.length = i.length;
      }
      if (c & /*numBars*/
      1) {
        o = Xl(Array(
          /*numBars*/
          u[0] / 2
        ));
        let d;
        for (d = 0; d < o.length; d += 1) {
          const h = e4(u, o, d);
          s[d] ? s[d].p(h, c) : (s[d] = r4(), s[d].c(), s[d].m(e, null));
        }
        for (; d < s.length; d += 1)
          s[d].d(1);
        s.length = o.length;
      }
      c & /*containerWidth*/
      128 && Ka(
        e,
        "width",
        /*containerWidth*/
        u[7]
      );
    },
    i: $1,
    o: $1,
    d(u) {
      u && pn(e), K3(l, u), K3(s, u);
    }
  };
}
function Wp(r) {
  let e, t, n, a;
  return n = new z5({
    props: {
      stream_state: (
        /*stream_state*/
        r[1]
      ),
      pulse_color: (
        /*pulse_color*/
        r[5]
      ),
      icon: (
        /*icon*/
        r[3]
      ),
      icon_button_color: (
        /*icon_button_color*/
        r[4]
      ),
      icon_radius,
      audio_source_callback: (
        /*audio_source_callback*/
        r[2]
      )
    }
  }), {
    c() {
      e = xa("div"), t = xa("div"), Rp(n.$$.fragment), this.h();
    },
    l(i) {
      e = Ca(i, "DIV", { class: !0 });
      var l = Fa(e);
      t = Ca(l, "DIV", { class: !0 });
      var o = Fa(t);
      Np(n.$$.fragment, o), o.forEach(pn), l.forEach(pn), this.h();
    },
    h() {
      Aa(t, "class", "gradio-webrtc-icon svelte-68mmig"), Ka(t, "transform", `scale(${/*pulseScale*/
      r[6]})`), Ka(
        t,
        "background",
        /*icon_button_color*/
        r[4]
      ), Aa(e, "class", "gradio-webrtc-icon-container svelte-68mmig");
    },
    m(i, l) {
      sl(i, e, l), c1(e, t), Vp(n, t, null), a = !0;
    },
    p(i, l) {
      const o = {};
      l & /*stream_state*/
      2 && (o.stream_state = /*stream_state*/
      i[1]), l & /*pulse_color*/
      32 && (o.pulse_color = /*pulse_color*/
      i[5]), l & /*icon*/
      8 && (o.icon = /*icon*/
      i[3]), l & /*icon_button_color*/
      16 && (o.icon_button_color = /*icon_button_color*/
      i[4]), l & /*audio_source_callback*/
      4 && (o.audio_source_callback = /*audio_source_callback*/
      i[2]), n.$set(o), l & /*pulseScale*/
      64 && Ka(t, "transform", `scale(${/*pulseScale*/
      i[6]})`), l & /*icon_button_color*/
      16 && Ka(
        t,
        "background",
        /*icon_button_color*/
        i[4]
      );
    },
    i(i) {
      a || (Ys(n.$$.fragment, i), a = !0);
    },
    o(i) {
      Xs(n.$$.fragment, i), a = !1;
    },
    d(i) {
      i && pn(e), Op(n);
    }
  };
}
function n4(r) {
  let e;
  return {
    c() {
      e = xa("div"), this.h();
    },
    l(t) {
      e = Ca(t, "DIV", { class: !0 }), Fa(e).forEach(pn), this.h();
    },
    h() {
      Aa(e, "class", "gradio-webrtc-box svelte-68mmig");
    },
    m(t, n) {
      sl(t, e, n);
    },
    p: $1,
    d(t) {
      t && pn(e);
    }
  };
}
function r4(r) {
  let e;
  return {
    c() {
      e = xa("div"), this.h();
    },
    l(t) {
      e = Ca(t, "DIV", { class: !0 }), Fa(e).forEach(pn), this.h();
    },
    h() {
      Aa(e, "class", "gradio-webrtc-box svelte-68mmig");
    },
    m(t, n) {
      sl(t, e, n);
    },
    p: $1,
    d(t) {
      t && pn(e);
    }
  };
}
function Zp(r) {
  let e, t, n, a;
  const i = [Wp, Gp], l = [];
  function o(s, u) {
    return (
      /*icon*/
      s[3] && !pending ? 0 : 1
    );
  }
  return t = o(r), n = l[t] = i[t](r), {
    c() {
      e = xa("div"), n.c(), this.h();
    },
    l(s) {
      e = Ca(s, "DIV", { class: !0 });
      var u = Fa(e);
      n.l(u), u.forEach(pn), this.h();
    },
    h() {
      Aa(e, "class", "gradio-webrtc-waveContainer svelte-68mmig");
    },
    m(s, u) {
      sl(s, e, u), l[t].m(e, null), a = !0;
    },
    p(s, [u]) {
      let c = t;
      t = o(s), t === c ? l[t].p(s, u) : (Pp(), Xs(l[c], 1, 1, () => {
        l[c] = null;
      }), qp(), n = l[t], n ? n.p(s, u) : (n = l[t] = i[t](s), n.c()), Ys(n, 1), n.m(e, null));
    },
    i(s) {
      a || (Ys(n), a = !0);
    },
    o(s) {
      Xs(n), a = !1;
    },
    d(s) {
      s && pn(e), l[t].d();
    }
  };
}
function Yp(r) {
  const e = [0, 2, 4, 6, 8, 10, 12, 14, 15, 13, 11, 9, 7, 5, 3, 1];
  if (r < 0 || r >= e.length)
    throw new Error("Index must be between 0 and 15");
  return e[r];
}
function Xp(r, e, t) {
  let n, { numBars: a = 16 } = e, { stream_state: i = "closed" } = e, { audio_source_callback: l } = e, { icon: o = void 0 } = e, { icon_button_color: s = "var(--color-accent)" } = e, { pulse_color: u = "var(--color-accent)" } = e, { wave_color: c = "var(--color-accent)" } = e, d, h, _, g, { pulseScale: b = 1 } = e;
  Up(() => {
    g && cancelAnimationFrame(g), d && d.close();
  });
  function y() {
    d = new (window.AudioContext || window.webkitAudioContext)(), h = d.createAnalyser();
    const k = l();
    if (!k) return;
    d.createMediaStreamSource(k).connect(h), h.fftSize = 64, h.smoothingTimeConstant = 0.8, _ = new Uint8Array(h.frequencyBinCount), D();
  }
  function D() {
    h.getByteFrequencyData(_);
    const k = document.querySelectorAll(".gradio-webrtc-waveContainer .gradio-webrtc-box");
    for (let p = 0; p < k.length; p++) {
      const S = _[Yp(p)] / 255;
      k[p].style.transform = `scaleY(${Math.max(0.1, S)})`, k[p].style.background = c, k[p].style.opacity = 0.5;
    }
    g = requestAnimationFrame(D);
  }
  return r.$$set = (k) => {
    "numBars" in k && t(0, a = k.numBars), "stream_state" in k && t(1, i = k.stream_state), "audio_source_callback" in k && t(2, l = k.audio_source_callback), "icon" in k && t(3, o = k.icon), "icon_button_color" in k && t(4, s = k.icon_button_color), "pulse_color" in k && t(5, u = k.pulse_color), "wave_color" in k && t(8, c = k.wave_color), "pulseScale" in k && t(6, b = k.pulseScale);
  }, r.$$.update = () => {
    r.$$.dirty & /*icon, numBars*/
    9 && t(7, n = o ? "128px" : `calc((var(--boxSize) + var(--gutter)) * ${a} + 80px)`), r.$$.dirty & /*stream_state*/
    2 && i === "open" && y();
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    b,
    n,
    c
  ];
}
class P5 extends Lp {
  constructor(e) {
    super(), Hp(this, e, Xp, Zp, jp, {
      numBars: 0,
      stream_state: 1,
      audio_source_callback: 2,
      icon: 3,
      icon_button_color: 4,
      pulse_color: 5,
      wave_color: 8,
      pulseScale: 6
    });
  }
}
const {
  SvelteComponent: Kp,
  attr: Bc,
  binding_callbacks: Jp,
  bubble: eg,
  check_outros: a4,
  children: zc,
  claim_component: Y1,
  claim_element: Ic,
  claim_space: hs,
  create_component: X1,
  destroy_component: K1,
  detach: Gr,
  element: Lc,
  empty: i4,
  group_outros: l4,
  init: tg,
  insert_hydration: Za,
  listen: ds,
  mount_component: J1,
  run_all: ng,
  safe_not_equal: rg,
  space: fs,
  toggle_class: ag,
  transition_in: er,
  transition_out: Zr
} = window.__gradio__svelte__internal, { createEventDispatcher: ig } = window.__gradio__svelte__internal;
function o4(r) {
  let e, t, n;
  return t = new P5({
    props: {
      audio_source_callback: (
        /*func*/
        r[18]
      ),
      stream_state: (
        /*stream_state*/
        r[8]
      ),
      icon: (
        /*icon*/
        r[4]
      ),
      icon_button_color: (
        /*icon_button_color*/
        r[5]
      ),
      pulse_color: (
        /*pulse_color*/
        r[6]
      ),
      icon_radius: (
        /*icon_radius*/
        r[7]
      )
    }
  }), {
    c() {
      e = Lc("div"), X1(t.$$.fragment), this.h();
    },
    l(a) {
      e = Ic(a, "DIV", { class: !0 });
      var i = zc(e);
      Y1(t.$$.fragment, i), i.forEach(Gr), this.h();
    },
    h() {
      Bc(e, "class", "audio-container svelte-js69uk");
    },
    m(a, i) {
      Za(a, e, i), J1(t, e, null), n = !0;
    },
    p(a, i) {
      const l = {};
      i & /*audio_player*/
      512 && (l.audio_source_callback = /*func*/
      a[18]), i & /*stream_state*/
      256 && (l.stream_state = /*stream_state*/
      a[8]), i & /*icon*/
      16 && (l.icon = /*icon*/
      a[4]), i & /*icon_button_color*/
      32 && (l.icon_button_color = /*icon_button_color*/
      a[5]), i & /*pulse_color*/
      64 && (l.pulse_color = /*pulse_color*/
      a[6]), i & /*icon_radius*/
      128 && (l.icon_radius = /*icon_radius*/
      a[7]), t.$set(l);
    },
    i(a) {
      n || (er(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Zr(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Gr(e), K1(t);
    }
  };
}
function s4(r) {
  let e, t;
  return e = new Sc({
    props: {
      size: "small",
      $$slots: { default: [lg] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      X1(e.$$.fragment);
    },
    l(n) {
      Y1(e.$$.fragment, n);
    },
    m(n, a) {
      J1(e, n, a), t = !0;
    },
    i(n) {
      t || (er(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Zr(e.$$.fragment, n), t = !1;
    },
    d(n) {
      K1(e, n);
    }
  };
}
function lg(r) {
  let e, t;
  return e = new i5({}), {
    c() {
      X1(e.$$.fragment);
    },
    l(n) {
      Y1(e.$$.fragment, n);
    },
    m(n, a) {
      J1(e, n, a), t = !0;
    },
    i(n) {
      t || (er(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Zr(e.$$.fragment, n), t = !1;
    },
    d(n) {
      K1(e, n);
    }
  };
}
function og(r) {
  let e, t, n, a, i, l, o, s, u;
  e = new G1({
    props: {
      show_label: (
        /*show_label*/
        r[2]
      ),
      Icon: i5,
      float: !1,
      label: (
        /*label*/
        r[1] || /*i18n*/
        r[3]("audio.audio")
      )
    }
  });
  let c = (
    /*value*/
    r[0] !== "__webrtc_value__" && o4(r)
  ), d = (
    /*value*/
    r[0] === "__webrtc_value__" && s4(r)
  );
  return {
    c() {
      X1(e.$$.fragment), t = fs(), n = Lc("audio"), a = fs(), c && c.c(), i = fs(), d && d.c(), l = i4(), this.h();
    },
    l(h) {
      Y1(e.$$.fragment, h), t = hs(h), n = Ic(h, "AUDIO", { class: !0 }), zc(n).forEach(Gr), a = hs(h), c && c.l(h), i = hs(h), d && d.l(h), l = i4(), this.h();
    },
    h() {
      Bc(n, "class", "standard-player svelte-js69uk"), ag(n, "hidden", !0);
    },
    m(h, _) {
      J1(e, h, _), Za(h, t, _), Za(h, n, _), r[15](n), Za(h, a, _), c && c.m(h, _), Za(h, i, _), d && d.m(h, _), Za(h, l, _), o = !0, s || (u = [
        ds(
          n,
          "load",
          /*load_handler*/
          r[14]
        ),
        ds(
          n,
          "ended",
          /*ended_handler*/
          r[16]
        ),
        ds(
          n,
          "play",
          /*play_handler*/
          r[17]
        )
      ], s = !0);
    },
    p(h, [_]) {
      const g = {};
      _ & /*show_label*/
      4 && (g.show_label = /*show_label*/
      h[2]), _ & /*label, i18n*/
      10 && (g.label = /*label*/
      h[1] || /*i18n*/
      h[3]("audio.audio")), e.$set(g), /*value*/
      h[0] !== "__webrtc_value__" ? c ? (c.p(h, _), _ & /*value*/
      1 && er(c, 1)) : (c = o4(h), c.c(), er(c, 1), c.m(i.parentNode, i)) : c && (l4(), Zr(c, 1, 1, () => {
        c = null;
      }), a4()), /*value*/
      h[0] === "__webrtc_value__" ? d ? _ & /*value*/
      1 && er(d, 1) : (d = s4(h), d.c(), er(d, 1), d.m(l.parentNode, l)) : d && (l4(), Zr(d, 1, 1, () => {
        d = null;
      }), a4());
    },
    i(h) {
      o || (er(e.$$.fragment, h), er(c), er(d), o = !0);
    },
    o(h) {
      Zr(e.$$.fragment, h), Zr(c), Zr(d), o = !1;
    },
    d(h) {
      h && (Gr(t), Gr(n), Gr(a), Gr(i), Gr(l)), K1(e, h), r[15](null), c && c.d(h), d && d.d(h), s = !1, ng(u);
    }
  };
}
function sg(r, e, t) {
  var n = this && this.__awaiter || function(x, L, P, ae) {
    function R(ee) {
      return ee instanceof P ? ee : new P(function(Z) {
        Z(ee);
      });
    }
    return new (P || (P = Promise))(function(ee, Z) {
      function ze(N) {
        try {
          ge(ae.next(N));
        } catch (H) {
          Z(H);
        }
      }
      function oe(N) {
        try {
          ge(ae.throw(N));
        } catch (H) {
          Z(H);
        }
      }
      function ge(N) {
        N.done ? ee(N.value) : R(N.value).then(ze, oe);
      }
      ge((ae = ae.apply(x, L || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { i18n: s } = e, { on_change_cb: u } = e, { icon: c = void 0 } = e, { icon_button_color: d = "var(--color-accent)" } = e, { pulse_color: h = "var(--color-accent)" } = e, { icon_radius: _ = 50 } = e, { server: g } = e, b = "closed", y, D, k = Math.random().toString(36).substring(2);
  const p = ig();
  function S(x) {
    return n(this, void 0, void 0, function* () {
      if (x === "start_webrtc_stream") {
        t(8, b = "waiting"), k = Math.random().toString(36).substring(2), x = k, D = new RTCPeerConnection(o), D.addEventListener("connectionstatechange", (ae) => n(this, void 0, void 0, function* () {
          switch (D.connectionState) {
            case "connected":
              console.info("connected"), t(8, b = "open"), p("tick");
              break;
            case "disconnected":
              console.info("closed"), _n(D);
              break;
            case "failed":
              t(8, b = "closed"), p("error", "Connection failed!"), _n(D);
              break;
          }
        }));
        let L = null;
        const P = setTimeout(
          () => {
            u({ type: "connection_timeout" });
          },
          5e3
        );
        al(L, D, y, g.offer, k, "audio", u).then(([ae]) => {
          clearTimeout(P), D = ae;
        }).catch(() => {
          clearTimeout(P), console.info("catching"), p("error", "Too many concurrent users. Come back later!");
        });
      }
      return x;
    });
  }
  function E(x) {
    eg.call(this, r, x);
  }
  function F(x) {
    Jp[x ? "unshift" : "push"](() => {
      y = x, t(9, y);
    });
  }
  const $ = () => p("stop"), B = () => p("play"), T = () => y.srcObject;
  return r.$$set = (x) => {
    "value" in x && t(0, a = x.value), "label" in x && t(1, i = x.label), "show_label" in x && t(2, l = x.show_label), "rtc_configuration" in x && t(11, o = x.rtc_configuration), "i18n" in x && t(3, s = x.i18n), "on_change_cb" in x && t(12, u = x.on_change_cb), "icon" in x && t(4, c = x.icon), "icon_button_color" in x && t(5, d = x.icon_button_color), "pulse_color" in x && t(6, h = x.pulse_color), "icon_radius" in x && t(7, _ = x.icon_radius), "server" in x && t(13, g = x.server);
  }, r.$$.update = () => {
    r.$$.dirty & /*value*/
    1 && S(a).then((x) => {
      t(0, a = x);
    });
  }, [
    a,
    i,
    l,
    s,
    c,
    d,
    h,
    _,
    b,
    y,
    p,
    o,
    u,
    g,
    E,
    F,
    $,
    B,
    T
  ];
}
class ug extends Kp {
  constructor(e) {
    super(), tg(this, e, sg, og, rg, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 11,
      i18n: 3,
      on_change_cb: 12,
      icon: 4,
      icon_button_color: 5,
      pulse_color: 6,
      icon_radius: 7,
      server: 13
    });
  }
}
const {
  SvelteComponent: cg,
  append_hydration: $i,
  attr: it,
  children: ja,
  claim_svg_element: Ua,
  detach: ca,
  init: hg,
  insert_hydration: dg,
  noop: ms,
  safe_not_equal: fg,
  svg_element: Ga
} = window.__gradio__svelte__internal;
function mg(r) {
  let e, t, n, a, i, l;
  return {
    c() {
      e = Ga("svg"), t = Ga("path"), n = Ga("path"), a = Ga("line"), i = Ga("line"), l = Ga("line"), this.h();
    },
    l(o) {
      e = Ua(o, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var s = ja(e);
      t = Ua(s, "path", { d: !0 }), ja(t).forEach(ca), n = Ua(s, "path", { d: !0 }), ja(n).forEach(ca), a = Ua(s, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), ja(a).forEach(ca), i = Ua(s, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), ja(i).forEach(ca), l = Ua(s, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), ja(l).forEach(ca), s.forEach(ca), this.h();
    },
    h() {
      it(t, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), it(n, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), it(a, "x1", "12"), it(a, "y1", "19"), it(a, "x2", "12"), it(a, "y2", "23"), it(i, "x1", "8"), it(i, "y1", "23"), it(i, "x2", "16"), it(i, "y2", "23"), it(l, "x1", "1"), it(l, "y1", "1"), it(l, "x2", "23"), it(l, "y2", "23"), it(e, "xmlns", "http://www.w3.org/2000/svg"), it(e, "width", "100%"), it(e, "height", "100%"), it(e, "viewBox", "0 0 24 24"), it(e, "fill", "none"), it(e, "stroke", "currentColor"), it(e, "stroke-width", "2"), it(e, "stroke-linecap", "round"), it(e, "stroke-linejoin", "round"), it(e, "class", "feather feather-mic");
    },
    m(o, s) {
      dg(o, e, s), $i(e, t), $i(e, n), $i(e, a), $i(e, i), $i(e, l);
    },
    p: ms,
    i: ms,
    o: ms,
    d(o) {
      o && ca(e);
    }
  };
}
class _g extends cg {
  constructor(e) {
    super(), hg(this, e, null, mg, fg, {});
  }
}
const {
  SvelteComponent: pg,
  action_destroyer: gg,
  add_render_callback: vg,
  append_hydration: gt,
  attr: Ce,
  binding_callbacks: bg,
  bubble: yg,
  check_outros: Dr,
  children: wt,
  claim_component: N0,
  claim_element: kt,
  claim_space: Y0,
  claim_text: ul,
  create_component: R0,
  create_in_transition: wg,
  destroy_component: O0,
  destroy_each: kg,
  detach: Ae,
  element: Dt,
  empty: u4,
  ensure_array_like: c4,
  group_outros: Sr,
  init: Dg,
  insert_hydration: Lt,
  listen: Cr,
  mount_component: P0,
  noop: H5,
  run_all: qc,
  safe_not_equal: Sg,
  set_data: cl,
  set_input_value: Ks,
  set_style: Eg,
  space: X0,
  stop_propagation: Ag,
  text: hl,
  toggle_class: Q1,
  transition_in: Me,
  transition_out: Pe
} = window.__gradio__svelte__internal, { createEventDispatcher: Fg } = window.__gradio__svelte__internal, { onMount: Cg } = window.__gradio__svelte__internal;
function h4(r, e, t) {
  const n = r.slice();
  return n[50] = e[t], n;
}
function xg(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h = (
    /*stream_state*/
    r[14] === "open" && /*mode*/
    r[1].includes("send")
  ), _, g, b, y;
  e = new P5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        r[22]
      ),
      stream_state: (
        /*stream_state*/
        r[14]
      ),
      icon: (
        /*icon*/
        r[5]
      ),
      icon_button_color: (
        /*icon_button_color*/
        r[6]
      ),
      pulse_color: (
        /*pulse_color*/
        r[7]
      ),
      pending: (
        /*pending*/
        r[11]
      ),
      icon_radius: (
        /*icon_radius*/
        r[8]
      )
    }
  }), n = new kc({
    props: { time_limit: (
      /*_time_limit*/
      r[13]
    ) }
  });
  const D = [Mg, Qg, $g], k = [];
  function p(B, T) {
    return (
      /*stream_state*/
      B[14] === "waiting" ? 0 : (
        /*stream_state*/
        B[14] === "open" ? 1 : 2
      )
    );
  }
  o = p(r), s = k[o] = D[o](r);
  let S = (
    /*stream_state*/
    r[14] === "closed" && d4(r)
  ), E = (
    /*stream_state*/
    r[14] === "open" && /*mode*/
    r[1] === "send-receive" && f4(r)
  ), F = h && m4(r), $ = (
    /*options_open*/
    r[12] && /*selected_device*/
    r[18] && _4(r)
  );
  return {
    c() {
      R0(e.$$.fragment), t = X0(), R0(n.$$.fragment), a = X0(), i = Dt("div"), l = Dt("button"), s.c(), u = X0(), S && S.c(), c = X0(), E && E.c(), d = X0(), F && F.c(), _ = X0(), $ && $.c(), this.h();
    },
    l(B) {
      N0(e.$$.fragment, B), t = Y0(B), N0(n.$$.fragment, B), a = Y0(B), i = kt(B, "DIV", { class: !0 });
      var T = wt(i);
      l = kt(T, "BUTTON", { "aria-label": !0, class: !0 });
      var x = wt(l);
      s.l(x), x.forEach(Ae), u = Y0(T), S && S.l(T), c = Y0(T), E && E.l(T), d = Y0(T), F && F.l(T), _ = Y0(T), $ && $.l(T), T.forEach(Ae), this.h();
    },
    h() {
      Ce(l, "aria-label", "start stream"), Ce(l, "class", "svelte-k2wuss"), Ce(i, "class", "button-wrap svelte-k2wuss"), Q1(
        i,
        "pulse",
        /*stopword_recognized*/
        r[10]
      );
    },
    m(B, T) {
      P0(e, B, T), Lt(B, t, T), P0(n, B, T), Lt(B, a, T), Lt(B, i, T), gt(i, l), k[o].m(l, null), gt(i, u), S && S.m(i, null), gt(i, c), E && E.m(i, null), gt(i, d), F && F.m(i, null), gt(i, _), $ && $.m(i, null), g = !0, b || (y = Cr(
        l,
        "click",
        /*start_stream*/
        r[25]
      ), b = !0);
    },
    p(B, T) {
      const x = {};
      T[0] & /*stream_state*/
      16384 && (x.stream_state = /*stream_state*/
      B[14]), T[0] & /*icon*/
      32 && (x.icon = /*icon*/
      B[5]), T[0] & /*icon_button_color*/
      64 && (x.icon_button_color = /*icon_button_color*/
      B[6]), T[0] & /*pulse_color*/
      128 && (x.pulse_color = /*pulse_color*/
      B[7]), T[0] & /*pending*/
      2048 && (x.pending = /*pending*/
      B[11]), T[0] & /*icon_radius*/
      256 && (x.icon_radius = /*icon_radius*/
      B[8]), e.$set(x);
      const L = {};
      T[0] & /*_time_limit*/
      8192 && (L.time_limit = /*_time_limit*/
      B[13]), n.$set(L);
      let P = o;
      o = p(B), o === P ? k[o].p(B, T) : (Sr(), Pe(k[P], 1, 1, () => {
        k[P] = null;
      }), Dr(), s = k[o], s ? s.p(B, T) : (s = k[o] = D[o](B), s.c()), Me(s, 1), s.m(l, null)), /*stream_state*/
      B[14] === "closed" ? S ? (S.p(B, T), T[0] & /*stream_state*/
      16384 && Me(S, 1)) : (S = d4(B), S.c(), Me(S, 1), S.m(i, c)) : S && (Sr(), Pe(S, 1, 1, () => {
        S = null;
      }), Dr()), /*stream_state*/
      B[14] === "open" && /*mode*/
      B[1] === "send-receive" ? E ? (E.p(B, T), T[0] & /*stream_state, mode*/
      16386 && Me(E, 1)) : (E = f4(B), E.c(), Me(E, 1), E.m(i, d)) : E && (Sr(), Pe(E, 1, 1, () => {
        E = null;
      }), Dr()), T[0] & /*stream_state, mode*/
      16386 && (h = /*stream_state*/
      B[14] === "open" && /*mode*/
      B[1].includes("send")), h ? F ? (F.p(B, T), T[0] & /*stream_state, mode*/
      16386 && Me(F, 1)) : (F = m4(B), F.c(), Me(F, 1), F.m(i, _)) : F && (Sr(), Pe(F, 1, 1, () => {
        F = null;
      }), Dr()), /*options_open*/
      B[12] && /*selected_device*/
      B[18] ? $ ? ($.p(B, T), T[0] & /*options_open, selected_device*/
      266240 && Me($, 1)) : ($ = _4(B), $.c(), Me($, 1), $.m(i, null)) : $ && (Sr(), Pe($, 1, 1, () => {
        $ = null;
      }), Dr()), (!g || T[0] & /*stopword_recognized*/
      1024) && Q1(
        i,
        "pulse",
        /*stopword_recognized*/
        B[10]
      );
    },
    i(B) {
      g || (Me(e.$$.fragment, B), Me(n.$$.fragment, B), Me(s), Me(S), Me(E), Me(F), Me($), g = !0);
    },
    o(B) {
      Pe(e.$$.fragment, B), Pe(n.$$.fragment, B), Pe(s), Pe(S), Pe(E), Pe(F), Pe($), g = !1;
    },
    d(B) {
      B && (Ae(t), Ae(a), Ae(i)), O0(e, B), O0(n, B), k[o].d(), S && S.d(), E && E.d(), F && F.d(), $ && $.d(), b = !1, y();
    }
  };
}
function Tg(r) {
  let e, t, n, a;
  return t = new B5({ props: { icon: h1 } }), t.$on(
    "click",
    /*click_handler*/
    r[42]
  ), {
    c() {
      e = Dt("div"), R0(t.$$.fragment), this.h();
    },
    l(i) {
      e = kt(i, "DIV", { title: !0, style: !0 });
      var l = wt(e);
      N0(t.$$.fragment, l), l.forEach(Ae), this.h();
    },
    h() {
      Ce(e, "title", "grant webcam access"), Eg(e, "height", "100%");
    },
    m(i, l) {
      Lt(i, e, l), P0(t, e, null), a = !0;
    },
    p: H5,
    i(i) {
      a || (Me(t.$$.fragment, i), i && (n || vg(() => {
        n = wg(e, M5, { delay: 100, duration: 200 }), n.start();
      })), a = !0);
    },
    o(i) {
      Pe(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Ae(e), O0(t);
    }
  };
}
function $g(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[9].start || /*i18n*/
    r[4]("audio.record")) + ""
  ), l, o;
  return n = new L1({}), {
    c() {
      e = Dt("div"), t = Dt("div"), R0(n.$$.fragment), a = X0(), l = hl(i), this.h();
    },
    l(s) {
      e = kt(s, "DIV", { class: !0 });
      var u = wt(e);
      t = kt(u, "DIV", { class: !0, title: !0 });
      var c = wt(t);
      N0(n.$$.fragment, c), c.forEach(Ae), a = Y0(u), l = ul(u, i), u.forEach(Ae), this.h();
    },
    h() {
      Ce(t, "class", "icon color-primary svelte-k2wuss"), Ce(t, "title", "start recording"), Ce(e, "class", "icon-with-text svelte-k2wuss");
    },
    m(s, u) {
      Lt(s, e, u), gt(e, t), P0(n, t, null), gt(e, a), gt(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      528) && i !== (i = /*button_labels*/
      (s[9].start || /*i18n*/
      s[4]("audio.record")) + "") && cl(l, i);
    },
    i(s) {
      o || (Me(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Pe(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ae(e), O0(n);
    }
  };
}
function Qg(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[9].stop || /*i18n*/
    r[4]("audio.stop")) + ""
  ), l, o;
  const s = [zg, Bg], u = [];
  function c(d, h) {
    return (
      /*mode*/
      d[1] === "send-receive" ? 0 : 1
    );
  }
  return t = c(r), n = u[t] = s[t](r), {
    c() {
      e = Dt("div"), n.c(), a = X0(), l = hl(i), this.h();
    },
    l(d) {
      e = kt(d, "DIV", { class: !0 });
      var h = wt(e);
      n.l(h), a = Y0(h), l = ul(h, i), h.forEach(Ae), this.h();
    },
    h() {
      Ce(e, "class", "icon-with-text svelte-k2wuss");
    },
    m(d, h) {
      Lt(d, e, h), u[t].m(e, null), gt(e, a), gt(e, l), o = !0;
    },
    p(d, h) {
      let _ = t;
      t = c(d), t === _ ? u[t].p(d, h) : (Sr(), Pe(u[_], 1, 1, () => {
        u[_] = null;
      }), Dr(), n = u[t], n ? n.p(d, h) : (n = u[t] = s[t](d), n.c()), Me(n, 1), n.m(e, a)), (!o || h[0] & /*button_labels, i18n*/
      528) && i !== (i = /*button_labels*/
      (d[9].stop || /*i18n*/
      d[4]("audio.stop")) + "") && cl(l, i);
    },
    i(d) {
      o || (Me(n), o = !0);
    },
    o(d) {
      Pe(n), o = !1;
    },
    d(d) {
      d && Ae(e), u[t].d();
    }
  };
}
function Mg(r) {
  let e, t, n, a, i = (
    /*button_labels*/
    (r[9].waiting || "Connecting...") + ""
  ), l, o;
  return n = new o5({}), {
    c() {
      e = Dt("div"), t = Dt("div"), R0(n.$$.fragment), a = X0(), l = hl(i), this.h();
    },
    l(s) {
      e = kt(s, "DIV", { class: !0 });
      var u = wt(e);
      t = kt(u, "DIV", { class: !0, title: !0 });
      var c = wt(t);
      N0(n.$$.fragment, c), c.forEach(Ae), a = Y0(u), l = ul(u, i), u.forEach(Ae), this.h();
    },
    h() {
      Ce(t, "class", "icon color-primary svelte-k2wuss"), Ce(t, "title", "spinner"), Ce(e, "class", "icon-with-text svelte-k2wuss");
    },
    m(s, u) {
      Lt(s, e, u), gt(e, t), P0(n, t, null), gt(e, a), gt(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels*/
      512) && i !== (i = /*button_labels*/
      (s[9].waiting || "Connecting...") + "") && cl(l, i);
    },
    i(s) {
      o || (Me(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Pe(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ae(e), O0(n);
    }
  };
}
function Bg(r) {
  let e, t, n;
  return t = new L1({}), {
    c() {
      e = Dt("div"), R0(t.$$.fragment), this.h();
    },
    l(a) {
      e = kt(a, "DIV", { class: !0, title: !0 });
      var i = wt(e);
      N0(t.$$.fragment, i), i.forEach(Ae), this.h();
    },
    h() {
      Ce(e, "class", "icon color-primary svelte-k2wuss"), Ce(e, "title", "start recording");
    },
    m(a, i) {
      Lt(a, e, i), P0(t, e, null), n = !0;
    },
    p: H5,
    i(a) {
      n || (Me(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Pe(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Ae(e), O0(t);
    }
  };
}
function zg(r) {
  let e, t, n, a;
  return t = new z5({
    props: {
      audio_source_callback: (
        /*func*/
        r[43]
      ),
      stream_state: "open",
      icon: L1,
      icon_button_color: (
        /*icon_button_color*/
        r[6]
      ),
      pulse_color: (
        /*pulse_color*/
        r[7]
      )
    }
  }), {
    c() {
      e = Dt("div"), R0(t.$$.fragment), this.h();
    },
    l(i) {
      e = kt(i, "DIV", { class: !0, title: !0, style: !0 });
      var l = wt(e);
      N0(t.$$.fragment, l), l.forEach(Ae), this.h();
    },
    h() {
      Ce(e, "class", "icon svelte-k2wuss"), Ce(e, "title", "stop recording"), Ce(e, "style", n = `fill: ${/*icon_button_color*/
      r[6]}; stroke: ${/*icon_button_color*/
      r[6]}; color: ${/*icon_button_color*/
      r[6]};`);
    },
    m(i, l) {
      Lt(i, e, l), P0(t, e, null), a = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*stream*/
      65536 && (o.audio_source_callback = /*func*/
      i[43]), l[0] & /*icon_button_color*/
      64 && (o.icon_button_color = /*icon_button_color*/
      i[6]), l[0] & /*pulse_color*/
      128 && (o.pulse_color = /*pulse_color*/
      i[7]), t.$set(o), (!a || l[0] & /*icon_button_color*/
      64 && n !== (n = `fill: ${/*icon_button_color*/
      i[6]}; stroke: ${/*icon_button_color*/
      i[6]}; color: ${/*icon_button_color*/
      i[6]};`)) && Ce(e, "style", n);
    },
    i(i) {
      a || (Me(t.$$.fragment, i), a = !0);
    },
    o(i) {
      Pe(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Ae(e), O0(t);
    }
  };
}
function d4(r) {
  let e, t, n, a, i;
  return t = new q1({}), {
    c() {
      e = Dt("button"), R0(t.$$.fragment), this.h();
    },
    l(l) {
      e = kt(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = wt(e);
      N0(t.$$.fragment, o), o.forEach(Ae), this.h();
    },
    h() {
      Ce(e, "class", "icon svelte-k2wuss"), Ce(e, "aria-label", "select input source");
    },
    m(l, o) {
      Lt(l, e, o), P0(t, e, null), n = !0, a || (i = Cr(
        e,
        "click",
        /*click_handler_1*/
        r[44]
      ), a = !0);
    },
    p: H5,
    i(l) {
      n || (Me(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Pe(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Ae(e), O0(t), a = !1, i();
    }
  };
}
function f4(r) {
  let e, t, n, a, i, l, o, s, u;
  const c = [Lg, Ig], d = [];
  function h(_, g) {
    return (
      /*is_muted*/
      _[20] ? 0 : 1
    );
  }
  return n = h(r), a = d[n] = c[n](r), {
    c() {
      e = Dt("button"), t = Dt("div"), a.c(), this.h();
    },
    l(_) {
      e = kt(_, "BUTTON", { class: !0, "aria-label": !0 });
      var g = wt(e);
      t = kt(g, "DIV", { class: !0, style: !0 });
      var b = wt(t);
      a.l(b), b.forEach(Ae), g.forEach(Ae), this.h();
    },
    h() {
      Ce(t, "class", "icon svelte-k2wuss"), Ce(t, "style", i = `fill: ${/*icon_button_color*/
      r[6]}; stroke: ${/*icon_button_color*/
      r[6]}; color: ${/*icon_button_color*/
      r[6]};`), Ce(e, "class", "mute-button svelte-k2wuss"), Ce(e, "aria-label", l = /*is_muted*/
      r[20] ? "unmute audio" : "mute audio");
    },
    m(_, g) {
      Lt(_, e, g), gt(e, t), d[n].m(t, null), o = !0, s || (u = Cr(
        e,
        "click",
        /*toggleMute*/
        r[28]
      ), s = !0);
    },
    p(_, g) {
      let b = n;
      n = h(_), n !== b && (Sr(), Pe(d[b], 1, 1, () => {
        d[b] = null;
      }), Dr(), a = d[n], a || (a = d[n] = c[n](_), a.c()), Me(a, 1), a.m(t, null)), (!o || g[0] & /*icon_button_color*/
      64 && i !== (i = `fill: ${/*icon_button_color*/
      _[6]}; stroke: ${/*icon_button_color*/
      _[6]}; color: ${/*icon_button_color*/
      _[6]};`)) && Ce(t, "style", i), (!o || g[0] & /*is_muted*/
      1048576 && l !== (l = /*is_muted*/
      _[20] ? "unmute audio" : "mute audio")) && Ce(e, "aria-label", l);
    },
    i(_) {
      o || (Me(a), o = !0);
    },
    o(_) {
      Pe(a), o = !1;
    },
    d(_) {
      _ && Ae(e), d[n].d(), s = !1, u();
    }
  };
}
function Ig(r) {
  let e, t;
  return e = new I9({}), {
    c() {
      R0(e.$$.fragment);
    },
    l(n) {
      N0(e.$$.fragment, n);
    },
    m(n, a) {
      P0(e, n, a), t = !0;
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      O0(e, n);
    }
  };
}
function Lg(r) {
  let e, t;
  return e = new V9({}), {
    c() {
      R0(e.$$.fragment);
    },
    l(n) {
      N0(e.$$.fragment, n);
    },
    m(n, a) {
      P0(e, n, a), t = !0;
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      O0(e, n);
    }
  };
}
function m4(r) {
  let e, t, n, a, i, l, o, s, u;
  const c = [Ng, qg], d = [];
  function h(_, g) {
    return (
      /*is_mic_muted*/
      _[21] ? 0 : 1
    );
  }
  return n = h(r), a = d[n] = c[n](r), {
    c() {
      e = Dt("button"), t = Dt("div"), a.c(), this.h();
    },
    l(_) {
      e = kt(_, "BUTTON", { class: !0, "aria-label": !0 });
      var g = wt(e);
      t = kt(g, "DIV", { class: !0, style: !0 });
      var b = wt(t);
      a.l(b), b.forEach(Ae), g.forEach(Ae), this.h();
    },
    h() {
      Ce(t, "class", "icon svelte-k2wuss"), Ce(t, "style", i = `fill: ${/*icon_button_color*/
      r[6]}; stroke: ${/*icon_button_color*/
      r[6]}; color: ${/*icon_button_color*/
      r[6]};`), Ce(e, "class", "mute-button svelte-k2wuss"), Ce(e, "aria-label", l = /*is_mic_muted*/
      r[21] ? "unmute mic" : "mute mic");
    },
    m(_, g) {
      Lt(_, e, g), gt(e, t), d[n].m(t, null), o = !0, s || (u = Cr(
        e,
        "click",
        /*toggleMuteMicrophone*/
        r[29]
      ), s = !0);
    },
    p(_, g) {
      let b = n;
      n = h(_), n !== b && (Sr(), Pe(d[b], 1, 1, () => {
        d[b] = null;
      }), Dr(), a = d[n], a || (a = d[n] = c[n](_), a.c()), Me(a, 1), a.m(t, null)), (!o || g[0] & /*icon_button_color*/
      64 && i !== (i = `fill: ${/*icon_button_color*/
      _[6]}; stroke: ${/*icon_button_color*/
      _[6]}; color: ${/*icon_button_color*/
      _[6]};`)) && Ce(t, "style", i), (!o || g[0] & /*is_mic_muted*/
      2097152 && l !== (l = /*is_mic_muted*/
      _[21] ? "unmute mic" : "mute mic")) && Ce(e, "aria-label", l);
    },
    i(_) {
      o || (Me(a), o = !0);
    },
    o(_) {
      Pe(a), o = !1;
    },
    d(_) {
      _ && Ae(e), d[n].d(), s = !1, u();
    }
  };
}
function qg(r) {
  let e, t;
  return e = new h1({}), {
    c() {
      R0(e.$$.fragment);
    },
    l(n) {
      N0(e.$$.fragment, n);
    },
    m(n, a) {
      P0(e, n, a), t = !0;
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      O0(e, n);
    }
  };
}
function Ng(r) {
  let e, t;
  return e = new _g({}), {
    c() {
      R0(e.$$.fragment);
    },
    l(n) {
      N0(e.$$.fragment, n);
    },
    m(n, a) {
      P0(e, n, a), t = !0;
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Pe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      O0(e, n);
    }
  };
}
function _4(r) {
  let e, t, n, a, i, l, o;
  n = new q1({});
  function s(d, h) {
    return (
      /*available_audio_devices*/
      d[17].length === 0 ? Og : Rg
    );
  }
  let u = s(r), c = u(r);
  return {
    c() {
      e = Dt("select"), t = Dt("button"), R0(n.$$.fragment), a = X0(), c.c(), this.h();
    },
    l(d) {
      e = kt(d, "SELECT", { class: !0, "aria-label": !0 });
      var h = wt(e);
      t = kt(h, "BUTTON", { class: !0 });
      var _ = wt(t);
      N0(n.$$.fragment, _), a = Y0(_), _.forEach(Ae), c.l(h), h.forEach(Ae), this.h();
    },
    h() {
      Ce(t, "class", "inset-icon svelte-k2wuss"), Ce(e, "class", "select-wrap svelte-k2wuss"), Ce(e, "aria-label", "select source");
    },
    m(d, h) {
      Lt(d, e, h), gt(e, t), P0(n, t, null), gt(t, a), c.m(e, null), i = !0, l || (o = [
        Cr(t, "click", Ag(
          /*click_handler_2*/
          r[45]
        )),
        gg(Hg.call(
          null,
          e,
          /*handle_click_outside*/
          r[26]
        )),
        Cr(
          e,
          "change",
          /*handle_device_change*/
          r[27]
        )
      ], l = !0);
    },
    p(d, h) {
      u === (u = s(d)) && c ? c.p(d, h) : (c.d(1), c = u(d), c && (c.c(), c.m(e, null)));
    },
    i(d) {
      i || (Me(n.$$.fragment, d), i = !0);
    },
    o(d) {
      Pe(n.$$.fragment, d), i = !1;
    },
    d(d) {
      d && Ae(e), O0(n), c.d(), l = !1, qc(o);
    }
  };
}
function Rg(r) {
  let e, t = c4(
    /*available_audio_devices*/
    r[17]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = p4(h4(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = u4();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = u4();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      Lt(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_audio_devices, selected_device*/
      393216) {
        t = c4(
          /*available_audio_devices*/
          a[17]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = h4(a, t, l);
          n[l] ? n[l].p(o, i) : (n[l] = p4(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && Ae(e), kg(n, a);
    }
  };
}
function Og(r) {
  let e, t = (
    /*i18n*/
    r[4]("common.no_devices") + ""
  ), n;
  return {
    c() {
      e = Dt("option"), n = hl(t), this.h();
    },
    l(a) {
      e = kt(a, "OPTION", { class: !0 });
      var i = wt(e);
      n = ul(i, t), i.forEach(Ae), this.h();
    },
    h() {
      e.__value = "", Ks(e, e.__value), Ce(e, "class", "svelte-k2wuss");
    },
    m(a, i) {
      Lt(a, e, i), gt(e, n);
    },
    p(a, i) {
      i[0] & /*i18n*/
      16 && t !== (t = /*i18n*/
      a[4]("common.no_devices") + "") && cl(n, t);
    },
    d(a) {
      a && Ae(e);
    }
  };
}
function p4(r) {
  let e, t = (
    /*device*/
    r[50].label + ""
  ), n, a, i, l;
  return {
    c() {
      e = Dt("option"), n = hl(t), a = X0(), this.h();
    },
    l(o) {
      e = kt(o, "OPTION", { class: !0 });
      var s = wt(e);
      n = ul(s, t), a = Y0(s), s.forEach(Ae), this.h();
    },
    h() {
      e.__value = i = /*device*/
      r[50].deviceId, Ks(e, e.__value), e.selected = l = /*selected_device*/
      r[18].deviceId === /*device*/
      r[50].deviceId, Ce(e, "class", "svelte-k2wuss");
    },
    m(o, s) {
      Lt(o, e, s), gt(e, n), gt(e, a);
    },
    p(o, s) {
      s[0] & /*available_audio_devices*/
      131072 && t !== (t = /*device*/
      o[50].label + "") && cl(n, t), s[0] & /*available_audio_devices*/
      131072 && i !== (i = /*device*/
      o[50].deviceId) && (e.__value = i, Ks(e, e.__value)), s[0] & /*selected_device, available_audio_devices*/
      393216 && l !== (l = /*selected_device*/
      o[18].deviceId === /*device*/
      o[50].deviceId) && (e.selected = l);
    },
    d(o) {
      o && Ae(e);
    }
  };
}
function Pg(r) {
  let e, t, n, a, i, l, o, s, u, c;
  e = new G1({
    props: {
      show_label: (
        /*show_label*/
        r[3]
      ),
      Icon: i5,
      float: !1,
      label: (
        /*label*/
        r[2] || /*i18n*/
        r[4]("audio.audio")
      )
    }
  });
  const d = [Tg, xg], h = [];
  function _(g, b) {
    return (
      /*mic_accessed*/
      g[19] ? 1 : 0
    );
  }
  return l = _(r), o = h[l] = d[l](r), {
    c() {
      R0(e.$$.fragment), t = X0(), n = Dt("div"), a = Dt("audio"), i = X0(), o.c(), this.h();
    },
    l(g) {
      N0(e.$$.fragment, g), t = Y0(g), n = kt(g, "DIV", { class: !0 });
      var b = wt(n);
      a = kt(b, "AUDIO", { class: !0 }), wt(a).forEach(Ae), i = Y0(b), o.l(b), b.forEach(Ae), this.h();
    },
    h() {
      Ce(a, "class", "standard-player svelte-k2wuss"), Q1(
        a,
        "hidden",
        /*value*/
        r[0] === "__webrtc_value__"
      ), Ce(n, "class", "audio-container svelte-k2wuss");
    },
    m(g, b) {
      P0(e, g, b), Lt(g, t, b), Lt(g, n, b), gt(n, a), r[39](a), gt(n, i), h[l].m(n, null), s = !0, u || (c = [
        Cr(
          a,
          "load",
          /*load_handler*/
          r[38]
        ),
        Cr(
          a,
          "ended",
          /*ended_handler*/
          r[40]
        ),
        Cr(
          a,
          "play",
          /*play_handler*/
          r[41]
        )
      ], u = !0);
    },
    p(g, b) {
      const y = {};
      b[0] & /*show_label*/
      8 && (y.show_label = /*show_label*/
      g[3]), b[0] & /*label, i18n*/
      20 && (y.label = /*label*/
      g[2] || /*i18n*/
      g[4]("audio.audio")), e.$set(y), (!s || b[0] & /*value*/
      1) && Q1(
        a,
        "hidden",
        /*value*/
        g[0] === "__webrtc_value__"
      );
      let D = l;
      l = _(g), l === D ? h[l].p(g, b) : (Sr(), Pe(h[D], 1, 1, () => {
        h[D] = null;
      }), Dr(), o = h[l], o ? o.p(g, b) : (o = h[l] = d[l](g), o.c()), Me(o, 1), o.m(n, null));
    },
    i(g) {
      s || (Me(e.$$.fragment, g), Me(o), s = !0);
    },
    o(g) {
      Pe(e.$$.fragment, g), Pe(o), s = !1;
    },
    d(g) {
      g && (Ae(t), Ae(n)), O0(e, g), r[39](null), h[l].d(), u = !1, qc(c);
    }
  };
}
function Hg(r, e) {
  const t = (n) => {
    r && !r.contains(n.target) && !n.defaultPrevented && e(n);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function Vg(r, e, t) {
  var n = this && this.__awaiter || function(G, Ve, K, qt) {
    function Oe(wn) {
      return wn instanceof K ? wn : new K(function(rn) {
        rn(wn);
      });
    }
    return new (K || (K = Promise))(function(wn, rn) {
      function M0(Rt) {
        try {
          Nt(qt.next(Rt));
        } catch (Hn) {
          rn(Hn);
        }
      }
      function B0(Rt) {
        try {
          Nt(qt.throw(Rt));
        } catch (Hn) {
          rn(Hn);
        }
      }
      function Nt(Rt) {
        Rt.done ? wn(Rt.value) : Oe(Rt.value).then(M0, B0);
      }
      Nt((qt = qt.apply(G, Ve || [])).next());
    });
  };
  let { mode: a } = e, { value: i = null } = e, { label: l = void 0 } = e, { show_label: o = !0 } = e, { rtc_configuration: s = null } = e, { i18n: u } = e, { time_limit: c = null } = e, { track_constraints: d = {} } = e, { rtp_params: h = {} } = e, { on_change_cb: _ } = e, { reject_cb: g } = e, { icon: b = void 0 } = e, { icon_button_color: y = "var(--color-accent)" } = e, { pulse_color: D = "var(--color-accent)" } = e, { icon_radius: k = 50 } = e, { button_labels: p } = e, S = !1, E = !1, F;
  Cg(() => {
    i === "__webrtc_value__" && t(37, F = new Audio("https://huggingface.co/datasets/freddyaboulton/bucket/resolve/main/pop-sounds.mp3"));
  });
  let $ = (G) => {
    G === "stopword" ? (t(10, E = !0), setTimeout(
      () => {
        t(10, E = !1);
      },
      3e3
    )) : (console.debug("calling on_change_cb with msg", G), _(G));
  }, B = !1, T = null, { server: x } = e, L = "closed", P, ae, R = null, ee, Z, ze = null, oe = !1, ge = !1, N = !1;
  const H = () => a === "send" ? ee : P.srcObject, te = Fg();
  function he() {
    return n(this, void 0, void 0, function* () {
      try {
        const Ve = ze ? Object.assign(
          {
            deviceId: { exact: ze.deviceId }
          },
          d
        ) : d, K = yield navigator.mediaDevices.getUserMedia({ audio: Ve });
        t(16, ee = K);
      } catch (Ve) {
        if (!navigator.mediaDevices) {
          te("error", u("audio.no_device_support"));
          return;
        }
        if (Ve instanceof DOMException && Ve.name == "NotAllowedError") {
          te("error", u("audio.allow_recording_access"));
          return;
        }
        throw Ve;
      }
      t(17, Z = Tc(yield xc(), "audioinput")), t(19, oe = !0);
      const G = ee.getTracks().map((Ve) => {
        var K;
        return (K = Ve.getSettings()) === null || K === void 0 ? void 0 : K.deviceId;
      })[0];
      t(18, ze = G && Z.find((Ve) => Ve.deviceId === G) || Z[0]);
    });
  }
  function Ie() {
    return n(this, void 0, void 0, function* () {
      if (L === "open") {
        _n(ae), t(14, L = "closed"), t(13, T = null), yield he();
        return;
      }
      R = Math.random().toString(36).substring(2), t(0, i = R), ae = new RTCPeerConnection(s), ae.addEventListener("connectionstatechange", (K) => n(this, void 0, void 0, function* () {
        switch (ae.connectionState) {
          case "connected":
            console.info("connected"), t(14, L = "open"), t(13, T = c);
            break;
          case "disconnected":
            console.info("closed"), t(14, L = "closed"), t(13, T = null), _n(ae);
            break;
          case "failed":
            console.info("failed"), t(14, L = "closed"), t(13, T = null), te("error", "Connection failed!"), _n(ae);
            break;
        }
      })), t(14, L = "waiting"), t(16, ee = null);
      try {
        yield he();
      } catch (K) {
        if (!navigator.mediaDevices) {
          te("error", u("audio.no_device_support"));
          return;
        }
        if (K instanceof DOMException && K.name == "NotAllowedError") {
          te("error", u("audio.allow_recording_access"));
          return;
        }
        throw K;
      }
      if (ee == null) return;
      const G = (K) => {
        K.type === "log" && K.data === "pause_detected" ? t(11, S = !0) : K.type === "log" && K.data === "response_starting" && t(
          11,
          S = !1
        );
      }, Ve = setTimeout(
        () => {
          $({ type: "connection_timeout" });
        },
        5e3
      );
      al(ee, ae, a === "send" ? null : P, x.offer, R, "audio", $, h, G, g).then(([K]) => {
        clearTimeout(Ve), ae = K;
      }).catch(() => {
        console.info("catching"), clearTimeout(Ve), t(14, L = "closed");
      });
    });
  }
  function z(G) {
    G.preventDefault(), G.stopPropagation(), t(12, B = !1);
  }
  const xe = (G) => n(void 0, void 0, void 0, function* () {
    const K = G.target.value;
    t(16, ee = yield navigator.mediaDevices.getUserMedia({
      audio: Object.assign({ deviceId: { exact: K } }, d)
    })), t(18, ze = Z.find((qt) => qt.deviceId === K) || null), t(12, B = !1);
  });
  function pe() {
    P && (t(15, P.muted = !P.muted, P), t(20, ge = P.muted));
  }
  function Te() {
    if (ee && ee.getAudioTracks().length > 0) {
      const G = ee.getAudioTracks()[0];
      G.enabled = !G.enabled, t(21, N = !G.enabled);
    }
  }
  function ot(G) {
    yg.call(this, r, G);
  }
  function Ue(G) {
    bg[G ? "unshift" : "push"](() => {
      P = G, t(15, P);
    });
  }
  const qe = () => te("stop"), fe = () => te("play"), tt = async () => he(), Qe = () => ee, He = () => t(12, B = !0), ve = () => t(12, B = !1);
  return r.$$set = (G) => {
    "mode" in G && t(1, a = G.mode), "value" in G && t(0, i = G.value), "label" in G && t(2, l = G.label), "show_label" in G && t(3, o = G.show_label), "rtc_configuration" in G && t(30, s = G.rtc_configuration), "i18n" in G && t(4, u = G.i18n), "time_limit" in G && t(31, c = G.time_limit), "track_constraints" in G && t(32, d = G.track_constraints), "rtp_params" in G && t(33, h = G.rtp_params), "on_change_cb" in G && t(34, _ = G.on_change_cb), "reject_cb" in G && t(35, g = G.reject_cb), "icon" in G && t(5, b = G.icon), "icon_button_color" in G && t(6, y = G.icon_button_color), "pulse_color" in G && t(7, D = G.pulse_color), "icon_radius" in G && t(8, k = G.icon_radius), "button_labels" in G && t(9, p = G.button_labels), "server" in G && t(36, x = G.server);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*stopword_recognized*/
    1024 | r.$$.dirty[1] & /*notification_sound*/
    64 && E && F.play();
  }, [
    i,
    a,
    l,
    o,
    u,
    b,
    y,
    D,
    k,
    p,
    E,
    S,
    B,
    T,
    L,
    P,
    ee,
    Z,
    ze,
    oe,
    ge,
    N,
    H,
    te,
    he,
    Ie,
    z,
    xe,
    pe,
    Te,
    s,
    c,
    d,
    h,
    _,
    g,
    x,
    F,
    ot,
    Ue,
    qe,
    fe,
    tt,
    Qe,
    He,
    ve
  ];
}
class jg extends pg {
  constructor(e) {
    super(), Dg(
      this,
      e,
      Vg,
      Pg,
      Sg,
      {
        mode: 1,
        value: 0,
        label: 2,
        show_label: 3,
        rtc_configuration: 30,
        i18n: 4,
        time_limit: 31,
        track_constraints: 32,
        rtp_params: 33,
        on_change_cb: 34,
        reject_cb: 35,
        icon: 5,
        icon_button_color: 6,
        pulse_color: 7,
        icon_radius: 8,
        button_labels: 9,
        server: 36
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: Ug,
  attr: g4,
  check_outros: Nc,
  children: Gg,
  claim_component: Wg,
  claim_element: Zg,
  construct_svelte_component: v4,
  create_component: b4,
  create_slot: Yg,
  destroy_component: y4,
  detach: Js,
  element: Xg,
  empty: w4,
  get_all_dirty_from_scope: Kg,
  get_slot_changes: Jg,
  group_outros: Rc,
  init: ev,
  insert_hydration: Oc,
  mount_component: k4,
  safe_not_equal: tv,
  transition_in: Ki,
  transition_out: Ji,
  update_slot_base: nv
} = window.__gradio__svelte__internal;
function rv(r) {
  let e;
  const t = (
    /*#slots*/
    r[4].default
  ), n = Yg(
    t,
    r,
    /*$$scope*/
    r[3],
    null
  );
  return {
    c() {
      n && n.c();
    },
    l(a) {
      n && n.l(a);
    },
    m(a, i) {
      n && n.m(a, i), e = !0;
    },
    p(a, i) {
      n && n.p && (!e || i & /*$$scope*/
      8) && nv(
        n,
        t,
        a,
        /*$$scope*/
        a[3],
        e ? Jg(
          t,
          /*$$scope*/
          a[3],
          i,
          null
        ) : Kg(
          /*$$scope*/
          a[3]
        ),
        null
      );
    },
    i(a) {
      e || (Ki(n, a), e = !0);
    },
    o(a) {
      Ji(n, a), e = !1;
    },
    d(a) {
      n && n.d(a);
    }
  };
}
function av(r) {
  let e, t, n;
  var a = (
    /*icon*/
    r[2]
  );
  function i(l, o) {
    return {};
  }
  return a && (e = v4(a, i())), {
    c() {
      e && b4(e.$$.fragment), t = w4();
    },
    l(l) {
      e && Wg(e.$$.fragment, l), t = w4();
    },
    m(l, o) {
      e && k4(e, l, o), Oc(l, t, o), n = !0;
    },
    p(l, o) {
      if (o & /*icon*/
      4 && a !== (a = /*icon*/
      l[2])) {
        if (e) {
          Rc();
          const s = e;
          Ji(s.$$.fragment, 1, 0, () => {
            y4(s, 1);
          }), Nc();
        }
        a ? (e = v4(a, i()), b4(e.$$.fragment), Ki(e.$$.fragment, 1), k4(e, t.parentNode, t)) : e = null;
      }
    },
    i(l) {
      n || (e && Ki(e.$$.fragment, l), n = !0);
    },
    o(l) {
      e && Ji(e.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Js(t), e && y4(e, l);
    }
  };
}
function iv(r) {
  let e, t, n, a, i;
  const l = [av, rv], o = [];
  function s(u, c) {
    return (
      /*icon*/
      u[2] ? 0 : 1
    );
  }
  return t = s(r), n = o[t] = l[t](r), {
    c() {
      e = Xg("span"), n.c(), this.h();
    },
    l(u) {
      e = Zg(u, "SPAN", { style: !0 });
      var c = Gg(e);
      n.l(c), c.forEach(Js), this.h();
    },
    h() {
      g4(e, "style", a = `color: ${/*color*/
      r[0]}; font-size: ${/*fontSize*/
      r[1]}`);
    },
    m(u, c) {
      Oc(u, e, c), o[t].m(e, null), i = !0;
    },
    p(u, [c]) {
      let d = t;
      t = s(u), t === d ? o[t].p(u, c) : (Rc(), Ji(o[d], 1, 1, () => {
        o[d] = null;
      }), Nc(), n = o[t], n ? n.p(u, c) : (n = o[t] = l[t](u), n.c()), Ki(n, 1), n.m(e, null)), (!i || c & /*color, fontSize*/
      3 && a !== (a = `color: ${/*color*/
      u[0]}; font-size: ${/*fontSize*/
      u[1]}`)) && g4(e, "style", a);
    },
    i(u) {
      i || (Ki(n), i = !0);
    },
    o(u) {
      Ji(n), i = !1;
    },
    d(u) {
      u && Js(e), o[t].d();
    }
  };
}
function lv(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { color: i } = e, { fontSize: l = "16px" } = e, { icon: o = void 0 } = e;
  return r.$$set = (s) => {
    "color" in s && t(0, i = s.color), "fontSize" in s && t(1, l = s.fontSize), "icon" in s && t(2, o = s.icon), "$$scope" in s && t(3, a = s.$$scope);
  }, [i, l, o, a, n];
}
class ov extends Ug {
  constructor(e) {
    super(), ev(this, e, lv, iv, tv, { color: 0, fontSize: 1, icon: 2 });
  }
}
const {
  SvelteComponent: sv,
  append_hydration: uv,
  attr: Qi,
  children: D4,
  claim_svg_element: S4,
  detach: _s,
  init: cv,
  insert_hydration: hv,
  noop: ps,
  safe_not_equal: dv,
  svg_element: E4
} = window.__gradio__svelte__internal;
function fv(r) {
  let e, t;
  return {
    c() {
      e = E4("svg"), t = E4("path"), this.h();
    },
    l(n) {
      e = S4(n, "svg", {
        class: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0
      });
      var a = D4(e);
      t = S4(a, "path", { d: !0 }), D4(t).forEach(_s), a.forEach(_s), this.h();
    },
    h() {
      Qi(t, "d", "M899.925333 172.080762a48.761905 48.761905 0 0 1 0 28.525714l-207.969523 679.448381a48.761905 48.761905 0 0 1-81.115429 20.187429l-150.552381-150.552381-96.304762 96.329143a24.380952 24.380952 0 0 1-41.593905-17.237334v-214.966857l275.821715-243.370667-355.57181 161.596953-103.253333-103.228953a48.761905 48.761905 0 0 1 20.23619-81.091047L838.997333 139.702857a48.761905 48.761905 0 0 1 60.903619 32.353524z"), Qi(e, "class", "icon"), Qi(e, "viewBox", "0 0 1024 1024"), Qi(e, "version", "1.1"), Qi(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, a) {
      hv(n, e, a), uv(e, t);
    },
    p: ps,
    i: ps,
    o: ps,
    d(n) {
      n && _s(e);
    }
  };
}
class mv extends sv {
  constructor(e) {
    super(), cv(this, e, null, fv, dv, {});
  }
}
const {
  SvelteComponent: Hz,
  append_hydration: Vz,
  attr: jz,
  children: Uz,
  claim_svg_element: Gz,
  detach: Wz,
  init: Zz,
  insert_hydration: Yz,
  noop: Xz,
  safe_not_equal: Kz,
  svg_element: Jz
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append_hydration: D0,
  attr: ke,
  children: r0,
  claim_svg_element: a0,
  detach: jt,
  init: pv,
  insert_hydration: gv,
  noop: gs,
  safe_not_equal: vv,
  set_style: Kl,
  svg_element: i0
} = window.__gradio__svelte__internal;
function bv(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y;
  return {
    c() {
      e = i0("svg"), t = i0("defs"), n = i0("clipPath"), a = i0("rect"), i = i0("clipPath"), l = i0("rect"), o = i0("g"), s = i0("g"), u = i0("g"), c = i0("rect"), d = i0("g"), h = i0("path"), _ = i0("g"), g = i0("path"), b = i0("g"), y = i0("path"), this.h();
    },
    l(D) {
      e = a0(D, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var k = r0(e);
      t = a0(k, "defs", {});
      var p = r0(t);
      n = a0(p, "clipPath", { id: !0 });
      var S = r0(n);
      a = a0(S, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), r0(a).forEach(jt), S.forEach(jt), i = a0(p, "clipPath", { id: !0 });
      var E = r0(i);
      l = a0(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), r0(l).forEach(jt), E.forEach(jt), p.forEach(jt), o = a0(k, "g", { "clip-path": !0 });
      var F = r0(o);
      s = a0(F, "g", { "clip-path": !0 });
      var $ = r0(s);
      u = a0($, "g", {});
      var B = r0(u);
      c = a0(B, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), r0(c).forEach(jt), B.forEach(jt), d = a0($, "g", {});
      var T = r0(d);
      h = a0(T, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), r0(h).forEach(jt), T.forEach(jt), _ = a0($, "g", {});
      var x = r0(_);
      g = a0(x, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), r0(g).forEach(jt), x.forEach(jt), b = a0($, "g", {});
      var L = r0(b);
      y = a0(L, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), r0(y).forEach(jt), L.forEach(jt), $.forEach(jt), F.forEach(jt), k.forEach(jt), this.h();
    },
    h() {
      ke(a, "x", "0"), ke(a, "y", "0"), ke(a, "width", "20"), ke(a, "height", "20"), ke(a, "rx", "0"), ke(n, "id", "master_svg0_13_287/13_279"), ke(l, "x", "0"), ke(l, "y", "0"), ke(l, "width", "20"), ke(l, "height", "20"), ke(l, "rx", "0"), ke(i, "id", "master_svg1_13_287/13_279/13_018"), ke(c, "x", "0"), ke(c, "y", "0"), ke(c, "width", "20"), ke(c, "height", "20"), ke(c, "rx", "0"), ke(c, "fill", "#FFFFFF"), ke(c, "fill-opacity", "0.009999999776482582"), Kl(c, "mix-blend-mode", "passthrough"), ke(h, "d", "M7.55256390625,4.9999589765625Q7.52622390625,5.0016259765625,7.49983390625,5.0016259765625Q7.41759390625,5.0016259765625,7.33693390625,4.9855819765625Q7.25627390625,4.9695369765625,7.18029390625,4.9380649765625Q7.10431390625,4.9065929765625,7.03593390625,4.8609029765625Q6.96755390625,4.8152129765625,6.90940390625,4.7570599765625Q6.85125390625,4.6989069765625,6.80556390625,4.6305269765625Q6.75986390625,4.5621469765625005,6.72839390625,4.4861669765625Q6.69692390625,4.4101859765625,6.68088390625,4.3295259765625Q6.66483390625,4.2488662765625,6.66483390625,4.1666259765625Q6.66483390625,4.0843856765625,6.68088390625,4.0037259765625Q6.69692390625,3.9230659765625,6.72839390625,3.8470849765625Q6.75986390625,3.7711049765625,6.80556390625,3.7027249765625Q6.85125390625,3.6343449765624998,6.90940390625,3.5761919765625Q6.96755390625,3.5180389765625,7.03593390625,3.4723489765625Q7.10431390625,3.4266589765625,7.18029390625,3.3951869765625Q7.25627390625,3.3637149765625,7.33693390625,3.3476699765625Q7.41759390625,3.3316259765625,7.49983390625,3.3316259765625Q7.52622390625,3.3316259765625,7.55256390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,11.1972259765625Q15.83480390625,11.2235659765625,15.83480390625,11.2499559765625Q15.83480390625,11.332195976562499,15.81880390625,11.4128559765625Q15.80270390625,11.493515976562499,15.77130390625,11.5694959765625Q15.73980390625,11.645475976562501,15.69410390625,11.713855976562499Q15.64840390625,11.7822359765625,15.59030390625,11.840395976562501Q15.53210390625,11.898545976562499,15.46370390625,11.9442359765625Q15.39540390625,11.9899259765625,15.31940390625,12.0213959765625Q15.24340390625,12.0528659765625,15.16270390625,12.0689159765625Q15.08210390625,12.084955976562501,14.99980390625,12.084955976562501Q14.91760390625,12.084955976562501,14.83690390625,12.0689159765625Q14.75630390625,12.0528659765625,14.68030390625,12.0213959765625Q14.60430390625,11.9899259765625,14.53590390625,11.9442359765625Q14.46760390625,11.898545976562499,14.40940390625,11.840395976562501Q14.35120390625,11.7822359765625,14.30560390625,11.713855976562499Q14.25990390625,11.645475976562501,14.22840390625,11.5694959765625Q14.19690390625,11.493515976562499,14.18090390625,11.4128559765625Q14.16480390625,11.332195976562499,14.16480390625,11.2499559765625Q14.16480390625,11.2235659765625,14.16650390625,11.1972259765625L14.16650390625,4.9999589765625L7.55256390625,4.9999589765625ZM2.49983690625,5.0526899765625Q2.50150390625,5.0263509765625,2.50150390625,4.9999589765625Q2.50150390625,4.9177189765625,2.48545990625,4.8370589765625Q2.46941490625,4.7563989765625,2.43794290625,4.6804189765625Q2.40647090625,4.6044379765625,2.36078090625,4.5360579765625Q2.31509090625,4.4676779765625,2.25693790625,4.4095249765625Q2.1987849062500002,4.3513719765625,2.13040490625,4.3056819765625Q2.06202490625,4.2599918765625,1.98604490625,4.2285198765625Q1.91006390625,4.1970478765625,1.82940390625,4.1810035765625Q1.74874420625,4.1649593165625,1.66650390625,4.1649593065625Q1.58426360625,4.1649593165625,1.50360390625,4.1810035765625Q1.42294390625,4.1970478765625,1.34696290625,4.2285198765625Q1.27098290625,4.2599918765625,1.20260290625,4.3056819765625Q1.13422290625,4.3513719765625,1.0760699062499999,4.4095249765625Q1.01791690625,4.4676779765625,0.97222690625,4.5360579765625Q0.92653690625,4.6044379765625,0.89506490625,4.6804189765625Q0.86359290625,4.7563989765625,0.84754790625,4.8370589765625Q0.83150390625,4.9177189765625,0.83150390625,4.9999589765625Q0.83150390625,5.0263509765625,0.83317090625,5.0526899765625L0.83317090625,15.8333259765625Q0.83317090625,15.9153259765625,0.84918290625,15.9958259765625Q0.86519490625,16.0763259765625,0.89660490625,16.152225976562498Q0.92801390625,16.2280259765625,0.97361290625,16.2962259765625Q1.01921190625,16.3645259765625,1.07724790625,16.4225259765625Q1.13528490625,16.4806259765625,1.2035289062499999,16.5262259765625Q1.27177290625,16.5718259765625,1.34760090625,16.6032259765625Q1.42342990625,16.6346259765625,1.50392890625,16.6506259765625Q1.58442770625,16.6666259765625,1.66650390625,16.6666259765625L12.44710390625,16.6666259765625Q12.47340390625,16.6683259765625,12.49980390625,16.6683259765625Q12.58210390625,16.6683259765625,12.66270390625,16.652225976562498Q12.74340390625,16.6362259765625,12.81940390625,16.6047259765625Q12.89540390625,16.573225976562497,12.96370390625,16.5275259765625Q13.03210390625,16.4819259765625,13.09030390625,16.4237259765625Q13.14840390625,16.365525976562502,13.19410390625,16.2972259765625Q13.23980390625,16.2288259765625,13.27130390625,16.1528259765625Q13.30270390625,16.0768259765625,13.31880390625,15.9962259765625Q13.33480390625,15.9155259765625,13.33480390625,15.8333259765625Q13.33480390625,15.7510259765625,13.31880390625,15.6704259765625Q13.30270390625,15.5897259765625,13.27130390625,15.5137259765625Q13.23980390625,15.4377259765625,13.19410390625,15.3694259765625Q13.14840390625,15.3010259765625,13.09030390625,15.2428259765625Q13.03210390625,15.1847259765625,12.96370390625,15.1390259765625Q12.89540390625,15.0933259765625,12.81940390625,15.0618259765625Q12.74340390625,15.0304259765625,12.66270390625,15.0143259765625Q12.58210390625,14.9983259765625,12.49980390625,14.9983259765625Q12.47340390625,14.9983259765625,12.44710390625,14.9999259765625L2.49983690625,14.9999259765625L2.49983690625,5.0526899765625Z"), ke(h, "fill-rule", "evenodd"), ke(h, "fill", "#FFFFFF"), ke(h, "fill-opacity", "1"), Kl(h, "mix-blend-mode", "passthrough"), ke(g, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), ke(g, "fill-rule", "evenodd"), ke(g, "fill", "#FFFFFF"), ke(g, "fill-opacity", "1"), Kl(g, "mix-blend-mode", "passthrough"), ke(y, "d", "M1.1145349062499998,2.2931679765625Q0.97958490625,2.1742799765625,0.90554390625,2.0103779765625Q0.83150390625,1.8464759765625,0.83150390625,1.6666259765625Q0.83150390625,1.5843856765625,0.84754790625,1.5037259765625Q0.86359290625,1.4230659765625,0.89506490625,1.3470849765625Q0.92653690625,1.2711049765625,0.97222690625,1.2027249765625Q1.01791690625,1.1343449765625,1.0760699062499999,1.0761919765624999Q1.13422290625,1.0180389765625,1.20260290625,0.9723489765625Q1.27098290625,0.9266589765625,1.34696290625,0.8951869765625Q1.42294390625,0.8637149765625,1.50360390625,0.8476699765625Q1.58426360625,0.8316259765625,1.66650390625,0.8316259765625Q1.84635390625,0.8316259765625,2.01025590625,0.9056659765625Q2.17415790625,0.9797069765625,2.29304590625,1.1146569765624998L18.88520390625,17.7067259765625Q19.02010390625,17.8256259765625,19.09410390625,17.9895259765625Q19.16820390625,18.1534259765625,19.16820390625,18.3333259765625Q19.16820390625,18.4155259765625,19.15210390625,18.4962259765625Q19.13610390625,18.5768259765625,19.10460390625,18.6528259765625Q19.07310390625,18.7288259765625,19.02740390625,18.7972259765625Q18.98170390625,18.8655259765625,18.92360390625,18.9237259765625Q18.86540390625,18.9818259765625,18.79710390625,19.0275259765625Q18.72870390625,19.0732259765625,18.65270390625,19.1047259765625Q18.57670390625,19.1362259765625,18.49610390625,19.1522259765625Q18.41540390625,19.1683259765625,18.33320390625,19.1683259765625Q18.15330390625,19.1683259765625,17.98940390625,19.0942259765625Q17.82550390625,19.0202259765625,17.70660390625,18.8853259765625L1.1145349062499998,2.2931679765625Z"), ke(y, "fill-rule", "evenodd"), ke(y, "fill", "#FFFFFF"), ke(y, "fill-opacity", "1"), Kl(y, "mix-blend-mode", "passthrough"), ke(s, "clip-path", "url(#master_svg1_13_287/13_279/13_018)"), ke(o, "clip-path", "url(#master_svg0_13_287/13_279)"), ke(e, "xmlns", "http://www.w3.org/2000/svg"), ke(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), ke(e, "fill", "none"), ke(e, "version", "1.1"), ke(e, "width", "20"), ke(e, "height", "20"), ke(e, "viewBox", "0 0 20 20");
    },
    m(D, k) {
      gv(D, e, k), D0(e, t), D0(t, n), D0(n, a), D0(t, i), D0(i, l), D0(e, o), D0(o, s), D0(s, u), D0(u, c), D0(s, d), D0(d, h), D0(s, _), D0(_, g), D0(s, b), D0(b, y);
    },
    p: gs,
    i: gs,
    o: gs,
    d(D) {
      D && jt(e);
    }
  };
}
class yv extends _v {
  constructor(e) {
    super(), pv(this, e, null, bv, vv, {});
  }
}
const {
  SvelteComponent: wv,
  append_hydration: S0,
  attr: Se,
  children: l0,
  claim_svg_element: o0,
  detach: Ut,
  init: kv,
  insert_hydration: Dv,
  noop: vs,
  safe_not_equal: Sv,
  set_style: Jl,
  svg_element: s0
} = window.__gradio__svelte__internal;
function Ev(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y;
  return {
    c() {
      e = s0("svg"), t = s0("defs"), n = s0("clipPath"), a = s0("rect"), i = s0("clipPath"), l = s0("rect"), o = s0("g"), s = s0("g"), u = s0("g"), c = s0("rect"), d = s0("g"), h = s0("path"), _ = s0("g"), g = s0("path"), b = s0("g"), y = s0("path"), this.h();
    },
    l(D) {
      e = o0(D, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var k = l0(e);
      t = o0(k, "defs", {});
      var p = l0(t);
      n = o0(p, "clipPath", { id: !0 });
      var S = l0(n);
      a = o0(S, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), l0(a).forEach(Ut), S.forEach(Ut), i = o0(p, "clipPath", { id: !0 });
      var E = l0(i);
      l = o0(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), l0(l).forEach(Ut), E.forEach(Ut), p.forEach(Ut), o = o0(k, "g", { "clip-path": !0 });
      var F = l0(o);
      s = o0(F, "g", { "clip-path": !0 });
      var $ = l0(s);
      u = o0($, "g", {});
      var B = l0(u);
      c = o0(B, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), l0(c).forEach(Ut), B.forEach(Ut), d = o0($, "g", {});
      var T = l0(d);
      h = o0(T, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), l0(h).forEach(Ut), T.forEach(Ut), _ = o0($, "g", {});
      var x = l0(_);
      g = o0(x, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), l0(g).forEach(Ut), x.forEach(Ut), b = o0($, "g", {});
      var L = l0(b);
      y = o0(L, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), l0(y).forEach(Ut), L.forEach(Ut), $.forEach(Ut), F.forEach(Ut), k.forEach(Ut), this.h();
    },
    h() {
      Se(a, "x", "0"), Se(a, "y", "0"), Se(a, "width", "20"), Se(a, "height", "20"), Se(a, "rx", "0"), Se(n, "id", "master_svg0_13_279"), Se(l, "x", "0"), Se(l, "y", "0"), Se(l, "width", "20"), Se(l, "height", "20"), Se(l, "rx", "0"), Se(i, "id", "master_svg1_13_279/13_007"), Se(c, "x", "0"), Se(c, "y", "0"), Se(c, "width", "20"), Se(c, "height", "20"), Se(c, "rx", "0"), Se(c, "fill", "#FFFFFF"), Se(c, "fill-opacity", "0.009999999776482582"), Jl(c, "mix-blend-mode", "passthrough"), Se(h, "d", "M0.83317090625,15.8333259765625L0.83317090625,4.1666259765625Q0.83317090625,4.0845497765625,0.84918290625,4.0040509765625Q0.86519490625,3.9235519765625,0.89660490625,3.8477229765625Q0.92801390625,3.7718949765625,0.97361290625,3.7036509765625Q1.01921190625,3.6354069765625,1.07724790625,3.5773699765625Q1.13528490625,3.5193339765625,1.2035289062499999,3.4737349765625Q1.27177290625,3.4281359765625,1.34760090625,3.3967269765625Q1.42342990625,3.3653169765625,1.50392890625,3.3493049765625003Q1.58442770625,3.3332929765625,1.66650390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,15.8333259765625Q15.83320390625,15.9153259765625,15.81720390625,15.9958259765625Q15.80110390625,16.0763259765625,15.76970390625,16.152225976562498Q15.73830390625,16.2280259765625,15.69270390625,16.2962259765625Q15.64710390625,16.3645259765625,15.58910390625,16.4225259765625Q15.53100390625,16.4806259765625,15.46280390625,16.5262259765625Q15.39460390625,16.5718259765625,15.31870390625,16.6032259765625Q15.24290390625,16.6346259765625,15.16240390625,16.6506259765625Q15.08190390625,16.6666259765625,14.99980390625,16.6666259765625L1.66650390625,16.6666259765625Q1.58442770625,16.6666259765625,1.50392890625,16.6506259765625Q1.42342990625,16.6346259765625,1.34760090625,16.6032259765625Q1.27177290625,16.5718259765625,1.2035289062499999,16.5262259765625Q1.13528490625,16.4806259765625,1.07724790625,16.4225259765625Q1.01921190625,16.3645259765625,0.97361290625,16.2962259765625Q0.92801390625,16.2280259765625,0.89660490625,16.152225976562498Q0.86519490625,16.0763259765625,0.84918290625,15.9958259765625Q0.83317090625,15.9153259765625,0.83317090625,15.8333259765625ZM2.49983690625,4.9999589765625L2.49983690625,14.9999259765625L14.16650390625,14.9999259765625L14.16650390625,4.9999589765625L2.49983690625,4.9999589765625Z"), Se(h, "fill", "#FFFFFF"), Se(h, "fill-opacity", "1"), Jl(h, "mix-blend-mode", "passthrough"), Se(g, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), Se(g, "fill-rule", "evenodd"), Se(g, "fill", "#FFFFFF"), Se(g, "fill-opacity", "1"), Jl(g, "mix-blend-mode", "passthrough"), Se(y, "d", "M7.65749209375,7.3101989765625L10.11698609375,9.3597759765625Q10.17518609375,9.4082759765625,10.22367609375,9.4664759765625Q10.32979609375,9.5938159765625,10.37910609375,9.7520659765625Q10.42841609375,9.9103259765625,10.41340609375,10.0754059765625Q10.39839609375,10.2404859765625,10.321366093750001,10.3872559765625Q10.24432609375,10.5340259765625,10.11698609375,10.6401459765625L7.65748809375,12.6897259765625Q7.54118509375,12.7998059765625,7.39241009375,12.8590459765625Q7.24363409375,12.9182959765625,7.08349609375,12.9182959765625Q7.00125579375,12.9182959765625,6.92059609375,12.9022459765625Q6.83993609375,12.8862059765625,6.76395509375,12.8547359765625Q6.6879750937499995,12.8232559765625,6.61959509375,12.7775659765625Q6.55121509375,12.731875976562499,6.49306209375,12.673725976562501Q6.43490909375,12.6155759765625,6.38921909375,12.547195976562499Q6.34352909375,12.478815976562501,6.31205709375,12.4028359765625Q6.28058509375,12.3268559765625,6.26454009375,12.2461959765625Q6.24849609375,12.1655359765625,6.24849609375,12.0832959765625Q6.24849609375,11.9848059765625,6.27141009375,11.8890159765625Q6.29432409375,11.7932359765625,6.33889509375,11.7054159765625Q6.38346609375,11.6175859765625,6.44724609375,11.5425459765625Q6.51102709375,11.4674959765625,6.59051809375,11.4093459765625L8.28178609375,9.9999559765625L6.59051809375,8.5905679765625Q6.51102709375,8.5324209765625,6.44724609375,8.4573769765625Q6.38346509375,8.3823319765625,6.33889509375,8.2945069765625Q6.29432409375,8.2066819765625,6.27141009375,8.1108979765625Q6.24849609375,8.0151131765625,6.24849609375,7.9166259765625Q6.24849609375,7.8343856765625,6.26454009375,7.7537259765625Q6.28058509375,7.6730659765625,6.31205709375,7.5970849765625Q6.34352909375,7.5211049765624995,6.38921909375,7.4527249765625Q6.43490909375,7.3843449765625,6.49306209375,7.3261919765625Q6.55121509375,7.2680389765625,6.61959509375,7.2223489765625Q6.6879750937499995,7.1766589765625,6.76395509375,7.1451869765625Q6.83993609375,7.1137149765625,6.92059609375,7.0976699765625Q7.00125579375,7.0816259765625,7.08349609375,7.0816259765625Q7.24363509375,7.0816259765625,7.39241209375,7.1408709765625Q7.54118909375,7.2001159765625005,7.65749209375,7.3101989765625Z"), Se(y, "fill-rule", "evenodd"), Se(y, "fill", "#FFFFFF"), Se(y, "fill-opacity", "1"), Jl(y, "mix-blend-mode", "passthrough"), Se(s, "clip-path", "url(#master_svg1_13_279/13_007)"), Se(o, "clip-path", "url(#master_svg0_13_279)"), Se(e, "xmlns", "http://www.w3.org/2000/svg"), Se(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Se(e, "fill", "none"), Se(e, "version", "1.1"), Se(e, "width", "20"), Se(e, "height", "20"), Se(e, "viewBox", "0 0 20 20");
    },
    m(D, k) {
      Dv(D, e, k), S0(e, t), S0(t, n), S0(n, a), S0(t, i), S0(i, l), S0(e, o), S0(o, s), S0(s, u), S0(u, c), S0(s, d), S0(d, h), S0(s, _), S0(_, g), S0(s, b), S0(b, y);
    },
    p: vs,
    i: vs,
    o: vs,
    d(D) {
      D && Ut(e);
    }
  };
}
class Av extends wv {
  constructor(e) {
    super(), kv(this, e, null, Ev, Sv, {});
  }
}
const {
  SvelteComponent: Fv,
  append_hydration: Xn,
  attr: Ke,
  children: Fn,
  claim_svg_element: Cn,
  detach: on,
  init: Cv,
  insert_hydration: xv,
  noop: bs,
  safe_not_equal: Tv,
  set_style: ys,
  svg_element: xn
} = window.__gradio__svelte__internal;
function $v(r) {
  let e, t, n, a, i, l, o, s, u, c, d;
  return {
    c() {
      e = xn("svg"), t = xn("defs"), n = xn("clipPath"), a = xn("rect"), i = xn("g"), l = xn("g"), o = xn("path"), s = xn("g"), u = xn("path"), c = xn("g"), d = xn("path"), this.h();
    },
    l(h) {
      e = Cn(h, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = Fn(e);
      t = Cn(_, "defs", {});
      var g = Fn(t);
      n = Cn(g, "clipPath", { id: !0 });
      var b = Fn(n);
      a = Cn(b, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), Fn(a).forEach(on), b.forEach(on), g.forEach(on), i = Cn(_, "g", { "clip-path": !0 });
      var y = Fn(i);
      l = Cn(y, "g", {});
      var D = Fn(l);
      o = Cn(D, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Fn(o).forEach(on), D.forEach(on), s = Cn(y, "g", {});
      var k = Fn(s);
      u = Cn(k, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Fn(u).forEach(on), k.forEach(on), c = Cn(y, "g", {});
      var p = Fn(c);
      d = Cn(p, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Fn(d).forEach(on), p.forEach(on), y.forEach(on), _.forEach(on), this.h();
    },
    h() {
      Ke(a, "x", "0"), Ke(a, "y", "0"), Ke(a, "width", "20"), Ke(a, "height", "20"), Ke(a, "rx", "0"), Ke(n, "id", "master_svg0_20_113"), Ke(o, "d", "M17.52452171875,9.078936578124999Q17.659471718749998,8.960048578125,17.73351171875,8.796145578125Q17.80755171875,8.632242578125,17.80755171875,8.452392578125Q17.80755171875,8.370152278125,17.79151171875,8.289492578125Q17.77546171875,8.208832578125,17.74399171875,8.132851578125Q17.71252171875,8.056871578125,17.66683171875,7.988491578125Q17.62114171875,7.920111578125,17.56299171875,7.861958578125Q17.50483171875,7.803805578125,17.43645171875,7.758115578125Q17.36807171875,7.712425578125,17.29209171875,7.680953578125Q17.21611171875,7.649481578125,17.13545171875,7.633436578125Q17.05479171875,7.617392578125,16.97255171875,7.617392578125Q16.79270171875,7.617392578125,16.62880171875,7.691433578125Q16.46490171875,7.765474578125,16.34601171875,7.900425578125L12.88504271875,11.361392578124999Q12.75009271875,11.480282578125,12.67605171875,11.644182578125001Q12.60201171875,11.808082578125,12.60201171875,11.987932578125001Q12.60201171875,12.070172578125,12.61805571875,12.150832578125Q12.63410071875,12.231492578125,12.66557271875,12.307472578125001Q12.69704471875,12.383452578125,12.74273471875,12.451832578125Q12.78842471875,12.520212578125001,12.84657771875,12.578362578124999Q12.90473071875,12.636522578125,12.97311071875,12.682212578125Q13.04149071875,12.727902578125,13.11747071875,12.759372578125Q13.19345171875,12.790842578125,13.27411171875,12.806892578125Q13.35477141875,12.822932578125,13.43701171875,12.822932578125Q13.61685971875,12.822932578125,13.78076071875,12.748892578125Q13.94466171875,12.674852578125,14.06354971875,12.539902578125L17.52452171875,9.078936578124999Z"), Ke(o, "fill-rule", "evenodd"), Ke(o, "fill", "#FFFFFF"), Ke(o, "fill-opacity", "1"), ys(o, "mix-blend-mode", "passthrough"), Ke(u, "d", "M12.88553,9.078933578125Q12.75058,8.960045578125,12.67654,8.796143578125Q12.6025,8.632241578125,12.6025,8.452392578125Q12.6025,8.370152278125,12.618544,8.289492578125Q12.634589,8.208832578125,12.666061,8.132851578125Q12.697533,8.056871578125,12.743223,7.988491578125Q12.788913,7.920111578125,12.847066,7.861958578125Q12.905219,7.803805578125,12.973599,7.758115578125Q13.041979,7.712425578125,13.117959,7.680953578125Q13.19394,7.649481578125,13.2746,7.633436578125Q13.3552597,7.617392578125,13.4375,7.617392578125Q13.617349,7.617392578125,13.781251,7.691432578125Q13.945153,7.765472578125,14.064041,7.900422578125L17.52501,11.361392578124999Q17.659959999999998,11.480282578125,17.734,11.644182578125001Q17.80804,11.808082578125,17.80804,11.987932578125001Q17.80804,12.070172578125,17.792,12.150832578125Q17.77595,12.231492578125,17.74448,12.307472578125001Q17.71301,12.383452578125,17.66732,12.451832578125Q17.62163,12.520212578125001,17.56347,12.578362578124999Q17.50532,12.636522578125,17.43694,12.682212578125Q17.36856,12.727902578125,17.29258,12.759372578125Q17.2166,12.790842578125,17.13594,12.806892578125Q17.05528,12.822932578125,16.97304,12.822932578125Q16.79319,12.822932578125,16.62929,12.748892578125Q16.46539,12.674852578125,16.3465,12.539902578125L12.88553,9.078933578125Z"), Ke(u, "fill-rule", "evenodd"), Ke(u, "fill", "#FFFFFF"), Ke(u, "fill-opacity", "1"), ys(u, "mix-blend-mode", "passthrough"), Ke(d, "d", "M4.44364390625,5.42117L2.49983690625,5.42117Q1.80948090625,5.42117,1.32132890625,5.90931Q0.83317090625,6.39747,0.83317090625,7.08783L0.83317090625,12.8496Q0.83317090625,13.54,1.32132990625,14.0281Q1.80948090625,14.5163,2.49983690625,14.5163L4.43961390625,14.5163Q6.77175390625,18.3333,9.99983390625,18.3333Q10.08191390625,18.3333,10.16241390625,18.3173Q10.24291390625,18.301299999999998,10.31874390625,18.2699Q10.39456390625,18.238500000000002,10.46281390625,18.1929Q10.53105390625,18.1473,10.58909390625,18.0893Q10.64713390625,18.0312,10.69272390625,17.963Q10.73832390625,17.8947,10.76973390625,17.8189Q10.80114390625,17.7431,10.81715390625,17.662599999999998Q10.83317390625,17.5821,10.83317390625,17.5L10.83317390625,2.5Q10.83317390625,2.4179238,10.81715390625,2.337425Q10.80114390625,2.256926,10.76973390625,2.181097Q10.73832390625,2.105269,10.69272390625,2.037025Q10.64712390625,1.968781,10.58909390625,1.910744Q10.53105390625,1.852708,10.46281390625,1.807109Q10.39456390625,1.76151,10.31874390625,1.7301009999999999Q10.24291390625,1.698691,10.16241390625,1.682679Q10.08191390625,1.666667,9.99983390625,1.666667Q6.77619390625,1.666667,4.44364390625,5.42117ZM4.91587390625,7.08783Q5.02559390625,7.08783,5.13157390625,7.05943Q5.23755390625,7.03103,5.3325739062499995,6.97617Q5.42758390625,6.92131,5.50516390625,6.84372Q5.58274390625,6.76614,5.63759390625,6.67111Q7.22859390625,3.91495,9.16650390625,3.434681L9.16650390625,16.563299999999998Q7.23188390625,16.074199999999998,5.6405439062500005,13.2715Q5.58600390625,13.1754,5.50830390625,13.0969Q5.4306139062500005,13.0184,5.33514390625,12.9628Q5.23966390625,12.9072,5.1330139062499995,12.8784Q5.02635390625,12.8496,4.91587390625,12.8496L2.49983690625,12.8496L2.49983790625,7.08783L4.91587390625,7.08783Z"), Ke(d, "fill-rule", "evenodd"), Ke(d, "fill", "#FFFFFF"), Ke(d, "fill-opacity", "1"), ys(d, "mix-blend-mode", "passthrough"), Ke(i, "clip-path", "url(#master_svg0_20_113)"), Ke(e, "xmlns", "http://www.w3.org/2000/svg"), Ke(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ke(e, "fill", "none"), Ke(e, "version", "1.1"), Ke(e, "width", "20"), Ke(e, "height", "20"), Ke(e, "viewBox", "0 0 20 20");
    },
    m(h, _) {
      xv(h, e, _), Xn(e, t), Xn(t, n), Xn(n, a), Xn(e, i), Xn(i, l), Xn(l, o), Xn(i, s), Xn(s, u), Xn(i, c), Xn(c, d);
    },
    p: bs,
    i: bs,
    o: bs,
    d(h) {
      h && on(e);
    }
  };
}
class Qv extends Fv {
  constructor(e) {
    super(), Cv(this, e, null, $v, Tv, {});
  }
}
const {
  SvelteComponent: Mv,
  append_hydration: E0,
  attr: De,
  children: u0,
  claim_svg_element: c0,
  detach: Gt,
  init: Bv,
  insert_hydration: zv,
  noop: ws,
  safe_not_equal: Iv,
  set_style: e1,
  svg_element: h0
} = window.__gradio__svelte__internal;
function Lv(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y;
  return {
    c() {
      e = h0("svg"), t = h0("defs"), n = h0("clipPath"), a = h0("rect"), i = h0("clipPath"), l = h0("rect"), o = h0("g"), s = h0("g"), u = h0("g"), c = h0("rect"), d = h0("g"), h = h0("path"), _ = h0("g"), g = h0("path"), b = h0("g"), y = h0("path"), this.h();
    },
    l(D) {
      e = c0(D, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var k = u0(e);
      t = c0(k, "defs", {});
      var p = u0(t);
      n = c0(p, "clipPath", { id: !0 });
      var S = u0(n);
      a = c0(S, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), u0(a).forEach(Gt), S.forEach(Gt), i = c0(p, "clipPath", { id: !0 });
      var E = u0(i);
      l = c0(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), u0(l).forEach(Gt), E.forEach(Gt), p.forEach(Gt), o = c0(k, "g", { "clip-path": !0 });
      var F = u0(o);
      s = c0(F, "g", { "clip-path": !0 });
      var $ = u0(s);
      u = c0($, "g", {});
      var B = u0(u);
      c = c0(B, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), u0(c).forEach(Gt), B.forEach(Gt), d = c0($, "g", {});
      var T = u0(d);
      h = c0(T, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), u0(h).forEach(Gt), T.forEach(Gt), _ = c0($, "g", {});
      var x = u0(_);
      g = c0(x, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), u0(g).forEach(Gt), x.forEach(Gt), b = c0($, "g", {});
      var L = u0(b);
      y = c0(L, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), u0(y).forEach(Gt), L.forEach(Gt), $.forEach(Gt), F.forEach(Gt), k.forEach(Gt), this.h();
    },
    h() {
      De(a, "x", "0"), De(a, "y", "0"), De(a, "width", "20"), De(a, "height", "20"), De(a, "rx", "0"), De(n, "id", "master_svg0_13_280"), De(l, "x", "0"), De(l, "y", "0"), De(l, "width", "20"), De(l, "height", "20"), De(l, "rx", "0"), De(i, "id", "master_svg1_13_280/13_053"), De(c, "x", "0"), De(c, "y", "0"), De(c, "width", "20"), De(c, "height", "20"), De(c, "rx", "0"), De(c, "fill", "#FFFFFF"), De(c, "fill-opacity", "0.009999999776482582"), e1(c, "mix-blend-mode", "passthrough"), De(h, "d", "M4.443888046875,5.42117L2.500081046875,5.42117Q1.809725046875,5.42117,1.321573046875,5.90931Q0.833415046875,6.39747,0.833415046875,7.08783L0.833415046875,12.8496Q0.833415046875,13.54,1.321574046875,14.0281Q1.809725046875,14.5163,2.500081046875,14.5163L4.439858046875,14.5163Q6.771998046875,18.3333,10.000078046875,18.3333Q10.082158046875,18.3333,10.162658046875,18.3173Q10.243158046875,18.301299999999998,10.318988046875,18.2699Q10.394808046875,18.238500000000002,10.463058046875,18.1929Q10.531298046875,18.1473,10.589338046875,18.0893Q10.647378046875,18.0312,10.692968046875,17.963Q10.738568046875,17.8947,10.769978046875,17.8189Q10.801388046875,17.7431,10.817398046875,17.662599999999998Q10.833418046875,17.5821,10.833418046875,17.5L10.833418046875,2.5Q10.833418046875,2.4179238,10.817398046875,2.337425Q10.801388046875,2.256926,10.769978046875,2.181097Q10.738568046875,2.105269,10.692968046875,2.037025Q10.647368046875,1.968781,10.589338046875,1.910744Q10.531298046875,1.852708,10.463058046875,1.807109Q10.394808046875,1.76151,10.318988046875,1.7301009999999999Q10.243158046875,1.698691,10.162658046875,1.682679Q10.082158046875,1.666667,10.000078046875,1.666667Q6.776438046875,1.666667,4.443888046875,5.42117ZM4.916118046875,7.08783Q5.025838046875,7.08783,5.131818046875,7.05943Q5.237798046875,7.03103,5.3328180468749995,6.97617Q5.427828046875,6.92131,5.505408046875,6.84372Q5.582988046875,6.76614,5.637838046875,6.67111Q7.228838046875,3.91495,9.166748046875,3.434681L9.166748046875,16.563299999999998Q7.232128046875,16.074199999999998,5.6407880468750005,13.2715Q5.586248046875,13.1754,5.508548046875,13.0969Q5.4308580468750005,13.0184,5.335388046875,12.9628Q5.239908046875,12.9072,5.1332580468749995,12.8784Q5.026598046875,12.8496,4.916118046875,12.8496L2.500081046875,12.8496L2.500082046875,7.08783L4.916118046875,7.08783Z"), De(h, "fill-rule", "evenodd"), De(h, "fill", "#FFFFFF"), De(h, "fill-opacity", "1"), e1(h, "mix-blend-mode", "passthrough"), De(g, "d", "M12.813896953124999,6.903831Q12.740067953125,6.845187,12.681175953125,6.771557Q12.622282953125,6.697926,12.581291953125,6.613017Q12.540300953125,6.528109,12.519276953125,6.436197Q12.498251953125,6.3442856,12.498251953125,6.25Q12.498251953125,6.1677597,12.514295953125,6.0871Q12.530340953125,6.00644,12.561812953125,5.930459Q12.593284953125,5.8544789999999995,12.638974953125,5.786099Q12.684664953125,5.717719,12.742817953125,5.659566Q12.800970953125,5.601413,12.869350953125,5.555723Q12.937730953125,5.510033,13.013710953125,5.478561Q13.089691953125,5.447089,13.170351953125,5.431044Q13.251011653125,5.415,13.333251953125,5.415Q13.501904953125,5.415,13.657335953125,5.4804580000000005Q13.812766953125,5.545916,13.930607953125,5.66657Q14.362131953125001,6.059567,14.707911953125,6.532997Q15.248111953125001,7.2726299999999995,15.535961953125,8.14354Q15.833251953125,9.04304,15.833251953125,10Q15.833251953125,10.94869,15.540941953125,11.84127Q15.257921953125,12.70551,14.726221953125,13.4418Q14.373671953125,13.92992,13.930609953125,14.33343Q13.812768953125,14.45408,13.657336953125,14.51954Q13.501904953125,14.585,13.333251953125,14.585Q13.251011653125,14.585,13.170351953125,14.56895Q13.089691953125,14.55291,13.013710953125,14.52144Q12.937730953125,14.48997,12.869350953125,14.44428Q12.800970953125,14.39859,12.742817953125,14.34043Q12.684664953125,14.28228,12.638974953125,14.213899999999999Q12.593284953125,14.145520000000001,12.561812953125,14.06954Q12.530340953125,13.99356,12.514295953125,13.9129Q12.498251953125,13.832239999999999,12.498251953125,13.75Q12.498251953125,13.655719999999999,12.519276953125,13.5638Q12.540300953125,13.47189,12.581291953125,13.386980000000001Q12.622282953125,13.30207,12.681174953125,13.228439999999999Q12.740067953125,13.154810000000001,12.813895953125,13.09617Q13.125969953125,12.8109,13.375114153125,12.46595Q14.166584953125,11.36993,14.166584953125,10Q14.166584953125,8.61762,13.362005753125,7.516Q13.117749953125,7.181583,12.813896953124999,6.903831Z"), De(g, "fill-rule", "evenodd"), De(g, "fill", "#FFFFFF"), De(g, "fill-opacity", "1"), e1(g, "mix-blend-mode", "passthrough"), De(y, "d", "M14.863105578125,2.228405984375Q16.823672578125,3.456592984375,17.969842578125,5.468508984375Q19.166602578125,7.569218984375,19.166602578125,10.000018984375Q19.166602578125,12.469708984375,17.933552578125,14.594658984375Q16.751772578125,16.631258984375002,14.739248578125,17.847858984375Q14.525103578125,17.995758984375,14.264892578125,17.995758984375Q14.182652278125,17.995758984375,14.101992578125,17.979658984375Q14.021332578125,17.963658984375,13.945351578125,17.932158984375Q13.869371578125,17.900658984375,13.800991578125,17.854958984375Q13.732611578125,17.809358984375002,13.674458578125,17.751158984375Q13.616305578125,17.692958984375,13.570615578125,17.624658984375Q13.524925578125,17.556258984375,13.493453578125,17.480258984375Q13.461981578125,17.404258984374998,13.445936578125,17.323658984375Q13.429892578125,17.242958984375,13.429892578125,17.160758984375Q13.429892578125,17.045958984374998,13.460862578124999,16.935458984375Q13.491831578125,16.824858984375,13.551473578125,16.726858984375Q13.611115578125,16.628758984375,13.695005578125,16.550458984375Q13.778896578125,16.472058984375,13.880811578125,16.419258984375Q15.525652578125,15.423558984375,16.492012578125,13.758158984375Q17.499932578125,12.021168984375,17.499932578125,10.000018984375Q17.499932578125,8.010658984374999,16.521692578125,6.293508984375Q15.584492578125,4.648418984375,13.982075578125,3.643182984375Q13.882499578125,3.589574984375,13.800770578125,3.511412984375Q13.719041578125,3.433249984375,13.661047578125,3.336162984375Q13.603053578125,3.239076984375,13.572972578125,3.130062984375Q13.542891578125,3.021047984375,13.542891578125,2.907958984375Q13.542891578125,2.825718684375,13.558936578125,2.745058984375Q13.574980578125,2.664398984375,13.606452578125,2.588417984375Q13.637924578125,2.512437984375,13.683614578125,2.444057984375Q13.729305578125,2.3756779843749998,13.787457578125,2.317524984375Q13.845610578125,2.259371984375,13.913990578125,2.213681984375Q13.982370578125,2.167991984375,14.058351578125,2.136519984375Q14.134331578125,2.105047984375,14.214991478125,2.089002984375Q14.295651478125,2.072958984375,14.377891578125,2.072958984375Q14.508378578125,2.072958984375,14.632644578125,2.112769984375Q14.756910578125,2.152579984375,14.863105578125,2.228405984375Z"), De(y, "fill-rule", "evenodd"), De(y, "fill", "#FFFFFF"), De(y, "fill-opacity", "1"), e1(y, "mix-blend-mode", "passthrough"), De(s, "clip-path", "url(#master_svg1_13_280/13_053)"), De(o, "clip-path", "url(#master_svg0_13_280)"), De(e, "xmlns", "http://www.w3.org/2000/svg"), De(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), De(e, "fill", "none"), De(e, "version", "1.1"), De(e, "width", "20"), De(e, "height", "20"), De(e, "viewBox", "0 0 20 20");
    },
    m(D, k) {
      zv(D, e, k), E0(e, t), E0(t, n), E0(n, a), E0(t, i), E0(i, l), E0(e, o), E0(o, s), E0(s, u), E0(u, c), E0(s, d), E0(d, h), E0(s, _), E0(_, g), E0(s, b), E0(b, y);
    },
    p: ws,
    i: ws,
    o: ws,
    d(D) {
      D && Gt(e);
    }
  };
}
class qv extends Mv {
  constructor(e) {
    super(), Bv(this, e, null, Lv, Iv, {});
  }
}
const {
  SvelteComponent: Nv,
  append_hydration: Wt,
  attr: be,
  children: Mt,
  claim_svg_element: Bt,
  detach: Ct,
  init: Rv,
  insert_hydration: Ov,
  noop: ks,
  safe_not_equal: Pv,
  set_style: Mi,
  svg_element: zt
} = window.__gradio__svelte__internal;
function Hv(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y, D, k;
  return {
    c() {
      e = zt("svg"), t = zt("defs"), n = zt("clipPath"), a = zt("rect"), i = zt("clipPath"), l = zt("rect"), o = zt("g"), s = zt("g"), u = zt("g"), c = zt("path"), d = zt("g"), h = zt("path"), _ = zt("g"), g = zt("path"), b = zt("g"), y = zt("path"), D = zt("g"), k = zt("path"), this.h();
    },
    l(p) {
      e = Bt(p, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var S = Mt(e);
      t = Bt(S, "defs", {});
      var E = Mt(t);
      n = Bt(E, "clipPath", { id: !0 });
      var F = Mt(n);
      a = Bt(F, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), Mt(a).forEach(Ct), F.forEach(Ct), i = Bt(E, "clipPath", { id: !0 });
      var $ = Mt(i);
      l = Bt($, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), Mt(l).forEach(Ct), $.forEach(Ct), E.forEach(Ct), o = Bt(S, "g", { "clip-path": !0 });
      var B = Mt(o);
      s = Bt(B, "g", { "clip-path": !0 });
      var T = Mt(s);
      u = Bt(T, "g", {});
      var x = Mt(u);
      c = Bt(x, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Mt(c).forEach(Ct), x.forEach(Ct), d = Bt(T, "g", {});
      var L = Mt(d);
      h = Bt(L, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Mt(h).forEach(Ct), L.forEach(Ct), _ = Bt(T, "g", {});
      var P = Mt(_);
      g = Bt(P, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Mt(g).forEach(Ct), P.forEach(Ct), b = Bt(T, "g", {});
      var ae = Mt(b);
      y = Bt(ae, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Mt(y).forEach(Ct), ae.forEach(Ct), D = Bt(T, "g", {});
      var R = Mt(D);
      k = Bt(R, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Mt(k).forEach(Ct), R.forEach(Ct), T.forEach(Ct), B.forEach(Ct), S.forEach(Ct), this.h();
    },
    h() {
      be(a, "x", "0"), be(a, "y", "0"), be(a, "width", "20"), be(a, "height", "20"), be(a, "rx", "0"), be(n, "id", "master_svg0_13_287/13_278"), be(l, "x", "0"), be(l, "y", "0"), be(l, "width", "20"), be(l, "height", "20"), be(l, "rx", "0"), be(i, "id", "master_svg1_13_287/13_278/13_040"), be(c, "d", "M7.34851109375,12.6516259765625Q8.44685609375,13.7499259765625,10.00016609375,13.7499259765625Q11.55346609375,13.7499259765625,12.65181609375,12.6516259765625Q13.75016609375,11.5532659765625,13.75016609375,9.9999559765625L13.75016609375,4.5832959765625Q13.75016609375,3.0299959765624997,12.65181609375,1.9316429765625Q11.55346609375,0.8332929765625,10.00016609375,0.8332919765625Q8.44685609375,0.8332929765625,7.34851109375,1.9316429765625Q6.25016309375,3.0299959765624997,6.25016309375,4.5832959765625L6.25016309375,9.9999559765625Q6.25016309375,11.5532659765625,7.34851109375,12.6516259765625ZM11.47330609375,11.4730959765625Q10.86310609375,12.0833259765625,10.00016609375,12.0833259765625Q9.13721609375,12.0833259765625,8.527026093749999,11.4730959765625Q7.91682909375,10.8629059765625,7.91682909375,9.9999559765625L7.91683009375,4.5832959765625Q7.91683009375,3.7203459765625,8.527026093749999,3.1101559765625Q9.13721609375,2.4999589765625,10.00016609375,2.4999589765625Q10.86310609375,2.4999589765625,11.47330609375,3.1101559765625Q12.08349609375,3.7203459765625,12.08349609375,4.5832959765625L12.08349609375,9.9999559765625Q12.08349609375,10.8629059765625,11.47330609375,11.4730959765625Z"), be(c, "fill-rule", "evenodd"), be(c, "fill", "#FFFFFF"), be(c, "fill-opacity", "1"), Mi(c, "mix-blend-mode", "passthrough"), be(h, "d", "M17.08315046875,9.6393233234375Q17.08502046875,9.6113801234375,17.08502046875,9.5833740234375Q17.08502046875,9.5011337234375,17.06898046875,9.4204740234375Q17.05293046875,9.3398140234375,17.02146046875,9.2638330234375Q16.98999046875,9.1878530234375,16.94430046875,9.1194730234375Q16.89861046875,9.0510930234375,16.84046046875,8.9929400234375Q16.78230046875,8.9347870234375,16.71392346875,8.8890970234375Q16.64554246875,8.8434070234375,16.56956246875,8.8119350234375Q16.49358246875,8.7804630234375,16.41292246875,8.7644180234375Q16.33226246875,8.7483740234375,16.25002246875,8.7483740234375Q16.16778146875,8.7483740234375,16.08712146875,8.7644180234375Q16.00646146875,8.7804630234375,15.93048146875,8.8119350234375Q15.85450146875,8.8434070234375,15.78612106875,8.8890970234375Q15.71774076875,8.9347870234375,15.65958806875,8.9929400234375Q15.60143546875,9.0510930234375,15.55574546875,9.1194730234375Q15.51005446875,9.1878530234375,15.47858246875,9.2638330234375Q15.44711046875,9.3398140234375,15.43106646875,9.4204740234375Q15.41502246875,9.5011337234375,15.41502246875,9.5833740234375Q15.41502246875,9.6080265234375,15.41647646875,9.6326360234375Q15.40712446875,10.7164940234375,14.98582546875,11.7046140234375Q14.89498046875,11.8831040234375,14.89498046875,12.0833740234375Q14.89498046875,12.1656140234375,14.91102446875,12.2462740234375Q14.92706946875,12.3269340234375,14.95854146875,12.4029140234375Q14.99001346875,12.4788940234375,15.03570346875,12.5472740234375Q15.08139346875,12.6156540234375,15.13954646875,12.6738040234375Q15.19769946875,12.7319640234375,15.26607946875,12.7776540234375Q15.33445946875,12.8233440234375,15.41043946875,12.8548140234375Q15.48642046875,12.8862840234375,15.56708046875,12.9023340234375Q15.64774016875,12.9183740234375,15.72998046875,12.9183740234375Q15.79409136875,12.9183740234375,15.85745046875,12.9085840234375Q15.92081046875,12.8988040234375,15.98193346875,12.8794540234375Q16.04305546875,12.8601140234375,16.10050846875,12.8316640234375Q16.15796246875,12.8032140234375,16.21039846875,12.7663240234375Q16.26283546875,12.7294440234375,16.309026468749998,12.6849840234375Q16.35521746875,12.6405240234375,16.39408046875,12.5895340234375Q16.43294246875,12.538544023437499,16.46356646875,12.4822240234375Q16.49418946875,12.4258940234375,16.51585446875,12.3655540234375Q17.07244046875,11.0643540234375,17.08315046875,9.6393233234375Z"), be(h, "fill-rule", "evenodd"), be(h, "fill", "#FFFFFF"), be(h, "fill-opacity", "1"), Mi(h, "mix-blend-mode", "passthrough"), be(g, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q11.1917,16.6667040234375,12.30806,16.2819440234375Q12.37346,16.2636640234375,12.43505,16.235064023437502Q12.49663,16.2064640234375,12.55279,16.1682840234375Q12.60894,16.1301040234375,12.65819,16.0833540234375Q12.70744,16.036604023437498,12.74849,15.9825140234375Q12.78954,15.9284240234375,12.82131,15.868404023437499Q12.85308,15.8083940234375,12.87473,15.7440340234375Q12.89639,15.6796740234375,12.90736,15.6126640234375Q12.91833,15.5456540234375,12.91833,15.4777440234375Q12.91833,15.3955040234375,12.90229,15.3148440234375Q12.88624,15.2341840234375,12.85477,15.1582040234375Q12.8233,15.082224023437501,12.77761,15.0138440234375Q12.73192,14.9454640234375,12.67377,14.8873140234375Q12.61561,14.8291640234375,12.54723,14.783474023437499Q12.47885,14.7377840234375,12.40287,14.7063140234375Q12.32689,14.6748340234375,12.24623,14.658794023437501Q12.16557,14.6427540234375,12.08333,14.642744023437501Q11.91469,14.642744023437501,11.75926,14.7082040234375Q10.9093,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), be(g, "fill-rule", "evenodd"), be(g, "fill", "#FFFFFF"), be(g, "fill-opacity", "1"), Mi(g, "mix-blend-mode", "passthrough"), be(y, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), be(y, "fill-rule", "evenodd"), be(y, "fill", "#FFFFFF"), be(y, "fill-opacity", "1"), Mi(y, "mix-blend-mode", "passthrough"), be(k, "d", "M1.9480309999999998,3.126542Q1.813081,3.007654,1.7390400000000001,2.843752Q1.665,2.67985,1.665,2.5Q1.665,2.4177597,1.681044,2.3371Q1.697089,2.25644,1.728561,2.180459Q1.760033,2.104479,1.805723,2.036099Q1.851413,1.967719,1.9095659999999999,1.9095659999999999Q1.967719,1.851413,2.036099,1.805723Q2.104479,1.760033,2.180459,1.728561Q2.25644,1.697089,2.3371,1.681044Q2.4177597,1.665,2.5,1.665Q2.67985,1.665,2.843752,1.7390400000000001Q3.007654,1.813081,3.126542,1.9480309999999998L18.052,16.8735Q18.1869,16.9923,18.261,17.1562Q18.335,17.3202,18.335,17.5Q18.335,17.5822,18.319000000000003,17.6629Q18.3029,17.7436,18.2714,17.819499999999998Q18.240000000000002,17.8955,18.1943,17.963900000000002Q18.148600000000002,18.0323,18.090400000000002,18.090400000000002Q18.0323,18.148600000000002,17.963900000000002,18.1943Q17.8955,18.240000000000002,17.819499999999998,18.2714Q17.7436,18.3029,17.6629,18.319000000000003Q17.5822,18.335,17.5,18.335Q17.3202,18.335,17.1562,18.261Q16.9923,18.1869,16.8735,18.052L1.9480309999999998,3.126542Z"), be(k, "fill-rule", "evenodd"), be(k, "fill", "#FFFFFF"), be(k, "fill-opacity", "1"), Mi(k, "mix-blend-mode", "passthrough"), be(s, "clip-path", "url(#master_svg1_13_287/13_278/13_040)"), be(o, "clip-path", "url(#master_svg0_13_287/13_278)"), be(e, "xmlns", "http://www.w3.org/2000/svg"), be(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), be(e, "fill", "none"), be(e, "version", "1.1"), be(e, "width", "20"), be(e, "height", "20"), be(e, "viewBox", "0 0 20 20");
    },
    m(p, S) {
      Ov(p, e, S), Wt(e, t), Wt(t, n), Wt(n, a), Wt(t, i), Wt(i, l), Wt(e, o), Wt(o, s), Wt(s, u), Wt(u, c), Wt(s, d), Wt(d, h), Wt(s, _), Wt(_, g), Wt(s, b), Wt(b, y), Wt(s, D), Wt(D, k);
    },
    p: ks,
    i: ks,
    o: ks,
    d(p) {
      p && Ct(e);
    }
  };
}
class Vv extends Nv {
  constructor(e) {
    super(), Rv(this, e, null, Hv, Pv, {});
  }
}
const {
  SvelteComponent: jv,
  append_hydration: A0,
  attr: Ee,
  children: d0,
  claim_svg_element: f0,
  detach: Zt,
  init: Uv,
  insert_hydration: Gv,
  noop: Ds,
  safe_not_equal: Wv,
  set_style: t1,
  svg_element: m0
} = window.__gradio__svelte__internal;
function Zv(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y;
  return {
    c() {
      e = m0("svg"), t = m0("defs"), n = m0("clipPath"), a = m0("rect"), i = m0("clipPath"), l = m0("rect"), o = m0("g"), s = m0("g"), u = m0("g"), c = m0("rect"), d = m0("g"), h = m0("path"), _ = m0("g"), g = m0("path"), b = m0("g"), y = m0("path"), this.h();
    },
    l(D) {
      e = f0(D, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var k = d0(e);
      t = f0(k, "defs", {});
      var p = d0(t);
      n = f0(p, "clipPath", { id: !0 });
      var S = d0(n);
      a = f0(S, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), d0(a).forEach(Zt), S.forEach(Zt), i = f0(p, "clipPath", { id: !0 });
      var E = d0(i);
      l = f0(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), d0(l).forEach(Zt), E.forEach(Zt), p.forEach(Zt), o = f0(k, "g", { "clip-path": !0 });
      var F = d0(o);
      s = f0(F, "g", { "clip-path": !0 });
      var $ = d0(s);
      u = f0($, "g", {});
      var B = d0(u);
      c = f0(B, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), d0(c).forEach(Zt), B.forEach(Zt), d = f0($, "g", {});
      var T = d0(d);
      h = f0(T, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), d0(h).forEach(Zt), T.forEach(Zt), _ = f0($, "g", {});
      var x = d0(_);
      g = f0(x, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), d0(g).forEach(Zt), x.forEach(Zt), b = f0($, "g", {});
      var L = d0(b);
      y = f0(L, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), d0(y).forEach(Zt), L.forEach(Zt), $.forEach(Zt), F.forEach(Zt), k.forEach(Zt), this.h();
    },
    h() {
      Ee(a, "x", "0"), Ee(a, "y", "0"), Ee(a, "width", "20"), Ee(a, "height", "20"), Ee(a, "rx", "0"), Ee(n, "id", "master_svg0_13_278"), Ee(l, "x", "0"), Ee(l, "y", "0"), Ee(l, "width", "20"), Ee(l, "height", "20"), Ee(l, "rx", "0"), Ee(i, "id", "master_svg1_13_278/13_029"), Ee(c, "x", "0"), Ee(c, "y", "0"), Ee(c, "width", "20"), Ee(c, "height", "20"), Ee(c, "rx", "0"), Ee(c, "fill", "#FFFFFF"), Ee(c, "fill-opacity", "0.009999999776482582"), t1(c, "mix-blend-mode", "passthrough"), Ee(h, "d", "M6.249918953125,9.9999559765625L6.249918953125,4.5832959765625Q6.249918953125,3.0299959765624997,7.348267953125,1.9316419765625Q8.446621953125,0.8332929765625,9.999921953125,0.8332929765625Q11.553221953125,0.8332929765625,12.651571953125,1.9316419765625Q13.749921953125,3.0299959765624997,13.749921953125,4.5832959765625L13.749921953125,9.9999559765625Q13.749921953125,11.5532559765625,12.651571953125,12.6516259765625Q11.553221953125,13.7499259765625,9.999921953125,13.7499259765625Q8.446621953125,13.7499259765625,7.348267953125,12.6516259765625Q6.249918953125,11.5532559765625,6.249918953125,9.9999559765625ZM7.916584953125,9.9999559765625Q7.916584953125,10.8629059765625,8.526781953124999,11.4730959765625Q9.136971953125,12.0833259765625,9.999921953125,12.0833259765625Q10.862861953125,12.0833259765625,11.473061953125,11.4730959765625Q12.083251953125,10.8629059765625,12.083251953125,9.9999559765625L12.083251953125,4.5832959765625Q12.083251953125,3.7203459765625,11.473061953125,3.1101559765625Q10.862861953125,2.4999589765625,9.999921953125,2.4999589765625Q9.136971953125,2.4999589765625,8.526781953124999,3.1101559765625Q7.916584953125,3.7203459765625,7.916584953125,4.5832959765625L7.916584953125,9.9999559765625Z"), Ee(h, "fill", "#FFFFFF"), Ee(h, "fill-opacity", "1"), t1(h, "mix-blend-mode", "passthrough"), Ee(g, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q12.93402,16.6667040234375,15.0087,14.5920540234375Q17.0636,12.5370940234375,17.0831,9.6390003234375Q17.085,9.6112181234375,17.085,9.5833740234375Q17.085,9.5011337234375,17.069000000000003,9.4204740234375Q17.0529,9.3398140234375,17.0214,9.2638330234375Q16.990000000000002,9.1878530234375,16.9443,9.1194730234375Q16.898600000000002,9.0510930234375,16.840400000000002,8.9929400234375Q16.7823,8.9347870234375,16.713900000000002,8.8890970234375Q16.6455,8.8434070234375,16.569499999999998,8.8119350234375Q16.4936,8.7804630234375,16.4129,8.7644180234375Q16.3322,8.7483740234375,16.25,8.7483740234375Q16.1678,8.7483740234375,16.0871,8.7644180234375Q16.0064,8.7804630234375,15.9305,8.8119350234375Q15.8545,8.8434070234375,15.7861,8.8890970234375Q15.7177,8.9347870234375,15.6596,8.9929400234375Q15.6014,9.0510930234375,15.5557,9.1194730234375Q15.51,9.1878530234375,15.4786,9.2638330234375Q15.4471,9.3398140234375,15.431,9.4204740234375Q15.415,9.5011337234375,15.415,9.5833740234375Q15.415,9.6081817234375,15.4165,9.6329456234375Q15.3991,11.8445940234375,13.8302,13.413544023437499Q12.24366,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), Ee(g, "fill-rule", "evenodd"), Ee(g, "fill", "#FFFFFF"), Ee(g, "fill-opacity", "1"), t1(g, "mix-blend-mode", "passthrough"), Ee(y, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), Ee(y, "fill-rule", "evenodd"), Ee(y, "fill", "#FFFFFF"), Ee(y, "fill-opacity", "1"), t1(y, "mix-blend-mode", "passthrough"), Ee(s, "clip-path", "url(#master_svg1_13_278/13_029)"), Ee(o, "clip-path", "url(#master_svg0_13_278)"), Ee(e, "xmlns", "http://www.w3.org/2000/svg"), Ee(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ee(e, "fill", "none"), Ee(e, "version", "1.1"), Ee(e, "width", "20"), Ee(e, "height", "20"), Ee(e, "viewBox", "0 0 20 20");
    },
    m(D, k) {
      Gv(D, e, k), A0(e, t), A0(t, n), A0(n, a), A0(t, i), A0(i, l), A0(e, o), A0(o, s), A0(s, u), A0(u, c), A0(s, d), A0(d, h), A0(s, _), A0(_, g), A0(s, b), A0(b, y);
    },
    p: Ds,
    i: Ds,
    o: Ds,
    d(D) {
      D && Zt(e);
    }
  };
}
class Yv extends jv {
  constructor(e) {
    super(), Uv(this, e, null, Zv, Wv, {});
  }
}
const {
  SvelteComponent: Xv,
  append_hydration: A4,
  attr: Tn,
  children: Ss,
  claim_svg_element: Es,
  detach: n1,
  init: Kv,
  insert_hydration: Jv,
  noop: As,
  safe_not_equal: eb,
  set_style: tb,
  svg_element: Fs
} = window.__gradio__svelte__internal;
function nb(r) {
  let e, t, n;
  return {
    c() {
      e = Fs("svg"), t = Fs("g"), n = Fs("path"), this.h();
    },
    l(a) {
      e = Es(a, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = Ss(e);
      t = Es(i, "g", {});
      var l = Ss(t);
      n = Es(l, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), Ss(n).forEach(n1), l.forEach(n1), i.forEach(n1), this.h();
    },
    h() {
      Tn(n, "d", "M13.802466686534881,1.1380186865348816Q13.89646668653488,1.0444176865348815,13.947366686534881,0.9218876865348815Q13.998366686534881,0.7993576865348816,13.998366686534881,0.6666666865348816Q13.998366686534881,0.6011698865348816,13.98556668653488,0.5369316865348817Q13.972766686534882,0.4726936865348816,13.947666686534882,0.4121826865348816Q13.922666686534882,0.3516706865348816,13.886266686534881,0.2972126865348816Q13.849866686534881,0.2427536865348816,13.803566686534882,0.19644068653488161Q13.757266686534882,0.15012768653488162,13.702766686534881,0.11373968653488165Q13.648366686534882,0.07735168653488156,13.587866686534882,0.052286686534881555Q13.527266686534881,0.02722268653488158,13.463066686534882,0.014444686534881623Q13.398866686534882,0.0016666865348815563,13.333366686534882,0.0016666865348815563Q13.201466686534882,0.0016666865348815563,13.079566686534882,0.051981686534881555Q12.957666686534882,0.10229768653488158,12.864266686534881,0.1953146865348816L12.863066686534882,0.19413268653488158L4.624996686534882,8.392776686534882L1.1369396865348815,4.921396686534882L1.1357636865348817,4.922586686534881Q1.0422996865348817,4.829566686534881,0.9204146865348816,4.779246686534882Q0.7985286865348816,4.728936686534881,0.6666666865348816,4.728936686534881Q0.6011698865348816,4.728936686534881,0.5369316865348817,4.741706686534882Q0.4726936865348816,4.754486686534881,0.4121826865348816,4.779556686534882Q0.3516706865348816,4.804616686534882,0.2972126865348816,4.8410066865348815Q0.2427536865348816,4.8773966865348815,0.19644068653488161,4.9237066865348815Q0.15012768653488162,4.970016686534882,0.11373968653488165,5.024476686534881Q0.07735168653488156,5.078936686534882,0.052286686534881555,5.139446686534882Q0.02722268653488158,5.199956686534882,0.014444686534881623,5.2641966865348815Q0.0016666865348815563,5.328436686534881,0.0016666865348815563,5.3939366865348815Q0.0016666865348815563,5.526626686534882,0.05259268653488158,5.649156686534882Q0.10351768653488158,5.771686686534881,0.1975696865348816,5.865286686534882L0.1963936865348816,5.866466686534881L4.1547266865348815,9.805866686534882Q4.201126686534882,9.852046686534882,4.255616686534882,9.888306686534882Q4.310106686534882,9.924576686534882,4.3706166865348814,9.949556686534882Q4.431126686534881,9.974536686534881,4.495326686534882,9.987266686534882Q4.559536686534882,9.999996686534882,4.624996686534882,9.999996686534882Q4.690456686534882,9.999996686534882,4.754666686534882,9.987266686534882Q4.818876686534882,9.974536686534881,4.879386686534882,9.949556686534882Q4.939886686534882,9.924576686534882,4.994386686534882,9.888306686534882Q5.048876686534881,9.852046686534882,5.0952766865348815,9.805866686534882L13.803566686534882,1.1392006865348816L13.802466686534881,1.1380186865348816Z"), Tn(n, "fill-rule", "evenodd"), Tn(n, "fill", "#E0E0FC"), Tn(n, "fill-opacity", "1"), tb(n, "mix-blend-mode", "passthrough"), Tn(e, "xmlns", "http://www.w3.org/2000/svg"), Tn(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Tn(e, "fill", "none"), Tn(e, "version", "1.1"), Tn(e, "width", "14.000000357627869"), Tn(e, "height", "10.000000357627869"), Tn(e, "viewBox", "0 0 14.000000357627869 10.000000357627869");
    },
    m(a, i) {
      Jv(a, e, i), A4(e, t), A4(t, n);
    },
    p: As,
    i: As,
    o: As,
    d(a) {
      a && n1(e);
    }
  };
}
class Pc extends Xv {
  constructor(e) {
    super(), Kv(this, e, null, nb, eb, {});
  }
}
const {
  SvelteComponent: rb,
  append_hydration: Wa,
  attr: It,
  children: ha,
  claim_svg_element: da,
  detach: Ur,
  init: ab,
  insert_hydration: ib,
  noop: Cs,
  safe_not_equal: lb,
  svg_element: fa
} = window.__gradio__svelte__internal;
function ob(r) {
  let e, t, n, a, i, l, o;
  return {
    c() {
      e = fa("svg"), t = fa("defs"), n = fa("clipPath"), a = fa("rect"), i = fa("g"), l = fa("g"), o = fa("path"), this.h();
    },
    l(s) {
      e = da(s, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var u = ha(e);
      t = da(u, "defs", {});
      var c = ha(t);
      n = da(c, "clipPath", { id: !0 });
      var d = ha(n);
      a = da(d, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), ha(a).forEach(Ur), d.forEach(Ur), c.forEach(Ur), i = da(u, "g", { "clip-path": !0 });
      var h = ha(i);
      l = da(h, "g", {});
      var _ = ha(l);
      o = da(_, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), ha(o).forEach(Ur), _.forEach(Ur), h.forEach(Ur), u.forEach(Ur), this.h();
    },
    h() {
      It(a, "x", "0"), It(a, "y", "0"), It(a, "width", "20"), It(a, "height", "20"), It(a, "rx", "0"), It(n, "id", "master_svg0_13_323"), It(o, "d", "M16.66650390625,5.0000440234375L16.66650390625,9.1667040234375C16.66650390625,9.626944023437499,17.03960390625,10.0000440234375,17.49980390625,10.0000440234375C17.96010390625,10.0000440234375,18.33320390625,9.626944023437499,18.33320390625,9.1667040234375L18.33320390625,5.0000440234375Q18.33300390625,4.3097080234375,17.84490390625,3.8215540234375Q17.35690390625,3.3333740234375,16.66650390625,3.3333740234375L3.33317390625,3.3333740234375Q2.64293990625,3.3333981633375,2.15478490625,3.8215540234375Q1.66650390625,4.3096850234375,1.66650390625,5.0000440234375L1.66650390625,15.0000740234375Q1.66662937425,15.6903740234375,2.15478490625,16.1785740234375Q2.64281490625,16.6666740234375,3.33317390625,16.6666740234375L9.99983390625,16.6666740234375C10.22085390625,16.6666740234375,10.43281390625,16.5788740234375,10.58909390625,16.4226740234375C10.74537390625,16.2663740234375,10.83317390625,16.0543740234375,10.83317390625,15.8333740234375C10.83317390625,15.3731740234375,10.46007390625,15.0000740234375,9.99983390625,15.0000740234375L3.33317390625,15.0000740234375L3.33317390625,5.0000440234375L16.66650390625,5.0000440234375ZM11.66650390625,12.5000440234375L11.66650390625,15.0000740234375Q11.66650390625,15.0818740234375,11.67450390625,15.1633740234375Q11.68260390625,15.2448740234375,11.69850390625,15.3251740234375Q11.71450390625,15.4054740234375,11.73830390625,15.4838740234375Q11.76200390625,15.5621740234375,11.79340390625,15.6378740234375Q11.82470390625,15.7134740234375,11.86330390625,15.7856740234375Q11.90190390625,15.8578740234375,11.94740390625,15.9259740234375Q11.99290390625,15.9940740234375,12.04480390625,16.0573740234375Q12.09680390625,16.120674023437502,12.15470390625,16.1785740234375Q12.21260390625,16.236474023437502,12.27580390625,16.2883740234375Q12.33910390625,16.340374023437498,12.40720390625,16.3857740234375Q12.47530390625,16.4312740234375,12.54750390625,16.469874023437498Q12.61970390625,16.5084740234375,12.69540390625,16.5398740234375Q12.77100390625,16.5711740234375,12.84940390625,16.5949740234375Q12.92770390625,16.6186740234375,13.00800390625,16.634674023437498Q13.08830390625,16.6506740234375,13.16980390625,16.6586740234375Q13.25130390625,16.6666740234375,13.33320390625,16.6666740234375L17.49980390625,16.6666740234375Q17.58170390625,16.6666740234375,17.66320390625,16.6586740234375Q17.74470390625,16.6506740234375,17.82500390625,16.634674023437498Q17.90530390625,16.6186740234375,17.98360390625,16.5949740234375Q18.06200390625,16.5711740234375,18.13760390625,16.5398740234375Q18.21330390625,16.5084740234375,18.28550390625,16.469874023437498Q18.35770390625,16.4312740234375,18.42580390625,16.3857740234375Q18.49390390625,16.340374023437498,18.55720390625,16.2883740234375Q18.62040390625,16.236474023437502,18.67830390625,16.1785740234375Q18.73620390625,16.120674023437502,18.78820390625,16.0573740234375Q18.84010390625,15.9940740234375,18.88560390625,15.9259740234375Q18.93110390625,15.8578740234375,18.96970390625,15.7856740234375Q19.00830390625,15.7134740234375,19.03960390625,15.6378740234375Q19.07100390625,15.5621740234375,19.09470390625,15.4838740234375Q19.11850390625,15.4054740234375,19.13450390625,15.3251740234375Q19.15040390625,15.2448740234375,19.15850390625,15.1633740234375Q19.16650390625,15.0818740234375,19.16650390625,15.0000740234375L19.16650390625,12.5000440234375Q19.16650390625,12.4181640234375,19.15850390625,12.3366840234375Q19.15040390625,12.2551940234375,19.13450390625,12.1748940234375Q19.11850390625,12.0945840234375,19.09470390625,12.0162340234375Q19.07100390625,11.9378840234375,19.03960390625,11.8622340234375Q19.00830390625,11.7865840234375,18.96970390625,11.7143840234375Q18.93110390625,11.6421640234375,18.88560390625,11.5740940234375Q18.84010390625,11.5060140234375,18.78820390625,11.4427140234375Q18.73620390625,11.3794240234375,18.67830390625,11.3215340234375Q18.62040390625,11.2636340234375,18.55720390625,11.2116940234375Q18.49390390625,11.1597440234375,18.42580390625,11.1142540234375Q18.35770390625,11.068764023437499,18.28550390625,11.0301740234375Q18.21330390625,10.9915740234375,18.13760390625,10.9602440234375Q18.06200390625,10.9289040234375,17.98360390625,10.9051440234375Q17.90530390625,10.8813740234375,17.82500390625,10.8653940234375Q17.74470390625,10.8494240234375,17.66320390625,10.8414040234375Q17.58170390625,10.8333740234375,17.49980390625,10.8333740234375L13.33320390625,10.8333740234375Q13.25130390625,10.8333740234375,13.16980390625,10.8414040234375Q13.08830390625,10.8494240234375,13.00800390625,10.8653940234375Q12.92770390625,10.8813740234375,12.84940390625,10.9051440234375Q12.77100390625,10.9289040234375,12.69540390625,10.9602440234375Q12.61970390625,10.9915740234375,12.54750390625,11.0301740234375Q12.47530390625,11.068764023437499,12.40720390625,11.1142540234375Q12.33910390625,11.1597440234375,12.27580390625,11.2116940234375Q12.21260390625,11.2636340234375,12.15470390625,11.3215340234375Q12.09680390625,11.3794240234375,12.04480390625,11.4427140234375Q11.99290390625,11.5060140234375,11.94740390625,11.5740940234375Q11.90190390625,11.6421640234375,11.86330390625,11.7143840234375Q11.82470390625,11.7865940234375,11.79340390625,11.8622340234375Q11.76200390625,11.9378840234375,11.73830390625,12.0162340234375Q11.71450390625,12.0945840234375,11.69850390625,12.1748940234375Q11.68260390625,12.2551940234375,11.67450390625,12.3366840234375Q11.66650390625,12.4181640234375,11.66650390625,12.5000440234375Z"), It(o, "fill-rule", "evenodd"), It(o, "fill", "#FFFFFF"), It(o, "fill-opacity", "1"), It(i, "clip-path", "url(#master_svg0_13_323)"), It(e, "xmlns", "http://www.w3.org/2000/svg"), It(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), It(e, "fill", "none"), It(e, "version", "1.1"), It(e, "width", "20"), It(e, "height", "20"), It(e, "viewBox", "0 0 20 20");
    },
    m(s, u) {
      ib(s, e, u), Wa(e, t), Wa(t, n), Wa(n, a), Wa(e, i), Wa(i, l), Wa(l, o);
    },
    p: Cs,
    i: Cs,
    o: Cs,
    d(s) {
      s && Ur(e);
    }
  };
}
class sb extends rb {
  constructor(e) {
    super(), ab(this, e, null, ob, lb, {});
  }
}
const {
  SvelteComponent: ub,
  append_hydration: Kn,
  attr: Je,
  children: $n,
  claim_svg_element: Qn,
  detach: sn,
  init: cb,
  insert_hydration: hb,
  noop: xs,
  safe_not_equal: db,
  svg_element: Mn
} = window.__gradio__svelte__internal;
function fb(r) {
  let e, t, n, a, i, l, o, s, u, c, d;
  return {
    c() {
      e = Mn("svg"), t = Mn("defs"), n = Mn("clipPath"), a = Mn("rect"), i = Mn("g"), l = Mn("g"), o = Mn("path"), s = Mn("g"), u = Mn("path"), c = Mn("g"), d = Mn("path"), this.h();
    },
    l(h) {
      e = Qn(h, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = $n(e);
      t = Qn(_, "defs", {});
      var g = $n(t);
      n = Qn(g, "clipPath", { id: !0 });
      var b = $n(n);
      a = Qn(b, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), $n(a).forEach(sn), b.forEach(sn), g.forEach(sn), i = Qn(_, "g", { "clip-path": !0 });
      var y = $n(i);
      l = Qn(y, "g", {});
      var D = $n(l);
      o = Qn(D, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), $n(o).forEach(sn), D.forEach(sn), s = Qn(y, "g", {});
      var k = $n(s);
      u = Qn(k, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), $n(u).forEach(sn), k.forEach(sn), c = Qn(y, "g", {});
      var p = $n(c);
      d = Qn(p, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), $n(d).forEach(sn), p.forEach(sn), y.forEach(sn), _.forEach(sn), this.h();
    },
    h() {
      Je(a, "x", "0"), Je(a, "y", "0"), Je(a, "width", "20"), Je(a, "height", "20"), Je(a, "rx", "0"), Je(n, "id", "master_svg0_13_533/13_323"), Je(o, "d", "M7.5,5.0016259765625Q7.58224,5.0016259765625,7.6629,4.9855819765625Q7.74356,4.9695369765625,7.81954,4.9380649765625Q7.89552,4.9065929765625,7.9639,4.8609029765625Q8.03228,4.8152129765625,8.09043,4.7570599765625Q8.14859,4.6989069765625,8.19428,4.6305269765625Q8.23997,4.5621469765625005,8.27144,4.4861669765625Q8.30291,4.4101859765625,8.318950000000001,4.3295259765625Q8.335,4.2488662765625,8.335,4.1666259765625Q8.335,4.0843856765625,8.31896,4.0037259765625Q8.30291,3.9230659765625,8.27144,3.8470849765625Q8.23997,3.7711049765625,8.19428,3.7027249765625Q8.14859,3.6343449765624998,8.09043,3.5761919765625Q8.03228,3.5180389765625,7.9639,3.4723489765625Q7.89552,3.4266589765625,7.81954,3.3951869765625Q7.74356,3.3637149765625,7.6629,3.3476699765625Q7.58224,3.3316259765625,7.5,3.3316259765625Q7.47361,3.3316259765625,7.44727,3.3332929765625L4.16667,3.3332929765625Q3.131133,3.3332929765625,2.3989,4.0655259765625Q1.666667,4.7977589765625,1.666667,5.8332959765625L1.666667,14.1666259765625Q1.666667,15.2021259765625,2.3989,15.9344259765625Q3.131133,16.6666259765625,4.16667,16.6666259765625L7.44728,16.6666259765625Q7.47361,16.6683259765625,7.5,16.6683259765625Q7.58224,16.6683259765625,7.6629,16.652225976562498Q7.74356,16.6362259765625,7.81954,16.6047259765625Q7.89552,16.573225976562497,7.9639,16.5275259765625Q8.03228,16.4819259765625,8.09043,16.4237259765625Q8.14859,16.365525976562502,8.19428,16.2972259765625Q8.23997,16.2288259765625,8.27144,16.1528259765625Q8.30291,16.0768259765625,8.318950000000001,15.9962259765625Q8.335,15.9155259765625,8.335,15.8333259765625Q8.335,15.7510259765625,8.31896,15.6704259765625Q8.30291,15.5897259765625,8.27144,15.5137259765625Q8.23997,15.4377259765625,8.19428,15.3694259765625Q8.14859,15.3010259765625,8.09043,15.2428259765625Q8.03228,15.1847259765625,7.9639,15.1390259765625Q7.89552,15.0933259765625,7.81954,15.0618259765625Q7.74356,15.0304259765625,7.6629,15.0143259765625Q7.58224,14.9983259765625,7.5,14.9983259765625Q7.47361,14.9983259765625,7.44728,14.9999259765625L4.16667,14.9999259765625Q3.82149,14.9999259765625,3.57741,14.7559259765625Q3.333333,14.5118259765625,3.333333,14.1666259765625L3.333333,5.8332959765625Q3.333333,5.4881159765625,3.57741,5.2440359765625Q3.82149,4.9999589765625,4.16667,4.9999589765625L7.44727,4.9999589765625Q7.47361,5.0016259765625,7.5,5.0016259765625Z"), Je(o, "fill-rule", "evenodd"), Je(o, "fill", "#FFFFFF"), Je(o, "fill-opacity", "1"), Je(u, "d", "M12.55273,4.9999589765625Q12.5263913,5.0016259765625,12.5,5.0016259765625Q12.4177597,5.0016259765625,12.3371,4.9855819765625Q12.25644,4.9695369765625,12.180459,4.9380649765625Q12.104479,4.9065929765625,12.036099,4.8609029765625Q11.967719,4.8152129765625,11.909566,4.7570599765625Q11.851413,4.6989069765625,11.805723,4.6305269765625Q11.760033,4.5621469765625005,11.728561,4.4861669765625Q11.697089,4.4101859765625,11.681044,4.3295259765625Q11.665,4.2488662765625,11.665,4.1666259765625Q11.665,4.0843856765625,11.681044,4.0037259765625Q11.697089,3.9230659765625,11.728561,3.8470849765625Q11.760033,3.7711049765625,11.805723,3.7027249765625Q11.851413,3.6343449765624998,11.909566,3.5761919765625Q11.967719,3.5180389765625,12.036099,3.4723489765625Q12.104479,3.4266589765625,12.180459,3.3951869765625Q12.25644,3.3637149765625,12.3371,3.3476699765625Q12.4177597,3.3316259765625,12.5,3.3316259765625Q12.5263913,3.3316259765625,12.55273,3.3332929765625L15.83333,3.3332929765625Q16.86887,3.3332929765625,17.6011,4.0655259765625Q18.33333,4.7977589765625,18.33333,5.8332959765625L18.33333,14.1666259765625Q18.33333,15.2021259765625,17.6011,15.9344259765625Q16.86887,16.6666259765625,15.83333,16.6666259765625L12.5527215,16.6666259765625Q12.5263871,16.6683259765625,12.5,16.6683259765625Q12.4177597,16.6683259765625,12.3371,16.652225976562498Q12.25644,16.6362259765625,12.180459,16.6047259765625Q12.104479,16.573225976562497,12.036099,16.5275259765625Q11.967719,16.4819259765625,11.909566,16.4237259765625Q11.851413,16.365525976562502,11.805723,16.2972259765625Q11.760033,16.2288259765625,11.728561,16.1528259765625Q11.697089,16.0768259765625,11.681044,15.9962259765625Q11.665,15.9155259765625,11.665,15.8333259765625Q11.665,15.7510259765625,11.681044,15.6704259765625Q11.697089,15.5897259765625,11.728561,15.5137259765625Q11.760033,15.4377259765625,11.805723,15.3694259765625Q11.851413,15.3010259765625,11.909566,15.2428259765625Q11.967719,15.1847259765625,12.036099,15.1390259765625Q12.104479,15.0933259765625,12.180459,15.0618259765625Q12.25644,15.0304259765625,12.3371,15.0143259765625Q12.4177597,14.9983259765625,12.5,14.9983259765625Q12.5263871,14.9983259765625,12.5527215,14.9999259765625L15.83333,14.9999259765625Q16.17851,14.9999259765625,16.42259,14.7559259765625Q16.66667,14.5118259765625,16.66667,14.1666259765625L16.66667,5.8332959765625Q16.66667,5.4881159765625,16.42259,5.2440359765625Q16.17851,4.9999589765625,15.83333,4.9999589765625L12.55273,4.9999589765625Z"), Je(u, "fill-rule", "evenodd"), Je(u, "fill", "#FFFFFF"), Je(u, "fill-opacity", "1"), Je(d, "d", "M10.833333,2.5527319Q10.835,2.5263923,10.835,2.5Q10.835,2.4177597,10.818956,2.3371Q10.802911,2.25644,10.771439,2.180459Q10.739967,2.104479,10.694277,2.036099Q10.648587,1.967719,10.590434,1.9095659999999999Q10.532281,1.851413,10.463901,1.805723Q10.395521,1.760033,10.319541,1.728561Q10.24356,1.697089,10.1629,1.681044Q10.0822403,1.665,10,1.665Q9.9177597,1.665,9.8371,1.681044Q9.75644,1.697089,9.680459,1.728561Q9.604479,1.760033,9.536099,1.805723Q9.467719,1.851413,9.409566,1.9095659999999999Q9.351413,1.967719,9.305723,2.036099Q9.260033,2.104479,9.228561,2.180459Q9.197089,2.25644,9.181044,2.3371Q9.165,2.4177597,9.165,2.5Q9.165,2.5263923,9.166667,2.5527319L9.166667,17.4473Q9.165,17.473599999999998,9.165,17.5Q9.165,17.5822,9.181044,17.6629Q9.197089,17.7436,9.228561,17.819499999999998Q9.260033,17.8955,9.305723,17.963900000000002Q9.351413,18.0323,9.409566,18.090400000000002Q9.467719,18.148600000000002,9.536099,18.1943Q9.604479,18.240000000000002,9.680459,18.2714Q9.75644,18.3029,9.8371,18.319000000000003Q9.9177597,18.335,10,18.335Q10.0822403,18.335,10.1629,18.319000000000003Q10.24356,18.3029,10.319541,18.2714Q10.395521,18.240000000000002,10.463901,18.1943Q10.532281,18.148600000000002,10.590434,18.090400000000002Q10.648587,18.0323,10.694277,17.963900000000002Q10.739967,17.8955,10.771439,17.819499999999998Q10.802911,17.7436,10.818956,17.6629Q10.835,17.5822,10.835,17.5Q10.835,17.473599999999998,10.833333,17.4473L10.833333,2.5527319Z"), Je(d, "fill-rule", "evenodd"), Je(d, "fill", "#FFFFFF"), Je(d, "fill-opacity", "1"), Je(i, "clip-path", "url(#master_svg0_13_533/13_323)"), Je(e, "xmlns", "http://www.w3.org/2000/svg"), Je(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Je(e, "fill", "none"), Je(e, "version", "1.1"), Je(e, "width", "20"), Je(e, "height", "20"), Je(e, "viewBox", "0 0 20 20");
    },
    m(h, _) {
      hb(h, e, _), Kn(e, t), Kn(t, n), Kn(n, a), Kn(e, i), Kn(i, l), Kn(l, o), Kn(i, s), Kn(s, u), Kn(i, c), Kn(c, d);
    },
    p: xs,
    i: xs,
    o: xs,
    d(h) {
      h && sn(e);
    }
  };
}
class mb extends ub {
  constructor(e) {
    super(), cb(this, e, null, fb, db, {});
  }
}
function _b() {
  return navigator.mediaDevices.enumerateDevices();
}
function F4(r, e) {
  e.srcObject = r, e.muted = !0, e.play();
}
async function C4(r, e, t, n) {
  const a = (n == null ? void 0 : n.video) || n || {
    width: { ideal: 500 },
    height: { ideal: 500 }
  }, i = (n == null ? void 0 : n.audio) || n || {
    echoCancellation: !0,
    noiseSuppression: !0,
    autoGainControl: !0
  }, l = {
    video: typeof e == "object" ? { ...e, ...a } : e,
    audio: typeof r == "object" ? { ...r, ...i } : r
  };
  return navigator.mediaDevices.getUserMedia(l).then((o) => o);
}
function x4(r, e = "videoinput") {
  return r.filter(
    (n) => n.kind === e
  );
}
let ma = null, br = null;
function pb(r = 1, e = 1) {
  const t = document.createElement("canvas");
  document.body.appendChild(t), t.width = r || 500, t.height = e || 500;
  const n = t.getContext("2d");
  n.fillStyle = "hsl(0,0, 0, 1)", n.fillRect(0, 0, t.width, t.height);
  function a() {
    n.fillStyle = "rgb(255, 255, 255)", n.fillRect(0, 0, t.width, t.height), requestAnimationFrame(a);
  }
  return a(), ma = t.captureStream(30).getVideoTracks()[0], ma.stop = () => {
    t.remove();
  }, ma.onended = () => {
    ma == null || ma.stop();
  }, ma;
}
function gb() {
  if (br) return br;
  const r = new (window.AudioContext || window.webkitAudioContext)(), e = r.createOscillator();
  e.frequency.setValueAtTime(0, r.currentTime);
  const t = r.createGain();
  t.gain.setValueAtTime(0, r.currentTime);
  const n = r.createMediaStreamDestination();
  return e.connect(t), t.connect(n), e.start(), br = n.stream.getAudioTracks()[0], br.stop = () => {
    r.close();
  }, br.onended = () => {
    br == null || br.stop();
  }, br;
}
function Hc(r, e) {
  const t = (n) => {
    r && !r.contains(n.target) && !n.defaultPrevented && e(n);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function vb(r, e, t) {
  return t < 0 || t > r.length ? (console.error("索引超出范围"), r) : r.substring(0, t) + e + r.substring(t);
}
const {
  SvelteComponent: bb,
  append_hydration: Bn,
  attr: In,
  binding_callbacks: T4,
  check_outros: yb,
  children: Wr,
  claim_component: wb,
  claim_element: wr,
  claim_space: r1,
  claim_text: kb,
  create_component: Db,
  destroy_component: Sb,
  detach: qn,
  element: kr,
  get_svelte_dataset: Eb,
  group_outros: Ab,
  init: Fb,
  insert_hydration: V5,
  is_function: Vc,
  listen: Hi,
  mount_component: Cb,
  noop: e5,
  run_all: xb,
  safe_not_equal: Tb,
  space: a1,
  text: $b,
  transition_in: t5,
  transition_out: n5
} = window.__gradio__svelte__internal;
function Qb(r) {
  let e, t, n, a, i;
  return t = new ov({ props: { icon: mv, color: "#fff" } }), {
    c() {
      e = kr("button"), Db(t.$$.fragment), this.h();
    },
    l(l) {
      e = wr(l, "BUTTON", { class: !0 });
      var o = Wr(e);
      wb(t.$$.fragment, o), o.forEach(qn), this.h();
    },
    h() {
      In(e, "class", "send-btn svelte-15phooz");
    },
    m(l, o) {
      V5(l, e, o), Cb(t, e, null), n = !0, a || (i = Hi(
        e,
        "click",
        /*on_send*/
        r[7]
      ), a = !0);
    },
    p: e5,
    i(l) {
      n || (t5(t.$$.fragment, l), n = !0);
    },
    o(l) {
      n5(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && qn(e), Sb(t), a = !1, i();
    }
  };
}
function Mb(r) {
  let e, t, n;
  return {
    c() {
      e = kr("button"), this.h();
    },
    l(a) {
      e = wr(a, "BUTTON", { class: !0 }), Wr(e).forEach(qn), this.h();
    },
    h() {
      In(e, "class", "interrupt-btn svelte-15phooz");
    },
    m(a, i) {
      V5(a, e, i), t || (n = Hi(e, "click", function() {
        Vc(
          /*onInterrupt*/
          r[2]
        ) && r[2].apply(this, arguments);
      }), t = !0);
    },
    p(a, i) {
      r = a;
    },
    i: e5,
    o: e5,
    d(a) {
      a && qn(e), t = !1, n();
    }
  };
}
function Bb(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y = "Texts are ignored during responding.", D, k, p;
  const S = [Mb, Qb], E = [];
  function F($, B) {
    return (
      /*replying*/
      $[0] ? 0 : 1
    );
  }
  return h = F(r), _ = E[h] = S[h](r), {
    c() {
      e = kr("div"), t = kr("div"), n = a1(), a = kr("div"), i = kr("div"), l = kr("textarea"), s = a1(), u = kr("div"), c = $b($4), d = a1(), _.c(), g = a1(), b = kr("div"), b.textContent = y, this.h();
    },
    l($) {
      e = wr($, "DIV", { class: !0 });
      var B = Wr(e);
      t = wr(B, "DIV", { class: !0 }), Wr(t).forEach(qn), n = r1(B), a = wr(B, "DIV", { class: !0 });
      var T = Wr(a);
      i = wr(T, "DIV", { class: !0 });
      var x = Wr(i);
      l = wr(x, "TEXTAREA", { class: !0, style: !0 }), Wr(l).forEach(qn), s = r1(x), u = wr(x, "DIV", { class: !0 });
      var L = Wr(u);
      c = kb(L, $4), L.forEach(qn), x.forEach(qn), d = r1(T), _.l(T), g = r1(T), b = wr(T, "DIV", { class: !0, "data-svelte-h": !0 }), Eb(b) !== "svelte-ceag5n" && (b.textContent = y), T.forEach(qn), B.forEach(qn), this.h();
    },
    h() {
      In(t, "class", "stop-chat-btn svelte-15phooz"), In(l, "class", "chat-input svelte-15phooz"), In(l, "style", o = `height:${/*inputHeight*/
      r[3]}px`), In(u, "class", "rowsDiv svelte-15phooz"), In(i, "class", "chat-input-wrapper svelte-15phooz"), In(b, "class", "chat-tip svelte-15phooz"), In(a, "class", "chat-input-inner svelte-15phooz"), In(e, "class", "chat-input-container svelte-15phooz");
    },
    m($, B) {
      V5($, e, B), Bn(e, t), Bn(e, n), Bn(e, a), Bn(a, i), Bn(i, l), r[10](l), Bn(i, s), Bn(i, u), Bn(u, c), r[11](u), Bn(a, d), E[h].m(a, null), Bn(a, g), Bn(a, b), D = !0, k || (p = [
        Hi(t, "click", function() {
          Vc(
            /*onStop*/
            r[1]
          ) && r[1].apply(this, arguments);
        }),
        Hi(
          l,
          "keydown",
          /*on_chat_input_keydown*/
          r[6]
        ),
        Hi(
          l,
          "input",
          /*on_chat_input*/
          r[8]
        )
      ], k = !0);
    },
    p($, [B]) {
      r = $, (!D || B & /*inputHeight*/
      8 && o !== (o = `height:${/*inputHeight*/
      r[3]}px`)) && In(l, "style", o);
      let T = h;
      h = F(r), h === T ? E[h].p(r, B) : (Ab(), n5(E[T], 1, 1, () => {
        E[T] = null;
      }), yb(), _ = E[h], _ ? _.p(r, B) : (_ = E[h] = S[h](r), _.c()), t5(_, 1), _.m(a, g));
    },
    i($) {
      D || (t5(_), D = !0);
    },
    o($) {
      n5(_), D = !1;
    },
    d($) {
      $ && qn(e), r[10](null), r[11](null), E[h].d(), k = !1, xb(p);
    }
  };
}
let $4 = "";
function zb(r, e, t) {
  var n = this && this.__awaiter || function(y, D, k, p) {
    function S(E) {
      return E instanceof k ? E : new k(function(F) {
        F(E);
      });
    }
    return new (k || (k = Promise))(function(E, F) {
      function $(x) {
        try {
          T(p.next(x));
        } catch (L) {
          F(L);
        }
      }
      function B(x) {
        try {
          T(p.throw(x));
        } catch (L) {
          F(L);
        }
      }
      function T(x) {
        x.done ? E(x.value) : S(x.value).then($, B);
      }
      T((p = p.apply(y, D || [])).next());
    });
  };
  let { replying: a } = e, { onSend: i } = e, { onStop: l } = e, { onInterrupt: o } = e, s = 24, u, c;
  function d(y) {
    y.key === "Enter" && (y.altKey ? (t(5, c.value = vb(c.value, `
`, c.selectionStart), c), c.dispatchEvent(new InputEvent("input"))) : (y.preventDefault(), h()));
  }
  function h() {
    return n(this, void 0, void 0, function* () {
      yield i(c.value), t(5, c.value = "", c);
    });
  }
  function _(y) {
    u && (t(4, u.textContent = y.target.value.replace(/\n$/, `

`), u), t(3, s = u.offsetHeight));
  }
  function g(y) {
    T4[y ? "unshift" : "push"](() => {
      c = y, t(5, c);
    });
  }
  function b(y) {
    T4[y ? "unshift" : "push"](() => {
      u = y, t(4, u);
    });
  }
  return r.$$set = (y) => {
    "replying" in y && t(0, a = y.replying), "onSend" in y && t(9, i = y.onSend), "onStop" in y && t(1, l = y.onStop), "onInterrupt" in y && t(2, o = y.onInterrupt);
  }, [
    a,
    l,
    o,
    s,
    u,
    c,
    d,
    h,
    _,
    i,
    g,
    b
  ];
}
class Ib extends bb {
  constructor(e) {
    super(), Fb(this, e, zb, Bb, Tb, {
      replying: 0,
      onSend: 9,
      onStop: 1,
      onInterrupt: 2
    });
  }
}
const {
  SvelteComponent: Lb,
  append_hydration: Vi,
  attr: Da,
  check_outros: Q4,
  children: ii,
  claim_component: jc,
  claim_element: Kr,
  claim_space: Uc,
  create_component: Gc,
  destroy_component: Wc,
  detach: Pn,
  element: Jr,
  get_svelte_dataset: Zc,
  group_outros: M4,
  init: qb,
  insert_hydration: dl,
  is_function: Nb,
  listen: Rb,
  mount_component: Yc,
  noop: M1,
  safe_not_equal: Ob,
  space: Xc,
  toggle_class: i1,
  transition_in: pa,
  transition_out: Ja
} = window.__gradio__svelte__internal, { createEventDispatcher: Pb } = window.__gradio__svelte__internal;
function Hb(r) {
  let e;
  return {
    c() {
      e = Jr("div"), this.h();
    },
    l(t) {
      e = Kr(t, "DIV", { class: !0 }), ii(e).forEach(Pn), this.h();
    },
    h() {
      Da(e, "class", "stop-chat-inner svelte-16vni9m");
    },
    m(t, n) {
      dl(t, e, n);
    },
    i: M1,
    o: M1,
    d(t) {
      t && Pn(e);
    }
  };
}
function Vb(r) {
  let e, t, n, a, i, l = "等待中", o;
  return n = new o5({}), {
    c() {
      e = Jr("div"), t = Jr("div"), Gc(n.$$.fragment), a = Xc(), i = Jr("span"), i.textContent = l, this.h();
    },
    l(s) {
      e = Kr(s, "DIV", { class: !0 });
      var u = ii(e);
      t = Kr(u, "DIV", { class: !0, title: !0 });
      var c = ii(t);
      jc(n.$$.fragment, c), c.forEach(Pn), a = Uc(u), i = Kr(u, "SPAN", { "data-svelte-h": !0 }), Zc(i) !== "svelte-anmp8h" && (i.textContent = l), u.forEach(Pn), this.h();
    },
    h() {
      Da(t, "class", "icon svelte-16vni9m"), Da(t, "title", "spinner"), Da(e, "class", "waiting-icon-text svelte-16vni9m");
    },
    m(s, u) {
      dl(s, e, u), Vi(e, t), Yc(n, t, null), Vi(e, a), Vi(e, i), o = !0;
    },
    i(s) {
      o || (pa(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Ja(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Pn(e), Wc(n);
    }
  };
}
function jb(r) {
  let e, t = "点击开始对话";
  return {
    c() {
      e = Jr("span"), e.textContent = t;
    },
    l(n) {
      e = Kr(n, "SPAN", { "data-svelte-h": !0 }), Zc(e) !== "svelte-12otyi9" && (e.textContent = t);
    },
    m(n, a) {
      dl(n, e, a);
    },
    i: M1,
    o: M1,
    d(n) {
      n && Pn(e);
    }
  };
}
function B4(r) {
  let e, t, n;
  return t = new P5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        r[2]
      ),
      stream_state: (
        /*stream_state*/
        r[0]
      ),
      wave_color: (
        /*wave_color*/
        r[3]
      )
    }
  }), {
    c() {
      e = Jr("div"), Gc(t.$$.fragment), this.h();
    },
    l(a) {
      e = Kr(a, "DIV", { class: !0 });
      var i = ii(e);
      jc(t.$$.fragment, i), i.forEach(Pn), this.h();
    },
    h() {
      Da(e, "class", "input-audio-wave svelte-16vni9m");
    },
    m(a, i) {
      dl(a, e, i), Yc(t, e, null), n = !0;
    },
    p(a, i) {
      const l = {};
      i & /*audio_source_callback*/
      4 && (l.audio_source_callback = /*audio_source_callback*/
      a[2]), i & /*stream_state*/
      1 && (l.stream_state = /*stream_state*/
      a[0]), i & /*wave_color*/
      8 && (l.wave_color = /*wave_color*/
      a[3]), t.$set(l);
    },
    i(a) {
      n || (pa(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Ja(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Pn(e), Wc(t);
    }
  };
}
function Ub(r) {
  let e, t, n, a, i, l, o, s;
  const u = [jb, Vb, Hb], c = [];
  function d(_, g) {
    return (
      /*stream_state*/
      _[0] === "closed" ? 0 : (
        /*stream_state*/
        _[0] === "waiting" ? 1 : 2
      )
    );
  }
  n = d(r), a = c[n] = u[n](r);
  let h = (
    /*stream_state*/
    r[0] === "open" && B4(r)
  );
  return {
    c() {
      e = Jr("div"), t = Jr("div"), a.c(), i = Xc(), h && h.c(), this.h();
    },
    l(_) {
      e = Kr(_, "DIV", { class: !0 });
      var g = ii(e);
      t = Kr(g, "DIV", { class: !0 });
      var b = ii(t);
      a.l(b), b.forEach(Pn), i = Uc(g), h && h.l(g), g.forEach(Pn), this.h();
    },
    h() {
      Da(t, "class", "chat-btn svelte-16vni9m"), i1(
        t,
        "start-chat",
        /*stream_state*/
        r[0] === "closed"
      ), i1(
        t,
        "stop-chat",
        /*stream_state*/
        r[0] === "open"
      ), Da(e, "class", "player-controls svelte-16vni9m");
    },
    m(_, g) {
      dl(_, e, g), Vi(e, t), c[n].m(t, null), Vi(e, i), h && h.m(e, null), l = !0, o || (s = Rb(t, "click", function() {
        Nb(
          /*onStartChat*/
          r[1]
        ) && r[1].apply(this, arguments);
      }), o = !0);
    },
    p(_, [g]) {
      r = _;
      let b = n;
      n = d(r), n !== b && (M4(), Ja(c[b], 1, 1, () => {
        c[b] = null;
      }), Q4(), a = c[n], a || (a = c[n] = u[n](r), a.c()), pa(a, 1), a.m(t, null)), (!l || g & /*stream_state*/
      1) && i1(
        t,
        "start-chat",
        /*stream_state*/
        r[0] === "closed"
      ), (!l || g & /*stream_state*/
      1) && i1(
        t,
        "stop-chat",
        /*stream_state*/
        r[0] === "open"
      ), /*stream_state*/
      r[0] === "open" ? h ? (h.p(r, g), g & /*stream_state*/
      1 && pa(h, 1)) : (h = B4(r), h.c(), pa(h, 1), h.m(e, null)) : h && (M4(), Ja(h, 1, 1, () => {
        h = null;
      }), Q4());
    },
    i(_) {
      l || (pa(a), pa(h), l = !0);
    },
    o(_) {
      Ja(a), Ja(h), l = !1;
    },
    d(_) {
      _ && Pn(e), c[n].d(), h && h.d(), o = !1, s();
    }
  };
}
function Gb(r, e, t) {
  Pb();
  let { stream_state: n } = e, { onStartChat: a } = e, { audio_source_callback: i } = e, { wave_color: l } = e;
  return r.$$set = (o) => {
    "stream_state" in o && t(0, n = o.stream_state), "onStartChat" in o && t(1, a = o.onStartChat), "audio_source_callback" in o && t(2, i = o.audio_source_callback), "wave_color" in o && t(3, l = o.wave_color);
  }, [n, a, i, l];
}
class Wb extends Lb {
  constructor(e) {
    super(), qb(this, e, Gb, Ub, Ob, {
      stream_state: 0,
      onStartChat: 1,
      audio_source_callback: 2,
      wave_color: 3
    });
  }
}
const {
  SvelteComponent: Zb,
  append_hydration: z4,
  attr: l1,
  children: I4,
  claim_element: L4,
  claim_text: Yb,
  detach: Ts,
  element: q4,
  init: Xb,
  insert_hydration: Kb,
  noop: N4,
  safe_not_equal: Jb,
  set_data: ey,
  text: ty
} = window.__gradio__svelte__internal;
function ny(r) {
  let e, t, n;
  return {
    c() {
      e = q4("div"), t = q4("div"), n = ty(
        /*message*/
        r[0]
      ), this.h();
    },
    l(a) {
      e = L4(a, "DIV", { class: !0, style: !0 });
      var i = I4(e);
      t = L4(i, "DIV", { class: !0 });
      var l = I4(t);
      n = Yb(
        l,
        /*message*/
        r[0]
      ), l.forEach(Ts), i.forEach(Ts), this.h();
    },
    h() {
      l1(t, "class", "answer-message-text"), l1(e, "class", "answer-message-container svelte-1ranrfe"), l1(
        e,
        "style",
        /*style*/
        r[1]
      );
    },
    m(a, i) {
      Kb(a, e, i), z4(e, t), z4(t, n);
    },
    p(a, [i]) {
      i & /*message*/
      1 && ey(
        n,
        /*message*/
        a[0]
      ), i & /*style*/
      2 && l1(
        e,
        "style",
        /*style*/
        a[1]
      );
    },
    i: N4,
    o: N4,
    d(a) {
      a && Ts(e);
    }
  };
}
function ry(r, e, t) {
  let { message: n } = e, { style: a = "" } = e;
  return r.$$set = (i) => {
    "message" in i && t(0, n = i.message), "style" in i && t(1, a = i.style);
  }, [n, a];
}
class ay extends Zb {
  constructor(e) {
    super(), Xb(this, e, ry, ny, Jb, { message: 0, style: 1 });
  }
}
const {
  SvelteComponent: iy,
  action_destroyer: Kc,
  add_render_callback: ly,
  append_hydration: Ge,
  attr: et,
  binding_callbacks: Bi,
  check_outros: F0,
  children: vt,
  claim_component: H0,
  claim_element: ct,
  claim_space: _0,
  claim_text: Jc,
  create_component: V0,
  create_in_transition: oy,
  destroy_component: j0,
  destroy_each: e7,
  detach: Le,
  element: ht,
  empty: R4,
  ensure_array_like: B1,
  get_svelte_dataset: t7,
  group_outros: C0,
  init: sy,
  insert_hydration: nn,
  is_function: n7,
  listen: hr,
  mount_component: U0,
  noop: j5,
  null_to_empty: z1,
  run_all: U5,
  safe_not_equal: uy,
  set_data: r7,
  set_style: Be,
  space: p0,
  stop_propagation: a7,
  text: i7,
  toggle_class: Jn,
  transition_in: ie,
  transition_out: me
} = window.__gradio__svelte__internal, { createEventDispatcher: cy, onMount: hy } = window.__gradio__svelte__internal;
function O4(r, e, t) {
  const n = r.slice();
  return n[76] = e[t], n[78] = t, n;
}
function P4(r, e, t) {
  const n = r.slice();
  return n[76] = e[t], n[78] = t, n;
}
function H4(r) {
  let e, t, n, a;
  return t = new B5({}), t.$on(
    "click",
    /*click_handler*/
    r[54]
  ), {
    c() {
      e = ht("div"), V0(t.$$.fragment), this.h();
    },
    l(i) {
      e = ct(i, "DIV", { style: !0 });
      var l = vt(e);
      H0(t.$$.fragment, l), l.forEach(Le), this.h();
    },
    h() {
      Be(e, "height", "100%");
    },
    m(i, l) {
      nn(i, e, l), U0(t, e, null), a = !0;
    },
    p: j5,
    i(i) {
      a || (ie(t.$$.fragment, i), i && (n || ly(() => {
        n = oy(e, M5, { delay: 100, duration: 200 }), n.start();
      })), a = !0);
    },
    o(i) {
      me(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Le(e), j0(t);
    }
  };
}
function V4(r) {
  let e, t, n = (
    /*answerMessage*/
    r[15] && j4(r)
  );
  return {
    c() {
      n && n.c(), e = R4();
    },
    l(a) {
      n && n.l(a), e = R4();
    },
    m(a, i) {
      n && n.m(a, i), nn(a, e, i), t = !0;
    },
    p(a, i) {
      /*answerMessage*/
      a[15] ? n ? (n.p(a, i), i[0] & /*answerMessage*/
      32768 && ie(n, 1)) : (n = j4(a), n.c(), ie(n, 1), n.m(e.parentNode, e)) : n && (C0(), me(n, 1, 1, () => {
        n = null;
      }), F0());
    },
    i(a) {
      t || (ie(n), t = !0);
    },
    o(a) {
      me(n), t = !1;
    },
    d(a) {
      a && Le(e), n && n.d(a);
    }
  };
}
function j4(r) {
  let e, t;
  return e = new ay({
    props: { message: (
      /*answerMessage*/
      r[15]
    ) }
  }), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*answerMessage*/
      32768 && (i.message = /*answerMessage*/
      n[15]), e.$set(i);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function U4(r) {
  let e, t, n, a, i, l, o, s, u, c, d;
  const h = [fy, dy], _ = [];
  function g(p, S) {
    return (
      /*cameraOff*/
      p[10] ? 0 : 1
    );
  }
  t = g(r), n = _[t] = h[t](r);
  let b = (
    /*stream_state*/
    r[7] === "closed" && G4(r)
  ), y = B1(
    /*available_video_devices*/
    r[3]
  ), D = [];
  for (let p = 0; p < y.length; p += 1)
    D[p] = Z4(P4(r, y, p));
  const k = (p) => me(D[p], 1, 1, () => {
    D[p] = null;
  });
  return {
    c() {
      e = ht("div"), n.c(), a = p0(), b && b.c(), i = p0(), l = ht("div");
      for (let p = 0; p < D.length; p += 1)
        D[p].c();
      this.h();
    },
    l(p) {
      e = ct(p, "DIV", { class: !0 });
      var S = vt(e);
      n.l(S), a = _0(S), b && b.l(S), i = _0(S), l = ct(S, "DIV", { class: !0 });
      var E = vt(l);
      for (let F = 0; F < D.length; F += 1)
        D[F].l(E);
      E.forEach(Le), S.forEach(Le), this.h();
    },
    h() {
      et(l, "class", o = z1(`selectors ${/*actionsPosition*/
      r[24].isOverflow || /*isSideBySide*/
      r[28] ? "left" : ""}`) + " svelte-jjnt02"), Be(
        l,
        "display",
        /*cameraListShow*/
        r[26] && /*stream_state*/
        r[7] === "closed" ? "block" : "none"
      ), et(e, "class", "action svelte-jjnt02");
    },
    m(p, S) {
      nn(p, e, S), _[t].m(e, null), Ge(e, a), b && b.m(e, null), Ge(e, i), Ge(e, l);
      for (let E = 0; E < D.length; E += 1)
        D[E] && D[E].m(l, null);
      u = !0, c || (d = [
        hr(
          e,
          "click",
          /*handle_camera_off*/
          r[31]
        ),
        Kc(s = Hc.call(
          null,
          e,
          /*click_outside_function*/
          r[60]
        ))
      ], c = !0);
    },
    p(p, S) {
      let E = t;
      if (t = g(p), t !== E && (C0(), me(_[E], 1, 1, () => {
        _[E] = null;
      }), F0(), n = _[t], n || (n = _[t] = h[t](p), n.c()), ie(n, 1), n.m(e, a)), /*stream_state*/
      p[7] === "closed" ? b ? b.p(p, S) : (b = G4(p), b.c(), b.m(e, i)) : b && (b.d(1), b = null), S[0] & /*available_video_devices, selected_video_device*/
      40 | S[1] & /*handle_device_change*/
      2) {
        y = B1(
          /*available_video_devices*/
          p[3]
        );
        let F;
        for (F = 0; F < y.length; F += 1) {
          const $ = P4(p, y, F);
          D[F] ? (D[F].p($, S), ie(D[F], 1)) : (D[F] = Z4($), D[F].c(), ie(D[F], 1), D[F].m(l, null));
        }
        for (C0(), F = y.length; F < D.length; F += 1)
          k(F);
        F0();
      }
      (!u || S[0] & /*actionsPosition, isSideBySide*/
      285212672 && o !== (o = z1(`selectors ${/*actionsPosition*/
      p[24].isOverflow || /*isSideBySide*/
      p[28] ? "left" : ""}`) + " svelte-jjnt02")) && et(l, "class", o), S[0] & /*cameraListShow, stream_state*/
      67108992 && Be(
        l,
        "display",
        /*cameraListShow*/
        p[26] && /*stream_state*/
        p[7] === "closed" ? "block" : "none"
      ), s && n7(s.update) && S[0] & /*cameraListShow*/
      67108864 && s.update.call(
        null,
        /*click_outside_function*/
        p[60]
      );
    },
    i(p) {
      if (!u) {
        ie(n);
        for (let S = 0; S < y.length; S += 1)
          ie(D[S]);
        u = !0;
      }
    },
    o(p) {
      me(n), D = D.filter(Boolean);
      for (let S = 0; S < D.length; S += 1)
        me(D[S]);
      u = !1;
    },
    d(p) {
      p && Le(e), _[t].d(), b && b.d(), e7(D, p), c = !1, U5(d);
    }
  };
}
function dy(r) {
  let e, t;
  return e = new Av({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function fy(r) {
  let e, t;
  return e = new yv({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function G4(r) {
  let e, t = '<div class="corner-inner svelte-jjnt02"></div>', n, a;
  return {
    c() {
      e = ht("div"), e.innerHTML = t, this.h();
    },
    l(i) {
      e = ct(i, "DIV", { class: !0, "data-svelte-h": !0 }), t7(e) !== "svelte-5yrdhh" && (e.innerHTML = t), this.h();
    },
    h() {
      et(e, "class", "corner svelte-jjnt02");
    },
    m(i, l) {
      nn(i, e, l), n || (a = hr(
        e,
        "click",
        /*open_camera_list*/
        r[42]
      ), n = !0);
    },
    p: j5,
    d(i) {
      i && Le(e), n = !1, a();
    }
  };
}
function W4(r) {
  let e, t, n;
  return t = new Pc({}), {
    c() {
      e = ht("div"), V0(t.$$.fragment), this.h();
    },
    l(a) {
      e = ct(a, "DIV", { class: !0 });
      var i = vt(e);
      H0(t.$$.fragment, i), i.forEach(Le), this.h();
    },
    h() {
      et(e, "class", "active-icon svelte-jjnt02");
    },
    m(a, i) {
      nn(a, e, i), U0(t, e, null), n = !0;
    },
    i(a) {
      n || (ie(t.$$.fragment, a), n = !0);
    },
    o(a) {
      me(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Le(e), j0(t);
    }
  };
}
function Z4(r) {
  let e, t = (
    /*device*/
    r[76].label + ""
  ), n, a, i, l, o, s, u = (
    /*selected_video_device*/
    r[5] && /*device*/
    r[76].deviceId === /*selected_video_device*/
    r[5].deviceId && W4()
  );
  function c(...d) {
    return (
      /*click_handler_1*/
      r[59](
        /*device*/
        r[76],
        ...d
      )
    );
  }
  return {
    c() {
      e = ht("div"), n = i7(t), a = p0(), u && u.c(), i = p0(), this.h();
    },
    l(d) {
      e = ct(d, "DIV", { class: !0 });
      var h = vt(e);
      n = Jc(h, t), a = _0(h), u && u.l(h), i = _0(h), h.forEach(Le), this.h();
    },
    h() {
      et(e, "class", "selector svelte-jjnt02");
    },
    m(d, h) {
      nn(d, e, h), Ge(e, n), Ge(e, a), u && u.m(e, null), Ge(e, i), l = !0, o || (s = hr(e, "click", a7(c)), o = !0);
    },
    p(d, h) {
      r = d, (!l || h[0] & /*available_video_devices*/
      8) && t !== (t = /*device*/
      r[76].label + "") && r7(n, t), /*selected_video_device*/
      r[5] && /*device*/
      r[76].deviceId === /*selected_video_device*/
      r[5].deviceId ? u ? h[0] & /*selected_video_device, available_video_devices*/
      40 && ie(u, 1) : (u = W4(), u.c(), ie(u, 1), u.m(e, i)) : u && (C0(), me(u, 1, 1, () => {
        u = null;
      }), F0());
    },
    i(d) {
      l || (ie(u), l = !0);
    },
    o(d) {
      me(u), l = !1;
    },
    d(d) {
      d && Le(e), u && u.d(), o = !1, s();
    }
  };
}
function Y4(r) {
  let e, t, n, a, i, l, o, s, u, c, d;
  const h = [_y, my], _ = [];
  function g(p, S) {
    return (
      /*micMuted*/
      p[9] ? 0 : 1
    );
  }
  t = g(r), n = _[t] = h[t](r);
  let b = (
    /*stream_state*/
    r[7] === "closed" && X4(r)
  ), y = B1(
    /*available_audio_devices*/
    r[4]
  ), D = [];
  for (let p = 0; p < y.length; p += 1)
    D[p] = J4(O4(r, y, p));
  const k = (p) => me(D[p], 1, 1, () => {
    D[p] = null;
  });
  return {
    c() {
      e = ht("div"), n.c(), a = p0(), b && b.c(), i = p0(), l = ht("div");
      for (let p = 0; p < D.length; p += 1)
        D[p].c();
      this.h();
    },
    l(p) {
      e = ct(p, "DIV", { class: !0 });
      var S = vt(e);
      n.l(S), a = _0(S), b && b.l(S), i = _0(S), l = ct(S, "DIV", { class: !0 });
      var E = vt(l);
      for (let F = 0; F < D.length; F += 1)
        D[F].l(E);
      E.forEach(Le), S.forEach(Le), this.h();
    },
    h() {
      et(l, "class", o = z1(`selectors ${/*actionsPosition*/
      r[24].isOverflow || /*isSideBySide*/
      r[28] ? "left" : ""}`) + " svelte-jjnt02"), Be(
        l,
        "display",
        /*micListShow*/
        r[25] && /*stream_state*/
        r[7] === "closed" ? "block" : "none"
      ), et(e, "class", "action svelte-jjnt02");
    },
    m(p, S) {
      nn(p, e, S), _[t].m(e, null), Ge(e, a), b && b.m(e, null), Ge(e, i), Ge(e, l);
      for (let E = 0; E < D.length; E += 1)
        D[E] && D[E].m(l, null);
      u = !0, c || (d = [
        hr(
          e,
          "click",
          /*handle_mic_mute*/
          r[30]
        ),
        Kc(s = Hc.call(
          null,
          e,
          /*click_outside_function_1*/
          r[62]
        ))
      ], c = !0);
    },
    p(p, S) {
      let E = t;
      if (t = g(p), t !== E && (C0(), me(_[E], 1, 1, () => {
        _[E] = null;
      }), F0(), n = _[t], n || (n = _[t] = h[t](p), n.c()), ie(n, 1), n.m(e, a)), /*stream_state*/
      p[7] === "closed" ? b ? b.p(p, S) : (b = X4(p), b.c(), b.m(e, i)) : b && (b.d(1), b = null), S[0] & /*available_audio_devices, selected_audio_device*/
      80 | S[1] & /*handle_device_change*/
      2) {
        y = B1(
          /*available_audio_devices*/
          p[4]
        );
        let F;
        for (F = 0; F < y.length; F += 1) {
          const $ = O4(p, y, F);
          D[F] ? (D[F].p($, S), ie(D[F], 1)) : (D[F] = J4($), D[F].c(), ie(D[F], 1), D[F].m(l, null));
        }
        for (C0(), F = y.length; F < D.length; F += 1)
          k(F);
        F0();
      }
      (!u || S[0] & /*actionsPosition, isSideBySide*/
      285212672 && o !== (o = z1(`selectors ${/*actionsPosition*/
      p[24].isOverflow || /*isSideBySide*/
      p[28] ? "left" : ""}`) + " svelte-jjnt02")) && et(l, "class", o), S[0] & /*micListShow, stream_state*/
      33554560 && Be(
        l,
        "display",
        /*micListShow*/
        p[25] && /*stream_state*/
        p[7] === "closed" ? "block" : "none"
      ), s && n7(s.update) && S[0] & /*micListShow*/
      33554432 && s.update.call(
        null,
        /*click_outside_function_1*/
        p[62]
      );
    },
    i(p) {
      if (!u) {
        ie(n);
        for (let S = 0; S < y.length; S += 1)
          ie(D[S]);
        u = !0;
      }
    },
    o(p) {
      me(n), D = D.filter(Boolean);
      for (let S = 0; S < D.length; S += 1)
        me(D[S]);
      u = !1;
    },
    d(p) {
      p && Le(e), _[t].d(), b && b.d(), e7(D, p), c = !1, U5(d);
    }
  };
}
function my(r) {
  let e, t;
  return e = new Yv({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function _y(r) {
  let e, t;
  return e = new Vv({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function X4(r) {
  let e, t = '<div class="corner-inner svelte-jjnt02"></div>', n, a;
  return {
    c() {
      e = ht("div"), e.innerHTML = t, this.h();
    },
    l(i) {
      e = ct(i, "DIV", { class: !0, "data-svelte-h": !0 }), t7(e) !== "svelte-1bfriu5" && (e.innerHTML = t), this.h();
    },
    h() {
      et(e, "class", "corner svelte-jjnt02");
    },
    m(i, l) {
      nn(i, e, l), n || (a = hr(
        e,
        "click",
        /*open_mic_list*/
        r[41]
      ), n = !0);
    },
    p: j5,
    d(i) {
      i && Le(e), n = !1, a();
    }
  };
}
function K4(r) {
  let e, t, n;
  return t = new Pc({}), {
    c() {
      e = ht("div"), V0(t.$$.fragment), this.h();
    },
    l(a) {
      e = ct(a, "DIV", { class: !0 });
      var i = vt(e);
      H0(t.$$.fragment, i), i.forEach(Le), this.h();
    },
    h() {
      et(e, "class", "active-icon svelte-jjnt02");
    },
    m(a, i) {
      nn(a, e, i), U0(t, e, null), n = !0;
    },
    i(a) {
      n || (ie(t.$$.fragment, a), n = !0);
    },
    o(a) {
      me(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Le(e), j0(t);
    }
  };
}
function J4(r) {
  let e, t = (
    /*device*/
    r[76].label + ""
  ), n, a, i, l, o, s, u = (
    /*selected_audio_device*/
    r[6] && /*device*/
    r[76].deviceId === /*selected_audio_device*/
    r[6].deviceId && K4()
  );
  function c(...d) {
    return (
      /*click_handler_2*/
      r[61](
        /*device*/
        r[76],
        ...d
      )
    );
  }
  return {
    c() {
      e = ht("div"), n = i7(t), a = p0(), u && u.c(), i = p0(), this.h();
    },
    l(d) {
      e = ct(d, "DIV", { class: !0 });
      var h = vt(e);
      n = Jc(h, t), a = _0(h), u && u.l(h), i = _0(h), h.forEach(Le), this.h();
    },
    h() {
      et(e, "class", "selector svelte-jjnt02");
    },
    m(d, h) {
      nn(d, e, h), Ge(e, n), Ge(e, a), u && u.m(e, null), Ge(e, i), l = !0, o || (s = hr(e, "click", a7(c)), o = !0);
    },
    p(d, h) {
      r = d, (!l || h[0] & /*available_audio_devices*/
      16) && t !== (t = /*device*/
      r[76].label + "") && r7(n, t), /*selected_audio_device*/
      r[6] && /*device*/
      r[76].deviceId === /*selected_audio_device*/
      r[6].deviceId ? u ? h[0] & /*selected_audio_device, available_audio_devices*/
      80 && ie(u, 1) : (u = K4(), u.c(), ie(u, 1), u.m(e, i)) : u && (C0(), me(u, 1, 1, () => {
        u = null;
      }), F0());
    },
    i(d) {
      l || (ie(u), l = !0);
    },
    o(d) {
      me(u), l = !1;
    },
    d(d) {
      d && Le(e), u && u.d(), o = !1, s();
    }
  };
}
function py(r) {
  let e, t;
  return e = new qv({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function gy(r) {
  let e, t;
  return e = new Qv({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function e6(r) {
  let e, t, n, a, i, l, o;
  const s = [by, vy], u = [];
  function c(d, h) {
    return (
      /*isPictureInPicture*/
      d[27] ? 0 : 1
    );
  }
  return n = c(r), a = u[n] = s[n](r), {
    c() {
      e = ht("div"), t = ht("div"), a.c(), this.h();
    },
    l(d) {
      e = ct(d, "DIV", { class: !0 });
      var h = vt(e);
      t = ct(h, "DIV", { class: !0 });
      var _ = vt(t);
      a.l(_), _.forEach(Le), h.forEach(Le), this.h();
    },
    h() {
      et(t, "class", "action svelte-jjnt02"), et(e, "class", "action-group svelte-jjnt02");
    },
    m(d, h) {
      nn(d, e, h), Ge(e, t), u[n].m(t, null), i = !0, l || (o = hr(
        t,
        "click",
        /*changeVideoShowType*/
        r[38]
      ), l = !0);
    },
    p(d, h) {
      let _ = n;
      n = c(d), n !== _ && (C0(), me(u[_], 1, 1, () => {
        u[_] = null;
      }), F0(), a = u[n], a || (a = u[n] = s[n](d), a.c()), ie(a, 1), a.m(t, null));
    },
    i(d) {
      i || (ie(a), i = !0);
    },
    o(d) {
      me(a), i = !1;
    },
    d(d) {
      d && Le(e), u[n].d(), l = !1, o();
    }
  };
}
function vy(r) {
  let e, t;
  return e = new mb({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function by(r) {
  let e, t;
  return e = new sb({}), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function yy(r) {
  let e, t;
  return e = new Wb({
    props: {
      onStartChat: (
        /*start_webrtc*/
        r[37]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        r[34]
      ),
      stream_state: (
        /*stream_state*/
        r[7]
      ),
      wave_color: (
        /*wave_color*/
        r[2]
      )
    }
  }), {
    c() {
      V0(e.$$.fragment);
    },
    l(n) {
      H0(e.$$.fragment, n);
    },
    m(n, a) {
      U0(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*stream_state*/
      128 && (i.stream_state = /*stream_state*/
      n[7]), a[0] & /*wave_color*/
      4 && (i.wave_color = /*wave_color*/
      n[2]), e.$set(i);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      me(e.$$.fragment, n), t = !1;
    },
    d(n) {
      j0(e, n);
    }
  };
}
function wy(r) {
  let e, t, n, a;
  return t = new Ib({
    props: {
      replying: (
        /*replying*/
        r[14]
      ),
      onInterrupt: (
        /*on_interrupt*/
        r[35]
      ),
      onSend: (
        /*on_send*/
        r[36]
      ),
      onStop: (
        /*start_webrtc*/
        r[37]
      )
    }
  }), {
    c() {
      e = ht("div"), V0(t.$$.fragment), this.h();
    },
    l(i) {
      e = ct(i, "DIV", { class: !0, style: !0 });
      var l = vt(e);
      H0(t.$$.fragment, l), l.forEach(Le), this.h();
    },
    h() {
      et(e, "class", "chat-input-wrapper svelte-jjnt02"), et(e, "style", n = /*isPictureInPicture*/
      r[27] ? `left: ${/*chatInputPosition*/
      r[23].left}px;width: ${/*chatInputPosition*/
      r[23].width}px` : ""), Jn(
        e,
        "side-by-side",
        /*isSideBySide*/
        r[28]
      );
    },
    m(i, l) {
      nn(i, e, l), U0(t, e, null), a = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*replying*/
      16384 && (o.replying = /*replying*/
      i[14]), t.$set(o), (!a || l[0] & /*isPictureInPicture, chatInputPosition*/
      142606336 && n !== (n = /*isPictureInPicture*/
      i[27] ? `left: ${/*chatInputPosition*/
      i[23].left}px;width: ${/*chatInputPosition*/
      i[23].width}px` : "")) && et(e, "style", n), (!a || l[0] & /*isSideBySide*/
      268435456) && Jn(
        e,
        "side-by-side",
        /*isSideBySide*/
        i[28]
      );
    },
    i(i) {
      a || (ie(t.$$.fragment, i), a = !0);
    },
    o(i) {
      me(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Le(e), j0(t);
    }
  };
}
function ky(r) {
  let e, t, n, a, i, l, o, s, u, c, d, h, _, g, b, y, D, k, p, S, E, F, $, B, T = !/*webcam_accessed*/
  r[13] && H4(r), x = (
    /*stream_state*/
    r[7] === "open" && V4(r)
  ), L = (
    /*hasCamera*/
    r[11] && U4(r)
  ), P = (
    /*hasMic*/
    r[12] && Y4(r)
  );
  const ae = [gy, py], R = [];
  function ee(N, H) {
    return (
      /*volumeMuted*/
      N[8] ? 0 : 1
    );
  }
  y = ee(r), D = R[y] = ae[y](r);
  let Z = (
    /*hasCamera*/
    r[11] && e6(r)
  );
  const ze = [wy, yy], oe = [];
  function ge(N, H) {
    return (!/*hasMic*/
    N[12] || /*micMuted*/
    N[9]) && /*stream_state*/
    N[7] === "open" ? 0 : 1;
  }
  return S = ge(r), E = oe[S] = ze[S](r), {
    c() {
      e = ht("div"), T && T.c(), t = p0(), n = ht("div"), a = ht("div"), i = ht("video"), l = p0(), o = ht("div"), s = ht("video"), u = p0(), x && x.c(), c = p0(), d = ht("div"), h = ht("div"), L && L.c(), _ = p0(), P && P.c(), g = p0(), b = ht("div"), D.c(), k = p0(), Z && Z.c(), p = p0(), E.c(), this.h();
    },
    l(N) {
      e = ct(N, "DIV", { class: !0 });
      var H = vt(e);
      T && T.l(H), t = _0(H), n = ct(H, "DIV", { class: !0 });
      var te = vt(n);
      a = ct(te, "DIV", { class: !0 });
      var he = vt(a);
      i = ct(he, "VIDEO", { class: !0 }), vt(i).forEach(Le), he.forEach(Le), l = _0(te), o = ct(te, "DIV", { class: !0 });
      var Ie = vt(o);
      s = ct(Ie, "VIDEO", { class: !0 }), vt(s).forEach(Le), u = _0(Ie), x && x.l(Ie), Ie.forEach(Le), c = _0(te), d = ct(te, "DIV", { class: !0 });
      var z = vt(d);
      h = ct(z, "DIV", { class: !0 });
      var xe = vt(h);
      L && L.l(xe), _ = _0(xe), P && P.l(xe), g = _0(xe), b = ct(xe, "DIV", { class: !0 });
      var pe = vt(b);
      D.l(pe), pe.forEach(Le), xe.forEach(Le), k = _0(z), Z && Z.l(z), z.forEach(Le), te.forEach(Le), p = _0(H), E.l(H), H.forEach(Le), this.h();
    },
    h() {
      et(i, "class", "local-video svelte-jjnt02"), i.autoplay = !0, i.muted = !0, i.playsInline = !0, Be(i, "display", !/*hasCamera*/
      r[11] || /*cameraOff*/
      r[10] ? "none" : "block"), Be(
        i,
        "visibility",
        /*isPictureInPicture*/
        r[27] && /*cameraOff*/
        r[10] ? "hidden" : "visible"
      ), et(a, "class", "local-video-container svelte-jjnt02"), Be(a, "display", !/*hasCamera*/
      r[11] && /*stream_state*/
      r[7] === "open" || /*cameraOff*/
      r[10] ? "none" : "block"), Be(
        a,
        "left",
        /*localVideoPosition*/
        r[19].width < 10 ? "50%" : (
          /*localVideoPosition*/
          r[19].left + "px"
        )
      ), Be(
        a,
        "top",
        /*localVideoPosition*/
        r[19].height < 10 ? "50%" : (
          /*localVideoPosition*/
          r[19].top + "px"
        )
      ), Be(
        a,
        "width",
        /*isPictureInPicture*/
        r[27] ? (
          /*localVideoPosition*/
          r[19].width + "px"
        ) : ""
      ), Be(
        a,
        "height",
        /*isPictureInPicture*/
        r[27] ? (
          /*localVideoPosition*/
          r[19].height + "px"
        ) : ""
      ), et(s, "class", "remote-video svelte-jjnt02"), s.autoplay = !0, s.playsInline = !0, s.muted = /*volumeMuted*/
      r[8], et(o, "class", "remote-video-container svelte-jjnt02"), Be(
        o,
        "left",
        /*remoteVideoPosition*/
        r[22].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          r[22].left + "px"
        )
      ), Be(
        o,
        "top",
        /*remoteVideoPosition*/
        r[22].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          r[22].top + "px"
        )
      ), Be(
        o,
        "width",
        /*isPictureInPicture*/
        r[27] ? (
          /*remoteVideoPosition*/
          r[22].width + "px"
        ) : ""
      ), Be(
        o,
        "height",
        /*isPictureInPicture*/
        r[27] ? (
          /*remoteVideoPosition*/
          r[22].height + "px"
        ) : ""
      ), et(b, "class", "action svelte-jjnt02"), et(h, "class", "action-group svelte-jjnt02"), et(d, "class", "actions svelte-jjnt02"), Be(
        d,
        "left",
        /*isPictureInPicture*/
        r[27] ? (
          /*actionsPosition*/
          r[24].left + "px"
        ) : ""
      ), Be(
        d,
        "bottom",
        /*isPictureInPicture*/
        r[27] ? (
          /*actionsPosition*/
          r[24].bottom + "px"
        ) : ""
      ), et(n, "class", "video-container svelte-jjnt02"), Jn(n, "vertical", !/*isLandScape*/
      r[0]), Jn(
        n,
        "picture-in-picture",
        /*isPictureInPicture*/
        r[27]
      ), Jn(
        n,
        "side-by-side",
        /*isSideBySide*/
        r[28]
      ), Jn(n, "no-local-video", !/*hasCamera*/
      r[11] || /*cameraOff*/
      r[10]), Be(
        n,
        "visibility",
        /*webcam_accessed*/
        r[13] ? "visible" : "hidden"
      ), et(e, "class", "wrap svelte-jjnt02"), Be(
        e,
        "height",
        /*height*/
        r[1] > 100 ? "100%" : "90vh"
      );
    },
    m(N, H) {
      nn(N, e, H), T && T.m(e, null), Ge(e, t), Ge(e, n), Ge(n, a), Ge(a, i), r[55](i), r[56](a), Ge(n, l), Ge(n, o), Ge(o, s), r[57](s), Ge(o, u), x && x.m(o, null), r[58](o), Ge(n, c), Ge(n, d), Ge(d, h), L && L.m(h, null), Ge(h, _), P && P.m(h, null), Ge(h, g), Ge(h, b), R[y].m(b, null), Ge(d, k), Z && Z.m(d, null), r[63](n), Ge(e, p), oe[S].m(e, null), F = !0, $ || (B = [
        hr(
          i,
          "playing",
          /*computeLocalPosition*/
          r[39]
        ),
        hr(
          s,
          "playing",
          /*computeRemotePosition*/
          r[40]
        ),
        hr(
          b,
          "click",
          /*handle_volume_mute*/
          r[29]
        )
      ], $ = !0);
    },
    p(N, H) {
      /*webcam_accessed*/
      N[13] ? T && (C0(), me(T, 1, 1, () => {
        T = null;
      }), F0()) : T ? (T.p(N, H), H[0] & /*webcam_accessed*/
      8192 && ie(T, 1)) : (T = H4(N), T.c(), ie(T, 1), T.m(e, t)), H[0] & /*hasCamera, cameraOff*/
      3072 && Be(i, "display", !/*hasCamera*/
      N[11] || /*cameraOff*/
      N[10] ? "none" : "block"), H[0] & /*isPictureInPicture, cameraOff*/
      134218752 && Be(
        i,
        "visibility",
        /*isPictureInPicture*/
        N[27] && /*cameraOff*/
        N[10] ? "hidden" : "visible"
      ), H[0] & /*hasCamera, stream_state, cameraOff*/
      3200 && Be(a, "display", !/*hasCamera*/
      N[11] && /*stream_state*/
      N[7] === "open" || /*cameraOff*/
      N[10] ? "none" : "block"), H[0] & /*localVideoPosition*/
      524288 && Be(
        a,
        "left",
        /*localVideoPosition*/
        N[19].width < 10 ? "50%" : (
          /*localVideoPosition*/
          N[19].left + "px"
        )
      ), H[0] & /*localVideoPosition*/
      524288 && Be(
        a,
        "top",
        /*localVideoPosition*/
        N[19].height < 10 ? "50%" : (
          /*localVideoPosition*/
          N[19].top + "px"
        )
      ), H[0] & /*isPictureInPicture, localVideoPosition*/
      134742016 && Be(
        a,
        "width",
        /*isPictureInPicture*/
        N[27] ? (
          /*localVideoPosition*/
          N[19].width + "px"
        ) : ""
      ), H[0] & /*isPictureInPicture, localVideoPosition*/
      134742016 && Be(
        a,
        "height",
        /*isPictureInPicture*/
        N[27] ? (
          /*localVideoPosition*/
          N[19].height + "px"
        ) : ""
      ), (!F || H[0] & /*volumeMuted*/
      256) && (s.muted = /*volumeMuted*/
      N[8]), /*stream_state*/
      N[7] === "open" ? x ? (x.p(N, H), H[0] & /*stream_state*/
      128 && ie(x, 1)) : (x = V4(N), x.c(), ie(x, 1), x.m(o, null)) : x && (C0(), me(x, 1, 1, () => {
        x = null;
      }), F0()), H[0] & /*remoteVideoPosition*/
      4194304 && Be(
        o,
        "left",
        /*remoteVideoPosition*/
        N[22].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          N[22].left + "px"
        )
      ), H[0] & /*remoteVideoPosition*/
      4194304 && Be(
        o,
        "top",
        /*remoteVideoPosition*/
        N[22].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          N[22].top + "px"
        )
      ), H[0] & /*isPictureInPicture, remoteVideoPosition*/
      138412032 && Be(
        o,
        "width",
        /*isPictureInPicture*/
        N[27] ? (
          /*remoteVideoPosition*/
          N[22].width + "px"
        ) : ""
      ), H[0] & /*isPictureInPicture, remoteVideoPosition*/
      138412032 && Be(
        o,
        "height",
        /*isPictureInPicture*/
        N[27] ? (
          /*remoteVideoPosition*/
          N[22].height + "px"
        ) : ""
      ), /*hasCamera*/
      N[11] ? L ? (L.p(N, H), H[0] & /*hasCamera*/
      2048 && ie(L, 1)) : (L = U4(N), L.c(), ie(L, 1), L.m(h, _)) : L && (C0(), me(L, 1, 1, () => {
        L = null;
      }), F0()), /*hasMic*/
      N[12] ? P ? (P.p(N, H), H[0] & /*hasMic*/
      4096 && ie(P, 1)) : (P = Y4(N), P.c(), ie(P, 1), P.m(h, g)) : P && (C0(), me(P, 1, 1, () => {
        P = null;
      }), F0());
      let te = y;
      y = ee(N), y !== te && (C0(), me(R[te], 1, 1, () => {
        R[te] = null;
      }), F0(), D = R[y], D || (D = R[y] = ae[y](N), D.c()), ie(D, 1), D.m(b, null)), /*hasCamera*/
      N[11] ? Z ? (Z.p(N, H), H[0] & /*hasCamera*/
      2048 && ie(Z, 1)) : (Z = e6(N), Z.c(), ie(Z, 1), Z.m(d, null)) : Z && (C0(), me(Z, 1, 1, () => {
        Z = null;
      }), F0()), H[0] & /*isPictureInPicture, actionsPosition*/
      150994944 && Be(
        d,
        "left",
        /*isPictureInPicture*/
        N[27] ? (
          /*actionsPosition*/
          N[24].left + "px"
        ) : ""
      ), H[0] & /*isPictureInPicture, actionsPosition*/
      150994944 && Be(
        d,
        "bottom",
        /*isPictureInPicture*/
        N[27] ? (
          /*actionsPosition*/
          N[24].bottom + "px"
        ) : ""
      ), (!F || H[0] & /*isLandScape*/
      1) && Jn(n, "vertical", !/*isLandScape*/
      N[0]), (!F || H[0] & /*isPictureInPicture*/
      134217728) && Jn(
        n,
        "picture-in-picture",
        /*isPictureInPicture*/
        N[27]
      ), (!F || H[0] & /*isSideBySide*/
      268435456) && Jn(
        n,
        "side-by-side",
        /*isSideBySide*/
        N[28]
      ), (!F || H[0] & /*hasCamera, cameraOff*/
      3072) && Jn(n, "no-local-video", !/*hasCamera*/
      N[11] || /*cameraOff*/
      N[10]), H[0] & /*webcam_accessed*/
      8192 && Be(
        n,
        "visibility",
        /*webcam_accessed*/
        N[13] ? "visible" : "hidden"
      );
      let he = S;
      S = ge(N), S === he ? oe[S].p(N, H) : (C0(), me(oe[he], 1, 1, () => {
        oe[he] = null;
      }), F0(), E = oe[S], E ? E.p(N, H) : (E = oe[S] = ze[S](N), E.c()), ie(E, 1), E.m(e, null)), H[0] & /*height*/
      2 && Be(
        e,
        "height",
        /*height*/
        N[1] > 100 ? "100%" : "90vh"
      );
    },
    i(N) {
      F || (ie(T), ie(x), ie(L), ie(P), ie(D), ie(Z), ie(E), F = !0);
    },
    o(N) {
      me(T), me(x), me(L), me(P), me(D), me(Z), me(E), F = !1;
    },
    d(N) {
      N && Le(e), T && T.d(), r[55](null), r[56](null), r[57](null), x && x.d(), r[58](null), L && L.d(), P && P.d(), R[y].d(), Z && Z.d(), r[63](null), oe[S].d(), $ = !1, U5(B);
    }
  };
}
function Dy(r, e, t) {
  let n, a;
  var i = this && this.__awaiter || function(V, we, rt, b0) {
    function Fe(st) {
      return st instanceof rt ? st : new rt(function(jn) {
        jn(st);
      });
    }
    return new (rt || (rt = Promise))(function(st, jn) {
      function pl(Un) {
        try {
          La(b0.next(Un));
        } catch (di) {
          jn(di);
        }
      }
      function hi(Un) {
        try {
          La(b0.throw(Un));
        } catch (di) {
          jn(di);
        }
      }
      function La(Un) {
        Un.done ? st(Un.value) : Fe(Un.value).then(pl, hi);
      }
      La((b0 = b0.apply(V, we || [])).next());
    });
  };
  let l = [], o = [], s = null, u = null, c = "closed", { on_change_cb: d } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: h = {} } = e, { button_labels: _ } = e, { height: g } = e;
  const b = (V) => {
    V === "closed" ? t(7, c = "closed") : V === "waiting" ? t(7, c = "waiting") : t(7, c = "open");
  };
  let { track_constraints: y = null } = e, { rtc_configuration: D } = e, { stream_every: k = 1 } = e, { server: p } = e, { i18n: S } = e, E = !1, F = !1, $ = !1;
  const B = () => {
    t(8, E = !E);
  }, T = () => {
    t(9, F = !F), Z.getTracks().forEach((V) => {
      V.kind.includes("audio") && (V.enabled = !F);
    });
  }, x = () => {
    t(10, $ = !$), Z.getTracks().forEach((V) => {
      V.kind.includes("video") && (V.enabled = !$);
    });
  }, L = cy(), P = (V) => i(void 0, void 0, void 0, function* () {
    const we = V;
    console.log(V, u, s);
    let rt = s ? s.deviceId : "", b0 = u ? u.deviceId : "";
    o.find((st) => st.deviceId === we) ? (b0 = we, t(25, Nt = !1), t(9, F = !1)) : l.find((st) => st.deviceId === we) && (rt = we, t(26, Rt = !1), t(10, $ = !1));
    const Fe = Qe;
    yield C4(
      b0 ? { deviceId: { exact: b0 } } : R,
      rt ? { deviceId: { exact: rt } } : ae,
      Fe,
      y
    ).then((st) => i(void 0, void 0, void 0, function* () {
      Z = st, st = st, F4(st, Fe), t(5, s = l.find((jn) => jn.deviceId === rt) || null), t(6, u = o.find((jn) => jn.deviceId === b0) || null);
    }));
  });
  let ae = !0, R = !0;
  function ee() {
    return i(this, void 0, void 0, function* () {
      try {
        const V = Qe;
        t(9, F = !1), t(10, $ = !1), t(8, E = !1), yield navigator.mediaDevices.getUserMedia({ audio: !0 }).catch(() => {
        }), yield navigator.mediaDevices.getUserMedia({ video: !0 }).catch(() => {
        });
        const we = yield _b();
        t(3, l = x4(we, "videoinput")), t(4, o = x4(we, "audioinput")), console.log(l), console.log(o), yield C4(we.some((rt) => rt.kind === "audioinput" && rt.deviceId), we.some((rt) => rt.kind === "videoinput" && rt.deviceId), V, y).then((rt) => i(this, void 0, void 0, function* () {
          Z = rt;
        })).then(() => {
          Z.getTracks().map((b0) => {
            var Fe;
            return (Fe = b0.getSettings()) === null || Fe === void 0 ? void 0 : Fe.deviceId;
          }).forEach((b0) => {
            const Fe = we.find((st) => st.deviceId === b0);
            Fe && (Fe != null && Fe.kind.includes("video")) ? t(5, s = Fe) : Fe && (Fe != null && Fe.kind.includes("audio")) && t(6, u = Fe);
          }), !s && t(5, s = l[0]);
        }).catch(() => {
          alert(S("image.no_webcam_support"));
        }).finally(() => {
          Z || (Z = new MediaStream()), Z.getTracks().find((rt) => rt.kind === "audio") || (Z.addTrack(gb()), t(12, R = !1)), Z.getTracks().find((rt) => rt.kind === "video") || (Z.addTrack(pb()), t(11, ae = !1)), t(13, oe = !0), ze = Z, F4(ze, V);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && (L("error", S("image.no_webcam_support")), alert(S("image.no_webcam_support")));
      } catch (V) {
        if (V instanceof DOMException && V.name == "NotAllowedError")
          L("error", S("image.allow_webcam_access"));
        else
          throw V;
      }
    });
  }
  let Z, ze, oe = !1, ge, { webrtc_id: N } = e, { wave_color: H = "#7873F6" } = e;
  const te = () => ze || Qe.srcObject;
  let he = !1, Ie;
  function z() {
    Ie && Ie.send(JSON.stringify({ type: "stop_chat" }));
  }
  function xe(V) {
    Ie.send(JSON.stringify({ type: "chat", data: V })), t(14, he = !0);
  }
  let pe = "", Te = "";
  function ot(V) {
    const we = JSON.parse(V.data);
    we.type === "chat" ? (pe !== we.id && (t(15, Te = ""), pe = we.id), t(15, Te += we.message)) : we.type === "avatar_end" && t(14, he = !1);
  }
  function Ue() {
    return i(this, void 0, void 0, function* () {
      if (c === "closed")
        ge = new RTCPeerConnection(D), ge.addEventListener("connectionstatechange", (V) => i(this, void 0, void 0, function* () {
          switch (ge.connectionState) {
            case "connected":
              t(7, c = "open");
              break;
            case "disconnected":
              t(7, c = "closed"), _n(ge), yield ee();
              break;
          }
        })), t(7, c = "waiting"), t(43, N = Math.random().toString(36).substring(2)), al(Z, ge, G, p.offer, N, "video", d, h).then(([V, we]) => {
          ge = V, B0(), Ie = we, Ie.addEventListener("message", ot);
        }).catch(() => {
          console.info("catching"), t(7, c = "closed"), L("error", "Too many concurrent users. Come back later!");
        });
      else {
        if (c === "waiting")
          return;
        t(14, he = !1), t(22, K.init = !1, K), M0(), _n(ge), t(7, c = "closed"), yield ee();
      }
    });
  }
  let qe;
  const fe = { width: 0, height: 0 };
  let tt = "picture-in-picture", Qe, He, ve = {
    left: 10,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, G, Ve, K = {
    left: 0,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, qt = { left: 0, top: 0, width: 1, height: 1 }, Oe = {
    left: 0,
    bottom: 0,
    init: !1,
    isOverflow: !1
  };
  hy(() => {
    qe.getBoundingClientRect(), fe.width = qe.clientWidth, fe.height = qe.clientHeight, t(0, Vn = fe.width * 1.5 > fe.height), console.log(fe);
  });
  function wn() {
    tt === "picture-in-picture" ? t(53, tt = "side-by-side") : tt === "side-by-side" && t(53, tt = "picture-in-picture");
  }
  function rn() {
    const V = K.init ? K : ve;
    t(23, qt.left = V.left, qt), t(23, qt.width = V.width, qt);
  }
  function M0() {
    if (!(!Qe || !He || !Qe.videoHeight)) {
      if (K.init) {
        let V = K.height / 4, we = V / Qe.videoHeight * Qe.videoWidth;
        t(19, ve.left = K.left + 14, ve), t(19, ve.top = K.top + K.height - V - 14, ve), t(19, ve.width = we, ve), t(19, ve.height = V, ve), t(24, Oe.left = K.left + K.width + 10, Oe), t(
          24,
          Oe.left = Oe.left > fe.width ? Oe.left - 60 : Oe.left,
          Oe
        ), t(24, Oe.bottom = fe.height - K.top - K.height + 5, Oe), t(24, Oe.isOverflow = Oe.left + 300 > fe.width, Oe);
      } else {
        let V = fe.height - 24, we = V / Qe.videoHeight * Qe.videoWidth;
        we > fe.width && (we = fe.width), t(19, ve.left = (fe.width - we) / 2, ve), t(19, ve.top = fe.height - V, ve), t(19, ve.width = we, ve), t(19, ve.height = V, ve), t(24, Oe.left = ve.left + ve.width + 10, Oe), t(
          24,
          Oe.left = Oe.left > fe.width ? Oe.left - 60 : Oe.left,
          Oe
        ), t(24, Oe.bottom = fe.height - ve.top - ve.height + 5, Oe), t(24, Oe.isOverflow = Oe.left + 300 > fe.width, Oe);
      }
      rn();
    }
  }
  function B0() {
    if (!G.srcObject || !G.videoHeight) return;
    console.log(G.videoHeight, G.videoWidth, "---------------------");
    let V = fe.height - 24, we = V / G.videoHeight * G.videoWidth;
    we > fe.width && (we = fe.width), t(22, K.left = (fe.width - we) / 2, K), t(22, K.top = fe.height - V, K), t(22, K.width = we, K), t(22, K.height = V, K), t(22, K.init = !0, K), M0();
  }
  let Nt = !1, Rt = !1;
  function Hn(V) {
    t(25, Nt = !0), V.preventDefault(), V.stopPropagation();
  }
  function Ma(V) {
    t(26, Rt = !0), V.preventDefault(), V.stopPropagation();
  }
  let { isLandScape: Vn = !0 } = e;
  window.addEventListener("resize", () => {
    qe.getBoundingClientRect(), fe.width = qe.clientWidth, fe.height = qe.clientHeight, t(0, Vn = fe.width * 1.5 > fe.height), M0(), B0();
  });
  const Ba = async () => ee();
  function zr(V) {
    Bi[V ? "unshift" : "push"](() => {
      Qe = V, t(17, Qe);
    });
  }
  function q(V) {
    Bi[V ? "unshift" : "push"](() => {
      He = V, t(18, He);
    });
  }
  function v0(V) {
    Bi[V ? "unshift" : "push"](() => {
      G = V, t(20, G);
    });
  }
  function Ir(V) {
    Bi[V ? "unshift" : "push"](() => {
      Ve = V, t(21, Ve);
    });
  }
  const ui = (V, we) => P(V.deviceId), ci = () => t(26, Rt = !1), eo = (V, we) => P(V.deviceId), za = () => t(25, Nt = !1);
  function Ia(V) {
    Bi[V ? "unshift" : "push"](() => {
      qe = V, t(16, qe);
    });
  }
  return r.$$set = (V) => {
    "on_change_cb" in V && t(44, d = V.on_change_cb), "rtp_params" in V && t(45, h = V.rtp_params), "button_labels" in V && t(46, _ = V.button_labels), "height" in V && t(1, g = V.height), "track_constraints" in V && t(48, y = V.track_constraints), "rtc_configuration" in V && t(49, D = V.rtc_configuration), "stream_every" in V && t(50, k = V.stream_every), "server" in V && t(51, p = V.server), "i18n" in V && t(52, S = V.i18n), "webrtc_id" in V && t(43, N = V.webrtc_id), "wave_color" in V && t(2, H = V.wave_color), "isLandScape" in V && t(0, Vn = V.isLandScape);
  }, r.$$.update = () => {
    r.$$.dirty[1] & /*videoShowType*/
    4194304 && t(28, n = tt === "side-by-side"), r.$$.dirty[1] & /*videoShowType*/
    4194304 && t(27, a = tt === "picture-in-picture");
  }, [
    Vn,
    g,
    H,
    l,
    o,
    s,
    u,
    c,
    E,
    F,
    $,
    ae,
    R,
    oe,
    he,
    Te,
    qe,
    Qe,
    He,
    ve,
    G,
    Ve,
    K,
    qt,
    Oe,
    Nt,
    Rt,
    a,
    n,
    B,
    T,
    x,
    P,
    ee,
    te,
    z,
    xe,
    Ue,
    wn,
    M0,
    B0,
    Hn,
    Ma,
    N,
    d,
    h,
    _,
    b,
    y,
    D,
    k,
    p,
    S,
    tt,
    Ba,
    zr,
    q,
    v0,
    Ir,
    ui,
    ci,
    eo,
    za,
    Ia
  ];
}
class Sy extends iy {
  constructor(e) {
    super(), sy(
      this,
      e,
      Dy,
      ky,
      uy,
      {
        on_change_cb: 44,
        rtp_params: 45,
        button_labels: 46,
        height: 1,
        modify_stream: 47,
        track_constraints: 48,
        rtc_configuration: 49,
        stream_every: 50,
        server: 51,
        i18n: 52,
        webrtc_id: 43,
        wave_color: 2,
        isLandScape: 0
      },
      null,
      [-1, -1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[47];
  }
}
const {
  SvelteComponent: Ey,
  add_flush_callback: fl,
  assign: Ay,
  bind: ml,
  binding_callbacks: _l,
  check_outros: l7,
  claim_component: $r,
  claim_space: Fy,
  create_component: Qr,
  destroy_component: Mr,
  detach: r5,
  empty: I1,
  flush: Ye,
  get_spread_object: Cy,
  get_spread_update: xy,
  group_outros: o7,
  init: Ty,
  insert_hydration: a5,
  mount_component: Br,
  safe_not_equal: $y,
  space: Qy,
  transition_in: K0,
  transition_out: J0
} = window.__gradio__svelte__internal;
function My(r) {
  let e, t;
  return e = new r6({
    props: {
      visible: (
        /*visible*/
        r[4]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        r[2]
      ),
      elem_classes: (
        /*elem_classes*/
        r[3]
      ),
      height: (
        /*height*/
        r[9]
      ),
      width: (
        /*width*/
        r[10]
      ),
      container: (
        /*container*/
        r[12]
      ),
      scale: (
        /*scale*/
        r[13]
      ),
      min_width: (
        /*min_width*/
        r[14]
      ),
      allow_overflow: !1,
      $$slots: { default: [Ry] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      Qr(e.$$.fragment);
    },
    l(n) {
      $r(e.$$.fragment, n);
    },
    m(n, a) {
      Br(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*visible*/
      16 && (i.visible = /*visible*/
      n[4]), a[0] & /*elem_id*/
      4 && (i.elem_id = /*elem_id*/
      n[2]), a[0] & /*elem_classes*/
      8 && (i.elem_classes = /*elem_classes*/
      n[3]), a[0] & /*height*/
      512 && (i.height = /*height*/
      n[9]), a[0] & /*width*/
      1024 && (i.width = /*width*/
      n[10]), a[0] & /*container*/
      4096 && (i.container = /*container*/
      n[12]), a[0] & /*scale*/
      8192 && (i.scale = /*scale*/
      n[13]), a[0] & /*min_width*/
      16384 && (i.min_width = /*min_width*/
      n[14]), a[0] & /*label, show_label, server, rtc_configuration, value, gradio, mode, modality, icon, icon_button_color, pulse_color, icon_radius, time_limit, track_constraints, rtp_params, button_labels, loading_status*/
      67078625 | a[2] & /*$$scope*/
      16 && (i.$$scope = { dirty: a, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (K0(e.$$.fragment, n), t = !0);
    },
    o(n) {
      J0(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Mr(e, n);
    }
  };
}
function By(r) {
  let e, t;
  return e = new r6({
    props: {
      visible: (
        /*visible*/
        r[4]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        r[2]
      ),
      elem_classes: (
        /*elem_classes*/
        r[3]
      ),
      height: (
        /*height*/
        r[9]
      ),
      width: (
        /*width*/
        r[10]
      ),
      container: (
        /*container*/
        r[12]
      ),
      scale: (
        /*scale*/
        r[13]
      ),
      min_width: (
        /*min_width*/
        r[14]
      ),
      allow_overflow: !1,
      $$slots: { default: [Oy] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      Qr(e.$$.fragment);
    },
    l(n) {
      $r(e.$$.fragment, n);
    },
    m(n, a) {
      Br(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*visible*/
      16 && (i.visible = /*visible*/
      n[4]), a[0] & /*elem_id*/
      4 && (i.elem_id = /*elem_id*/
      n[2]), a[0] & /*elem_classes*/
      8 && (i.elem_classes = /*elem_classes*/
      n[3]), a[0] & /*height*/
      512 && (i.height = /*height*/
      n[9]), a[0] & /*width*/
      1024 && (i.width = /*width*/
      n[10]), a[0] & /*container*/
      4096 && (i.container = /*container*/
      n[12]), a[0] & /*scale*/
      8192 && (i.scale = /*scale*/
      n[13]), a[0] & /*min_width*/
      16384 && (i.min_width = /*min_width*/
      n[14]), a[0] & /*server, gradio, track_constraints, height, rtc_configuration, value*/
      2198017 | a[2] & /*$$scope*/
      16 && (i.$$scope = { dirty: a, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (K0(e.$$.fragment, n), t = !0);
    },
    o(n) {
      J0(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Mr(e, n);
    }
  };
}
function zy(r) {
  let e, t, n;
  function a(l) {
    r[62](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      r[26]
    ),
    label: (
      /*label*/
      r[6]
    ),
    show_label: (
      /*show_label*/
      r[7]
    ),
    server: (
      /*server*/
      r[11]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      r[16]
    ),
    time_limit: (
      /*time_limit*/
      r[17]
    ),
    track_constraints: (
      /*track_constraints*/
      r[21]
    ),
    mode: (
      /*mode*/
      r[19]
    ),
    rtp_params: (
      /*rtp_params*/
      r[20]
    ),
    i18n: (
      /*gradio*/
      r[15].i18n
    ),
    icon: (
      /*icon*/
      r[22]
    ),
    reject_cb: (
      /*reject_cb*/
      r[27]
    ),
    icon_button_color: (
      /*icon_button_color*/
      r[23]
    ),
    icon_radius: (
      /*icon_radius*/
      r[25]
    ),
    pulse_color: (
      /*pulse_color*/
      r[24]
    ),
    button_labels: (
      /*button_labels*/
      r[5]
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (i.value = /*value*/
    r[0]), e = new jg({ props: i }), _l.push(() => ml(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_5*/
      r[63]
    ), e.$on(
      "error",
      /*error_handler_5*/
      r[64]
    ), e.$on(
      "warning",
      /*warning_handler*/
      r[65]
    ), {
      c() {
        Qr(e.$$.fragment);
      },
      l(l) {
        $r(e.$$.fragment, l);
      },
      m(l, o) {
        Br(e, l, o), n = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        64 && (s.label = /*label*/
        l[6]), o[0] & /*show_label*/
        128 && (s.show_label = /*show_label*/
        l[7]), o[0] & /*server*/
        2048 && (s.server = /*server*/
        l[11]), o[0] & /*rtc_configuration*/
        65536 && (s.rtc_configuration = /*rtc_configuration*/
        l[16]), o[0] & /*time_limit*/
        131072 && (s.time_limit = /*time_limit*/
        l[17]), o[0] & /*track_constraints*/
        2097152 && (s.track_constraints = /*track_constraints*/
        l[21]), o[0] & /*mode*/
        524288 && (s.mode = /*mode*/
        l[19]), o[0] & /*rtp_params*/
        1048576 && (s.rtp_params = /*rtp_params*/
        l[20]), o[0] & /*gradio*/
        32768 && (s.i18n = /*gradio*/
        l[15].i18n), o[0] & /*icon*/
        4194304 && (s.icon = /*icon*/
        l[22]), o[0] & /*icon_button_color*/
        8388608 && (s.icon_button_color = /*icon_button_color*/
        l[23]), o[0] & /*icon_radius*/
        33554432 && (s.icon_radius = /*icon_radius*/
        l[25]), o[0] & /*pulse_color*/
        16777216 && (s.pulse_color = /*pulse_color*/
        l[24]), o[0] & /*button_labels*/
        32 && (s.button_labels = /*button_labels*/
        l[5]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], fl(() => t = !1)), e.$set(s);
      },
      i(l) {
        n || (K0(e.$$.fragment, l), n = !0);
      },
      o(l) {
        J0(e.$$.fragment, l), n = !1;
      },
      d(l) {
        Mr(e, l);
      }
    }
  );
}
function Iy(r) {
  let e, t, n;
  function a(l) {
    r[51](l);
  }
  let i = {
    label: (
      /*label*/
      r[6]
    ),
    show_label: (
      /*show_label*/
      r[7]
    ),
    active_source: "webcam",
    include_audio: (
      /*modality*/
      r[18] === "audio-video"
    ),
    server: (
      /*server*/
      r[11]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      r[16]
    ),
    time_limit: (
      /*time_limit*/
      r[17]
    ),
    mode: (
      /*mode*/
      r[19]
    ),
    track_constraints: (
      /*track_constraints*/
      r[21]
    ),
    rtp_params: (
      /*rtp_params*/
      r[20]
    ),
    on_change_cb: (
      /*on_change_cb*/
      r[26]
    ),
    reject_cb: (
      /*reject_cb*/
      r[27]
    ),
    icon: (
      /*icon*/
      r[22]
    ),
    icon_button_color: (
      /*icon_button_color*/
      r[23]
    ),
    pulse_color: (
      /*pulse_color*/
      r[24]
    ),
    icon_radius: (
      /*icon_radius*/
      r[25]
    ),
    button_labels: (
      /*button_labels*/
      r[5]
    ),
    i18n: (
      /*gradio*/
      r[15].i18n
    ),
    stream_handler: (
      /*func_1*/
      r[50]
    ),
    $$slots: { default: [Ny] },
    $$scope: { ctx: r }
  };
  return (
    /*value*/
    r[0] !== void 0 && (i.value = /*value*/
    r[0]), e = new mp({ props: i }), _l.push(() => ml(e, "value", a)), e.$on(
      "clear",
      /*clear_handler_1*/
      r[52]
    ), e.$on(
      "play",
      /*play_handler_1*/
      r[53]
    ), e.$on(
      "pause",
      /*pause_handler_1*/
      r[54]
    ), e.$on(
      "upload",
      /*upload_handler_1*/
      r[55]
    ), e.$on(
      "stop",
      /*stop_handler_1*/
      r[56]
    ), e.$on(
      "end",
      /*end_handler_1*/
      r[57]
    ), e.$on(
      "start_recording",
      /*start_recording_handler_1*/
      r[58]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler_1*/
      r[59]
    ), e.$on(
      "tick",
      /*tick_handler_4*/
      r[60]
    ), e.$on(
      "error",
      /*error_handler_4*/
      r[61]
    ), {
      c() {
        Qr(e.$$.fragment);
      },
      l(l) {
        $r(e.$$.fragment, l);
      },
      m(l, o) {
        Br(e, l, o), n = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        64 && (s.label = /*label*/
        l[6]), o[0] & /*show_label*/
        128 && (s.show_label = /*show_label*/
        l[7]), o[0] & /*modality*/
        262144 && (s.include_audio = /*modality*/
        l[18] === "audio-video"), o[0] & /*server*/
        2048 && (s.server = /*server*/
        l[11]), o[0] & /*rtc_configuration*/
        65536 && (s.rtc_configuration = /*rtc_configuration*/
        l[16]), o[0] & /*time_limit*/
        131072 && (s.time_limit = /*time_limit*/
        l[17]), o[0] & /*mode*/
        524288 && (s.mode = /*mode*/
        l[19]), o[0] & /*track_constraints*/
        2097152 && (s.track_constraints = /*track_constraints*/
        l[21]), o[0] & /*rtp_params*/
        1048576 && (s.rtp_params = /*rtp_params*/
        l[20]), o[0] & /*icon*/
        4194304 && (s.icon = /*icon*/
        l[22]), o[0] & /*icon_button_color*/
        8388608 && (s.icon_button_color = /*icon_button_color*/
        l[23]), o[0] & /*pulse_color*/
        16777216 && (s.pulse_color = /*pulse_color*/
        l[24]), o[0] & /*icon_radius*/
        33554432 && (s.icon_radius = /*icon_radius*/
        l[25]), o[0] & /*button_labels*/
        32 && (s.button_labels = /*button_labels*/
        l[5]), o[0] & /*gradio*/
        32768 && (s.i18n = /*gradio*/
        l[15].i18n), o[0] & /*gradio*/
        32768 && (s.stream_handler = /*func_1*/
        l[50]), o[0] & /*gradio*/
        32768 | o[2] & /*$$scope*/
        16 && (s.$$scope = { dirty: o, ctx: l }), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], fl(() => t = !1)), e.$set(s);
      },
      i(l) {
        n || (K0(e.$$.fragment, l), n = !0);
      },
      o(l) {
        J0(e.$$.fragment, l), n = !1;
      },
      d(l) {
        Mr(e, l);
      }
    }
  );
}
function Ly(r) {
  let e, t, n;
  function a(l) {
    r[47](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      r[26]
    ),
    label: (
      /*label*/
      r[6]
    ),
    show_label: (
      /*show_label*/
      r[7]
    ),
    server: (
      /*server*/
      r[11]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      r[16]
    ),
    icon: (
      /*icon*/
      r[22]
    ),
    icon_button_color: (
      /*icon_button_color*/
      r[23]
    ),
    pulse_color: (
      /*pulse_color*/
      r[24]
    ),
    icon_radius: (
      /*icon_radius*/
      r[25]
    ),
    i18n: (
      /*gradio*/
      r[15].i18n
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (i.value = /*value*/
    r[0]), e = new ug({ props: i }), _l.push(() => ml(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_3*/
      r[48]
    ), e.$on(
      "error",
      /*error_handler_3*/
      r[49]
    ), {
      c() {
        Qr(e.$$.fragment);
      },
      l(l) {
        $r(e.$$.fragment, l);
      },
      m(l, o) {
        Br(e, l, o), n = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        64 && (s.label = /*label*/
        l[6]), o[0] & /*show_label*/
        128 && (s.show_label = /*show_label*/
        l[7]), o[0] & /*server*/
        2048 && (s.server = /*server*/
        l[11]), o[0] & /*rtc_configuration*/
        65536 && (s.rtc_configuration = /*rtc_configuration*/
        l[16]), o[0] & /*icon*/
        4194304 && (s.icon = /*icon*/
        l[22]), o[0] & /*icon_button_color*/
        8388608 && (s.icon_button_color = /*icon_button_color*/
        l[23]), o[0] & /*pulse_color*/
        16777216 && (s.pulse_color = /*pulse_color*/
        l[24]), o[0] & /*icon_radius*/
        33554432 && (s.icon_radius = /*icon_radius*/
        l[25]), o[0] & /*gradio*/
        32768 && (s.i18n = /*gradio*/
        l[15].i18n), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], fl(() => t = !1)), e.$set(s);
      },
      i(l) {
        n || (K0(e.$$.fragment, l), n = !0);
      },
      o(l) {
        J0(e.$$.fragment, l), n = !1;
      },
      d(l) {
        Mr(e, l);
      }
    }
  );
}
function qy(r) {
  let e, t, n;
  function a(l) {
    r[44](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      r[26]
    ),
    label: (
      /*label*/
      r[6]
    ),
    show_label: (
      /*show_label*/
      r[7]
    ),
    server: (
      /*server*/
      r[11]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      r[16]
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (i.value = /*value*/
    r[0]), e = new Ip({ props: i }), _l.push(() => ml(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_2*/
      r[45]
    ), e.$on(
      "error",
      /*error_handler_2*/
      r[46]
    ), {
      c() {
        Qr(e.$$.fragment);
      },
      l(l) {
        $r(e.$$.fragment, l);
      },
      m(l, o) {
        Br(e, l, o), n = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        64 && (s.label = /*label*/
        l[6]), o[0] & /*show_label*/
        128 && (s.show_label = /*show_label*/
        l[7]), o[0] & /*server*/
        2048 && (s.server = /*server*/
        l[11]), o[0] & /*rtc_configuration*/
        65536 && (s.rtc_configuration = /*rtc_configuration*/
        l[16]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], fl(() => t = !1)), e.$set(s);
      },
      i(l) {
        n || (K0(e.$$.fragment, l), n = !0);
      },
      o(l) {
        J0(e.$$.fragment, l), n = !1;
      },
      d(l) {
        Mr(e, l);
      }
    }
  );
}
function Ny(r) {
  let e, t;
  return e = new Wm({
    props: {
      i18n: (
        /*gradio*/
        r[15].i18n
      ),
      type: "video"
    }
  }), {
    c() {
      Qr(e.$$.fragment);
    },
    l(n) {
      $r(e.$$.fragment, n);
    },
    m(n, a) {
      Br(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*gradio*/
      32768 && (i.i18n = /*gradio*/
      n[15].i18n), e.$set(i);
    },
    i(n) {
      t || (K0(e.$$.fragment, n), t = !0);
    },
    o(n) {
      J0(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Mr(e, n);
    }
  };
}
function Ry(r) {
  let e, t, n, a, i, l;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        r[15].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      r[15].i18n
    ) },
    /*loading_status*/
    r[8]
  ];
  let s = {};
  for (let h = 0; h < o.length; h += 1)
    s = Ay(s, o[h]);
  e = new hf({ props: s }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    r[43]
  );
  const u = [qy, Ly, Iy, zy], c = [];
  function d(h, _) {
    return (
      /*mode*/
      h[19] == "receive" && /*modality*/
      h[18] === "video" ? 0 : (
        /*mode*/
        h[19] == "receive" && /*modality*/
        h[18] === "audio" ? 1 : (
          /*mode*/
          (h[19] === "send-receive" || /*mode*/
          h[19] == "send") && /*modality*/
          (h[18] === "video" || /*modality*/
          h[18] == "audio-video") ? 2 : (
            /*mode*/
            (h[19] === "send-receive" || /*mode*/
            h[19] === "send") && /*modality*/
            h[18] === "audio" ? 3 : -1
          )
        )
      )
    );
  }
  return ~(n = d(r)) && (a = c[n] = u[n](r)), {
    c() {
      Qr(e.$$.fragment), t = Qy(), a && a.c(), i = I1();
    },
    l(h) {
      $r(e.$$.fragment, h), t = Fy(h), a && a.l(h), i = I1();
    },
    m(h, _) {
      Br(e, h, _), a5(h, t, _), ~n && c[n].m(h, _), a5(h, i, _), l = !0;
    },
    p(h, _) {
      const g = _[0] & /*gradio, loading_status*/
      33024 ? xy(o, [
        _[0] & /*gradio*/
        32768 && {
          autoscroll: (
            /*gradio*/
            h[15].autoscroll
          )
        },
        _[0] & /*gradio*/
        32768 && { i18n: (
          /*gradio*/
          h[15].i18n
        ) },
        _[0] & /*loading_status*/
        256 && Cy(
          /*loading_status*/
          h[8]
        )
      ]) : {};
      e.$set(g);
      let b = n;
      n = d(h), n === b ? ~n && c[n].p(h, _) : (a && (o7(), J0(c[b], 1, 1, () => {
        c[b] = null;
      }), l7()), ~n ? (a = c[n], a ? a.p(h, _) : (a = c[n] = u[n](h), a.c()), K0(a, 1), a.m(i.parentNode, i)) : a = null);
    },
    i(h) {
      l || (K0(e.$$.fragment, h), K0(a), l = !0);
    },
    o(h) {
      J0(e.$$.fragment, h), J0(a), l = !1;
    },
    d(h) {
      h && (r5(t), r5(i)), Mr(e, h), ~n && c[n].d(h);
    }
  };
}
function Oy(r) {
  let e, t, n;
  function a(l) {
    r[30](l);
  }
  let i = {
    server: (
      /*server*/
      r[11]
    ),
    i18n: (
      /*gradio*/
      r[15].i18n
    ),
    stream_handler: (
      /*func*/
      r[29]
    ),
    track_constraints: (
      /*track_constraints*/
      r[21]
    ),
    height: (
      /*height*/
      r[9]
    ),
    on_change_cb: (
      /*on_change_cb*/
      r[26]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      r[16]
    )
  };
  return (
    /*value*/
    r[0] !== void 0 && (i.webrtc_id = /*value*/
    r[0]), e = new Sy({ props: i }), _l.push(() => ml(e, "webrtc_id", a)), e.$on(
      "clear",
      /*clear_handler*/
      r[31]
    ), e.$on(
      "play",
      /*play_handler*/
      r[32]
    ), e.$on(
      "pause",
      /*pause_handler*/
      r[33]
    ), e.$on(
      "upload",
      /*upload_handler*/
      r[34]
    ), e.$on(
      "stop",
      /*stop_handler*/
      r[35]
    ), e.$on(
      "end",
      /*end_handler*/
      r[36]
    ), e.$on(
      "start_recording",
      /*start_recording_handler*/
      r[37]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler*/
      r[38]
    ), e.$on(
      "tick",
      /*tick_handler*/
      r[39]
    ), e.$on(
      "error",
      /*error_handler*/
      r[40]
    ), e.$on(
      "tick",
      /*tick_handler_1*/
      r[41]
    ), e.$on(
      "error",
      /*error_handler_1*/
      r[42]
    ), {
      c() {
        Qr(e.$$.fragment);
      },
      l(l) {
        $r(e.$$.fragment, l);
      },
      m(l, o) {
        Br(e, l, o), n = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*server*/
        2048 && (s.server = /*server*/
        l[11]), o[0] & /*gradio*/
        32768 && (s.i18n = /*gradio*/
        l[15].i18n), o[0] & /*gradio*/
        32768 && (s.stream_handler = /*func*/
        l[29]), o[0] & /*track_constraints*/
        2097152 && (s.track_constraints = /*track_constraints*/
        l[21]), o[0] & /*height*/
        512 && (s.height = /*height*/
        l[9]), o[0] & /*rtc_configuration*/
        65536 && (s.rtc_configuration = /*rtc_configuration*/
        l[16]), !t && o[0] & /*value*/
        1 && (t = !0, s.webrtc_id = /*value*/
        l[0], fl(() => t = !1)), e.$set(s);
      },
      i(l) {
        n || (K0(e.$$.fragment, l), n = !0);
      },
      o(l) {
        J0(e.$$.fragment, l), n = !1;
      },
      d(l) {
        Mr(e, l);
      }
    }
  );
}
function Py(r) {
  let e, t, n, a;
  const i = [By, My], l = [];
  function o(s, u) {
    return (
      /*video_chat*/
      s[1] ? 0 : 1
    );
  }
  return e = o(r), t = l[e] = i[e](r), {
    c() {
      t.c(), n = I1();
    },
    l(s) {
      t.l(s), n = I1();
    },
    m(s, u) {
      l[e].m(s, u), a5(s, n, u), a = !0;
    },
    p(s, u) {
      let c = e;
      e = o(s), e === c ? l[e].p(s, u) : (o7(), J0(l[c], 1, 1, () => {
        l[c] = null;
      }), l7(), t = l[e], t ? t.p(s, u) : (t = l[e] = i[e](s), t.c()), K0(t, 1), t.m(n.parentNode, n));
    },
    i(s) {
      a || (K0(t), a = !0);
    },
    o(s) {
      J0(t), a = !1;
    },
    d(s) {
      s && r5(n), l[e].d(s);
    }
  };
}
function Hy(r, e, t) {
  let { video_chat: n = !1 } = e, { elem_id: a = "" } = e, { elem_classes: i = [] } = e, { visible: l = !0 } = e, { value: o = "__webrtc_value__" } = e, { button_labels: s } = e, { label: u } = e, { root: c } = e, { show_label: d } = e, { loading_status: h } = e, { height: _ } = e, { width: g } = e, { server: b } = e, { container: y = !1 } = e, { scale: D = null } = e, { min_width: k = void 0 } = e, { gradio: p } = e, { rtc_configuration: S } = e, { time_limit: E = null } = e, { modality: F = "video" } = e, { mode: $ = "send-receive" } = e, { rtp_params: B = {} } = e, { track_constraints: T = {} } = e, { icon: x = void 0 } = e, { icon_button_color: L = "var(--color-accent)" } = e, { pulse_color: P = "var(--color-accent)" } = e, { icon_radius: ae = 50 } = e;
  const R = (q) => {
    (q == null ? void 0 : q.type) === "info" || (q == null ? void 0 : q.type) === "warning" || (q == null ? void 0 : q.type) === "error" ? p.dispatch(
      (q == null ? void 0 : q.type) === "error" ? "error" : "warning",
      q.message
    ) : (q == null ? void 0 : q.type) === "fetch_output" ? p.dispatch("state_change") : (q == null ? void 0 : q.type) === "send_input" ? p.dispatch("tick") : (q == null ? void 0 : q.type) === "connection_timeout" && p.dispatch("warning", "Taking a while to connect. Are you on a VPN?"), q.type === "state_change" && p.dispatch(q === "change" ? "state_change" : "tick");
  }, ee = (q) => {
    var v0;
    q.status === "failed" && ((v0 = q.meta) === null || v0 === void 0 ? void 0 : v0.error) === "concurrency_limit_reached" ? p.dispatch("error", "Too many concurrent connections. Please try again later!") : p.dispatch("error", "Unexpected server error");
  }, Z = (...q) => p.client.stream(...q);
  function ze(q) {
    o = q, t(0, o);
  }
  const oe = () => p.dispatch("clear"), ge = () => p.dispatch("play"), N = () => p.dispatch("pause"), H = () => p.dispatch("upload"), te = () => p.dispatch("stop"), he = () => p.dispatch("end"), Ie = () => p.dispatch("start_recording"), z = () => p.dispatch("stop_recording"), xe = () => p.dispatch("tick"), pe = ({ detail: q }) => p.dispatch("error", q), Te = () => p.dispatch("tick"), ot = ({ detail: q }) => p.dispatch("error", q), Ue = () => p.dispatch("clear_status", h);
  function qe(q) {
    o = q, t(0, o);
  }
  const fe = () => p.dispatch("tick"), tt = ({ detail: q }) => p.dispatch("error", q);
  function Qe(q) {
    o = q, t(0, o);
  }
  const He = () => p.dispatch("tick"), ve = ({ detail: q }) => p.dispatch("error", q), G = (...q) => p.client.stream(...q);
  function Ve(q) {
    o = q, t(0, o);
  }
  const K = () => p.dispatch("clear"), qt = () => p.dispatch("play"), Oe = () => p.dispatch("pause"), wn = () => p.dispatch("upload"), rn = () => p.dispatch("stop"), M0 = () => p.dispatch("end"), B0 = () => p.dispatch("start_recording"), Nt = () => p.dispatch("stop_recording"), Rt = () => p.dispatch("tick"), Hn = ({ detail: q }) => p.dispatch("error", q);
  function Ma(q) {
    o = q, t(0, o);
  }
  const Vn = () => p.dispatch("tick"), Ba = ({ detail: q }) => p.dispatch("error", q), zr = ({ detail: q }) => p.dispatch("warning", q);
  return r.$$set = (q) => {
    "video_chat" in q && t(1, n = q.video_chat), "elem_id" in q && t(2, a = q.elem_id), "elem_classes" in q && t(3, i = q.elem_classes), "visible" in q && t(4, l = q.visible), "value" in q && t(0, o = q.value), "button_labels" in q && t(5, s = q.button_labels), "label" in q && t(6, u = q.label), "root" in q && t(28, c = q.root), "show_label" in q && t(7, d = q.show_label), "loading_status" in q && t(8, h = q.loading_status), "height" in q && t(9, _ = q.height), "width" in q && t(10, g = q.width), "server" in q && t(11, b = q.server), "container" in q && t(12, y = q.container), "scale" in q && t(13, D = q.scale), "min_width" in q && t(14, k = q.min_width), "gradio" in q && t(15, p = q.gradio), "rtc_configuration" in q && t(16, S = q.rtc_configuration), "time_limit" in q && t(17, E = q.time_limit), "modality" in q && t(18, F = q.modality), "mode" in q && t(19, $ = q.mode), "rtp_params" in q && t(20, B = q.rtp_params), "track_constraints" in q && t(21, T = q.track_constraints), "icon" in q && t(22, x = q.icon), "icon_button_color" in q && t(23, L = q.icon_button_color), "pulse_color" in q && t(24, P = q.pulse_color), "icon_radius" in q && t(25, ae = q.icon_radius);
  }, [
    o,
    n,
    a,
    i,
    l,
    s,
    u,
    d,
    h,
    _,
    g,
    b,
    y,
    D,
    k,
    p,
    S,
    E,
    F,
    $,
    B,
    T,
    x,
    L,
    P,
    ae,
    R,
    ee,
    c,
    Z,
    ze,
    oe,
    ge,
    N,
    H,
    te,
    he,
    Ie,
    z,
    xe,
    pe,
    Te,
    ot,
    Ue,
    qe,
    fe,
    tt,
    Qe,
    He,
    ve,
    G,
    Ve,
    K,
    qt,
    Oe,
    wn,
    rn,
    M0,
    B0,
    Nt,
    Rt,
    Hn,
    Ma,
    Vn,
    Ba,
    zr
  ];
}
class eI extends Ey {
  constructor(e) {
    super(), Ty(
      this,
      e,
      Hy,
      Py,
      $y,
      {
        video_chat: 1,
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        button_labels: 5,
        label: 6,
        root: 28,
        show_label: 7,
        loading_status: 8,
        height: 9,
        width: 10,
        server: 11,
        container: 12,
        scale: 13,
        min_width: 14,
        gradio: 15,
        rtc_configuration: 16,
        time_limit: 17,
        modality: 18,
        mode: 19,
        rtp_params: 20,
        track_constraints: 21,
        icon: 22,
        icon_button_color: 23,
        pulse_color: 24,
        icon_radius: 25
      },
      null,
      [-1, -1, -1]
    );
  }
  get video_chat() {
    return this.$$.ctx[1];
  }
  set video_chat(e) {
    this.$$set({ video_chat: e }), Ye();
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), Ye();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), Ye();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), Ye();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), Ye();
  }
  get button_labels() {
    return this.$$.ctx[5];
  }
  set button_labels(e) {
    this.$$set({ button_labels: e }), Ye();
  }
  get label() {
    return this.$$.ctx[6];
  }
  set label(e) {
    this.$$set({ label: e }), Ye();
  }
  get root() {
    return this.$$.ctx[28];
  }
  set root(e) {
    this.$$set({ root: e }), Ye();
  }
  get show_label() {
    return this.$$.ctx[7];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), Ye();
  }
  get loading_status() {
    return this.$$.ctx[8];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), Ye();
  }
  get height() {
    return this.$$.ctx[9];
  }
  set height(e) {
    this.$$set({ height: e }), Ye();
  }
  get width() {
    return this.$$.ctx[10];
  }
  set width(e) {
    this.$$set({ width: e }), Ye();
  }
  get server() {
    return this.$$.ctx[11];
  }
  set server(e) {
    this.$$set({ server: e }), Ye();
  }
  get container() {
    return this.$$.ctx[12];
  }
  set container(e) {
    this.$$set({ container: e }), Ye();
  }
  get scale() {
    return this.$$.ctx[13];
  }
  set scale(e) {
    this.$$set({ scale: e }), Ye();
  }
  get min_width() {
    return this.$$.ctx[14];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), Ye();
  }
  get gradio() {
    return this.$$.ctx[15];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), Ye();
  }
  get rtc_configuration() {
    return this.$$.ctx[16];
  }
  set rtc_configuration(e) {
    this.$$set({ rtc_configuration: e }), Ye();
  }
  get time_limit() {
    return this.$$.ctx[17];
  }
  set time_limit(e) {
    this.$$set({ time_limit: e }), Ye();
  }
  get modality() {
    return this.$$.ctx[18];
  }
  set modality(e) {
    this.$$set({ modality: e }), Ye();
  }
  get mode() {
    return this.$$.ctx[19];
  }
  set mode(e) {
    this.$$set({ mode: e }), Ye();
  }
  get rtp_params() {
    return this.$$.ctx[20];
  }
  set rtp_params(e) {
    this.$$set({ rtp_params: e }), Ye();
  }
  get track_constraints() {
    return this.$$.ctx[21];
  }
  set track_constraints(e) {
    this.$$set({ track_constraints: e }), Ye();
  }
  get icon() {
    return this.$$.ctx[22];
  }
  set icon(e) {
    this.$$set({ icon: e }), Ye();
  }
  get icon_button_color() {
    return this.$$.ctx[23];
  }
  set icon_button_color(e) {
    this.$$set({ icon_button_color: e }), Ye();
  }
  get pulse_color() {
    return this.$$.ctx[24];
  }
  set pulse_color(e) {
    this.$$set({ pulse_color: e }), Ye();
  }
  get icon_radius() {
    return this.$$.ctx[25];
  }
  set icon_radius(e) {
    this.$$set({ icon_radius: e }), Ye();
  }
}
export {
  Pz as BaseExample,
  mp as BaseInteractiveVideo,
  eI as default,
  qz as loaded,
  Lz as playable,
  Iz as prettyBytes
};
