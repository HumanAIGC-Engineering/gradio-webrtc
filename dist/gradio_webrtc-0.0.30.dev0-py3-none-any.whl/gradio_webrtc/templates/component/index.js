var C4 = Object.defineProperty;
var as = (n) => {
  throw TypeError(n);
};
var T4 = (n, e, t) => e in n ? C4(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var u0 = (n, e, t) => T4(n, typeof e != "symbol" ? e + "" : e, t), Q4 = (n, e, t) => e.has(n) || as("Cannot " + t);
var is = (n, e, t) => e.has(n) ? as("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t);
var j1 = (n, e, t) => (Q4(n, e, "access private method"), t);
const {
  SvelteComponent: M4,
  assign: B4,
  children: z4,
  claim_element: L4,
  create_slot: I4,
  detach: ls,
  element: N4,
  get_all_dirty_from_scope: R4,
  get_slot_changes: O4,
  get_spread_update: q4,
  init: P4,
  insert_hydration: H4,
  safe_not_equal: V4,
  set_dynamic_element_data: ss,
  set_style: I0,
  toggle_class: _t,
  transition_in: Q6,
  transition_out: M6,
  update_slot_base: U4
} = window.__gradio__svelte__internal;
function j4(n) {
  let e, t, r;
  const a = (
    /*#slots*/
    n[22].default
  ), i = I4(
    a,
    n,
    /*$$scope*/
    n[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      n[10]
    ) },
    { id: (
      /*elem_id*/
      n[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      n[6].join(" ") + " svelte-1ezsyiy"
    }
  ], o = {};
  for (let s = 0; s < l.length; s += 1)
    o = B4(o, l[s]);
  return {
    c() {
      e = N4(
        /*tag*/
        n[18]
      ), i && i.c(), this.h();
    },
    l(s) {
      e = L4(
        s,
        /*tag*/
        (n[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var u = z4(e);
      i && i.l(u), u.forEach(ls), this.h();
    },
    h() {
      ss(
        /*tag*/
        n[18]
      )(e, o), _t(
        e,
        "hidden",
        /*visible*/
        n[13] === !1
      ), _t(
        e,
        "padded",
        /*padding*/
        n[9]
      ), _t(
        e,
        "flex",
        /*flex*/
        n[0]
      ), _t(
        e,
        "border_focus",
        /*border_mode*/
        n[8] === "focus"
      ), _t(
        e,
        "border_contrast",
        /*border_mode*/
        n[8] === "contrast"
      ), _t(e, "hide-container", !/*explicit_call*/
      n[11] && !/*container*/
      n[12]), I0(
        e,
        "height",
        /*get_dimension*/
        n[19](
          /*height*/
          n[1]
        )
      ), I0(
        e,
        "min-height",
        /*get_dimension*/
        n[19](
          /*min_height*/
          n[2]
        )
      ), I0(
        e,
        "max-height",
        /*get_dimension*/
        n[19](
          /*max_height*/
          n[3]
        )
      ), I0(e, "width", typeof /*width*/
      n[4] == "number" ? `calc(min(${/*width*/
      n[4]}px, 100%))` : (
        /*get_dimension*/
        n[19](
          /*width*/
          n[4]
        )
      )), I0(
        e,
        "border-style",
        /*variant*/
        n[7]
      ), I0(
        e,
        "overflow",
        /*allow_overflow*/
        n[14] ? (
          /*overflow_behavior*/
          n[15]
        ) : "hidden"
      ), I0(
        e,
        "flex-grow",
        /*scale*/
        n[16]
      ), I0(e, "min-width", `calc(min(${/*min_width*/
      n[17]}px, 100%))`), I0(e, "border-width", "var(--block-border-width)");
    },
    m(s, u) {
      H4(s, e, u), i && i.m(e, null), r = !0;
    },
    p(s, u) {
      i && i.p && (!r || u & /*$$scope*/
      2097152) && U4(
        i,
        a,
        s,
        /*$$scope*/
        s[21],
        r ? O4(
          a,
          /*$$scope*/
          s[21],
          u,
          null
        ) : R4(
          /*$$scope*/
          s[21]
        ),
        null
      ), ss(
        /*tag*/
        s[18]
      )(e, o = q4(l, [
        (!r || u & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          s[10]
        ) },
        (!r || u & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          s[5]
        ) },
        (!r || u & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        s[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), _t(
        e,
        "hidden",
        /*visible*/
        s[13] === !1
      ), _t(
        e,
        "padded",
        /*padding*/
        s[9]
      ), _t(
        e,
        "flex",
        /*flex*/
        s[0]
      ), _t(
        e,
        "border_focus",
        /*border_mode*/
        s[8] === "focus"
      ), _t(
        e,
        "border_contrast",
        /*border_mode*/
        s[8] === "contrast"
      ), _t(e, "hide-container", !/*explicit_call*/
      s[11] && !/*container*/
      s[12]), u & /*height*/
      2 && I0(
        e,
        "height",
        /*get_dimension*/
        s[19](
          /*height*/
          s[1]
        )
      ), u & /*min_height*/
      4 && I0(
        e,
        "min-height",
        /*get_dimension*/
        s[19](
          /*min_height*/
          s[2]
        )
      ), u & /*max_height*/
      8 && I0(
        e,
        "max-height",
        /*get_dimension*/
        s[19](
          /*max_height*/
          s[3]
        )
      ), u & /*width*/
      16 && I0(e, "width", typeof /*width*/
      s[4] == "number" ? `calc(min(${/*width*/
      s[4]}px, 100%))` : (
        /*get_dimension*/
        s[19](
          /*width*/
          s[4]
        )
      )), u & /*variant*/
      128 && I0(
        e,
        "border-style",
        /*variant*/
        s[7]
      ), u & /*allow_overflow, overflow_behavior*/
      49152 && I0(
        e,
        "overflow",
        /*allow_overflow*/
        s[14] ? (
          /*overflow_behavior*/
          s[15]
        ) : "hidden"
      ), u & /*scale*/
      65536 && I0(
        e,
        "flex-grow",
        /*scale*/
        s[16]
      ), u & /*min_width*/
      131072 && I0(e, "min-width", `calc(min(${/*min_width*/
      s[17]}px, 100%))`);
    },
    i(s) {
      r || (Q6(i, s), r = !0);
    },
    o(s) {
      M6(i, s), r = !1;
    },
    d(s) {
      s && ls(e), i && i.d(s);
    }
  };
}
function G4(n) {
  let e, t = (
    /*tag*/
    n[18] && j4(n)
  );
  return {
    c() {
      t && t.c();
    },
    l(r) {
      t && t.l(r);
    },
    m(r, a) {
      t && t.m(r, a), e = !0;
    },
    p(r, [a]) {
      /*tag*/
      r[18] && t.p(r, a);
    },
    i(r) {
      e || (Q6(t, r), e = !0);
    },
    o(r) {
      M6(t, r), e = !1;
    },
    d(r) {
      t && t.d(r);
    }
  };
}
function W4(n, e, t) {
  let { $$slots: r = {}, $$scope: a } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: f = "solid" } = e, { border_mode: d = "base" } = e, { padding: p = !0 } = e, { type: b = "normal" } = e, { test_id: E = void 0 } = e, { explicit_call: k = !1 } = e, { container: w = !0 } = e, { visible: v = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: A = "auto" } = e, { scale: x = null } = e, { min_width: Q = 0 } = e, { flex: z = !1 } = e;
  v || (z = !1);
  let P = b === "fieldset" ? "fieldset" : "div";
  const B = (N) => {
    if (N !== void 0) {
      if (typeof N == "number")
        return N + "px";
      if (typeof N == "string")
        return N;
    }
  };
  return n.$$set = (N) => {
    "height" in N && t(1, i = N.height), "min_height" in N && t(2, l = N.min_height), "max_height" in N && t(3, o = N.max_height), "width" in N && t(4, s = N.width), "elem_id" in N && t(5, u = N.elem_id), "elem_classes" in N && t(6, c = N.elem_classes), "variant" in N && t(7, f = N.variant), "border_mode" in N && t(8, d = N.border_mode), "padding" in N && t(9, p = N.padding), "type" in N && t(20, b = N.type), "test_id" in N && t(10, E = N.test_id), "explicit_call" in N && t(11, k = N.explicit_call), "container" in N && t(12, w = N.container), "visible" in N && t(13, v = N.visible), "allow_overflow" in N && t(14, _ = N.allow_overflow), "overflow_behavior" in N && t(15, A = N.overflow_behavior), "scale" in N && t(16, x = N.scale), "min_width" in N && t(17, Q = N.min_width), "flex" in N && t(0, z = N.flex), "$$scope" in N && t(21, a = N.$$scope);
  }, [
    z,
    i,
    l,
    o,
    s,
    u,
    c,
    f,
    d,
    p,
    E,
    k,
    w,
    v,
    _,
    A,
    x,
    Q,
    P,
    B,
    b,
    a,
    r
  ];
}
class B6 extends M4 {
  constructor(e) {
    super(), P4(this, e, W4, G4, V4, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
const Z4 = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], os = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Z4.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: os[e][t],
      secondary: os[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: Y4,
  append_hydration: X4,
  attr: Tt,
  children: us,
  claim_svg_element: cs,
  detach: _i,
  init: K4,
  insert_hydration: J4,
  noop: vi,
  safe_not_equal: $4,
  svg_element: hs
} = window.__gradio__svelte__internal;
function eu(n) {
  let e, t;
  return {
    c() {
      e = hs("svg"), t = hs("circle"), this.h();
    },
    l(r) {
      e = cs(r, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = us(e);
      t = cs(a, "circle", { cx: !0, cy: !0, r: !0 }), us(t).forEach(_i), a.forEach(_i), this.h();
    },
    h() {
      Tt(t, "cx", "12"), Tt(t, "cy", "12"), Tt(t, "r", "10"), Tt(e, "xmlns", "http://www.w3.org/2000/svg"), Tt(e, "width", "100%"), Tt(e, "height", "100%"), Tt(e, "viewBox", "0 0 24 24"), Tt(e, "stroke-width", "1.5"), Tt(e, "stroke-linecap", "round"), Tt(e, "stroke-linejoin", "round"), Tt(e, "class", "feather feather-circle");
    },
    m(r, a) {
      J4(r, e, a), X4(e, t);
    },
    p: vi,
    i: vi,
    o: vi,
    d(r) {
      r && _i(e);
    }
  };
}
class z6 extends Y4 {
  constructor(e) {
    super(), K4(this, e, null, eu, $4, {});
  }
}
const {
  SvelteComponent: tu,
  append_hydration: bi,
  attr: Qt,
  children: G1,
  claim_svg_element: W1,
  detach: jn,
  init: ru,
  insert_hydration: nu,
  noop: wi,
  safe_not_equal: au,
  set_style: $t,
  svg_element: Z1
} = window.__gradio__svelte__internal;
function iu(n) {
  let e, t, r, a;
  return {
    c() {
      e = Z1("svg"), t = Z1("g"), r = Z1("path"), a = Z1("path"), this.h();
    },
    l(i) {
      e = W1(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = G1(e);
      t = W1(l, "g", { transform: !0 });
      var o = G1(t);
      r = W1(o, "path", { d: !0, style: !0 }), G1(r).forEach(jn), o.forEach(jn), a = W1(l, "path", { d: !0, style: !0 }), G1(a).forEach(jn), l.forEach(jn), this.h();
    },
    h() {
      Qt(r, "d", "M18,6L6.087,17.913"), $t(r, "fill", "none"), $t(r, "fill-rule", "nonzero"), $t(r, "stroke-width", "2px"), Qt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Qt(a, "d", "M4.364,4.364L19.636,19.636"), $t(a, "fill", "none"), $t(a, "fill-rule", "nonzero"), $t(a, "stroke-width", "2px"), Qt(e, "width", "100%"), Qt(e, "height", "100%"), Qt(e, "viewBox", "0 0 24 24"), Qt(e, "version", "1.1"), Qt(e, "xmlns", "http://www.w3.org/2000/svg"), Qt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Qt(e, "xml:space", "preserve"), Qt(e, "stroke", "currentColor"), $t(e, "fill-rule", "evenodd"), $t(e, "clip-rule", "evenodd"), $t(e, "stroke-linecap", "round"), $t(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      nu(i, e, l), bi(e, t), bi(t, r), bi(e, a);
    },
    p: wi,
    i: wi,
    o: wi,
    d(i) {
      i && jn(e);
    }
  };
}
class lu extends tu {
  constructor(e) {
    super(), ru(this, e, null, iu, au, {});
  }
}
const {
  SvelteComponent: su,
  append_hydration: ou,
  attr: An,
  children: fs,
  claim_svg_element: ds,
  detach: yi,
  init: uu,
  insert_hydration: cu,
  noop: ki,
  safe_not_equal: hu,
  svg_element: ms
} = window.__gradio__svelte__internal;
function fu(n) {
  let e, t;
  return {
    c() {
      e = ms("svg"), t = ms("path"), this.h();
    },
    l(r) {
      e = ds(r, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var a = fs(e);
      t = ds(a, "path", { d: !0 }), fs(t).forEach(yi), a.forEach(yi), this.h();
    },
    h() {
      An(t, "d", "M5 8l4 4 4-4z"), An(e, "class", "dropdown-arrow svelte-145leq6"), An(e, "xmlns", "http://www.w3.org/2000/svg"), An(e, "width", "100%"), An(e, "height", "100%"), An(e, "viewBox", "0 0 18 18");
    },
    m(r, a) {
      cu(r, e, a), ou(e, t);
    },
    p: ki,
    i: ki,
    o: ki,
    d(r) {
      r && yi(e);
    }
  };
}
class x1 extends su {
  constructor(e) {
    super(), uu(this, e, null, fu, hu, {});
  }
}
const {
  SvelteComponent: du,
  append_hydration: mu,
  attr: Y1,
  children: ps,
  claim_svg_element: gs,
  detach: Di,
  init: pu,
  insert_hydration: gu,
  noop: Ei,
  safe_not_equal: _u,
  svg_element: _s
} = window.__gradio__svelte__internal;
function vu(n) {
  let e, t;
  return {
    c() {
      e = _s("svg"), t = _s("path"), this.h();
    },
    l(r) {
      e = gs(r, "svg", { xmlns: !0, viewBox: !0 });
      var a = ps(e);
      t = gs(a, "path", { fill: !0, d: !0 }), ps(t).forEach(Di), a.forEach(Di), this.h();
    },
    h() {
      Y1(t, "fill", "currentColor"), Y1(t, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a4 4 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2zm2.245 2.096L16 4.25q0-.078-.005-.154M13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5M15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3zm0 11a3 3 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A3 3 0 0 1 20 23zm5-7a1 1 0 1 1 0-2 1 1 0 0 1 0 2"), Y1(e, "xmlns", "http://www.w3.org/2000/svg"), Y1(e, "viewBox", "0 0 24 24");
    },
    m(r, a) {
      gu(r, e, a), mu(e, t);
    },
    p: Ei,
    i: Ei,
    o: Ei,
    d(r) {
      r && Di(e);
    }
  };
}
class bu extends du {
  constructor(e) {
    super(), pu(this, e, null, vu, _u, {});
  }
}
const {
  SvelteComponent: wu,
  append_hydration: X1,
  attr: k0,
  children: Gn,
  claim_svg_element: Wn,
  detach: Fn,
  init: yu,
  insert_hydration: ku,
  noop: Ai,
  safe_not_equal: Du,
  svg_element: Zn
} = window.__gradio__svelte__internal;
function Eu(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = Zn("svg"), t = Zn("path"), r = Zn("path"), a = Zn("line"), i = Zn("line"), this.h();
    },
    l(l) {
      e = Wn(l, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = Gn(e);
      t = Wn(o, "path", { d: !0 }), Gn(t).forEach(Fn), r = Wn(o, "path", { d: !0 }), Gn(r).forEach(Fn), a = Wn(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Gn(a).forEach(Fn), i = Wn(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Gn(i).forEach(Fn), o.forEach(Fn), this.h();
    },
    h() {
      k0(t, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), k0(r, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), k0(a, "x1", "12"), k0(a, "y1", "19"), k0(a, "x2", "12"), k0(a, "y2", "23"), k0(i, "x1", "8"), k0(i, "y1", "23"), k0(i, "x2", "16"), k0(i, "y2", "23"), k0(e, "xmlns", "http://www.w3.org/2000/svg"), k0(e, "width", "100%"), k0(e, "height", "100%"), k0(e, "viewBox", "0 0 24 24"), k0(e, "fill", "none"), k0(e, "stroke", "currentColor"), k0(e, "stroke-width", "2"), k0(e, "stroke-linecap", "round"), k0(e, "stroke-linejoin", "round"), k0(e, "class", "feather feather-mic");
    },
    m(l, o) {
      ku(l, e, o), X1(e, t), X1(e, r), X1(e, a), X1(e, i);
    },
    p: Ai,
    i: Ai,
    o: Ai,
    d(l) {
      l && Fn(e);
    }
  };
}
class Tl extends wu {
  constructor(e) {
    super(), yu(this, e, null, Eu, Du, {});
  }
}
const {
  SvelteComponent: Au,
  append_hydration: Fi,
  attr: N0,
  children: K1,
  claim_svg_element: J1,
  detach: Yn,
  init: Fu,
  insert_hydration: Su,
  noop: Si,
  safe_not_equal: xu,
  svg_element: $1
} = window.__gradio__svelte__internal;
function Cu(n) {
  let e, t, r, a;
  return {
    c() {
      e = $1("svg"), t = $1("path"), r = $1("circle"), a = $1("circle"), this.h();
    },
    l(i) {
      e = J1(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = K1(e);
      t = J1(l, "path", { d: !0 }), K1(t).forEach(Yn), r = J1(l, "circle", { cx: !0, cy: !0, r: !0 }), K1(r).forEach(Yn), a = J1(l, "circle", { cx: !0, cy: !0, r: !0 }), K1(a).forEach(Yn), l.forEach(Yn), this.h();
    },
    h() {
      N0(t, "d", "M9 18V5l12-2v13"), N0(r, "cx", "6"), N0(r, "cy", "18"), N0(r, "r", "3"), N0(a, "cx", "18"), N0(a, "cy", "16"), N0(a, "r", "3"), N0(e, "xmlns", "http://www.w3.org/2000/svg"), N0(e, "width", "100%"), N0(e, "height", "100%"), N0(e, "viewBox", "0 0 24 24"), N0(e, "fill", "none"), N0(e, "stroke", "currentColor"), N0(e, "stroke-width", "1.5"), N0(e, "stroke-linecap", "round"), N0(e, "stroke-linejoin", "round"), N0(e, "class", "feather feather-music");
    },
    m(i, l) {
      Su(i, e, l), Fi(e, t), Fi(e, r), Fi(e, a);
    },
    p: Si,
    i: Si,
    o: Si,
    d(i) {
      i && Yn(e);
    }
  };
}
class e5 extends Au {
  constructor(e) {
    super(), Fu(this, e, null, Cu, xu, {});
  }
}
const {
  SvelteComponent: Tu,
  append_hydration: Qu,
  attr: T0,
  children: vs,
  claim_svg_element: bs,
  detach: xi,
  init: Mu,
  insert_hydration: Bu,
  noop: ws,
  safe_not_equal: zu,
  svg_element: ys
} = window.__gradio__svelte__internal;
function Lu(n) {
  let e, t, r;
  return {
    c() {
      e = ys("svg"), t = ys("rect"), this.h();
    },
    l(a) {
      e = bs(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = vs(e);
      t = bs(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), vs(t).forEach(xi), i.forEach(xi), this.h();
    },
    h() {
      T0(t, "x", "3"), T0(t, "y", "3"), T0(t, "width", "18"), T0(t, "height", "18"), T0(t, "rx", "2"), T0(t, "ry", "2"), T0(e, "xmlns", "http://www.w3.org/2000/svg"), T0(e, "width", "100%"), T0(e, "height", "100%"), T0(e, "viewBox", "0 0 24 24"), T0(
        e,
        "fill",
        /*fill*/
        n[0]
      ), T0(e, "stroke", "currentColor"), T0(e, "stroke-width", r = `${/*stroke_width*/
      n[1]}`), T0(e, "stroke-linecap", "round"), T0(e, "stroke-linejoin", "round"), T0(e, "class", "feather feather-square");
    },
    m(a, i) {
      Bu(a, e, i), Qu(e, t);
    },
    p(a, [i]) {
      i & /*fill*/
      1 && T0(
        e,
        "fill",
        /*fill*/
        a[0]
      ), i & /*stroke_width*/
      2 && r !== (r = `${/*stroke_width*/
      a[1]}`) && T0(e, "stroke-width", r);
    },
    i: ws,
    o: ws,
    d(a) {
      a && xi(e);
    }
  };
}
function Iu(n, e, t) {
  let { fill: r = "currentColor" } = e, { stroke_width: a = 1.5 } = e;
  return n.$$set = (i) => {
    "fill" in i && t(0, r = i.fill), "stroke_width" in i && t(1, a = i.stroke_width);
  }, [r, a];
}
class L6 extends Tu {
  constructor(e) {
    super(), Mu(this, e, Iu, Lu, zu, { fill: 0, stroke_width: 1 });
  }
}
const {
  SvelteComponent: Nu,
  append_hydration: Ci,
  attr: G0,
  children: ea,
  claim_svg_element: ta,
  detach: Xn,
  init: Ru,
  insert_hydration: Ou,
  noop: Ti,
  safe_not_equal: qu,
  svg_element: ra
} = window.__gradio__svelte__internal;
function Pu(n) {
  let e, t, r, a;
  return {
    c() {
      e = ra("svg"), t = ra("path"), r = ra("polyline"), a = ra("line"), this.h();
    },
    l(i) {
      e = ta(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = ea(e);
      t = ta(l, "path", { d: !0 }), ea(t).forEach(Xn), r = ta(l, "polyline", { points: !0 }), ea(r).forEach(Xn), a = ta(l, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), ea(a).forEach(Xn), l.forEach(Xn), this.h();
    },
    h() {
      G0(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), G0(r, "points", "17 8 12 3 7 8"), G0(a, "x1", "12"), G0(a, "y1", "3"), G0(a, "x2", "12"), G0(a, "y2", "15"), G0(e, "xmlns", "http://www.w3.org/2000/svg"), G0(e, "width", "90%"), G0(e, "height", "90%"), G0(e, "viewBox", "0 0 24 24"), G0(e, "fill", "none"), G0(e, "stroke", "currentColor"), G0(e, "stroke-width", "2"), G0(e, "stroke-linecap", "round"), G0(e, "stroke-linejoin", "round"), G0(e, "class", "feather feather-upload");
    },
    m(i, l) {
      Ou(i, e, l), Ci(e, t), Ci(e, r), Ci(e, a);
    },
    p: Ti,
    i: Ti,
    o: Ti,
    d(i) {
      i && Xn(e);
    }
  };
}
class Hu extends Nu {
  constructor(e) {
    super(), Ru(this, e, null, Pu, qu, {});
  }
}
const {
  SvelteComponent: Vu,
  append_hydration: ks,
  attr: R0,
  children: Qi,
  claim_svg_element: Mi,
  detach: na,
  init: Uu,
  insert_hydration: ju,
  noop: Bi,
  safe_not_equal: Gu,
  svg_element: zi
} = window.__gradio__svelte__internal;
function Wu(n) {
  let e, t, r;
  return {
    c() {
      e = zi("svg"), t = zi("polygon"), r = zi("rect"), this.h();
    },
    l(a) {
      e = Mi(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = Qi(e);
      t = Mi(i, "polygon", { points: !0 }), Qi(t).forEach(na), r = Mi(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), Qi(r).forEach(na), i.forEach(na), this.h();
    },
    h() {
      R0(t, "points", "23 7 16 12 23 17 23 7"), R0(r, "x", "1"), R0(r, "y", "5"), R0(r, "width", "15"), R0(r, "height", "14"), R0(r, "rx", "2"), R0(r, "ry", "2"), R0(e, "xmlns", "http://www.w3.org/2000/svg"), R0(e, "width", "100%"), R0(e, "height", "100%"), R0(e, "viewBox", "0 0 24 24"), R0(e, "fill", "none"), R0(e, "stroke", "currentColor"), R0(e, "stroke-width", "1.5"), R0(e, "stroke-linecap", "round"), R0(e, "stroke-linejoin", "round"), R0(e, "class", "feather feather-video");
    },
    m(a, i) {
      ju(a, e, i), ks(e, t), ks(e, r);
    },
    p: Bi,
    i: Bi,
    o: Bi,
    d(a) {
      a && na(e);
    }
  };
}
class t5 extends Vu {
  constructor(e) {
    super(), Uu(this, e, null, Wu, Gu, {});
  }
}
const {
  SvelteComponent: Zu,
  append_hydration: Kn,
  attr: Q0,
  children: Jn,
  claim_svg_element: $n,
  claim_text: Yu,
  detach: Sn,
  init: Xu,
  insert_hydration: Ku,
  noop: Li,
  safe_not_equal: Ju,
  svg_element: e1,
  text: $u
} = window.__gradio__svelte__internal;
function e7(n) {
  let e, t, r, a, i, l;
  return {
    c() {
      e = e1("svg"), t = e1("title"), r = $u("High volume"), a = e1("path"), i = e1("path"), l = e1("path"), this.h();
    },
    l(o) {
      e = $n(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        stroke: !0,
        xmlns: !0,
        color: !0
      });
      var s = Jn(e);
      t = $n(s, "title", {});
      var u = Jn(t);
      r = Yu(u, "High volume"), u.forEach(Sn), a = $n(s, "path", { d: !0, "stroke-width": !0 }), Jn(a).forEach(Sn), i = $n(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Jn(i).forEach(Sn), l = $n(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Jn(l).forEach(Sn), s.forEach(Sn), this.h();
    },
    h() {
      Q0(a, "d", "M1 13.8571V10.1429C1 9.03829 1.89543 8.14286 3 8.14286H5.9C6.09569 8.14286 6.28708 8.08544 6.45046 7.97772L12.4495 4.02228C13.1144 3.5839 14 4.06075 14 4.85714V19.1429C14 19.9392 13.1144 20.4161 12.4495 19.9777L6.45046 16.0223C6.28708 15.9146 6.09569 15.8571 5.9 15.8571H3C1.89543 15.8571 1 14.9617 1 13.8571Z"), Q0(a, "stroke-width", "1.5"), Q0(i, "d", "M17.5 7.5C17.5 7.5 19 9 19 11.5C19 14 17.5 15.5 17.5 15.5"), Q0(i, "stroke-width", "1.5"), Q0(i, "stroke-linecap", "round"), Q0(i, "stroke-linejoin", "round"), Q0(l, "d", "M20.5 4.5C20.5 4.5 23 7 23 11.5C23 16 20.5 18.5 20.5 18.5"), Q0(l, "stroke-width", "1.5"), Q0(l, "stroke-linecap", "round"), Q0(l, "stroke-linejoin", "round"), Q0(e, "width", "100%"), Q0(e, "height", "100%"), Q0(e, "viewBox", "0 0 24 24"), Q0(e, "stroke-width", "1.5"), Q0(e, "fill", "none"), Q0(e, "stroke", "currentColor"), Q0(e, "xmlns", "http://www.w3.org/2000/svg"), Q0(e, "color", "currentColor");
    },
    m(o, s) {
      Ku(o, e, s), Kn(e, t), Kn(t, r), Kn(e, a), Kn(e, i), Kn(e, l);
    },
    p: Li,
    i: Li,
    o: Li,
    d(o) {
      o && Sn(e);
    }
  };
}
class t7 extends Zu {
  constructor(e) {
    super(), Xu(this, e, null, e7, Ju, {});
  }
}
const {
  SvelteComponent: r7,
  append_hydration: zr,
  attr: F0,
  children: Lr,
  claim_svg_element: Ir,
  claim_text: n7,
  detach: mr,
  init: a7,
  insert_hydration: i7,
  noop: Ii,
  safe_not_equal: l7,
  svg_element: Nr,
  text: s7
} = window.__gradio__svelte__internal;
function o7(n) {
  let e, t, r, a, i, l, o, s, u;
  return {
    c() {
      e = Nr("svg"), t = Nr("title"), r = s7("Muted volume"), a = Nr("g"), i = Nr("path"), l = Nr("path"), o = Nr("defs"), s = Nr("clipPath"), u = Nr("rect"), this.h();
    },
    l(c) {
      e = Ir(c, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        xmlns: !0,
        stroke: !0,
        color: !0
      });
      var f = Lr(e);
      t = Ir(f, "title", {});
      var d = Lr(t);
      r = n7(d, "Muted volume"), d.forEach(mr), a = Ir(f, "g", { "clip-path": !0 });
      var p = Lr(a);
      i = Ir(p, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Lr(i).forEach(mr), l = Ir(p, "path", { d: !0, "stroke-width": !0 }), Lr(l).forEach(mr), p.forEach(mr), o = Ir(f, "defs", {});
      var b = Lr(o);
      s = Ir(b, "clipPath", { id: !0 });
      var E = Lr(s);
      u = Ir(E, "rect", { width: !0, height: !0, fill: !0 }), Lr(u).forEach(mr), E.forEach(mr), b.forEach(mr), f.forEach(mr), this.h();
    },
    h() {
      F0(i, "d", "M18 14L20.0005 12M22 10L20.0005 12M20.0005 12L18 10M20.0005 12L22 14"), F0(i, "stroke-width", "1.5"), F0(i, "stroke-linecap", "round"), F0(i, "stroke-linejoin", "round"), F0(l, "d", "M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z"), F0(l, "stroke-width", "1.5"), F0(a, "clip-path", "url(#clip0_3173_16686)"), F0(u, "width", "24"), F0(u, "height", "24"), F0(u, "fill", "white"), F0(s, "id", "clip0_3173_16686"), F0(e, "width", "100%"), F0(e, "height", "100%"), F0(e, "viewBox", "0 0 24 24"), F0(e, "stroke-width", "1.5"), F0(e, "fill", "none"), F0(e, "xmlns", "http://www.w3.org/2000/svg"), F0(e, "stroke", "currentColor"), F0(e, "color", "currentColor");
    },
    m(c, f) {
      i7(c, e, f), zr(e, t), zr(t, r), zr(e, a), zr(a, i), zr(a, l), zr(e, o), zr(o, s), zr(s, u);
    },
    p: Ii,
    i: Ii,
    o: Ii,
    d(c) {
      c && mr(e);
    }
  };
}
class u7 extends r7 {
  constructor(e) {
    super(), a7(this, e, null, o7, l7, {});
  }
}
const {
  SvelteComponent: c7,
  append_hydration: Ds,
  attr: Rr,
  children: Ni,
  claim_svg_element: Ri,
  detach: aa,
  init: h7,
  insert_hydration: f7,
  noop: Oi,
  safe_not_equal: d7,
  svg_element: qi
} = window.__gradio__svelte__internal;
function m7(n) {
  let e, t, r;
  return {
    c() {
      e = qi("svg"), t = qi("path"), r = qi("path"), this.h();
    },
    l(a) {
      e = Ri(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = Ni(e);
      t = Ri(i, "path", { fill: !0, d: !0 }), Ni(t).forEach(aa), r = Ri(i, "path", { fill: !0, d: !0 }), Ni(r).forEach(aa), i.forEach(aa), this.h();
    },
    h() {
      Rr(t, "fill", "currentColor"), Rr(t, "d", "M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"), Rr(r, "fill", "currentColor"), Rr(r, "d", "M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"), Rr(e, "xmlns", "http://www.w3.org/2000/svg"), Rr(e, "width", "100%"), Rr(e, "height", "100%"), Rr(e, "viewBox", "0 0 24 24");
    },
    m(a, i) {
      f7(a, e, i), Ds(e, t), Ds(e, r);
    },
    p: Oi,
    i: Oi,
    o: Oi,
    d(a) {
      a && aa(e);
    }
  };
}
let Es = class extends c7 {
  constructor(e) {
    super(), h7(this, e, null, m7, d7, {});
  }
};
const {
  SvelteComponent: p7,
  append_hydration: As,
  attr: M0,
  children: Pi,
  claim_svg_element: Hi,
  detach: ia,
  init: g7,
  insert_hydration: _7,
  noop: Vi,
  safe_not_equal: v7,
  svg_element: Ui
} = window.__gradio__svelte__internal;
function b7(n) {
  let e, t, r;
  return {
    c() {
      e = Ui("svg"), t = Ui("circle"), r = Ui("animateTransform"), this.h();
    },
    l(a) {
      e = Hi(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        class: !0
      });
      var i = Pi(e);
      t = Hi(i, "circle", {
        cx: !0,
        cy: !0,
        r: !0,
        fill: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-dasharray": !0,
        "stroke-dashoffset": !0
      });
      var l = Pi(t);
      r = Hi(l, "animateTransform", {
        attributeName: !0,
        type: !0,
        from: !0,
        to: !0,
        repeatCount: !0
      }), Pi(r).forEach(ia), l.forEach(ia), i.forEach(ia), this.h();
    },
    h() {
      M0(r, "attributeName", "transform"), M0(r, "type", "rotate"), M0(r, "from", "0 25 25"), M0(r, "to", "360 25 25"), M0(r, "repeatCount", "indefinite"), M0(t, "cx", "25"), M0(t, "cy", "25"), M0(t, "r", "20"), M0(t, "fill", "none"), M0(t, "stroke-width", "3.0"), M0(t, "stroke-linecap", "round"), M0(t, "stroke-dasharray", "94.2477796076938 94.2477796076938"), M0(t, "stroke-dashoffset", "0"), M0(e, "xmlns", "http://www.w3.org/2000/svg"), M0(e, "width", "100%"), M0(e, "height", "100%"), M0(e, "viewBox", "0 0 50 50"), M0(e, "class", "svelte-pb9pol");
    },
    m(a, i) {
      _7(a, e, i), As(e, t), As(t, r);
    },
    p: Vi,
    i: Vi,
    o: Vi,
    d(a) {
      a && ia(e);
    }
  };
}
class r5 extends p7 {
  constructor(e) {
    super(), g7(this, e, null, b7, v7, {});
  }
}
class n5 {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, r) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = r;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new n5(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class a5 {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new a5(t, n5.range(this, e));
  }
}
class ge {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var r = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var o = l.lexer.input;
      a = l.start, i = l.end, a === o.length ? r += " at end of input: " : r += " at position " + (a + 1) + ": ";
      var s = o.slice(a, i).replace(/[^]/g, "$&̲"), u;
      a > 15 ? u = "…" + o.slice(a - 15, a) : u = o.slice(0, a);
      var c;
      i + 15 < o.length ? c = o.slice(i, i + 15) + "…" : c = o.slice(i), r += u + s + c;
    }
    var f = new Error(r);
    return f.name = "ParseError", f.__proto__ = ge.prototype, f.position = a, a != null && i != null && (f.length = i - a), f.rawMessage = e, f;
  }
}
ge.prototype.__proto__ = Error.prototype;
var w7 = function(e, t) {
  return e.indexOf(t) !== -1;
}, y7 = function(e, t) {
  return e === void 0 ? t : e;
}, k7 = /([A-Z])/g, D7 = function(e) {
  return e.replace(k7, "-$1").toLowerCase();
}, E7 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, A7 = /[&><"']/g;
function F7(n) {
  return String(n).replace(A7, (e) => E7[e]);
}
var I6 = function n(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? n(e.body[0]) : e : e.type === "font" ? n(e.body) : e;
}, S7 = function(e) {
  var t = I6(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, x7 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, C7 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, we = {
  contains: w7,
  deflt: y7,
  escape: F7,
  hyphenate: D7,
  getBaseElem: I6,
  isCharacterBox: S7,
  protocolFromUrl: C7
};
class Or {
  constructor(e, t, r) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = r;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return rr[T7[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return rr[Q7[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return rr[M7[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return rr[B7[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return rr[z7[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return rr[L7[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var i5 = 0, Ba = 1, Ln = 2, wr = 3, w1 = 4, kt = 5, Nn = 6, et = 7, rr = [new Or(i5, 0, !1), new Or(Ba, 0, !0), new Or(Ln, 1, !1), new Or(wr, 1, !0), new Or(w1, 2, !1), new Or(kt, 2, !0), new Or(Nn, 3, !1), new Or(et, 3, !0)], T7 = [w1, kt, w1, kt, Nn, et, Nn, et], Q7 = [kt, kt, kt, kt, et, et, et, et], M7 = [Ln, wr, w1, kt, Nn, et, Nn, et], B7 = [wr, wr, kt, kt, et, et, et, et], z7 = [Ba, Ba, wr, wr, kt, kt, et, et], L7 = [i5, Ba, Ln, wr, Ln, wr, Ln, wr], ye = {
  DISPLAY: rr[i5],
  TEXT: rr[Ln],
  SCRIPT: rr[w1],
  SCRIPTSCRIPT: rr[Nn]
}, Ql = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function I7(n) {
  for (var e = 0; e < Ql.length; e++)
    for (var t = Ql[e], r = 0; r < t.blocks.length; r++) {
      var a = t.blocks[r];
      if (n >= a[0] && n <= a[1])
        return t.name;
    }
  return null;
}
var Fa = [];
Ql.forEach((n) => n.blocks.forEach((e) => Fa.push(...e)));
function N7(n) {
  for (var e = 0; e < Fa.length; e += 2)
    if (n >= Fa[e] && n <= Fa[e + 1])
      return !0;
  return !1;
}
var xn = 80, R7 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, O7 = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, q7 = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, P7 = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, H7 = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, V7 = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, U7 = function(e, t, r) {
  var a = r - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, j7 = function(e, t, r) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = R7(t, xn);
      break;
    case "sqrtSize1":
      a = O7(t, xn);
      break;
    case "sqrtSize2":
      a = q7(t, xn);
      break;
    case "sqrtSize3":
      a = P7(t, xn);
      break;
    case "sqrtSize4":
      a = H7(t, xn);
      break;
    case "sqrtTall":
      a = U7(t, xn, r);
  }
  return a;
}, G7 = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, Fs = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, W7 = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class C1 {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return we.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var vr = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, Ss = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function l5(n, e, t) {
  if (!vr[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var r = n.charCodeAt(0), a = vr[e][r];
  if (!a && n[0] in Ss && (r = Ss[n[0]].charCodeAt(0), a = vr[e][r]), !a && t === "text" && N7(r) && (a = vr[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var Ml = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, Z7 = {
  ex: !0,
  em: !0,
  mu: !0
}, Y7 = function(e) {
  return typeof e != "string" && (e = e.unit), e in Ml || e in Z7 || e === "ex";
}, m0 = function(e, t) {
  var r;
  if (e.unit in Ml)
    r = Ml[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    r = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      r = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      r = a.fontMetrics().quad;
    else
      throw new ge("Invalid unit: '" + e.unit + "'");
    a !== t && (r *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * r, t.maxSize);
}, te = function(e) {
  return +e.toFixed(4) + "em";
}, Zr = function(e) {
  return e.filter((t) => t).join(" ");
}, N6 = function(e, t, r) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, R6 = function(e) {
  var t = document.createElement(e);
  t.className = Zr(this.classes);
  for (var r in this.style)
    this.style.hasOwnProperty(r) && (t.style[r] = this.style[r]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, O6 = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + we.escape(Zr(this.classes)) + '"');
  var r = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (r += we.hyphenate(a) + ":" + this.style[a] + ";");
  r && (t += ' style="' + we.escape(r) + '"');
  for (var i in this.attributes)
    this.attributes.hasOwnProperty(i) && (t += " " + i + '="' + we.escape(this.attributes[i]) + '"');
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class ti {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, N6.call(this, e, r, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return we.contains(this.classes, e);
  }
  toNode() {
    return R6.call(this, "span");
  }
  toMarkup() {
    return O6.call(this, "span");
  }
}
class q6 {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, N6.call(this, t, a), this.children = r || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return we.contains(this.classes, e);
  }
  toNode() {
    return R6.call(this, "a");
  }
  toMarkup() {
    return O6.call(this, "a");
  }
}
class X7 {
  constructor(e, t, r) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = r;
  }
  hasClass(e) {
    return we.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + we.escape(this.src) + '"' + (' alt="' + we.escape(this.alt) + '"'), t = "";
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t += we.hyphenate(r) + ":" + this.style[r] + ";");
    return t && (e += ' style="' + we.escape(t) + '"'), e += "'/>", e;
  }
}
var K7 = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class ur {
  constructor(e, t, r, a, i, l, o, s) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = r || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
    var u = I7(this.text.charCodeAt(0));
    u && this.classes.push(u + "_fallback"), /[îïíì]/.test(this.text) && (this.text = K7[this.text]);
  }
  hasClass(e) {
    return we.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = te(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = Zr(this.classes));
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t = t || document.createElement("span"), t.style[r] = this.style[r]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += we.escape(Zr(this.classes)), t += '"');
    var r = "";
    this.italic > 0 && (r += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (r += we.hyphenate(a) + ":" + this.style[a] + ";");
    r && (e = !0, t += ' style="' + we.escape(r) + '"');
    var i = we.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class Yr {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + we.escape(this.attributes[t]) + '"');
    e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</svg>", e;
  }
}
class cn {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", Fs[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + we.escape(this.alternate) + '"/>' : '<path d="' + we.escape(Fs[this.pathName]) + '"/>';
  }
}
class xs {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + we.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function Cs(n) {
  if (n instanceof ur)
    return n;
  throw new Error("Expected symbolNode but got " + String(n) + ".");
}
function J7(n) {
  if (n instanceof ti)
    return n;
  throw new Error("Expected span<HtmlDomNode> but got " + String(n) + ".");
}
var $7 = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, y0 = {
  math: {},
  text: {}
};
function h(n, e, t, r, a, i) {
  y0[n][a] = {
    font: e,
    group: t,
    replace: r
  }, i && r && (y0[n][r] = y0[n][a]);
}
var m = "math", G = "text", g = "main", F = "ams", f0 = "accent-token", ae = "bin", rt = "close", Pn = "inner", be = "mathord", E0 = "op-token", pt = "open", ri = "punct", S = "rel", xr = "spacing", T = "textord";
h(m, g, S, "≡", "\\equiv", !0);
h(m, g, S, "≺", "\\prec", !0);
h(m, g, S, "≻", "\\succ", !0);
h(m, g, S, "∼", "\\sim", !0);
h(m, g, S, "⊥", "\\perp");
h(m, g, S, "⪯", "\\preceq", !0);
h(m, g, S, "⪰", "\\succeq", !0);
h(m, g, S, "≃", "\\simeq", !0);
h(m, g, S, "∣", "\\mid", !0);
h(m, g, S, "≪", "\\ll", !0);
h(m, g, S, "≫", "\\gg", !0);
h(m, g, S, "≍", "\\asymp", !0);
h(m, g, S, "∥", "\\parallel");
h(m, g, S, "⋈", "\\bowtie", !0);
h(m, g, S, "⌣", "\\smile", !0);
h(m, g, S, "⊑", "\\sqsubseteq", !0);
h(m, g, S, "⊒", "\\sqsupseteq", !0);
h(m, g, S, "≐", "\\doteq", !0);
h(m, g, S, "⌢", "\\frown", !0);
h(m, g, S, "∋", "\\ni", !0);
h(m, g, S, "∝", "\\propto", !0);
h(m, g, S, "⊢", "\\vdash", !0);
h(m, g, S, "⊣", "\\dashv", !0);
h(m, g, S, "∋", "\\owns");
h(m, g, ri, ".", "\\ldotp");
h(m, g, ri, "⋅", "\\cdotp");
h(m, g, T, "#", "\\#");
h(G, g, T, "#", "\\#");
h(m, g, T, "&", "\\&");
h(G, g, T, "&", "\\&");
h(m, g, T, "ℵ", "\\aleph", !0);
h(m, g, T, "∀", "\\forall", !0);
h(m, g, T, "ℏ", "\\hbar", !0);
h(m, g, T, "∃", "\\exists", !0);
h(m, g, T, "∇", "\\nabla", !0);
h(m, g, T, "♭", "\\flat", !0);
h(m, g, T, "ℓ", "\\ell", !0);
h(m, g, T, "♮", "\\natural", !0);
h(m, g, T, "♣", "\\clubsuit", !0);
h(m, g, T, "℘", "\\wp", !0);
h(m, g, T, "♯", "\\sharp", !0);
h(m, g, T, "♢", "\\diamondsuit", !0);
h(m, g, T, "ℜ", "\\Re", !0);
h(m, g, T, "♡", "\\heartsuit", !0);
h(m, g, T, "ℑ", "\\Im", !0);
h(m, g, T, "♠", "\\spadesuit", !0);
h(m, g, T, "§", "\\S", !0);
h(G, g, T, "§", "\\S");
h(m, g, T, "¶", "\\P", !0);
h(G, g, T, "¶", "\\P");
h(m, g, T, "†", "\\dag");
h(G, g, T, "†", "\\dag");
h(G, g, T, "†", "\\textdagger");
h(m, g, T, "‡", "\\ddag");
h(G, g, T, "‡", "\\ddag");
h(G, g, T, "‡", "\\textdaggerdbl");
h(m, g, rt, "⎱", "\\rmoustache", !0);
h(m, g, pt, "⎰", "\\lmoustache", !0);
h(m, g, rt, "⟯", "\\rgroup", !0);
h(m, g, pt, "⟮", "\\lgroup", !0);
h(m, g, ae, "∓", "\\mp", !0);
h(m, g, ae, "⊖", "\\ominus", !0);
h(m, g, ae, "⊎", "\\uplus", !0);
h(m, g, ae, "⊓", "\\sqcap", !0);
h(m, g, ae, "∗", "\\ast");
h(m, g, ae, "⊔", "\\sqcup", !0);
h(m, g, ae, "◯", "\\bigcirc", !0);
h(m, g, ae, "∙", "\\bullet", !0);
h(m, g, ae, "‡", "\\ddagger");
h(m, g, ae, "≀", "\\wr", !0);
h(m, g, ae, "⨿", "\\amalg");
h(m, g, ae, "&", "\\And");
h(m, g, S, "⟵", "\\longleftarrow", !0);
h(m, g, S, "⇐", "\\Leftarrow", !0);
h(m, g, S, "⟸", "\\Longleftarrow", !0);
h(m, g, S, "⟶", "\\longrightarrow", !0);
h(m, g, S, "⇒", "\\Rightarrow", !0);
h(m, g, S, "⟹", "\\Longrightarrow", !0);
h(m, g, S, "↔", "\\leftrightarrow", !0);
h(m, g, S, "⟷", "\\longleftrightarrow", !0);
h(m, g, S, "⇔", "\\Leftrightarrow", !0);
h(m, g, S, "⟺", "\\Longleftrightarrow", !0);
h(m, g, S, "↦", "\\mapsto", !0);
h(m, g, S, "⟼", "\\longmapsto", !0);
h(m, g, S, "↗", "\\nearrow", !0);
h(m, g, S, "↩", "\\hookleftarrow", !0);
h(m, g, S, "↪", "\\hookrightarrow", !0);
h(m, g, S, "↘", "\\searrow", !0);
h(m, g, S, "↼", "\\leftharpoonup", !0);
h(m, g, S, "⇀", "\\rightharpoonup", !0);
h(m, g, S, "↙", "\\swarrow", !0);
h(m, g, S, "↽", "\\leftharpoondown", !0);
h(m, g, S, "⇁", "\\rightharpoondown", !0);
h(m, g, S, "↖", "\\nwarrow", !0);
h(m, g, S, "⇌", "\\rightleftharpoons", !0);
h(m, F, S, "≮", "\\nless", !0);
h(m, F, S, "", "\\@nleqslant");
h(m, F, S, "", "\\@nleqq");
h(m, F, S, "⪇", "\\lneq", !0);
h(m, F, S, "≨", "\\lneqq", !0);
h(m, F, S, "", "\\@lvertneqq");
h(m, F, S, "⋦", "\\lnsim", !0);
h(m, F, S, "⪉", "\\lnapprox", !0);
h(m, F, S, "⊀", "\\nprec", !0);
h(m, F, S, "⋠", "\\npreceq", !0);
h(m, F, S, "⋨", "\\precnsim", !0);
h(m, F, S, "⪹", "\\precnapprox", !0);
h(m, F, S, "≁", "\\nsim", !0);
h(m, F, S, "", "\\@nshortmid");
h(m, F, S, "∤", "\\nmid", !0);
h(m, F, S, "⊬", "\\nvdash", !0);
h(m, F, S, "⊭", "\\nvDash", !0);
h(m, F, S, "⋪", "\\ntriangleleft");
h(m, F, S, "⋬", "\\ntrianglelefteq", !0);
h(m, F, S, "⊊", "\\subsetneq", !0);
h(m, F, S, "", "\\@varsubsetneq");
h(m, F, S, "⫋", "\\subsetneqq", !0);
h(m, F, S, "", "\\@varsubsetneqq");
h(m, F, S, "≯", "\\ngtr", !0);
h(m, F, S, "", "\\@ngeqslant");
h(m, F, S, "", "\\@ngeqq");
h(m, F, S, "⪈", "\\gneq", !0);
h(m, F, S, "≩", "\\gneqq", !0);
h(m, F, S, "", "\\@gvertneqq");
h(m, F, S, "⋧", "\\gnsim", !0);
h(m, F, S, "⪊", "\\gnapprox", !0);
h(m, F, S, "⊁", "\\nsucc", !0);
h(m, F, S, "⋡", "\\nsucceq", !0);
h(m, F, S, "⋩", "\\succnsim", !0);
h(m, F, S, "⪺", "\\succnapprox", !0);
h(m, F, S, "≆", "\\ncong", !0);
h(m, F, S, "", "\\@nshortparallel");
h(m, F, S, "∦", "\\nparallel", !0);
h(m, F, S, "⊯", "\\nVDash", !0);
h(m, F, S, "⋫", "\\ntriangleright");
h(m, F, S, "⋭", "\\ntrianglerighteq", !0);
h(m, F, S, "", "\\@nsupseteqq");
h(m, F, S, "⊋", "\\supsetneq", !0);
h(m, F, S, "", "\\@varsupsetneq");
h(m, F, S, "⫌", "\\supsetneqq", !0);
h(m, F, S, "", "\\@varsupsetneqq");
h(m, F, S, "⊮", "\\nVdash", !0);
h(m, F, S, "⪵", "\\precneqq", !0);
h(m, F, S, "⪶", "\\succneqq", !0);
h(m, F, S, "", "\\@nsubseteqq");
h(m, F, ae, "⊴", "\\unlhd");
h(m, F, ae, "⊵", "\\unrhd");
h(m, F, S, "↚", "\\nleftarrow", !0);
h(m, F, S, "↛", "\\nrightarrow", !0);
h(m, F, S, "⇍", "\\nLeftarrow", !0);
h(m, F, S, "⇏", "\\nRightarrow", !0);
h(m, F, S, "↮", "\\nleftrightarrow", !0);
h(m, F, S, "⇎", "\\nLeftrightarrow", !0);
h(m, F, S, "△", "\\vartriangle");
h(m, F, T, "ℏ", "\\hslash");
h(m, F, T, "▽", "\\triangledown");
h(m, F, T, "◊", "\\lozenge");
h(m, F, T, "Ⓢ", "\\circledS");
h(m, F, T, "®", "\\circledR");
h(G, F, T, "®", "\\circledR");
h(m, F, T, "∡", "\\measuredangle", !0);
h(m, F, T, "∄", "\\nexists");
h(m, F, T, "℧", "\\mho");
h(m, F, T, "Ⅎ", "\\Finv", !0);
h(m, F, T, "⅁", "\\Game", !0);
h(m, F, T, "‵", "\\backprime");
h(m, F, T, "▲", "\\blacktriangle");
h(m, F, T, "▼", "\\blacktriangledown");
h(m, F, T, "■", "\\blacksquare");
h(m, F, T, "⧫", "\\blacklozenge");
h(m, F, T, "★", "\\bigstar");
h(m, F, T, "∢", "\\sphericalangle", !0);
h(m, F, T, "∁", "\\complement", !0);
h(m, F, T, "ð", "\\eth", !0);
h(G, g, T, "ð", "ð");
h(m, F, T, "╱", "\\diagup");
h(m, F, T, "╲", "\\diagdown");
h(m, F, T, "□", "\\square");
h(m, F, T, "□", "\\Box");
h(m, F, T, "◊", "\\Diamond");
h(m, F, T, "¥", "\\yen", !0);
h(G, F, T, "¥", "\\yen", !0);
h(m, F, T, "✓", "\\checkmark", !0);
h(G, F, T, "✓", "\\checkmark");
h(m, F, T, "ℶ", "\\beth", !0);
h(m, F, T, "ℸ", "\\daleth", !0);
h(m, F, T, "ℷ", "\\gimel", !0);
h(m, F, T, "ϝ", "\\digamma", !0);
h(m, F, T, "ϰ", "\\varkappa");
h(m, F, pt, "┌", "\\@ulcorner", !0);
h(m, F, rt, "┐", "\\@urcorner", !0);
h(m, F, pt, "└", "\\@llcorner", !0);
h(m, F, rt, "┘", "\\@lrcorner", !0);
h(m, F, S, "≦", "\\leqq", !0);
h(m, F, S, "⩽", "\\leqslant", !0);
h(m, F, S, "⪕", "\\eqslantless", !0);
h(m, F, S, "≲", "\\lesssim", !0);
h(m, F, S, "⪅", "\\lessapprox", !0);
h(m, F, S, "≊", "\\approxeq", !0);
h(m, F, ae, "⋖", "\\lessdot");
h(m, F, S, "⋘", "\\lll", !0);
h(m, F, S, "≶", "\\lessgtr", !0);
h(m, F, S, "⋚", "\\lesseqgtr", !0);
h(m, F, S, "⪋", "\\lesseqqgtr", !0);
h(m, F, S, "≑", "\\doteqdot");
h(m, F, S, "≓", "\\risingdotseq", !0);
h(m, F, S, "≒", "\\fallingdotseq", !0);
h(m, F, S, "∽", "\\backsim", !0);
h(m, F, S, "⋍", "\\backsimeq", !0);
h(m, F, S, "⫅", "\\subseteqq", !0);
h(m, F, S, "⋐", "\\Subset", !0);
h(m, F, S, "⊏", "\\sqsubset", !0);
h(m, F, S, "≼", "\\preccurlyeq", !0);
h(m, F, S, "⋞", "\\curlyeqprec", !0);
h(m, F, S, "≾", "\\precsim", !0);
h(m, F, S, "⪷", "\\precapprox", !0);
h(m, F, S, "⊲", "\\vartriangleleft");
h(m, F, S, "⊴", "\\trianglelefteq");
h(m, F, S, "⊨", "\\vDash", !0);
h(m, F, S, "⊪", "\\Vvdash", !0);
h(m, F, S, "⌣", "\\smallsmile");
h(m, F, S, "⌢", "\\smallfrown");
h(m, F, S, "≏", "\\bumpeq", !0);
h(m, F, S, "≎", "\\Bumpeq", !0);
h(m, F, S, "≧", "\\geqq", !0);
h(m, F, S, "⩾", "\\geqslant", !0);
h(m, F, S, "⪖", "\\eqslantgtr", !0);
h(m, F, S, "≳", "\\gtrsim", !0);
h(m, F, S, "⪆", "\\gtrapprox", !0);
h(m, F, ae, "⋗", "\\gtrdot");
h(m, F, S, "⋙", "\\ggg", !0);
h(m, F, S, "≷", "\\gtrless", !0);
h(m, F, S, "⋛", "\\gtreqless", !0);
h(m, F, S, "⪌", "\\gtreqqless", !0);
h(m, F, S, "≖", "\\eqcirc", !0);
h(m, F, S, "≗", "\\circeq", !0);
h(m, F, S, "≜", "\\triangleq", !0);
h(m, F, S, "∼", "\\thicksim");
h(m, F, S, "≈", "\\thickapprox");
h(m, F, S, "⫆", "\\supseteqq", !0);
h(m, F, S, "⋑", "\\Supset", !0);
h(m, F, S, "⊐", "\\sqsupset", !0);
h(m, F, S, "≽", "\\succcurlyeq", !0);
h(m, F, S, "⋟", "\\curlyeqsucc", !0);
h(m, F, S, "≿", "\\succsim", !0);
h(m, F, S, "⪸", "\\succapprox", !0);
h(m, F, S, "⊳", "\\vartriangleright");
h(m, F, S, "⊵", "\\trianglerighteq");
h(m, F, S, "⊩", "\\Vdash", !0);
h(m, F, S, "∣", "\\shortmid");
h(m, F, S, "∥", "\\shortparallel");
h(m, F, S, "≬", "\\between", !0);
h(m, F, S, "⋔", "\\pitchfork", !0);
h(m, F, S, "∝", "\\varpropto");
h(m, F, S, "◀", "\\blacktriangleleft");
h(m, F, S, "∴", "\\therefore", !0);
h(m, F, S, "∍", "\\backepsilon");
h(m, F, S, "▶", "\\blacktriangleright");
h(m, F, S, "∵", "\\because", !0);
h(m, F, S, "⋘", "\\llless");
h(m, F, S, "⋙", "\\gggtr");
h(m, F, ae, "⊲", "\\lhd");
h(m, F, ae, "⊳", "\\rhd");
h(m, F, S, "≂", "\\eqsim", !0);
h(m, g, S, "⋈", "\\Join");
h(m, F, S, "≑", "\\Doteq", !0);
h(m, F, ae, "∔", "\\dotplus", !0);
h(m, F, ae, "∖", "\\smallsetminus");
h(m, F, ae, "⋒", "\\Cap", !0);
h(m, F, ae, "⋓", "\\Cup", !0);
h(m, F, ae, "⩞", "\\doublebarwedge", !0);
h(m, F, ae, "⊟", "\\boxminus", !0);
h(m, F, ae, "⊞", "\\boxplus", !0);
h(m, F, ae, "⋇", "\\divideontimes", !0);
h(m, F, ae, "⋉", "\\ltimes", !0);
h(m, F, ae, "⋊", "\\rtimes", !0);
h(m, F, ae, "⋋", "\\leftthreetimes", !0);
h(m, F, ae, "⋌", "\\rightthreetimes", !0);
h(m, F, ae, "⋏", "\\curlywedge", !0);
h(m, F, ae, "⋎", "\\curlyvee", !0);
h(m, F, ae, "⊝", "\\circleddash", !0);
h(m, F, ae, "⊛", "\\circledast", !0);
h(m, F, ae, "⋅", "\\centerdot");
h(m, F, ae, "⊺", "\\intercal", !0);
h(m, F, ae, "⋒", "\\doublecap");
h(m, F, ae, "⋓", "\\doublecup");
h(m, F, ae, "⊠", "\\boxtimes", !0);
h(m, F, S, "⇢", "\\dashrightarrow", !0);
h(m, F, S, "⇠", "\\dashleftarrow", !0);
h(m, F, S, "⇇", "\\leftleftarrows", !0);
h(m, F, S, "⇆", "\\leftrightarrows", !0);
h(m, F, S, "⇚", "\\Lleftarrow", !0);
h(m, F, S, "↞", "\\twoheadleftarrow", !0);
h(m, F, S, "↢", "\\leftarrowtail", !0);
h(m, F, S, "↫", "\\looparrowleft", !0);
h(m, F, S, "⇋", "\\leftrightharpoons", !0);
h(m, F, S, "↶", "\\curvearrowleft", !0);
h(m, F, S, "↺", "\\circlearrowleft", !0);
h(m, F, S, "↰", "\\Lsh", !0);
h(m, F, S, "⇈", "\\upuparrows", !0);
h(m, F, S, "↿", "\\upharpoonleft", !0);
h(m, F, S, "⇃", "\\downharpoonleft", !0);
h(m, g, S, "⊶", "\\origof", !0);
h(m, g, S, "⊷", "\\imageof", !0);
h(m, F, S, "⊸", "\\multimap", !0);
h(m, F, S, "↭", "\\leftrightsquigarrow", !0);
h(m, F, S, "⇉", "\\rightrightarrows", !0);
h(m, F, S, "⇄", "\\rightleftarrows", !0);
h(m, F, S, "↠", "\\twoheadrightarrow", !0);
h(m, F, S, "↣", "\\rightarrowtail", !0);
h(m, F, S, "↬", "\\looparrowright", !0);
h(m, F, S, "↷", "\\curvearrowright", !0);
h(m, F, S, "↻", "\\circlearrowright", !0);
h(m, F, S, "↱", "\\Rsh", !0);
h(m, F, S, "⇊", "\\downdownarrows", !0);
h(m, F, S, "↾", "\\upharpoonright", !0);
h(m, F, S, "⇂", "\\downharpoonright", !0);
h(m, F, S, "⇝", "\\rightsquigarrow", !0);
h(m, F, S, "⇝", "\\leadsto");
h(m, F, S, "⇛", "\\Rrightarrow", !0);
h(m, F, S, "↾", "\\restriction");
h(m, g, T, "‘", "`");
h(m, g, T, "$", "\\$");
h(G, g, T, "$", "\\$");
h(G, g, T, "$", "\\textdollar");
h(m, g, T, "%", "\\%");
h(G, g, T, "%", "\\%");
h(m, g, T, "_", "\\_");
h(G, g, T, "_", "\\_");
h(G, g, T, "_", "\\textunderscore");
h(m, g, T, "∠", "\\angle", !0);
h(m, g, T, "∞", "\\infty", !0);
h(m, g, T, "′", "\\prime");
h(m, g, T, "△", "\\triangle");
h(m, g, T, "Γ", "\\Gamma", !0);
h(m, g, T, "Δ", "\\Delta", !0);
h(m, g, T, "Θ", "\\Theta", !0);
h(m, g, T, "Λ", "\\Lambda", !0);
h(m, g, T, "Ξ", "\\Xi", !0);
h(m, g, T, "Π", "\\Pi", !0);
h(m, g, T, "Σ", "\\Sigma", !0);
h(m, g, T, "Υ", "\\Upsilon", !0);
h(m, g, T, "Φ", "\\Phi", !0);
h(m, g, T, "Ψ", "\\Psi", !0);
h(m, g, T, "Ω", "\\Omega", !0);
h(m, g, T, "A", "Α");
h(m, g, T, "B", "Β");
h(m, g, T, "E", "Ε");
h(m, g, T, "Z", "Ζ");
h(m, g, T, "H", "Η");
h(m, g, T, "I", "Ι");
h(m, g, T, "K", "Κ");
h(m, g, T, "M", "Μ");
h(m, g, T, "N", "Ν");
h(m, g, T, "O", "Ο");
h(m, g, T, "P", "Ρ");
h(m, g, T, "T", "Τ");
h(m, g, T, "X", "Χ");
h(m, g, T, "¬", "\\neg", !0);
h(m, g, T, "¬", "\\lnot");
h(m, g, T, "⊤", "\\top");
h(m, g, T, "⊥", "\\bot");
h(m, g, T, "∅", "\\emptyset");
h(m, F, T, "∅", "\\varnothing");
h(m, g, be, "α", "\\alpha", !0);
h(m, g, be, "β", "\\beta", !0);
h(m, g, be, "γ", "\\gamma", !0);
h(m, g, be, "δ", "\\delta", !0);
h(m, g, be, "ϵ", "\\epsilon", !0);
h(m, g, be, "ζ", "\\zeta", !0);
h(m, g, be, "η", "\\eta", !0);
h(m, g, be, "θ", "\\theta", !0);
h(m, g, be, "ι", "\\iota", !0);
h(m, g, be, "κ", "\\kappa", !0);
h(m, g, be, "λ", "\\lambda", !0);
h(m, g, be, "μ", "\\mu", !0);
h(m, g, be, "ν", "\\nu", !0);
h(m, g, be, "ξ", "\\xi", !0);
h(m, g, be, "ο", "\\omicron", !0);
h(m, g, be, "π", "\\pi", !0);
h(m, g, be, "ρ", "\\rho", !0);
h(m, g, be, "σ", "\\sigma", !0);
h(m, g, be, "τ", "\\tau", !0);
h(m, g, be, "υ", "\\upsilon", !0);
h(m, g, be, "ϕ", "\\phi", !0);
h(m, g, be, "χ", "\\chi", !0);
h(m, g, be, "ψ", "\\psi", !0);
h(m, g, be, "ω", "\\omega", !0);
h(m, g, be, "ε", "\\varepsilon", !0);
h(m, g, be, "ϑ", "\\vartheta", !0);
h(m, g, be, "ϖ", "\\varpi", !0);
h(m, g, be, "ϱ", "\\varrho", !0);
h(m, g, be, "ς", "\\varsigma", !0);
h(m, g, be, "φ", "\\varphi", !0);
h(m, g, ae, "∗", "*", !0);
h(m, g, ae, "+", "+");
h(m, g, ae, "−", "-", !0);
h(m, g, ae, "⋅", "\\cdot", !0);
h(m, g, ae, "∘", "\\circ", !0);
h(m, g, ae, "÷", "\\div", !0);
h(m, g, ae, "±", "\\pm", !0);
h(m, g, ae, "×", "\\times", !0);
h(m, g, ae, "∩", "\\cap", !0);
h(m, g, ae, "∪", "\\cup", !0);
h(m, g, ae, "∖", "\\setminus", !0);
h(m, g, ae, "∧", "\\land");
h(m, g, ae, "∨", "\\lor");
h(m, g, ae, "∧", "\\wedge", !0);
h(m, g, ae, "∨", "\\vee", !0);
h(m, g, T, "√", "\\surd");
h(m, g, pt, "⟨", "\\langle", !0);
h(m, g, pt, "∣", "\\lvert");
h(m, g, pt, "∥", "\\lVert");
h(m, g, rt, "?", "?");
h(m, g, rt, "!", "!");
h(m, g, rt, "⟩", "\\rangle", !0);
h(m, g, rt, "∣", "\\rvert");
h(m, g, rt, "∥", "\\rVert");
h(m, g, S, "=", "=");
h(m, g, S, ":", ":");
h(m, g, S, "≈", "\\approx", !0);
h(m, g, S, "≅", "\\cong", !0);
h(m, g, S, "≥", "\\ge");
h(m, g, S, "≥", "\\geq", !0);
h(m, g, S, "←", "\\gets");
h(m, g, S, ">", "\\gt", !0);
h(m, g, S, "∈", "\\in", !0);
h(m, g, S, "", "\\@not");
h(m, g, S, "⊂", "\\subset", !0);
h(m, g, S, "⊃", "\\supset", !0);
h(m, g, S, "⊆", "\\subseteq", !0);
h(m, g, S, "⊇", "\\supseteq", !0);
h(m, F, S, "⊈", "\\nsubseteq", !0);
h(m, F, S, "⊉", "\\nsupseteq", !0);
h(m, g, S, "⊨", "\\models");
h(m, g, S, "←", "\\leftarrow", !0);
h(m, g, S, "≤", "\\le");
h(m, g, S, "≤", "\\leq", !0);
h(m, g, S, "<", "\\lt", !0);
h(m, g, S, "→", "\\rightarrow", !0);
h(m, g, S, "→", "\\to");
h(m, F, S, "≱", "\\ngeq", !0);
h(m, F, S, "≰", "\\nleq", !0);
h(m, g, xr, " ", "\\ ");
h(m, g, xr, " ", "\\space");
h(m, g, xr, " ", "\\nobreakspace");
h(G, g, xr, " ", "\\ ");
h(G, g, xr, " ", " ");
h(G, g, xr, " ", "\\space");
h(G, g, xr, " ", "\\nobreakspace");
h(m, g, xr, null, "\\nobreak");
h(m, g, xr, null, "\\allowbreak");
h(m, g, ri, ",", ",");
h(m, g, ri, ";", ";");
h(m, F, ae, "⊼", "\\barwedge", !0);
h(m, F, ae, "⊻", "\\veebar", !0);
h(m, g, ae, "⊙", "\\odot", !0);
h(m, g, ae, "⊕", "\\oplus", !0);
h(m, g, ae, "⊗", "\\otimes", !0);
h(m, g, T, "∂", "\\partial", !0);
h(m, g, ae, "⊘", "\\oslash", !0);
h(m, F, ae, "⊚", "\\circledcirc", !0);
h(m, F, ae, "⊡", "\\boxdot", !0);
h(m, g, ae, "△", "\\bigtriangleup");
h(m, g, ae, "▽", "\\bigtriangledown");
h(m, g, ae, "†", "\\dagger");
h(m, g, ae, "⋄", "\\diamond");
h(m, g, ae, "⋆", "\\star");
h(m, g, ae, "◃", "\\triangleleft");
h(m, g, ae, "▹", "\\triangleright");
h(m, g, pt, "{", "\\{");
h(G, g, T, "{", "\\{");
h(G, g, T, "{", "\\textbraceleft");
h(m, g, rt, "}", "\\}");
h(G, g, T, "}", "\\}");
h(G, g, T, "}", "\\textbraceright");
h(m, g, pt, "{", "\\lbrace");
h(m, g, rt, "}", "\\rbrace");
h(m, g, pt, "[", "\\lbrack", !0);
h(G, g, T, "[", "\\lbrack", !0);
h(m, g, rt, "]", "\\rbrack", !0);
h(G, g, T, "]", "\\rbrack", !0);
h(m, g, pt, "(", "\\lparen", !0);
h(m, g, rt, ")", "\\rparen", !0);
h(G, g, T, "<", "\\textless", !0);
h(G, g, T, ">", "\\textgreater", !0);
h(m, g, pt, "⌊", "\\lfloor", !0);
h(m, g, rt, "⌋", "\\rfloor", !0);
h(m, g, pt, "⌈", "\\lceil", !0);
h(m, g, rt, "⌉", "\\rceil", !0);
h(m, g, T, "\\", "\\backslash");
h(m, g, T, "∣", "|");
h(m, g, T, "∣", "\\vert");
h(G, g, T, "|", "\\textbar", !0);
h(m, g, T, "∥", "\\|");
h(m, g, T, "∥", "\\Vert");
h(G, g, T, "∥", "\\textbardbl");
h(G, g, T, "~", "\\textasciitilde");
h(G, g, T, "\\", "\\textbackslash");
h(G, g, T, "^", "\\textasciicircum");
h(m, g, S, "↑", "\\uparrow", !0);
h(m, g, S, "⇑", "\\Uparrow", !0);
h(m, g, S, "↓", "\\downarrow", !0);
h(m, g, S, "⇓", "\\Downarrow", !0);
h(m, g, S, "↕", "\\updownarrow", !0);
h(m, g, S, "⇕", "\\Updownarrow", !0);
h(m, g, E0, "∐", "\\coprod");
h(m, g, E0, "⋁", "\\bigvee");
h(m, g, E0, "⋀", "\\bigwedge");
h(m, g, E0, "⨄", "\\biguplus");
h(m, g, E0, "⋂", "\\bigcap");
h(m, g, E0, "⋃", "\\bigcup");
h(m, g, E0, "∫", "\\int");
h(m, g, E0, "∫", "\\intop");
h(m, g, E0, "∬", "\\iint");
h(m, g, E0, "∭", "\\iiint");
h(m, g, E0, "∏", "\\prod");
h(m, g, E0, "∑", "\\sum");
h(m, g, E0, "⨂", "\\bigotimes");
h(m, g, E0, "⨁", "\\bigoplus");
h(m, g, E0, "⨀", "\\bigodot");
h(m, g, E0, "∮", "\\oint");
h(m, g, E0, "∯", "\\oiint");
h(m, g, E0, "∰", "\\oiiint");
h(m, g, E0, "⨆", "\\bigsqcup");
h(m, g, E0, "∫", "\\smallint");
h(G, g, Pn, "…", "\\textellipsis");
h(m, g, Pn, "…", "\\mathellipsis");
h(G, g, Pn, "…", "\\ldots", !0);
h(m, g, Pn, "…", "\\ldots", !0);
h(m, g, Pn, "⋯", "\\@cdots", !0);
h(m, g, Pn, "⋱", "\\ddots", !0);
h(m, g, T, "⋮", "\\varvdots");
h(m, g, f0, "ˊ", "\\acute");
h(m, g, f0, "ˋ", "\\grave");
h(m, g, f0, "¨", "\\ddot");
h(m, g, f0, "~", "\\tilde");
h(m, g, f0, "ˉ", "\\bar");
h(m, g, f0, "˘", "\\breve");
h(m, g, f0, "ˇ", "\\check");
h(m, g, f0, "^", "\\hat");
h(m, g, f0, "⃗", "\\vec");
h(m, g, f0, "˙", "\\dot");
h(m, g, f0, "˚", "\\mathring");
h(m, g, be, "", "\\@imath");
h(m, g, be, "", "\\@jmath");
h(m, g, T, "ı", "ı");
h(m, g, T, "ȷ", "ȷ");
h(G, g, T, "ı", "\\i", !0);
h(G, g, T, "ȷ", "\\j", !0);
h(G, g, T, "ß", "\\ss", !0);
h(G, g, T, "æ", "\\ae", !0);
h(G, g, T, "œ", "\\oe", !0);
h(G, g, T, "ø", "\\o", !0);
h(G, g, T, "Æ", "\\AE", !0);
h(G, g, T, "Œ", "\\OE", !0);
h(G, g, T, "Ø", "\\O", !0);
h(G, g, f0, "ˊ", "\\'");
h(G, g, f0, "ˋ", "\\`");
h(G, g, f0, "ˆ", "\\^");
h(G, g, f0, "˜", "\\~");
h(G, g, f0, "ˉ", "\\=");
h(G, g, f0, "˘", "\\u");
h(G, g, f0, "˙", "\\.");
h(G, g, f0, "¸", "\\c");
h(G, g, f0, "˚", "\\r");
h(G, g, f0, "ˇ", "\\v");
h(G, g, f0, "¨", '\\"');
h(G, g, f0, "˝", "\\H");
h(G, g, f0, "◯", "\\textcircled");
var P6 = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
h(G, g, T, "–", "--", !0);
h(G, g, T, "–", "\\textendash");
h(G, g, T, "—", "---", !0);
h(G, g, T, "—", "\\textemdash");
h(G, g, T, "‘", "`", !0);
h(G, g, T, "‘", "\\textquoteleft");
h(G, g, T, "’", "'", !0);
h(G, g, T, "’", "\\textquoteright");
h(G, g, T, "“", "``", !0);
h(G, g, T, "“", "\\textquotedblleft");
h(G, g, T, "”", "''", !0);
h(G, g, T, "”", "\\textquotedblright");
h(m, g, T, "°", "\\degree", !0);
h(G, g, T, "°", "\\degree");
h(G, g, T, "°", "\\textdegree", !0);
h(m, g, T, "£", "\\pounds");
h(m, g, T, "£", "\\mathsterling", !0);
h(G, g, T, "£", "\\pounds");
h(G, g, T, "£", "\\textsterling", !0);
h(m, F, T, "✠", "\\maltese");
h(G, F, T, "✠", "\\maltese");
var Ts = '0123456789/@."';
for (var ji = 0; ji < Ts.length; ji++) {
  var Qs = Ts.charAt(ji);
  h(m, g, T, Qs, Qs);
}
var Ms = '0123456789!@*()-=+";:?/.,';
for (var Gi = 0; Gi < Ms.length; Gi++) {
  var Bs = Ms.charAt(Gi);
  h(G, g, T, Bs, Bs);
}
var za = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Wi = 0; Wi < za.length; Wi++) {
  var la = za.charAt(Wi);
  h(m, g, be, la, la), h(G, g, T, la, la);
}
h(m, F, T, "C", "ℂ");
h(G, F, T, "C", "ℂ");
h(m, F, T, "H", "ℍ");
h(G, F, T, "H", "ℍ");
h(m, F, T, "N", "ℕ");
h(G, F, T, "N", "ℕ");
h(m, F, T, "P", "ℙ");
h(G, F, T, "P", "ℙ");
h(m, F, T, "Q", "ℚ");
h(G, F, T, "Q", "ℚ");
h(m, F, T, "R", "ℝ");
h(G, F, T, "R", "ℝ");
h(m, F, T, "Z", "ℤ");
h(G, F, T, "Z", "ℤ");
h(m, g, be, "h", "ℎ");
h(G, g, be, "h", "ℎ");
var De = "";
for (var J0 = 0; J0 < za.length; J0++) {
  var _0 = za.charAt(J0);
  De = String.fromCharCode(55349, 56320 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56372 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56424 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56580 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56684 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56736 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56788 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56840 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56944 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), J0 < 26 && (De = String.fromCharCode(55349, 56632 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De), De = String.fromCharCode(55349, 56476 + J0), h(m, g, be, _0, De), h(G, g, T, _0, De));
}
De = "𝕜";
h(m, g, be, "k", De);
h(G, g, T, "k", De);
for (var $r = 0; $r < 10; $r++) {
  var qr = $r.toString();
  De = String.fromCharCode(55349, 57294 + $r), h(m, g, be, qr, De), h(G, g, T, qr, De), De = String.fromCharCode(55349, 57314 + $r), h(m, g, be, qr, De), h(G, g, T, qr, De), De = String.fromCharCode(55349, 57324 + $r), h(m, g, be, qr, De), h(G, g, T, qr, De), De = String.fromCharCode(55349, 57334 + $r), h(m, g, be, qr, De), h(G, g, T, qr, De);
}
var zs = "ÐÞþ";
for (var Zi = 0; Zi < zs.length; Zi++) {
  var sa = zs.charAt(Zi);
  h(m, g, be, sa, sa), h(G, g, T, sa, sa);
}
var oa = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Ls = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], ec = function(e, t) {
  var r = e.charCodeAt(0), a = e.charCodeAt(1), i = (r - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var o = Math.floor((i - 119808) / 26);
    return [oa[o][2], oa[o][l]];
  } else if (120782 <= i && i <= 120831) {
    var s = Math.floor((i - 120782) / 10);
    return [Ls[s][2], Ls[s][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [oa[0][2], oa[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new ge("Unsupported character: " + e);
  }
}, ni = function(e, t, r) {
  return y0[r][e] && y0[r][e].replace && (e = y0[r][e].replace), {
    value: e,
    metrics: l5(e, t, r)
  };
}, Nt = function(e, t, r, a, i) {
  var l = ni(e, t, r), o = l.metrics;
  e = l.value;
  var s;
  if (o) {
    var u = o.italic;
    (r === "text" || a && a.font === "mathit") && (u = 0), s = new ur(e, o.height, o.depth, u, o.skew, o.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + r + "'")), s = new ur(e, 0, 0, 0, 0, 0, i);
  if (a) {
    s.maxFontSize = a.sizeMultiplier, a.style.isTight() && s.classes.push("mtight");
    var c = a.getColor();
    c && (s.style.color = c);
  }
  return s;
}, tc = function(e, t, r, a) {
  return a === void 0 && (a = []), r.font === "boldsymbol" && ni(e, "Main-Bold", t).metrics ? Nt(e, "Main-Bold", t, r, a.concat(["mathbf"])) : e === "\\" || y0[t][e].font === "main" ? Nt(e, "Main-Regular", t, r, a) : Nt(e, "AMS-Regular", t, r, a.concat(["amsrm"]));
}, rc = function(e, t, r, a, i) {
  return i !== "textord" && ni(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, nc = function(e, t, r) {
  var a = e.mode, i = e.text, l = ["mord"], o = a === "math" || a === "text" && t.font, s = o ? t.font : t.fontFamily, u = "", c = "";
  if (i.charCodeAt(0) === 55349 && ([u, c] = ec(i, a)), u.length > 0)
    return Nt(i, u, a, t, l.concat(c));
  if (s) {
    var f, d;
    if (s === "boldsymbol") {
      var p = rc(i, a, t, l, r);
      f = p.fontName, d = [p.fontClass];
    } else o ? (f = U6[s].fontName, d = [s]) : (f = ua(s, t.fontWeight, t.fontShape), d = [s, t.fontWeight, t.fontShape]);
    if (ni(i, f, a).metrics)
      return Nt(i, f, a, t, l.concat(d));
    if (P6.hasOwnProperty(i) && f.slice(0, 10) === "Typewriter") {
      for (var b = [], E = 0; E < i.length; E++)
        b.push(Nt(i[E], f, a, t, l.concat(d)));
      return V6(b);
    }
  }
  if (r === "mathord")
    return Nt(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (r === "textord") {
    var k = y0[a][i] && y0[a][i].font;
    if (k === "ams") {
      var w = ua("amsrm", t.fontWeight, t.fontShape);
      return Nt(i, w, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (k === "main" || !k) {
      var v = ua("textrm", t.fontWeight, t.fontShape);
      return Nt(i, v, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var _ = ua(k, t.fontWeight, t.fontShape);
      return Nt(i, _, a, t, l.concat(_, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + r + " in makeOrd");
}, ac = (n, e) => {
  if (Zr(n.classes) !== Zr(e.classes) || n.skew !== e.skew || n.maxFontSize !== e.maxFontSize)
    return !1;
  if (n.classes.length === 1) {
    var t = n.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var r in n.style)
    if (n.style.hasOwnProperty(r) && n.style[r] !== e.style[r])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && n.style[a] !== e.style[a])
      return !1;
  return !0;
}, ic = (n) => {
  for (var e = 0; e < n.length - 1; e++) {
    var t = n[e], r = n[e + 1];
    t instanceof ur && r instanceof ur && ac(t, r) && (t.text += r.text, t.height = Math.max(t.height, r.height), t.depth = Math.max(t.depth, r.depth), t.italic = r.italic, n.splice(e + 1, 1), e--);
  }
  return n;
}, s5 = function(e) {
  for (var t = 0, r = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > r && (r = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = r, e.maxFontSize = a;
}, st = function(e, t, r, a) {
  var i = new ti(e, t, r, a);
  return s5(i), i;
}, H6 = (n, e, t, r) => new ti(n, e, t, r), lc = function(e, t, r) {
  var a = st([e], [], t);
  return a.height = Math.max(r || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = te(a.height), a.maxFontSize = 1, a;
}, sc = function(e, t, r, a) {
  var i = new q6(e, t, r, a);
  return s5(i), i;
}, V6 = function(e) {
  var t = new C1(e);
  return s5(t), t;
}, oc = function(e, t) {
  return e instanceof C1 ? st([], [e], t) : e;
}, uc = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, r = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var o = -t[l].shift - i - t[l].elem.depth, s = o - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + o, r.push({
        type: "kern",
        size: s
      }), r.push(t[l]);
    }
    return {
      children: r,
      depth: a
    };
  }
  var u;
  if (e.positionType === "top") {
    for (var c = e.positionData, f = 0; f < e.children.length; f++) {
      var d = e.children[f];
      c -= d.type === "kern" ? d.size : d.elem.height + d.elem.depth;
    }
    u = c;
  } else if (e.positionType === "bottom")
    u = -e.positionData;
  else {
    var p = e.children[0];
    if (p.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      u = -p.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      u = -p.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: u
  };
}, cc = function(e, t) {
  for (var {
    children: r,
    depth: a
  } = uc(e), i = 0, l = 0; l < r.length; l++) {
    var o = r[l];
    if (o.type === "elem") {
      var s = o.elem;
      i = Math.max(i, s.maxFontSize, s.height);
    }
  }
  i += 2;
  var u = st(["pstrut"], []);
  u.style.height = te(i);
  for (var c = [], f = a, d = a, p = a, b = 0; b < r.length; b++) {
    var E = r[b];
    if (E.type === "kern")
      p += E.size;
    else {
      var k = E.elem, w = E.wrapperClasses || [], v = E.wrapperStyle || {}, _ = st(w, [u, k], void 0, v);
      _.style.top = te(-i - p - k.depth), E.marginLeft && (_.style.marginLeft = E.marginLeft), E.marginRight && (_.style.marginRight = E.marginRight), c.push(_), p += k.height + k.depth;
    }
    f = Math.min(f, p), d = Math.max(d, p);
  }
  var A = st(["vlist"], c);
  A.style.height = te(d);
  var x;
  if (f < 0) {
    var Q = st([], []), z = st(["vlist"], [Q]);
    z.style.height = te(-f);
    var P = st(["vlist-s"], [new ur("​")]);
    x = [st(["vlist-r"], [A, P]), st(["vlist-r"], [z])];
  } else
    x = [st(["vlist-r"], [A])];
  var B = st(["vlist-t"], x);
  return x.length === 2 && B.classes.push("vlist-t2"), B.height = d, B.depth = -f, B;
}, hc = (n, e) => {
  var t = st(["mspace"], [], e), r = m0(n, e);
  return t.style.marginRight = te(r), t;
}, ua = function(e, t, r) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && r === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, U6 = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, j6 = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, fc = function(e, t) {
  var [r, a, i] = j6[e], l = new cn(r), o = new Yr([l], {
    width: te(a),
    height: te(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + te(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), s = H6(["overlay"], [o], t);
  return s.height = i, s.style.height = te(i), s.style.width = te(a), s;
}, I = {
  fontMap: U6,
  makeSymbol: Nt,
  mathsym: tc,
  makeSpan: st,
  makeSvgSpan: H6,
  makeLineSpan: lc,
  makeAnchor: sc,
  makeFragment: V6,
  wrapFragment: oc,
  makeVList: cc,
  makeOrd: nc,
  makeGlue: hc,
  staticSvg: fc,
  svgData: j6,
  tryCombineChars: ic
}, d0 = {
  number: 3,
  unit: "mu"
}, en = {
  number: 4,
  unit: "mu"
}, pr = {
  number: 5,
  unit: "mu"
}, dc = {
  mord: {
    mop: d0,
    mbin: en,
    mrel: pr,
    minner: d0
  },
  mop: {
    mord: d0,
    mop: d0,
    mrel: pr,
    minner: d0
  },
  mbin: {
    mord: en,
    mop: en,
    mopen: en,
    minner: en
  },
  mrel: {
    mord: pr,
    mop: pr,
    mopen: pr,
    minner: pr
  },
  mopen: {},
  mclose: {
    mop: d0,
    mbin: en,
    mrel: pr,
    minner: d0
  },
  mpunct: {
    mord: d0,
    mop: d0,
    mrel: pr,
    mopen: d0,
    mclose: d0,
    mpunct: d0,
    minner: d0
  },
  minner: {
    mord: d0,
    mop: d0,
    mbin: en,
    mrel: pr,
    mopen: d0,
    mpunct: d0,
    minner: d0
  }
}, mc = {
  mord: {
    mop: d0
  },
  mop: {
    mord: d0,
    mop: d0
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: d0
  },
  mpunct: {},
  minner: {
    mop: d0
  }
}, G6 = {}, La = {}, Ia = {};
function re(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs,
    argTypes: r.argTypes,
    allowedInArgument: !!r.allowedInArgument,
    allowedInText: !!r.allowedInText,
    allowedInMath: r.allowedInMath === void 0 ? !0 : r.allowedInMath,
    numOptionalArgs: r.numOptionalArgs || 0,
    infix: !!r.infix,
    primitive: !!r.primitive,
    handler: a
  }, s = 0; s < t.length; ++s)
    G6[t[s]] = o;
  e && (i && (La[e] = i), l && (Ia[e] = l));
}
function vn(n) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: r
  } = n;
  re({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: r
  });
}
var Na = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, w0 = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, Rn = I.makeSpan, pc = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], gc = ["rightmost", "mrel", "mclose", "mpunct"], _c = {
  display: ye.DISPLAY,
  text: ye.TEXT,
  script: ye.SCRIPT,
  scriptscript: ye.SCRIPTSCRIPT
}, vc = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, U0 = function(e, t, r, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var o = Ge(e[l], t);
    if (o instanceof C1) {
      var s = o.children;
      i.push(...s);
    } else
      i.push(o);
  }
  if (I.tryCombineChars(i), !r)
    return i;
  var u = t;
  if (e.length === 1) {
    var c = e[0];
    c.type === "sizing" ? u = t.havingSize(c.size) : c.type === "styling" && (u = t.havingStyle(_c[c.style]));
  }
  var f = Rn([a[0] || "leftmost"], [], t), d = Rn([a[1] || "rightmost"], [], t), p = r === "root";
  return Is(i, (b, E) => {
    var k = E.classes[0], w = b.classes[0];
    k === "mbin" && we.contains(gc, w) ? E.classes[0] = "mord" : w === "mbin" && we.contains(pc, k) && (b.classes[0] = "mord");
  }, {
    node: f
  }, d, p), Is(i, (b, E) => {
    var k = Bl(E), w = Bl(b), v = k && w ? b.hasClass("mtight") ? mc[k][w] : dc[k][w] : null;
    if (v)
      return I.makeGlue(v, u);
  }, {
    node: f
  }, d, p), i;
}, Is = function n(e, t, r, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var o = e[l], s = W6(o);
    if (s) {
      n(s.children, t, r, null, i);
      continue;
    }
    var u = !o.hasClass("mspace");
    if (u) {
      var c = t(o, r.node);
      c && (r.insertAfter ? r.insertAfter(c) : (e.unshift(c), l++));
    }
    u ? r.node = o : i && o.hasClass("newline") && (r.node = Rn(["leftmost"])), r.insertAfter = /* @__PURE__ */ ((f) => (d) => {
      e.splice(f + 1, 0, d), l++;
    })(l);
  }
  a && e.pop();
}, W6 = function(e) {
  return e instanceof C1 || e instanceof q6 || e instanceof ti && e.hasClass("enclosing") ? e : null;
}, bc = function n(e, t) {
  var r = W6(e);
  if (r) {
    var a = r.children;
    if (a.length) {
      if (t === "right")
        return n(a[a.length - 1], "right");
      if (t === "left")
        return n(a[0], "left");
    }
  }
  return e;
}, Bl = function(e, t) {
  return e ? (t && (e = bc(e, t)), vc[e.classes[0]] || null) : null;
}, y1 = function(e, t) {
  var r = ["nulldelimiter"].concat(e.baseSizingClasses());
  return Rn(t.concat(r));
}, Ge = function(e, t, r) {
  if (!e)
    return Rn();
  if (La[e.type]) {
    var a = La[e.type](e, t);
    if (r && t.size !== r.size) {
      a = Rn(t.sizingClasses(r), [a], t);
      var i = t.sizeMultiplier / r.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new ge("Got group of unknown type: '" + e.type + "'");
};
function Z6(n) {
  return new C1(n);
}
class qt {
  constructor(e, t, r) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = r || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = Zr(this.classes));
    for (var r = 0; r < this.children.length; r++)
      e.appendChild(this.children[r].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += we.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + we.escape(Zr(this.classes)) + '"'), e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class c1 {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return we.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class wc {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", te(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + te(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var Y = {
  MathNode: qt,
  TextNode: c1,
  SpaceNode: wc,
  newDocumentFragment: Z6
}, Ft = function(e, t, r) {
  return y0[t][e] && y0[t][e].replace && e.charCodeAt(0) !== 55349 && !(P6.hasOwnProperty(e) && r && (r.fontFamily && r.fontFamily.slice(4, 6) === "tt" || r.font && r.font.slice(4, 6) === "tt")) && (e = y0[t][e].replace), new Y.TextNode(e);
}, o5 = function(e) {
  return e.length === 1 ? e[0] : new Y.MathNode("mrow", e);
}, u5 = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var r = t.font;
  if (!r || r === "mathnormal")
    return null;
  var a = e.mode;
  if (r === "mathit")
    return "italic";
  if (r === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (r === "mathbf")
    return "bold";
  if (r === "mathbb")
    return "double-struck";
  if (r === "mathfrak")
    return "fraktur";
  if (r === "mathscr" || r === "mathcal")
    return "script";
  if (r === "mathsf")
    return "sans-serif";
  if (r === "mathtt")
    return "monospace";
  var i = e.text;
  if (we.contains(["\\imath", "\\jmath"], i))
    return null;
  y0[a][i] && y0[a][i].replace && (i = y0[a][i].replace);
  var l = I.fontMap[r].fontName;
  return l5(i, l, a) ? I.fontMap[r].variant : null;
}, gt = function(e, t, r) {
  if (e.length === 1) {
    var a = a0(e[0], t);
    return r && a instanceof qt && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, o = 0; o < e.length; o++) {
    var s = a0(e[o], t);
    if (s instanceof qt && l instanceof qt) {
      if (s.type === "mtext" && l.type === "mtext" && s.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mn" && l.type === "mn") {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mi" && s.children.length === 1 && l.type === "mn") {
        var u = s.children[0];
        if (u instanceof c1 && u.text === ".") {
          l.children.push(...s.children);
          continue;
        }
      } else if (l.type === "mi" && l.children.length === 1) {
        var c = l.children[0];
        if (c instanceof c1 && c.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
          var f = s.children[0];
          f instanceof c1 && f.text.length > 0 && (f.text = f.text.slice(0, 1) + "̸" + f.text.slice(1), i.pop());
        }
      }
    }
    i.push(s), l = s;
  }
  return i;
}, Xr = function(e, t, r) {
  return o5(gt(e, t, r));
}, a0 = function(e, t) {
  if (!e)
    return new Y.MathNode("mrow");
  if (Ia[e.type]) {
    var r = Ia[e.type](e, t);
    return r;
  } else
    throw new ge("Got group of unknown type: '" + e.type + "'");
}, yc = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, kc = function(e) {
  var t = new Y.MathNode("mo", [new Y.TextNode(yc[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, Dc = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Ec = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, Ac = function(e, t) {
  function r() {
    var o = 4e5, s = e.label.slice(1);
    if (we.contains(["widehat", "widecheck", "widetilde", "utilde"], s)) {
      var u = e, c = Ec(u.base), f, d, p;
      if (c > 5)
        s === "widehat" || s === "widecheck" ? (f = 420, o = 2364, p = 0.42, d = s + "4") : (f = 312, o = 2340, p = 0.34, d = "tilde4");
      else {
        var b = [1, 1, 2, 2, 3, 3][c];
        s === "widehat" || s === "widecheck" ? (o = [0, 1062, 2364, 2364, 2364][b], f = [0, 239, 300, 360, 420][b], p = [0, 0.24, 0.3, 0.3, 0.36, 0.42][b], d = s + b) : (o = [0, 600, 1033, 2339, 2340][b], f = [0, 260, 286, 306, 312][b], p = [0, 0.26, 0.286, 0.3, 0.306, 0.34][b], d = "tilde" + b);
      }
      var E = new cn(d), k = new Yr([E], {
        width: "100%",
        height: te(p),
        viewBox: "0 0 " + o + " " + f,
        preserveAspectRatio: "none"
      });
      return {
        span: I.makeSvgSpan([], [k], t),
        minWidth: 0,
        height: p
      };
    } else {
      var w = [], v = Dc[s], [_, A, x] = v, Q = x / 1e3, z = _.length, P, B;
      if (z === 1) {
        var N = v[3];
        P = ["hide-tail"], B = [N];
      } else if (z === 2)
        P = ["halfarrow-left", "halfarrow-right"], B = ["xMinYMin", "xMaxYMin"];
      else if (z === 3)
        P = ["brace-left", "brace-center", "brace-right"], B = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + z + " children.");
      for (var j = 0; j < z; j++) {
        var $ = new cn(_[j]), W = new Yr([$], {
          width: "400em",
          height: te(Q),
          viewBox: "0 0 " + o + " " + x,
          preserveAspectRatio: B[j] + " slice"
        }), se = I.makeSvgSpan([P[j]], [W], t);
        if (z === 1)
          return {
            span: se,
            minWidth: A,
            height: Q
          };
        se.style.height = te(Q), w.push(se);
      }
      return {
        span: I.makeSpan(["stretchy"], w, t),
        minWidth: A,
        height: Q
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = r();
  return a.height = l, a.style.height = te(l), i > 0 && (a.style.minWidth = te(i)), a;
}, Fc = function(e, t, r, a, i) {
  var l, o = e.height + e.depth + r + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = I.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var s = i.color && i.getColor();
      s && (l.style.borderColor = s);
    }
  } else {
    var u = [];
    /^[bx]cancel$/.test(t) && u.push(new xs({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && u.push(new xs({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var c = new Yr(u, {
      width: "100%",
      height: te(o)
    });
    l = I.makeSvgSpan([], [c], i);
  }
  return l.height = o, l.style.height = te(o), l;
}, Dr = {
  encloseSpan: Fc,
  mathMLnode: kc,
  svgSpan: Ac
};
function ze(n, e) {
  if (!n || n.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (n ? "node of type " + n.type : String(n)));
  return n;
}
function c5(n) {
  var e = ai(n);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (n ? "node of type " + n.type : String(n)));
  return e;
}
function ai(n) {
  return n && (n.type === "atom" || $7.hasOwnProperty(n.type)) ? n : null;
}
var h5 = (n, e) => {
  var t, r, a;
  n && n.type === "supsub" ? (r = ze(n.base, "accent"), t = r.base, n.base = t, a = J7(Ge(n, e)), n.base = r) : (r = ze(n, "accent"), t = r.base);
  var i = Ge(t, e.havingCrampedStyle()), l = r.isShifty && we.isCharacterBox(t), o = 0;
  if (l) {
    var s = we.getBaseElem(t), u = Ge(s, e.havingCrampedStyle());
    o = Cs(u).skew;
  }
  var c = r.label === "\\c", f = c ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), d;
  if (r.isStretchy)
    d = Dr.svgSpan(r, e), d = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: d,
        wrapperClasses: ["svg-align"],
        wrapperStyle: o > 0 ? {
          width: "calc(100% - " + te(2 * o) + ")",
          marginLeft: te(2 * o)
        } : void 0
      }]
    }, e);
  else {
    var p, b;
    r.label === "\\vec" ? (p = I.staticSvg("vec", e), b = I.svgData.vec[1]) : (p = I.makeOrd({
      mode: r.mode,
      text: r.label
    }, e, "textord"), p = Cs(p), p.italic = 0, b = p.width, c && (f += p.depth)), d = I.makeSpan(["accent-body"], [p]);
    var E = r.label === "\\textcircled";
    E && (d.classes.push("accent-full"), f = i.height);
    var k = o;
    E || (k -= b / 2), d.style.left = te(k), r.label === "\\textcircled" && (d.style.top = ".2em"), d = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -f
      }, {
        type: "elem",
        elem: d
      }]
    }, e);
  }
  var w = I.makeSpan(["mord", "accent"], [d], e);
  return a ? (a.children[0] = w, a.height = Math.max(w.height, a.height), a.classes[0] = "mord", a) : w;
}, Y6 = (n, e) => {
  var t = n.isStretchy ? Dr.mathMLnode(n.label) : new Y.MathNode("mo", [Ft(n.label, n.mode)]), r = new Y.MathNode("mover", [a0(n.base, e), t]);
  return r.setAttribute("accent", "true"), r;
}, Sc = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((n) => "\\" + n).join("|"));
re({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var t = Na(e[0]), r = !Sc.test(n.funcName), a = !r || n.funcName === "\\widehat" || n.funcName === "\\widetilde" || n.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: n.parser.mode,
      label: n.funcName,
      isStretchy: r,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: h5,
  mathmlBuilder: Y6
});
re({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = e[0], r = n.parser.mode;
    return r === "math" && (n.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + n.funcName + " works only in text mode"), r = "text"), {
      type: "accent",
      mode: r,
      label: n.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: h5,
  mathmlBuilder: Y6
});
re({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: r,
      base: a
    };
  },
  htmlBuilder: (n, e) => {
    var t = Ge(n.base, e), r = Dr.svgSpan(n, e), a = n.label === "\\utilde" ? 0.12 : 0, i = I.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: r,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Dr.mathMLnode(n.label), r = new Y.MathNode("munder", [a0(n.base, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
var ca = (n) => {
  var e = new Y.MathNode("mpadded", n ? [n] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
re({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n;
    return {
      type: "xArrow",
      mode: r.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(n, e) {
    var t = e.style, r = e.havingStyle(t.sup()), a = I.wrapFragment(Ge(n.body, r, e), e), i = n.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    n.below && (r = e.havingStyle(t.sub()), l = I.wrapFragment(Ge(n.below, r, e), e), l.classes.push(i + "-arrow-pad"));
    var o = Dr.svgSpan(n, e), s = -e.fontMetrics().axisHeight + 0.5 * o.height, u = -e.fontMetrics().axisHeight - 0.5 * o.height - 0.111;
    (a.depth > 0.25 || n.label === "\\xleftequilibrium") && (u -= a.depth);
    var c;
    if (l) {
      var f = -e.fontMetrics().axisHeight + l.height + 0.5 * o.height + 0.111;
      c = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }, {
          type: "elem",
          elem: l,
          shift: f
        }]
      }, e);
    } else
      c = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }]
      }, e);
    return c.children[0].children[0].children[1].classes.push("svg-align"), I.makeSpan(["mrel", "x-arrow"], [c], e);
  },
  mathmlBuilder(n, e) {
    var t = Dr.mathMLnode(n.label);
    t.setAttribute("minsize", n.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var r;
    if (n.body) {
      var a = ca(a0(n.body, e));
      if (n.below) {
        var i = ca(a0(n.below, e));
        r = new Y.MathNode("munderover", [t, i, a]);
      } else
        r = new Y.MathNode("mover", [t, a]);
    } else if (n.below) {
      var l = ca(a0(n.below, e));
      r = new Y.MathNode("munder", [t, l]);
    } else
      r = ca(), r = new Y.MathNode("mover", [t, r]);
    return r;
  }
});
var xc = I.makeSpan;
function X6(n, e) {
  var t = U0(n.body, e, !0);
  return xc([n.mclass], t, e);
}
function K6(n, e) {
  var t, r = gt(n.body, e);
  return n.mclass === "minner" ? t = new Y.MathNode("mpadded", r) : n.mclass === "mord" ? n.isCharacterBox ? (t = r[0], t.type = "mi") : t = new Y.MathNode("mi", r) : (n.isCharacterBox ? (t = r[0], t.type = "mo") : t = new Y.MathNode("mo", r), n.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : n.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : n.mclass === "mopen" || n.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : n.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
re({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + r.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: w0(a),
      isCharacterBox: we.isCharacterBox(a)
    };
  },
  htmlBuilder: X6,
  mathmlBuilder: K6
});
var ii = (n) => {
  var e = n.type === "ordgroup" && n.body.length ? n.body[0] : n;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
re({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: ii(e[0]),
      body: w0(e[1]),
      isCharacterBox: we.isCharacterBox(e[1])
    };
  }
});
re({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[1], i = e[0], l;
    r !== "\\stackrel" ? l = ii(a) : l = "mrel";
    var o = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: r !== "\\stackrel",
      body: w0(a)
    }, s = {
      type: "supsub",
      mode: i.mode,
      base: o,
      sup: r === "\\underset" ? null : i,
      sub: r === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [s],
      isCharacterBox: we.isCharacterBox(s)
    };
  },
  htmlBuilder: X6,
  mathmlBuilder: K6
});
re({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: ii(e[0]),
      body: w0(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = U0(n.body, e, !0), r = I.makeSpan([n.mclass], t, e);
    return r.style.textShadow = "0.02em 0.01em 0.04px", r;
  },
  mathmlBuilder(n, e) {
    var t = gt(n.body, e), r = new Y.MathNode("mstyle", t);
    return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
  }
});
var Cc = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Ns = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), Rs = (n) => n.type === "textord" && n.text === "@", Tc = (n, e) => (n.type === "mathord" || n.type === "atom") && n.text === e;
function Qc(n, e, t) {
  var r = Cc[n];
  switch (r) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(r, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: r,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), o = t.callFunction("\\\\cdright", [e[1]], []), s = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, o]
      };
      return t.callFunction("\\\\cdparent", [s], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var u = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [u], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function Mc(n) {
  var e = [];
  for (n.gullet.beginGroup(), n.gullet.macros.set("\\cr", "\\\\\\relax"), n.gullet.beginGroup(); ; ) {
    e.push(n.parseExpression(!1, "\\\\")), n.gullet.endGroup(), n.gullet.beginGroup();
    var t = n.fetch().text;
    if (t === "&" || t === "\\\\")
      n.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new ge("Expected \\\\ or \\cr or \\end", n.nextToken);
  }
  for (var r = [], a = [r], i = 0; i < e.length; i++) {
    for (var l = e[i], o = Ns(), s = 0; s < l.length; s++)
      if (!Rs(l[s]))
        o.body.push(l[s]);
      else {
        r.push(o), s += 1;
        var u = c5(l[s]).text, c = new Array(2);
        if (c[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, c[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(u) > -1)) if ("<>AV".indexOf(u) > -1)
          for (var f = 0; f < 2; f++) {
            for (var d = !0, p = s + 1; p < l.length; p++) {
              if (Tc(l[p], u)) {
                d = !1, s = p;
                break;
              }
              if (Rs(l[p]))
                throw new ge("Missing a " + u + " character to complete a CD arrow.", l[p]);
              c[f].body.push(l[p]);
            }
            if (d)
              throw new ge("Missing a " + u + " character to complete a CD arrow.", l[s]);
          }
        else
          throw new ge('Expected one of "<>AV=|." after @', l[s]);
        var b = Qc(u, c, n), E = {
          type: "styling",
          body: [b],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        r.push(E), o = Ns();
      }
    i % 2 === 0 ? r.push(o) : r.shift(), r = [], a.push(r);
  }
  n.gullet.endGroup(), n.gullet.endGroup();
  var k = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: k,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
re({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: r.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = e.havingStyle(e.style.sup()), r = I.wrapFragment(Ge(n.label, t, e), e);
    return r.classes.push("cd-label-" + n.side), r.style.bottom = te(0.8 - r.depth), r.height = 0, r.depth = 0, r;
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mrow", [a0(n.label, e)]);
    return t = new Y.MathNode("mpadded", [t]), t.setAttribute("width", "0"), n.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new Y.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
re({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = I.wrapFragment(Ge(n.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mrow", [a0(n.fragment, e)]);
  }
});
re({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    for (var {
      parser: t
    } = n, r = ze(e[0], "ordgroup"), a = r.body, i = "", l = 0; l < a.length; l++) {
      var o = ze(a[l], "textord");
      i += o.text;
    }
    var s = parseInt(i), u;
    if (isNaN(s))
      throw new ge("\\@char has non-numeric argument " + i);
    if (s < 0 || s >= 1114111)
      throw new ge("\\@char with invalid code point " + i);
    return s <= 65535 ? u = String.fromCharCode(s) : (s -= 65536, u = String.fromCharCode((s >> 10) + 55296, (s & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: u
    };
  }
});
var J6 = (n, e) => {
  var t = U0(n.body, e.withColor(n.color), !1);
  return I.makeFragment(t);
}, $6 = (n, e) => {
  var t = gt(n.body, e.withColor(n.color)), r = new Y.MathNode("mstyle", t);
  return r.setAttribute("mathcolor", n.color), r;
};
re({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = ze(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: r,
      body: w0(a)
    };
  },
  htmlBuilder: J6,
  mathmlBuilder: $6
});
re({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(n, e) {
    var {
      parser: t,
      breakOnTokenText: r
    } = n, a = ze(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, r);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: J6,
  mathmlBuilder: $6
});
re({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, i = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: r.mode,
      newLine: i,
      size: a && ze(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(n, e) {
    var t = I.makeSpan(["mspace"], [], e);
    return n.newLine && (t.classes.push("newline"), n.size && (t.style.marginTop = te(m0(n.size, e)))), t;
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mspace");
    return n.newLine && (t.setAttribute("linebreak", "newline"), n.size && t.setAttribute("height", te(m0(n.size, e)))), t;
  }
});
var zl = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, e3 = (n) => {
  var e = n.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new ge("Expected a control sequence", n);
  return e;
}, Bc = (n) => {
  var e = n.gullet.popToken();
  return e.text === "=" && (e = n.gullet.popToken(), e.text === " " && (e = n.gullet.popToken())), e;
}, t3 = (n, e, t, r) => {
  var a = n.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !n.gullet.isExpandable(t.text)
  }), n.gullet.macros.set(e, a, r);
};
re({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    e.consumeSpaces();
    var r = e.fetch();
    if (zl[r.text])
      return (t === "\\global" || t === "\\\\globallong") && (r.text = zl[r.text]), ze(e.parseFunction(), "internal");
    throw new ge("Invalid token after macro prefix", r);
  }
});
re({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e.gullet.popToken(), a = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new ge("Expected a control sequence", r);
    for (var i = 0, l, o = [[]]; e.gullet.future().text !== "{"; )
      if (r = e.gullet.popToken(), r.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), o[i].push("{");
          break;
        }
        if (r = e.gullet.popToken(), !/^[1-9]$/.test(r.text))
          throw new ge('Invalid argument number "' + r.text + '"');
        if (parseInt(r.text) !== i + 1)
          throw new ge('Argument number "' + r.text + '" out of order');
        i++, o.push([]);
      } else {
        if (r.text === "EOF")
          throw new ge("Expected a macro definition");
        o[i].push(r.text);
      }
    var {
      tokens: s
    } = e.gullet.consumeArg();
    return l && s.unshift(l), (t === "\\edef" || t === "\\xdef") && (s = e.gullet.expandTokens(s), s.reverse()), e.gullet.macros.set(a, {
      tokens: s,
      numArgs: i,
      delimiters: o
    }, t === zl[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
re({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e3(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = Bc(e);
    return t3(e, r, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
re({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e3(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return t3(e, r, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var u1 = function(e, t, r) {
  var a = y0.math[e] && y0.math[e].replace, i = l5(a || e, t, r);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, f5 = function(e, t, r, a) {
  var i = r.havingBaseStyle(t), l = I.makeSpan(a.concat(i.sizingClasses(r)), [e], r), o = i.sizeMultiplier / r.sizeMultiplier;
  return l.height *= o, l.depth *= o, l.maxFontSize = i.sizeMultiplier, l;
}, r3 = function(e, t, r) {
  var a = t.havingBaseStyle(r), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = te(i), e.height -= i, e.depth += i;
}, zc = function(e, t, r, a, i, l) {
  var o = I.makeSymbol(e, "Main-Regular", i, a), s = f5(o, t, a, l);
  return r && r3(s, a, t), s;
}, Lc = function(e, t, r, a) {
  return I.makeSymbol(e, "Size" + t + "-Regular", r, a);
}, n3 = function(e, t, r, a, i, l) {
  var o = Lc(e, t, i, a), s = f5(I.makeSpan(["delimsizing", "size" + t], [o], a), ye.TEXT, a, l);
  return r && r3(s, a, ye.TEXT), s;
}, Yi = function(e, t, r) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = I.makeSpan(["delimsizinginner", a], [I.makeSpan([], [I.makeSymbol(e, t, r)])]);
  return {
    type: "elem",
    elem: i
  };
}, Xi = function(e, t, r) {
  var a = vr["Size4-Regular"][e.charCodeAt(0)] ? vr["Size4-Regular"][e.charCodeAt(0)][4] : vr["Size1-Regular"][e.charCodeAt(0)][4], i = new cn("inner", G7(e, Math.round(1e3 * t))), l = new Yr([i], {
    width: te(a),
    height: te(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + te(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), o = I.makeSvgSpan([], [l], r);
  return o.height = t, o.style.height = te(t), o.style.width = te(a), {
    type: "elem",
    elem: o
  };
}, Ll = 8e-3, ha = {
  type: "kern",
  size: -1 * Ll
}, Ic = ["|", "\\lvert", "\\rvert", "\\vert"], Nc = ["\\|", "\\lVert", "\\rVert", "\\Vert"], a3 = function(e, t, r, a, i, l) {
  var o, s, u, c, f = "", d = 0;
  o = u = c = e, s = null;
  var p = "Size1-Regular";
  e === "\\uparrow" ? u = c = "⏐" : e === "\\Uparrow" ? u = c = "‖" : e === "\\downarrow" ? o = u = "⏐" : e === "\\Downarrow" ? o = u = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", u = "⏐", c = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", u = "‖", c = "\\Downarrow") : we.contains(Ic, e) ? (u = "∣", f = "vert", d = 333) : we.contains(Nc, e) ? (u = "∥", f = "doublevert", d = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", u = "⎢", c = "⎣", p = "Size4-Regular", f = "lbrack", d = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", u = "⎥", c = "⎦", p = "Size4-Regular", f = "rbrack", d = 667) : e === "\\lfloor" || e === "⌊" ? (u = o = "⎢", c = "⎣", p = "Size4-Regular", f = "lfloor", d = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", u = c = "⎢", p = "Size4-Regular", f = "lceil", d = 667) : e === "\\rfloor" || e === "⌋" ? (u = o = "⎥", c = "⎦", p = "Size4-Regular", f = "rfloor", d = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", u = c = "⎥", p = "Size4-Regular", f = "rceil", d = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", u = "⎜", c = "⎝", p = "Size4-Regular", f = "lparen", d = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", u = "⎟", c = "⎠", p = "Size4-Regular", f = "rparen", d = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", c = "⎩", u = "⎪", p = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", c = "⎭", u = "⎪", p = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", c = "⎩", u = "⎪", p = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", c = "⎭", u = "⎪", p = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", c = "⎭", u = "⎪", p = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", c = "⎩", u = "⎪", p = "Size4-Regular");
  var b = u1(o, p, i), E = b.height + b.depth, k = u1(u, p, i), w = k.height + k.depth, v = u1(c, p, i), _ = v.height + v.depth, A = 0, x = 1;
  if (s !== null) {
    var Q = u1(s, p, i);
    A = Q.height + Q.depth, x = 2;
  }
  var z = E + _ + A, P = Math.max(0, Math.ceil((t - z) / (x * w))), B = z + P * x * w, N = a.fontMetrics().axisHeight;
  r && (N *= a.sizeMultiplier);
  var j = B / 2 - N, $ = [];
  if (f.length > 0) {
    var W = B - E - _, se = Math.round(B * 1e3), ke = W7(f, Math.round(W * 1e3)), Fe = new cn(f, ke), xe = (d / 1e3).toFixed(3) + "em", he = (se / 1e3).toFixed(3) + "em", Ee = new Yr([Fe], {
      width: xe,
      height: he,
      viewBox: "0 0 " + d + " " + se
    }), ie = I.makeSvgSpan([], [Ee], a);
    ie.height = se / 1e3, ie.style.width = xe, ie.style.height = he, $.push({
      type: "elem",
      elem: ie
    });
  } else {
    if ($.push(Yi(c, p, i)), $.push(ha), s === null) {
      var ce = B - E - _ + 2 * Ll;
      $.push(Xi(u, ce, a));
    } else {
      var ve = (B - E - _ - A) / 2 + 2 * Ll;
      $.push(Xi(u, ve, a)), $.push(ha), $.push(Yi(s, p, i)), $.push(ha), $.push(Xi(u, ve, a));
    }
    $.push(ha), $.push(Yi(o, p, i));
  }
  var oe = a.havingBaseStyle(ye.TEXT), me = I.makeVList({
    positionType: "bottom",
    positionData: j,
    children: $
  }, oe);
  return f5(I.makeSpan(["delimsizing", "mult"], [me], oe), ye.TEXT, a, l);
}, Ki = 80, Ji = 0.08, $i = function(e, t, r, a, i) {
  var l = j7(e, a, r), o = new cn(e, l), s = new Yr([o], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: te(t),
    viewBox: "0 0 400000 " + r,
    preserveAspectRatio: "xMinYMin slice"
  });
  return I.makeSvgSpan(["hide-tail"], [s], i);
}, Rc = function(e, t) {
  var r = t.havingBaseSizing(), a = o3("\\surd", e * r.sizeMultiplier, s3, r), i = r.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s = 0, u = 0, c = 0, f;
  return a.type === "small" ? (c = 1e3 + 1e3 * l + Ki, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), s = (1 + l + Ji) / i, u = (1 + l) / i, o = $i("sqrtMain", s, c, l, t), o.style.minWidth = "0.853em", f = 0.833 / i) : a.type === "large" ? (c = (1e3 + Ki) * h1[a.size], u = (h1[a.size] + l) / i, s = (h1[a.size] + l + Ji) / i, o = $i("sqrtSize" + a.size, s, c, l, t), o.style.minWidth = "1.02em", f = 1 / i) : (s = e + l + Ji, u = e + l, c = Math.floor(1e3 * e + l) + Ki, o = $i("sqrtTall", s, c, l, t), o.style.minWidth = "0.742em", f = 1.056), o.height = u, o.style.height = te(s), {
    span: o,
    advanceWidth: f,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, i3 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], Oc = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], l3 = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], h1 = [0, 1.2, 1.8, 2.4, 3], qc = function(e, t, r, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), we.contains(i3, e) || we.contains(l3, e))
    return n3(e, t, !1, r, a, i);
  if (we.contains(Oc, e))
    return a3(e, h1[t], !1, r, a, i);
  throw new ge("Illegal delimiter: '" + e + "'");
}, Pc = [{
  type: "small",
  style: ye.SCRIPTSCRIPT
}, {
  type: "small",
  style: ye.SCRIPT
}, {
  type: "small",
  style: ye.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], Hc = [{
  type: "small",
  style: ye.SCRIPTSCRIPT
}, {
  type: "small",
  style: ye.SCRIPT
}, {
  type: "small",
  style: ye.TEXT
}, {
  type: "stack"
}], s3 = [{
  type: "small",
  style: ye.SCRIPTSCRIPT
}, {
  type: "small",
  style: ye.SCRIPT
}, {
  type: "small",
  style: ye.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], Vc = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, o3 = function(e, t, r, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < r.length && r[l].type !== "stack"; l++) {
    var o = u1(e, Vc(r[l]), "math"), s = o.height + o.depth;
    if (r[l].type === "small") {
      var u = a.havingBaseStyle(r[l].style);
      s *= u.sizeMultiplier;
    }
    if (s > t)
      return r[l];
  }
  return r[r.length - 1];
}, u3 = function(e, t, r, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var o;
  we.contains(l3, e) ? o = Pc : we.contains(i3, e) ? o = s3 : o = Hc;
  var s = o3(e, t, o, a);
  return s.type === "small" ? zc(e, s.style, r, a, i, l) : s.type === "large" ? n3(e, s.size, r, a, i, l) : a3(e, t, r, a, i, l);
}, Uc = function(e, t, r, a, i, l) {
  var o = a.fontMetrics().axisHeight * a.sizeMultiplier, s = 901, u = 5 / a.fontMetrics().ptPerEm, c = Math.max(t - o, r + o), f = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    c / 500 * s,
    2 * c - u
  );
  return u3(e, f, !0, a, i, l);
}, yr = {
  sqrtImage: Rc,
  sizedDelim: qc,
  sizeToMaxHeight: h1,
  customSizedDelim: u3,
  leftRightDelim: Uc
}, Os = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, jc = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function li(n, e) {
  var t = ai(n);
  if (t && we.contains(jc, t.text))
    return t;
  throw t ? new ge("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", n) : new ge("Invalid delimiter type '" + n.type + "'", n);
}
re({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = li(e[0], n);
    return {
      type: "delimsizing",
      mode: n.parser.mode,
      size: Os[n.funcName].size,
      mclass: Os[n.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => n.delim === "." ? I.makeSpan([n.mclass]) : yr.sizedDelim(n.delim, n.size, e, n.mode, [n.mclass]),
  mathmlBuilder: (n) => {
    var e = [];
    n.delim !== "." && e.push(Ft(n.delim, n.mode));
    var t = new Y.MathNode("mo", e);
    n.mclass === "mopen" || n.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var r = te(yr.sizeToMaxHeight[n.size]);
    return t.setAttribute("minsize", r), t.setAttribute("maxsize", r), t;
  }
});
function qs(n) {
  if (!n.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
re({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = n.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new ge("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: n.parser.mode,
      delim: li(e[0], n).text,
      color: t
      // undefined if not set via \color
    };
  }
});
re({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = li(e[0], n), r = n.parser;
    ++r.leftrightDepth;
    var a = r.parseExpression(!1);
    --r.leftrightDepth, r.expect("\\right", !1);
    var i = ze(r.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: r.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (n, e) => {
    qs(n);
    for (var t = U0(n.body, e, !0, ["mopen", "mclose"]), r = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (r = Math.max(t[l].height, r), a = Math.max(t[l].depth, a));
    r *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var o;
    if (n.left === "." ? o = y1(e, ["mopen"]) : o = yr.leftRightDelim(n.left, r, a, e, n.mode, ["mopen"]), t.unshift(o), i)
      for (var s = 1; s < t.length; s++) {
        var u = t[s], c = u.isMiddle;
        c && (t[s] = yr.leftRightDelim(c.delim, r, a, c.options, n.mode, []));
      }
    var f;
    if (n.right === ".")
      f = y1(e, ["mclose"]);
    else {
      var d = n.rightColor ? e.withColor(n.rightColor) : e;
      f = yr.leftRightDelim(n.right, r, a, d, n.mode, ["mclose"]);
    }
    return t.push(f), I.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (n, e) => {
    qs(n);
    var t = gt(n.body, e);
    if (n.left !== ".") {
      var r = new Y.MathNode("mo", [Ft(n.left, n.mode)]);
      r.setAttribute("fence", "true"), t.unshift(r);
    }
    if (n.right !== ".") {
      var a = new Y.MathNode("mo", [Ft(n.right, n.mode)]);
      a.setAttribute("fence", "true"), n.rightColor && a.setAttribute("mathcolor", n.rightColor), t.push(a);
    }
    return o5(t);
  }
});
re({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = li(e[0], n);
    if (!n.parser.leftrightDepth)
      throw new ge("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: n.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    if (n.delim === ".")
      t = y1(e, []);
    else {
      t = yr.sizedDelim(n.delim, 1, e, n.mode, []);
      var r = {
        delim: n.delim,
        options: e
      };
      t.isMiddle = r;
    }
    return t;
  },
  mathmlBuilder: (n, e) => {
    var t = n.delim === "\\vert" || n.delim === "|" ? Ft("|", "text") : Ft(n.delim, n.mode), r = new Y.MathNode("mo", [t]);
    return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
  }
});
var d5 = (n, e) => {
  var t = I.wrapFragment(Ge(n.body, e), e), r = n.label.slice(1), a = e.sizeMultiplier, i, l = 0, o = we.isCharacterBox(n.body);
  if (r === "sout")
    i = I.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (r === "phase") {
    var s = m0({
      number: 0.6,
      unit: "pt"
    }, e), u = m0({
      number: 0.35,
      unit: "ex"
    }, e), c = e.havingBaseSizing();
    a = a / c.sizeMultiplier;
    var f = t.height + t.depth + s + u;
    t.style.paddingLeft = te(f / 2 + s);
    var d = Math.floor(1e3 * f * a), p = V7(d), b = new Yr([new cn("phase", p)], {
      width: "400em",
      height: te(d / 1e3),
      viewBox: "0 0 400000 " + d,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = I.makeSvgSpan(["hide-tail"], [b], e), i.style.height = te(f), l = t.depth + s + u;
  } else {
    /cancel/.test(r) ? o || t.classes.push("cancel-pad") : r === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var E = 0, k = 0, w = 0;
    /box/.test(r) ? (w = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), E = e.fontMetrics().fboxsep + (r === "colorbox" ? 0 : w), k = E) : r === "angl" ? (w = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), E = 4 * w, k = Math.max(0, 0.25 - t.depth)) : (E = o ? 0.2 : 0, k = E), i = Dr.encloseSpan(t, r, E, k, e), /fbox|boxed|fcolorbox/.test(r) ? (i.style.borderStyle = "solid", i.style.borderWidth = te(w)) : r === "angl" && w !== 0.049 && (i.style.borderTopWidth = te(w), i.style.borderRightWidth = te(w)), l = t.depth + k, n.backgroundColor && (i.style.backgroundColor = n.backgroundColor, n.borderColor && (i.style.borderColor = n.borderColor));
  }
  var v;
  if (n.backgroundColor)
    v = I.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var _ = /cancel|phase/.test(r) ? ["svg-align"] : [];
    v = I.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: _
        }
      ]
    }, e);
  }
  return /cancel/.test(r) && (v.height = t.height, v.depth = t.depth), /cancel/.test(r) && !o ? I.makeSpan(["mord", "cancel-lap"], [v], e) : I.makeSpan(["mord"], [v], e);
}, m5 = (n, e) => {
  var t = 0, r = new Y.MathNode(n.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [a0(n.body, e)]);
  switch (n.label) {
    case "\\cancel":
      r.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      r.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      r.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      r.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      r.setAttribute("notation", "box");
      break;
    case "\\angl":
      r.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * t + "pt"), r.setAttribute("height", "+" + 2 * t + "pt"), r.setAttribute("lspace", t + "pt"), r.setAttribute("voffset", t + "pt"), n.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        r.setAttribute("style", "border: " + a + "em solid " + String(n.borderColor));
      }
      break;
    case "\\xcancel":
      r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return n.backgroundColor && r.setAttribute("mathbackground", n.backgroundColor), r;
};
re({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = ze(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
re({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = ze(e[0], "color-token").color, l = ze(e[1], "color-token").color, o = e[2];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: o
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
re({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
re({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: r,
      body: a
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
re({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var c3 = {};
function cr(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, s = 0; s < t.length; ++s)
    c3[t[s]] = o;
  i && (La[e] = i), l && (Ia[e] = l);
}
var Gc = {};
function y(n, e) {
  Gc[n] = e;
}
function Ps(n) {
  var e = [];
  n.consumeSpaces();
  var t = n.fetch().text;
  for (t === "\\relax" && (n.consume(), n.consumeSpaces(), t = n.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    n.consume(), e.push(t === "\\hdashline"), n.consumeSpaces(), t = n.fetch().text;
  return e;
}
var si = (n) => {
  var e = n.parser.settings;
  if (!e.displayMode)
    throw new ge("{" + n.envName + "} can be used only in display mode.");
};
function p5(n) {
  if (n.indexOf("ed") === -1)
    return n.indexOf("*") === -1;
}
function Jr(n, e, t) {
  var {
    hskipBeforeAndAfter: r,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: o,
    autoTag: s,
    singleRow: u,
    emptySingleRow: c,
    maxNumCols: f,
    leqno: d
  } = e;
  if (n.gullet.beginGroup(), u || n.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var p = n.gullet.expandMacroAsText("\\arraystretch");
    if (p == null)
      l = 1;
    else if (l = parseFloat(p), !l || l < 0)
      throw new ge("Invalid \\arraystretch: " + p);
  }
  n.gullet.beginGroup();
  var b = [], E = [b], k = [], w = [], v = s != null ? [] : void 0;
  function _() {
    s && n.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function A() {
    v && (n.gullet.macros.get("\\df@tag") ? (v.push(n.subparse([new a5("\\df@tag")])), n.gullet.macros.set("\\df@tag", void 0, !0)) : v.push(!!s && n.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (_(), w.push(Ps(n)); ; ) {
    var x = n.parseExpression(!1, u ? "\\end" : "\\\\");
    n.gullet.endGroup(), n.gullet.beginGroup(), x = {
      type: "ordgroup",
      mode: n.mode,
      body: x
    }, t && (x = {
      type: "styling",
      mode: n.mode,
      style: t,
      body: [x]
    }), b.push(x);
    var Q = n.fetch().text;
    if (Q === "&") {
      if (f && b.length === f) {
        if (u || o)
          throw new ge("Too many tab characters: &", n.nextToken);
        n.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      n.consume();
    } else if (Q === "\\end") {
      A(), b.length === 1 && x.type === "styling" && x.body[0].body.length === 0 && (E.length > 1 || !c) && E.pop(), w.length < E.length + 1 && w.push([]);
      break;
    } else if (Q === "\\\\") {
      n.consume();
      var z = void 0;
      n.gullet.future().text !== " " && (z = n.parseSizeGroup(!0)), k.push(z ? z.value : null), A(), w.push(Ps(n)), b = [], E.push(b), _();
    } else
      throw new ge("Expected & or \\\\ or \\cr or \\end", n.nextToken);
  }
  return n.gullet.endGroup(), n.gullet.endGroup(), {
    type: "array",
    mode: n.mode,
    addJot: a,
    arraystretch: l,
    body: E,
    cols: i,
    rowGaps: k,
    hskipBeforeAndAfter: r,
    hLinesBeforeRow: w,
    colSeparationType: o,
    tags: v,
    leqno: d
  };
}
function g5(n) {
  return n.slice(0, 1) === "d" ? "display" : "text";
}
var hr = function(e, t) {
  var r, a, i = e.body.length, l = e.hLinesBeforeRow, o = 0, s = new Array(i), u = [], c = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), f = 1 / t.fontMetrics().ptPerEm, d = 5 * f;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var p = t.havingStyle(ye.SCRIPT).sizeMultiplier;
    d = 0.2778 * (p / t.sizeMultiplier);
  }
  var b = e.colSeparationType === "CD" ? m0({
    number: 3,
    unit: "ex"
  }, t) : 12 * f, E = 3 * f, k = e.arraystretch * b, w = 0.7 * k, v = 0.3 * k, _ = 0;
  function A(qe) {
    for (var Pe = 0; Pe < qe.length; ++Pe)
      Pe > 0 && (_ += 0.25), u.push({
        pos: _,
        isDashed: qe[Pe]
      });
  }
  for (A(l[0]), r = 0; r < e.body.length; ++r) {
    var x = e.body[r], Q = w, z = v;
    o < x.length && (o = x.length);
    var P = new Array(x.length);
    for (a = 0; a < x.length; ++a) {
      var B = Ge(x[a], t);
      z < B.depth && (z = B.depth), Q < B.height && (Q = B.height), P[a] = B;
    }
    var N = e.rowGaps[r], j = 0;
    N && (j = m0(N, t), j > 0 && (j += v, z < j && (z = j), j = 0)), e.addJot && (z += E), P.height = Q, P.depth = z, _ += Q, P.pos = _, _ += z + j, s[r] = P, A(l[r + 1]);
  }
  var $ = _ / 2 + t.fontMetrics().axisHeight, W = e.cols || [], se = [], ke, Fe, xe = [];
  if (e.tags && e.tags.some((qe) => qe))
    for (r = 0; r < i; ++r) {
      var he = s[r], Ee = he.pos - $, ie = e.tags[r], ce = void 0;
      ie === !0 ? ce = I.makeSpan(["eqn-num"], [], t) : ie === !1 ? ce = I.makeSpan([], [], t) : ce = I.makeSpan([], U0(ie, t, !0), t), ce.depth = he.depth, ce.height = he.height, xe.push({
        type: "elem",
        elem: ce,
        shift: Ee
      });
    }
  for (
    a = 0, Fe = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < o || Fe < W.length;
    ++a, ++Fe
  ) {
    for (var ve = W[Fe] || {}, oe = !0; ve.type === "separator"; ) {
      if (oe || (ke = I.makeSpan(["arraycolsep"], []), ke.style.width = te(t.fontMetrics().doubleRuleSep), se.push(ke)), ve.separator === "|" || ve.separator === ":") {
        var me = ve.separator === "|" ? "solid" : "dashed", U = I.makeSpan(["vertical-separator"], [], t);
        U.style.height = te(_), U.style.borderRightWidth = te(c), U.style.borderRightStyle = me, U.style.margin = "0 " + te(-c / 2);
        var He = _ - $;
        He && (U.style.verticalAlign = te(-He)), se.push(U);
      } else
        throw new ge("Invalid separator type: " + ve.separator);
      Fe++, ve = W[Fe] || {}, oe = !1;
    }
    if (!(a >= o)) {
      var ne = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (ne = we.deflt(ve.pregap, d), ne !== 0 && (ke = I.makeSpan(["arraycolsep"], []), ke.style.width = te(ne), se.push(ke)));
      var fe = [];
      for (r = 0; r < i; ++r) {
        var Z = s[r], Qe = Z[a];
        if (Qe) {
          var Le = Z.pos - $;
          Qe.depth = Z.depth, Qe.height = Z.height, fe.push({
            type: "elem",
            elem: Qe,
            shift: Le
          });
        }
      }
      fe = I.makeVList({
        positionType: "individualShift",
        children: fe
      }, t), fe = I.makeSpan(["col-align-" + (ve.align || "c")], [fe]), se.push(fe), (a < o - 1 || e.hskipBeforeAndAfter) && (ne = we.deflt(ve.postgap, d), ne !== 0 && (ke = I.makeSpan(["arraycolsep"], []), ke.style.width = te(ne), se.push(ke)));
    }
  }
  if (s = I.makeSpan(["mtable"], se), u.length > 0) {
    for (var Ne = I.makeLineSpan("hline", t, c), Ie = I.makeLineSpan("hdashline", t, c), Ve = [{
      type: "elem",
      elem: s,
      shift: 0
    }]; u.length > 0; ) {
      var Ce = u.pop(), b0 = Ce.pos - $;
      Ce.isDashed ? Ve.push({
        type: "elem",
        elem: Ie,
        shift: b0
      }) : Ve.push({
        type: "elem",
        elem: Ne,
        shift: b0
      });
    }
    s = I.makeVList({
      positionType: "individualShift",
      children: Ve
    }, t);
  }
  if (xe.length === 0)
    return I.makeSpan(["mord"], [s], t);
  var K = I.makeVList({
    positionType: "individualShift",
    children: xe
  }, t);
  return K = I.makeSpan(["tag"], [K], t), I.makeFragment([s, K]);
}, Wc = {
  c: "center ",
  l: "left ",
  r: "right "
}, fr = function(e, t) {
  for (var r = [], a = new Y.MathNode("mtd", [], ["mtr-glue"]), i = new Y.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var o = e.body[l], s = [], u = 0; u < o.length; u++)
      s.push(new Y.MathNode("mtd", [a0(o[u], t)]));
    e.tags && e.tags[l] && (s.unshift(a), s.push(a), e.leqno ? s.unshift(i) : s.push(i)), r.push(new Y.MathNode("mtr", s));
  }
  var c = new Y.MathNode("mtable", r), f = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  c.setAttribute("rowspacing", te(f));
  var d = "", p = "";
  if (e.cols && e.cols.length > 0) {
    var b = e.cols, E = "", k = !1, w = 0, v = b.length;
    b[0].type === "separator" && (d += "top ", w = 1), b[b.length - 1].type === "separator" && (d += "bottom ", v -= 1);
    for (var _ = w; _ < v; _++)
      b[_].type === "align" ? (p += Wc[b[_].align], k && (E += "none "), k = !0) : b[_].type === "separator" && k && (E += b[_].separator === "|" ? "solid " : "dashed ", k = !1);
    c.setAttribute("columnalign", p.trim()), /[sd]/.test(E) && c.setAttribute("columnlines", E.trim());
  }
  if (e.colSeparationType === "align") {
    for (var A = e.cols || [], x = "", Q = 1; Q < A.length; Q++)
      x += Q % 2 ? "0em " : "1em ";
    c.setAttribute("columnspacing", x.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? c.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? c.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? c.setAttribute("columnspacing", "0.5em") : c.setAttribute("columnspacing", "1em");
  var z = "", P = e.hLinesBeforeRow;
  d += P[0].length > 0 ? "left " : "", d += P[P.length - 1].length > 0 ? "right " : "";
  for (var B = 1; B < P.length - 1; B++)
    z += P[B].length === 0 ? "none " : P[B][0] ? "dashed " : "solid ";
  return /[sd]/.test(z) && c.setAttribute("rowlines", z.trim()), d !== "" && (c = new Y.MathNode("menclose", [c]), c.setAttribute("notation", d.trim())), e.arraystretch && e.arraystretch < 1 && (c = new Y.MathNode("mstyle", [c]), c.setAttribute("scriptlevel", "1")), c;
}, h3 = function(e, t) {
  e.envName.indexOf("ed") === -1 && si(e);
  var r = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = Jr(e.parser, {
    cols: r,
    addJot: !0,
    autoTag: i ? void 0 : p5(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), o, s = 0, u = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var c = "", f = 0; f < t[0].body.length; f++) {
      var d = ze(t[0].body[f], "textord");
      c += d.text;
    }
    o = Number(c), s = o * 2;
  }
  var p = !s;
  l.body.forEach(function(w) {
    for (var v = 1; v < w.length; v += 2) {
      var _ = ze(w[v], "styling"), A = ze(_.body[0], "ordgroup");
      A.body.unshift(u);
    }
    if (p)
      s < w.length && (s = w.length);
    else {
      var x = w.length / 2;
      if (o < x)
        throw new ge("Too many math in a row: " + ("expected " + o + ", but got " + x), w[0]);
    }
  });
  for (var b = 0; b < s; ++b) {
    var E = "r", k = 0;
    b % 2 === 1 ? E = "l" : b > 0 && p && (k = 1), r[b] = {
      type: "align",
      align: E,
      pregap: k,
      postgap: 0
    };
  }
  return l.colSeparationType = p ? "align" : "alignat", l;
};
cr({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = ai(e[0]), r = t ? [e[0]] : ze(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = c5(l), s = o.text;
      if ("lcr".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      if (s === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (s === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new ge("Unknown column alignment: " + s, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return Jr(n.parser, i, g5(n.envName));
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[n.envName.replace("*", "")], t = "c", r = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (n.envName.charAt(n.envName.length - 1) === "*") {
      var a = n.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new ge("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), r.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = Jr(n.parser, r, g5(n.envName)), l = Math.max(0, ...i.body.map((o) => o.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: n.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 0.5
    }, t = Jr(n.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = ai(e[0]), r = t ? [e[0]] : ze(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = c5(l), s = o.text;
      if ("lc".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      throw new ge("Unknown column alignment: " + s, l);
    });
    if (a.length > 1)
      throw new ge("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = Jr(n.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new ge("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = Jr(n.parser, e, g5(n.envName));
    return {
      type: "leftright",
      mode: n.mode,
      body: [t],
      left: n.envName.indexOf("r") > -1 ? "." : "\\{",
      right: n.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: h3,
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    we.contains(["gather", "gather*"], n.envName) && si(n);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: p5(n.envName),
      emptySingleRow: !0,
      leqno: n.parser.settings.leqno
    };
    return Jr(n.parser, e, "display");
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: h3,
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    si(n);
    var e = {
      autoTag: p5(n.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: n.parser.settings.leqno
    };
    return Jr(n.parser, e, "display");
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
cr({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(n) {
    return si(n), Mc(n.parser);
  },
  htmlBuilder: hr,
  mathmlBuilder: fr
});
y("\\nonumber", "\\gdef\\@eqnsw{0}");
y("\\notag", "\\nonumber");
re({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(n, e) {
    throw new ge(n.funcName + " valid only within array environment");
  }
});
var Hs = c3;
re({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    if (a.type !== "ordgroup")
      throw new ge("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += ze(a.body[l], "textord").text;
    if (r === "\\begin") {
      if (!Hs.hasOwnProperty(i))
        throw new ge("No such environment: " + i, a);
      var o = Hs[i], {
        args: s,
        optArgs: u
      } = t.parseArguments("\\begin{" + i + "}", o), c = {
        mode: t.mode,
        envName: i,
        parser: t
      }, f = o.handler(c, s, u);
      t.expect("\\end", !1);
      var d = t.nextToken, p = ze(t.parseFunction(), "environment");
      if (p.name !== i)
        throw new ge("Mismatch: \\begin{" + i + "} matched by \\end{" + p.name + "}", d);
      return f;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var f3 = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return Ge(n.body, r);
}, d3 = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return a0(n.body, r);
}, Vs = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
re({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = Na(e[0]), i = r;
    return i in Vs && (i = Vs[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: f3,
  mathmlBuilder: d3
});
re({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0], a = we.isCharacterBox(r);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: ii(r),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: r
      }],
      isCharacterBox: a
    };
  }
});
re({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      breakOnTokenText: a
    } = n, {
      mode: i
    } = t, l = t.parseExpression(!0, a), o = "math" + r.slice(1);
    return {
      type: "font",
      mode: i,
      font: o,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: f3,
  mathmlBuilder: d3
});
var m3 = (n, e) => {
  var t = e;
  return n === "display" ? t = t.id >= ye.SCRIPT.id ? t.text() : ye.DISPLAY : n === "text" && t.size === ye.DISPLAY.size ? t = ye.TEXT : n === "script" ? t = ye.SCRIPT : n === "scriptscript" && (t = ye.SCRIPTSCRIPT), t;
}, _5 = (n, e) => {
  var t = m3(n.size, e.style), r = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(r);
  var l = Ge(n.numer, i, e);
  if (n.continued) {
    var o = 8.5 / e.fontMetrics().ptPerEm, s = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < o ? o : l.height, l.depth = l.depth < s ? s : l.depth;
  }
  i = e.havingStyle(a);
  var u = Ge(n.denom, i, e), c, f, d;
  n.hasBarLine ? (n.barSize ? (f = m0(n.barSize, e), c = I.makeLineSpan("frac-line", e, f)) : c = I.makeLineSpan("frac-line", e), f = c.height, d = c.height) : (c = null, f = 0, d = e.fontMetrics().defaultRuleThickness);
  var p, b, E;
  t.size === ye.DISPLAY.size || n.size === "display" ? (p = e.fontMetrics().num1, f > 0 ? b = 3 * d : b = 7 * d, E = e.fontMetrics().denom1) : (f > 0 ? (p = e.fontMetrics().num2, b = d) : (p = e.fontMetrics().num3, b = 3 * d), E = e.fontMetrics().denom2);
  var k;
  if (c) {
    var v = e.fontMetrics().axisHeight;
    p - l.depth - (v + 0.5 * f) < b && (p += b - (p - l.depth - (v + 0.5 * f))), v - 0.5 * f - (u.height - E) < b && (E += b - (v - 0.5 * f - (u.height - E)));
    var _ = -(v - 0.5 * f);
    k = I.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: E
      }, {
        type: "elem",
        elem: c,
        shift: _
      }, {
        type: "elem",
        elem: l,
        shift: -p
      }]
    }, e);
  } else {
    var w = p - l.depth - (u.height - E);
    w < b && (p += 0.5 * (b - w), E += 0.5 * (b - w)), k = I.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: E
      }, {
        type: "elem",
        elem: l,
        shift: -p
      }]
    }, e);
  }
  i = e.havingStyle(t), k.height *= i.sizeMultiplier / e.sizeMultiplier, k.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var A;
  t.size === ye.DISPLAY.size ? A = e.fontMetrics().delim1 : t.size === ye.SCRIPTSCRIPT.size ? A = e.havingStyle(ye.SCRIPT).fontMetrics().delim2 : A = e.fontMetrics().delim2;
  var x, Q;
  return n.leftDelim == null ? x = y1(e, ["mopen"]) : x = yr.customSizedDelim(n.leftDelim, A, !0, e.havingStyle(t), n.mode, ["mopen"]), n.continued ? Q = I.makeSpan([]) : n.rightDelim == null ? Q = y1(e, ["mclose"]) : Q = yr.customSizedDelim(n.rightDelim, A, !0, e.havingStyle(t), n.mode, ["mclose"]), I.makeSpan(["mord"].concat(i.sizingClasses(e)), [x, I.makeSpan(["mfrac"], [k]), Q], e);
}, v5 = (n, e) => {
  var t = new Y.MathNode("mfrac", [a0(n.numer, e), a0(n.denom, e)]);
  if (!n.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (n.barSize) {
    var r = m0(n.barSize, e);
    t.setAttribute("linethickness", te(r));
  }
  var a = m3(n.size, e.style);
  if (a.size !== e.style.size) {
    t = new Y.MathNode("mstyle", [t]);
    var i = a.size === ye.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (n.leftDelim != null || n.rightDelim != null) {
    var l = [];
    if (n.leftDelim != null) {
      var o = new Y.MathNode("mo", [new Y.TextNode(n.leftDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    if (l.push(t), n.rightDelim != null) {
      var s = new Y.MathNode("mo", [new Y.TextNode(n.rightDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    return o5(l);
  }
  return t;
};
re({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1], l, o = null, s = null, u = "auto";
    switch (r) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, o = "(", s = ")";
        break;
      case "\\\\bracefrac":
        l = !1, o = "\\{", s = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, o = "[", s = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (r) {
      case "\\dfrac":
      case "\\dbinom":
        u = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        u = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: o,
      rightDelim: s,
      size: u,
      barSize: null
    };
  },
  htmlBuilder: _5,
  mathmlBuilder: v5
});
re({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
re({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t,
      token: r
    } = n, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: r
    };
  }
});
var Us = ["display", "text", "script", "scriptscript"], js = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
re({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[4], a = e[5], i = Na(e[0]), l = i.type === "atom" && i.family === "open" ? js(i.text) : null, o = Na(e[1]), s = o.type === "atom" && o.family === "close" ? js(o.text) : null, u = ze(e[2], "size"), c, f = null;
    u.isBlank ? c = !0 : (f = u.value, c = f.number > 0);
    var d = "auto", p = e[3];
    if (p.type === "ordgroup") {
      if (p.body.length > 0) {
        var b = ze(p.body[0], "textord");
        d = Us[Number(b.text)];
      }
    } else
      p = ze(p, "textord"), d = Us[Number(p.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: r,
      denom: a,
      continued: !1,
      hasBarLine: c,
      barSize: f,
      leftDelim: l,
      rightDelim: s,
      size: d
    };
  },
  htmlBuilder: _5,
  mathmlBuilder: v5
});
re({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: ze(e[0], "size").value,
      token: a
    };
  }
});
re({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = x7(ze(e[1], "infix").size), l = e[2], o = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: o,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: _5,
  mathmlBuilder: v5
});
var p3 = (n, e) => {
  var t = e.style, r, a;
  n.type === "supsub" ? (r = n.sup ? Ge(n.sup, e.havingStyle(t.sup()), e) : Ge(n.sub, e.havingStyle(t.sub()), e), a = ze(n.base, "horizBrace")) : a = ze(n, "horizBrace");
  var i = Ge(a.base, e.havingBaseStyle(ye.DISPLAY)), l = Dr.svgSpan(a, e), o;
  if (a.isOver ? (o = I.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), o.children[0].children[0].children[1].classes.push("svg-align")) : (o = I.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), o.children[0].children[0].children[0].classes.push("svg-align")), r) {
    var s = I.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
    a.isOver ? o = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: r
      }]
    }, e) : o = I.makeVList({
      positionType: "bottom",
      positionData: s.depth + 0.2 + r.height + r.depth,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: s
      }]
    }, e);
  }
  return I.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
}, Zc = (n, e) => {
  var t = Dr.mathMLnode(n.label);
  return new Y.MathNode(n.isOver ? "mover" : "munder", [a0(n.base, e), t]);
};
re({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: r,
      isOver: /^\\over/.test(r),
      base: e[0]
    };
  },
  htmlBuilder: p3,
  mathmlBuilder: Zc
});
re({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[1], a = ze(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: w0(r)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e, !1);
    return I.makeAnchor(n.href, [], t, e);
  },
  mathmlBuilder: (n, e) => {
    var t = Xr(n.body, e);
    return t instanceof qt || (t = new qt("mrow", [t])), t.setAttribute("href", n.href), t;
  }
});
re({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = ze(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: r
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < r.length; i++) {
      var l = r[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var o = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: r,
      body: w0(o)
    };
  }
});
re({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "hbox",
      mode: t.mode,
      body: w0(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = U0(n.body, e, !1);
    return I.makeFragment(t);
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mrow", gt(n.body, e));
  }
});
re({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n, i = ze(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var o, s = {};
    switch (r) {
      case "\\htmlClass":
        s.class = i, o = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        s.id = i, o = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        s.style = i, o = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var u = i.split(","), c = 0; c < u.length; c++) {
          var f = u[c].split("=");
          if (f.length !== 2)
            throw new ge("Error parsing key-value for \\htmlData");
          s["data-" + f[0].trim()] = f[1].trim();
        }
        o = {
          command: "\\htmlData",
          attributes: s
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(o) ? {
      type: "html",
      mode: t.mode,
      attributes: s,
      body: w0(l)
    } : t.formatUnsupportedCmd(r);
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e, !1), r = ["enclosing"];
    n.attributes.class && r.push(...n.attributes.class.trim().split(/\s+/));
    var a = I.makeSpan(r, t, e);
    for (var i in n.attributes)
      i !== "class" && n.attributes.hasOwnProperty(i) && a.setAttribute(i, n.attributes[i]);
    return a;
  },
  mathmlBuilder: (n, e) => Xr(n.body, e)
});
re({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: w0(e[0]),
      mathml: w0(e[1])
    };
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.html, e, !1);
    return I.makeFragment(t);
  },
  mathmlBuilder: (n, e) => Xr(n.mathml, e)
});
var el = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new ge("Invalid size: '" + e + "' in \\includegraphics");
  var r = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!Y7(r))
    throw new ge("Invalid unit: '" + r.unit + "' in \\includegraphics.");
  return r;
};
re({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, o = "";
    if (t[0])
      for (var s = ze(t[0], "raw").string, u = s.split(","), c = 0; c < u.length; c++) {
        var f = u[c].split("=");
        if (f.length === 2) {
          var d = f[1].trim();
          switch (f[0].trim()) {
            case "alt":
              o = d;
              break;
            case "width":
              a = el(d);
              break;
            case "height":
              i = el(d);
              break;
            case "totalheight":
              l = el(d);
              break;
            default:
              throw new ge("Invalid key: '" + f[0] + "' in \\includegraphics.");
          }
        }
      }
    var p = ze(e[0], "url").url;
    return o === "" && (o = p, o = o.replace(/^.*[\\/]/, ""), o = o.substring(0, o.lastIndexOf("."))), r.settings.isTrusted({
      command: "\\includegraphics",
      url: p
    }) ? {
      type: "includegraphics",
      mode: r.mode,
      alt: o,
      width: a,
      height: i,
      totalheight: l,
      src: p
    } : r.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (n, e) => {
    var t = m0(n.height, e), r = 0;
    n.totalheight.number > 0 && (r = m0(n.totalheight, e) - t);
    var a = 0;
    n.width.number > 0 && (a = m0(n.width, e));
    var i = {
      height: te(t + r)
    };
    a > 0 && (i.width = te(a)), r > 0 && (i.verticalAlign = te(-r));
    var l = new X7(n.src, n.alt, i);
    return l.height = t, l.depth = r, l;
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mglyph", []);
    t.setAttribute("alt", n.alt);
    var r = m0(n.height, e), a = 0;
    if (n.totalheight.number > 0 && (a = m0(n.totalheight, e) - r, t.setAttribute("valign", te(-a))), t.setAttribute("height", te(r + a)), n.width.number > 0) {
      var i = m0(n.width, e);
      t.setAttribute("width", te(i));
    }
    return t.setAttribute("src", n.src), t;
  }
});
re({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = ze(e[0], "size");
    if (t.settings.strict) {
      var i = r[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(n, e) {
    return I.makeGlue(n.dimension, e);
  },
  mathmlBuilder(n, e) {
    var t = m0(n.dimension, e);
    return new Y.SpaceNode(t);
  }
});
re({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: r.slice(5),
      body: a
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    n.alignment === "clap" ? (t = I.makeSpan([], [Ge(n.body, e)]), t = I.makeSpan(["inner"], [t], e)) : t = I.makeSpan(["inner"], [Ge(n.body, e)]);
    var r = I.makeSpan(["fix"], []), a = I.makeSpan([n.alignment], [t, r], e), i = I.makeSpan(["strut"]);
    return i.style.height = te(a.height + a.depth), a.depth && (i.style.verticalAlign = te(-a.depth)), a.children.unshift(i), a = I.makeSpan(["thinbox"], [a], e), I.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mpadded", [a0(n.body, e)]);
    if (n.alignment !== "rlap") {
      var r = n.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", r + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
re({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    var {
      funcName: t,
      parser: r
    } = n, a = r.mode;
    r.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = r.parseExpression(!1, i);
    return r.expect(i), r.switchMode(a), {
      type: "styling",
      mode: r.mode,
      style: "text",
      body: l
    };
  }
});
re({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    throw new ge("Mismatched " + n.funcName);
  }
});
var Gs = (n, e) => {
  switch (e.style.size) {
    case ye.DISPLAY.size:
      return n.display;
    case ye.TEXT.size:
      return n.text;
    case ye.SCRIPT.size:
      return n.script;
    case ye.SCRIPTSCRIPT.size:
      return n.scriptscript;
    default:
      return n.text;
  }
};
re({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: w0(e[0]),
      text: w0(e[1]),
      script: w0(e[2]),
      scriptscript: w0(e[3])
    };
  },
  htmlBuilder: (n, e) => {
    var t = Gs(n, e), r = U0(t, e, !1);
    return I.makeFragment(r);
  },
  mathmlBuilder: (n, e) => {
    var t = Gs(n, e);
    return Xr(t, e);
  }
});
var g3 = (n, e, t, r, a, i, l) => {
  n = I.makeSpan([], [n]);
  var o = t && we.isCharacterBox(t), s, u;
  if (e) {
    var c = Ge(e, r.havingStyle(a.sup()), r);
    u = {
      elem: c,
      kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - c.depth)
    };
  }
  if (t) {
    var f = Ge(t, r.havingStyle(a.sub()), r);
    s = {
      elem: f,
      kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - f.height)
    };
  }
  var d;
  if (u && s) {
    var p = r.fontMetrics().bigOpSpacing5 + s.elem.height + s.elem.depth + s.kern + n.depth + l;
    d = I.makeVList({
      positionType: "bottom",
      positionData: p,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: te(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: te(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else if (s) {
    var b = n.height - l;
    d = I.makeVList({
      positionType: "top",
      positionData: b,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: te(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: n
      }]
    }, r);
  } else if (u) {
    var E = n.depth + l;
    d = I.makeVList({
      positionType: "bottom",
      positionData: E,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: te(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else
    return n;
  var k = [d];
  if (s && i !== 0 && !o) {
    var w = I.makeSpan(["mspace"], [], r);
    w.style.marginRight = te(i), k.unshift(w);
  }
  return I.makeSpan(["mop", "op-limits"], k, r);
}, _3 = ["\\smallint"], Hn = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = ze(n.base, "op"), a = !0) : i = ze(n, "op");
  var l = e.style, o = !1;
  l.size === ye.DISPLAY.size && i.symbol && !we.contains(_3, i.name) && (o = !0);
  var s;
  if (i.symbol) {
    var u = o ? "Size2-Regular" : "Size1-Regular", c = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (c = i.name.slice(1), i.name = c === "oiint" ? "\\iint" : "\\iiint"), s = I.makeSymbol(i.name, u, "math", e, ["mop", "op-symbol", o ? "large-op" : "small-op"]), c.length > 0) {
      var f = s.italic, d = I.staticSvg(c + "Size" + (o ? "2" : "1"), e);
      s = I.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: s,
          shift: 0
        }, {
          type: "elem",
          elem: d,
          shift: o ? 0.08 : 0
        }]
      }, e), i.name = "\\" + c, s.classes.unshift("mop"), s.italic = f;
    }
  } else if (i.body) {
    var p = U0(i.body, e, !0);
    p.length === 1 && p[0] instanceof ur ? (s = p[0], s.classes[0] = "mop") : s = I.makeSpan(["mop"], p, e);
  } else {
    for (var b = [], E = 1; E < i.name.length; E++)
      b.push(I.mathsym(i.name[E], i.mode, e));
    s = I.makeSpan(["mop"], b, e);
  }
  var k = 0, w = 0;
  return (s instanceof ur || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (k = (s.height - s.depth) / 2 - e.fontMetrics().axisHeight, w = s.italic), a ? g3(s, t, r, e, l, w, k) : (k && (s.style.position = "relative", s.style.top = te(k)), s);
}, T1 = (n, e) => {
  var t;
  if (n.symbol)
    t = new qt("mo", [Ft(n.name, n.mode)]), we.contains(_3, n.name) && t.setAttribute("largeop", "false");
  else if (n.body)
    t = new qt("mo", gt(n.body, e));
  else {
    t = new qt("mi", [new c1(n.name.slice(1))]);
    var r = new qt("mo", [Ft("⁡", "text")]);
    n.parentIsSupSub ? t = new qt("mrow", [t, r]) : t = Z6([t, r]);
  }
  return t;
}, Yc = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
re({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = r;
    return a.length === 1 && (a = Yc[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: T1
});
re({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: w0(r)
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: T1
});
var Xc = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
re({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: T1
});
re({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: T1
});
re({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = t;
    return r.length === 1 && (r = Xc[r]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: r
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: T1
});
var v3 = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = ze(n.base, "operatorname"), a = !0) : i = ze(n, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var o = i.body.map((f) => {
      var d = f.text;
      return typeof d == "string" ? {
        type: "textord",
        mode: f.mode,
        text: d
      } : f;
    }), s = U0(o, e.withFont("mathrm"), !0), u = 0; u < s.length; u++) {
      var c = s[u];
      c instanceof ur && (c.text = c.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = I.makeSpan(["mop"], s, e);
  } else
    l = I.makeSpan(["mop"], [], e);
  return a ? g3(l, t, r, e, e.style, 0, 0) : l;
}, Kc = (n, e) => {
  for (var t = gt(n.body, e.withFont("mathrm")), r = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof Y.SpaceNode)) if (i instanceof Y.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof Y.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
          break;
        }
        default:
          r = !1;
      }
    else
      r = !1;
  }
  if (r) {
    var o = t.map((c) => c.toText()).join("");
    t = [new Y.TextNode(o)];
  }
  var s = new Y.MathNode("mi", t);
  s.setAttribute("mathvariant", "normal");
  var u = new Y.MathNode("mo", [Ft("⁡", "text")]);
  return n.parentIsSupSub ? new Y.MathNode("mrow", [s, u]) : Y.newDocumentFragment([s, u]);
};
re({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: w0(a),
      alwaysHandleSupSub: r === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: v3,
  mathmlBuilder: Kc
});
y("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
vn({
  type: "ordgroup",
  htmlBuilder(n, e) {
    return n.semisimple ? I.makeFragment(U0(n.body, e, !1)) : I.makeSpan(["mord"], U0(n.body, e, !0), e);
  },
  mathmlBuilder(n, e) {
    return Xr(n.body, e, !0);
  }
});
re({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder(n, e) {
    var t = Ge(n.body, e.havingCrampedStyle()), r = I.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return I.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [new Y.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new Y.MathNode("mover", [a0(n.body, e), t]);
    return r.setAttribute("accent", "true"), r;
  }
});
re({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: w0(r)
    };
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e.withPhantom(), !1);
    return I.makeFragment(t);
  },
  mathmlBuilder: (n, e) => {
    var t = gt(n.body, e);
    return new Y.MathNode("mphantom", t);
  }
});
re({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = I.makeSpan([], [Ge(n.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0, t.children[r].depth = 0;
    return t = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), I.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (n, e) => {
    var t = gt(w0(n.body), e), r = new Y.MathNode("mphantom", t), a = new Y.MathNode("mpadded", [r]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
re({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = I.makeSpan(["inner"], [Ge(n.body, e.withPhantom())]), r = I.makeSpan(["fix"], []);
    return I.makeSpan(["mord", "rlap"], [t, r], e);
  },
  mathmlBuilder: (n, e) => {
    var t = gt(w0(n.body), e), r = new Y.MathNode("mphantom", t), a = new Y.MathNode("mpadded", [r]);
    return a.setAttribute("width", "0px"), a;
  }
});
re({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = ze(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: r,
      body: a
    };
  },
  htmlBuilder(n, e) {
    var t = Ge(n.body, e), r = m0(n.dy, e);
    return I.makeVList({
      positionType: "shift",
      positionData: -r,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mpadded", [a0(n.body, e)]), r = n.dy.number + n.dy.unit;
    return t.setAttribute("voffset", r), t;
  }
});
re({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e
    } = n;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
re({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    argTypes: ["size", "size", "size"]
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = ze(e[0], "size"), l = ze(e[1], "size");
    return {
      type: "rule",
      mode: r.mode,
      shift: a && ze(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(n, e) {
    var t = I.makeSpan(["mord", "rule"], [], e), r = m0(n.width, e), a = m0(n.height, e), i = n.shift ? m0(n.shift, e) : 0;
    return t.style.borderRightWidth = te(r), t.style.borderTopWidth = te(a), t.style.bottom = te(i), t.width = r, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(n, e) {
    var t = m0(n.width, e), r = m0(n.height, e), a = n.shift ? m0(n.shift, e) : 0, i = e.color && e.getColor() || "black", l = new Y.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", te(t)), l.setAttribute("height", te(r));
    var o = new Y.MathNode("mpadded", [l]);
    return a >= 0 ? o.setAttribute("height", te(a)) : (o.setAttribute("height", te(a)), o.setAttribute("depth", te(-a))), o.setAttribute("voffset", te(a)), o;
  }
});
function b3(n, e, t) {
  for (var r = U0(n, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < r.length; i++) {
    var l = r[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(r[i].classes, e.sizingClasses(t)) : r[i].classes[l + 1] === "reset-size" + e.size && (r[i].classes[l + 1] = "reset-size" + t.size), r[i].height *= a, r[i].depth *= a;
  }
  return I.makeFragment(r);
}
var Ws = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], Jc = (n, e) => {
  var t = e.havingSize(n.size);
  return b3(n.body, t, e);
};
re({
  type: "sizing",
  names: Ws,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: Ws.indexOf(r) + 1,
      body: i
    };
  },
  htmlBuilder: Jc,
  mathmlBuilder: (n, e) => {
    var t = e.havingSize(n.size), r = gt(n.body, t), a = new Y.MathNode("mstyle", r);
    return a.setAttribute("mathsize", te(t.sizeMultiplier)), a;
  }
});
re({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = !1, i = !1, l = t[0] && ze(t[0], "ordgroup");
    if (l)
      for (var o = "", s = 0; s < l.body.length; ++s) {
        var u = l.body[s];
        if (o = u.text, o === "t")
          a = !0;
        else if (o === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var c = e[0];
    return {
      type: "smash",
      mode: r.mode,
      body: c,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (n, e) => {
    var t = I.makeSpan([], [Ge(n.body, e)]);
    if (!n.smashHeight && !n.smashDepth)
      return t;
    if (n.smashHeight && (t.height = 0, t.children))
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0;
    if (n.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mpadded", [a0(n.body, e)]);
    return n.smashHeight && t.setAttribute("height", "0px"), n.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
re({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: r.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(n, e) {
    var t = Ge(n.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = I.wrapFragment(t, e);
    var r = e.fontMetrics(), a = r.defaultRuleThickness, i = a;
    e.style.id < ye.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, o = t.height + t.depth + l + a, {
      span: s,
      ruleWidth: u,
      advanceWidth: c
    } = yr.sqrtImage(o, e), f = s.height - u;
    f > t.height + t.depth + l && (l = (l + f - t.height - t.depth) / 2);
    var d = s.height - t.height - l - u;
    t.style.paddingLeft = te(c);
    var p = I.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + d)
      }, {
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: u
      }]
    }, e);
    if (n.index) {
      var b = e.havingStyle(ye.SCRIPTSCRIPT), E = Ge(n.index, b, e), k = 0.6 * (p.height - p.depth), w = I.makeVList({
        positionType: "shift",
        positionData: -k,
        children: [{
          type: "elem",
          elem: E
        }]
      }, e), v = I.makeSpan(["root"], [w]);
      return I.makeSpan(["mord", "sqrt"], [v, p], e);
    } else
      return I.makeSpan(["mord", "sqrt"], [p], e);
  },
  mathmlBuilder(n, e) {
    var {
      body: t,
      index: r
    } = n;
    return r ? new Y.MathNode("mroot", [a0(t, e), a0(r, e)]) : new Y.MathNode("msqrt", [a0(t, e)]);
  }
});
var Zs = {
  display: ye.DISPLAY,
  text: ye.TEXT,
  script: ye.SCRIPT,
  scriptscript: ye.SCRIPTSCRIPT
};
re({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!0, t), l = r.slice(1, r.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(n, e) {
    var t = Zs[n.style], r = e.havingStyle(t).withFont("");
    return b3(n.body, r, e);
  },
  mathmlBuilder(n, e) {
    var t = Zs[n.style], r = e.havingStyle(t), a = gt(n.body, r), i = new Y.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, o = l[n.style];
    return i.setAttribute("scriptlevel", o[0]), i.setAttribute("displaystyle", o[1]), i;
  }
});
var $c = function(e, t) {
  var r = e.base;
  if (r)
    if (r.type === "op") {
      var a = r.limits && (t.style.size === ye.DISPLAY.size || r.alwaysHandleSupSub);
      return a ? Hn : null;
    } else if (r.type === "operatorname") {
      var i = r.alwaysHandleSupSub && (t.style.size === ye.DISPLAY.size || r.limits);
      return i ? v3 : null;
    } else {
      if (r.type === "accent")
        return we.isCharacterBox(r.base) ? h5 : null;
      if (r.type === "horizBrace") {
        var l = !e.sub;
        return l === r.isOver ? p3 : null;
      } else
        return null;
    }
  else return null;
};
vn({
  type: "supsub",
  htmlBuilder(n, e) {
    var t = $c(n, e);
    if (t)
      return t(n, e);
    var {
      base: r,
      sup: a,
      sub: i
    } = n, l = Ge(r, e), o, s, u = e.fontMetrics(), c = 0, f = 0, d = r && we.isCharacterBox(r);
    if (a) {
      var p = e.havingStyle(e.style.sup());
      o = Ge(a, p, e), d || (c = l.height - p.fontMetrics().supDrop * p.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var b = e.havingStyle(e.style.sub());
      s = Ge(i, b, e), d || (f = l.depth + b.fontMetrics().subDrop * b.sizeMultiplier / e.sizeMultiplier);
    }
    var E;
    e.style === ye.DISPLAY ? E = u.sup1 : e.style.cramped ? E = u.sup3 : E = u.sup2;
    var k = e.sizeMultiplier, w = te(0.5 / u.ptPerEm / k), v = null;
    if (s) {
      var _ = n.base && n.base.type === "op" && n.base.name && (n.base.name === "\\oiint" || n.base.name === "\\oiiint");
      (l instanceof ur || _) && (v = te(-l.italic));
    }
    var A;
    if (o && s) {
      c = Math.max(c, E, o.depth + 0.25 * u.xHeight), f = Math.max(f, u.sub2);
      var x = u.defaultRuleThickness, Q = 4 * x;
      if (c - o.depth - (s.height - f) < Q) {
        f = Q - (c - o.depth) + s.height;
        var z = 0.8 * u.xHeight - (c - o.depth);
        z > 0 && (c += z, f -= z);
      }
      var P = [{
        type: "elem",
        elem: s,
        shift: f,
        marginRight: w,
        marginLeft: v
      }, {
        type: "elem",
        elem: o,
        shift: -c,
        marginRight: w
      }];
      A = I.makeVList({
        positionType: "individualShift",
        children: P
      }, e);
    } else if (s) {
      f = Math.max(f, u.sub1, s.height - 0.8 * u.xHeight);
      var B = [{
        type: "elem",
        elem: s,
        marginLeft: v,
        marginRight: w
      }];
      A = I.makeVList({
        positionType: "shift",
        positionData: f,
        children: B
      }, e);
    } else if (o)
      c = Math.max(c, E, o.depth + 0.25 * u.xHeight), A = I.makeVList({
        positionType: "shift",
        positionData: -c,
        children: [{
          type: "elem",
          elem: o,
          marginRight: w
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var N = Bl(l, "right") || "mord";
    return I.makeSpan([N], [l, I.makeSpan(["msupsub"], [A])], e);
  },
  mathmlBuilder(n, e) {
    var t = !1, r, a;
    n.base && n.base.type === "horizBrace" && (a = !!n.sup, a === n.base.isOver && (t = !0, r = n.base.isOver)), n.base && (n.base.type === "op" || n.base.type === "operatorname") && (n.base.parentIsSupSub = !0);
    var i = [a0(n.base, e)];
    n.sub && i.push(a0(n.sub, e)), n.sup && i.push(a0(n.sup, e));
    var l;
    if (t)
      l = r ? "mover" : "munder";
    else if (n.sub)
      if (n.sup) {
        var u = n.base;
        u && u.type === "op" && u.limits && e.style === ye.DISPLAY || u && u.type === "operatorname" && u.alwaysHandleSupSub && (e.style === ye.DISPLAY || u.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var s = n.base;
        s && s.type === "op" && s.limits && (e.style === ye.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === ye.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var o = n.base;
      o && o.type === "op" && o.limits && (e.style === ye.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === ye.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new Y.MathNode(l, i);
  }
});
vn({
  type: "atom",
  htmlBuilder(n, e) {
    return I.mathsym(n.text, n.mode, e, ["m" + n.family]);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [Ft(n.text, n.mode)]);
    if (n.family === "bin") {
      var r = u5(n, e);
      r === "bold-italic" && t.setAttribute("mathvariant", r);
    } else n.family === "punct" ? t.setAttribute("separator", "true") : (n.family === "open" || n.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var w3 = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
vn({
  type: "mathord",
  htmlBuilder(n, e) {
    return I.makeOrd(n, e, "mathord");
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mi", [Ft(n.text, n.mode, e)]), r = u5(n, e) || "italic";
    return r !== w3[t.type] && t.setAttribute("mathvariant", r), t;
  }
});
vn({
  type: "textord",
  htmlBuilder(n, e) {
    return I.makeOrd(n, e, "textord");
  },
  mathmlBuilder(n, e) {
    var t = Ft(n.text, n.mode, e), r = u5(n, e) || "normal", a;
    return n.mode === "text" ? a = new Y.MathNode("mtext", [t]) : /[0-9]/.test(n.text) ? a = new Y.MathNode("mn", [t]) : n.text === "\\prime" ? a = new Y.MathNode("mo", [t]) : a = new Y.MathNode("mi", [t]), r !== w3[a.type] && a.setAttribute("mathvariant", r), a;
  }
});
var tl = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, rl = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
vn({
  type: "spacing",
  htmlBuilder(n, e) {
    if (rl.hasOwnProperty(n.text)) {
      var t = rl[n.text].className || "";
      if (n.mode === "text") {
        var r = I.makeOrd(n, e, "textord");
        return r.classes.push(t), r;
      } else
        return I.makeSpan(["mspace", t], [I.mathsym(n.text, n.mode, e)], e);
    } else {
      if (tl.hasOwnProperty(n.text))
        return I.makeSpan(["mspace", tl[n.text]], [], e);
      throw new ge('Unknown type of space "' + n.text + '"');
    }
  },
  mathmlBuilder(n, e) {
    var t;
    if (rl.hasOwnProperty(n.text))
      t = new Y.MathNode("mtext", [new Y.TextNode(" ")]);
    else {
      if (tl.hasOwnProperty(n.text))
        return new Y.MathNode("mspace");
      throw new ge('Unknown type of space "' + n.text + '"');
    }
    return t;
  }
});
var Ys = () => {
  var n = new Y.MathNode("mtd", []);
  return n.setAttribute("width", "50%"), n;
};
vn({
  type: "tag",
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mtable", [new Y.MathNode("mtr", [Ys(), new Y.MathNode("mtd", [Xr(n.body, e)]), Ys(), new Y.MathNode("mtd", [Xr(n.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var Xs = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Ks = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, e9 = {
  "\\textit": "textit",
  "\\textup": "textup"
}, Js = (n, e) => {
  var t = n.font;
  if (t) {
    if (Xs[t])
      return e.withTextFontFamily(Xs[t]);
    if (Ks[t])
      return e.withTextFontWeight(Ks[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(e9[t]);
};
re({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: w0(a),
      font: r
    };
  },
  htmlBuilder(n, e) {
    var t = Js(n, e), r = U0(n.body, t, !0);
    return I.makeSpan(["mord", "text"], r, t);
  },
  mathmlBuilder(n, e) {
    var t = Js(n, e);
    return Xr(n.body, t);
  }
});
re({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = Ge(n.body, e), r = I.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = I.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return I.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [new Y.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new Y.MathNode("munder", [a0(n.body, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
re({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = Ge(n.body, e), r = e.fontMetrics().axisHeight, a = 0.5 * (t.height - r - (t.depth + r));
    return I.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mpadded", [a0(n.body, e)], ["vcenter"]);
  }
});
re({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    throw new ge("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(n, e) {
    for (var t = $s(n), r = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), r.push(I.makeSymbol(l, "Typewriter-Regular", n.mode, a, ["mord", "texttt"]));
    }
    return I.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), I.tryCombineChars(r), a);
  },
  mathmlBuilder(n, e) {
    var t = new Y.TextNode($s(n)), r = new Y.MathNode("mtext", [t]);
    return r.setAttribute("mathvariant", "monospace"), r;
  }
});
var $s = (n) => n.body.replace(/ /g, n.star ? "␣" : " "), t9 = G6;
y("\\noexpand", function(n) {
  var e = n.popToken();
  return n.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
y("\\expandafter", function(n) {
  var e = n.popToken();
  return n.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
y("\\@firstoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
y("\\@secondoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
y("\\@ifnextchar", function(n) {
  var e = n.consumeArgs(3);
  n.consumeSpaces();
  var t = n.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
y("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
y("\\TextOrMath", function(n) {
  var e = n.consumeArgs(2);
  return n.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var eo = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
y("\\char", function(n) {
  var e = n.popToken(), t, r = "";
  if (e.text === "'")
    t = 8, e = n.popToken();
  else if (e.text === '"')
    t = 16, e = n.popToken();
  else if (e.text === "`")
    if (e = n.popToken(), e.text[0] === "\\")
      r = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new ge("\\char` missing argument");
      r = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (r = eo[e.text], r == null || r >= t)
      throw new ge("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = eo[n.future().text]) != null && a < t; )
      r *= t, r += a, n.popToken();
  }
  return "\\@char{" + r + "}";
});
var b5 = (n, e, t) => {
  var r = n.consumeArg().tokens;
  if (r.length !== 1)
    throw new ge("\\newcommand's first argument must be a macro name");
  var a = r[0].text, i = n.isDefined(a);
  if (i && !e)
    throw new ge("\\newcommand{" + a + "} attempting to redefine " + (a + "; use \\renewcommand"));
  if (!i && !t)
    throw new ge("\\renewcommand{" + a + "} when command " + a + " does not yet exist; use \\newcommand");
  var l = 0;
  if (r = n.consumeArg().tokens, r.length === 1 && r[0].text === "[") {
    for (var o = "", s = n.expandNextToken(); s.text !== "]" && s.text !== "EOF"; )
      o += s.text, s = n.expandNextToken();
    if (!o.match(/^\s*[0-9]+\s*$/))
      throw new ge("Invalid number of arguments: " + o);
    l = parseInt(o), r = n.consumeArg().tokens;
  }
  return n.macros.set(a, {
    tokens: r,
    numArgs: l
  }), "";
};
y("\\newcommand", (n) => b5(n, !1, !0));
y("\\renewcommand", (n) => b5(n, !0, !1));
y("\\providecommand", (n) => b5(n, !0, !0));
y("\\message", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
y("\\errmessage", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
y("\\show", (n) => {
  var e = n.popToken(), t = e.text;
  return console.log(e, n.macros.get(t), t9[t], y0.math[t], y0.text[t]), "";
});
y("\\bgroup", "{");
y("\\egroup", "}");
y("~", "\\nobreakspace");
y("\\lq", "`");
y("\\rq", "'");
y("\\aa", "\\r a");
y("\\AA", "\\r A");
y("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
y("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
y("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
y("ℬ", "\\mathscr{B}");
y("ℰ", "\\mathscr{E}");
y("ℱ", "\\mathscr{F}");
y("ℋ", "\\mathscr{H}");
y("ℐ", "\\mathscr{I}");
y("ℒ", "\\mathscr{L}");
y("ℳ", "\\mathscr{M}");
y("ℛ", "\\mathscr{R}");
y("ℭ", "\\mathfrak{C}");
y("ℌ", "\\mathfrak{H}");
y("ℨ", "\\mathfrak{Z}");
y("\\Bbbk", "\\Bbb{k}");
y("·", "\\cdotp");
y("\\llap", "\\mathllap{\\textrm{#1}}");
y("\\rlap", "\\mathrlap{\\textrm{#1}}");
y("\\clap", "\\mathclap{\\textrm{#1}}");
y("\\mathstrut", "\\vphantom{(}");
y("\\underbar", "\\underline{\\text{#1}}");
y("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
y("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
y("\\ne", "\\neq");
y("≠", "\\neq");
y("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
y("∉", "\\notin");
y("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
y("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
y("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
y("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
y("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
y("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
y("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
y("⟂", "\\perp");
y("‼", "\\mathclose{!\\mkern-0.8mu!}");
y("∌", "\\notni");
y("⌜", "\\ulcorner");
y("⌝", "\\urcorner");
y("⌞", "\\llcorner");
y("⌟", "\\lrcorner");
y("©", "\\copyright");
y("®", "\\textregistered");
y("️", "\\textregistered");
y("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
y("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
y("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
y("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
y("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}");
y("⋮", "\\vdots");
y("\\varGamma", "\\mathit{\\Gamma}");
y("\\varDelta", "\\mathit{\\Delta}");
y("\\varTheta", "\\mathit{\\Theta}");
y("\\varLambda", "\\mathit{\\Lambda}");
y("\\varXi", "\\mathit{\\Xi}");
y("\\varPi", "\\mathit{\\Pi}");
y("\\varSigma", "\\mathit{\\Sigma}");
y("\\varUpsilon", "\\mathit{\\Upsilon}");
y("\\varPhi", "\\mathit{\\Phi}");
y("\\varPsi", "\\mathit{\\Psi}");
y("\\varOmega", "\\mathit{\\Omega}");
y("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
y("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
y("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
y("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
y("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
y("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
var to = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
y("\\dots", function(n) {
  var e = "\\dotso", t = n.expandAfterFuture().text;
  return t in to ? e = to[t] : (t.slice(0, 4) === "\\not" || t in y0.math && we.contains(["bin", "rel"], y0.math[t].group)) && (e = "\\dotsb"), e;
});
var w5 = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
y("\\dotso", function(n) {
  var e = n.future().text;
  return e in w5 ? "\\ldots\\," : "\\ldots";
});
y("\\dotsc", function(n) {
  var e = n.future().text;
  return e in w5 && e !== "," ? "\\ldots\\," : "\\ldots";
});
y("\\cdots", function(n) {
  var e = n.future().text;
  return e in w5 ? "\\@cdots\\," : "\\@cdots";
});
y("\\dotsb", "\\cdots");
y("\\dotsm", "\\cdots");
y("\\dotsi", "\\!\\cdots");
y("\\dotsx", "\\ldots\\,");
y("\\DOTSI", "\\relax");
y("\\DOTSB", "\\relax");
y("\\DOTSX", "\\relax");
y("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
y("\\,", "\\tmspace+{3mu}{.1667em}");
y("\\thinspace", "\\,");
y("\\>", "\\mskip{4mu}");
y("\\:", "\\tmspace+{4mu}{.2222em}");
y("\\medspace", "\\:");
y("\\;", "\\tmspace+{5mu}{.2777em}");
y("\\thickspace", "\\;");
y("\\!", "\\tmspace-{3mu}{.1667em}");
y("\\negthinspace", "\\!");
y("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
y("\\negthickspace", "\\tmspace-{5mu}{.277em}");
y("\\enspace", "\\kern.5em ");
y("\\enskip", "\\hskip.5em\\relax");
y("\\quad", "\\hskip1em\\relax");
y("\\qquad", "\\hskip2em\\relax");
y("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
y("\\tag@paren", "\\tag@literal{({#1})}");
y("\\tag@literal", (n) => {
  if (n.macros.get("\\df@tag"))
    throw new ge("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
y("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
y("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
y("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
y("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
y("\\newline", "\\\\\\relax");
y("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var y3 = te(vr["Main-Regular"][84][1] - 0.7 * vr["Main-Regular"][65][1]);
y("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + y3 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
y("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + y3 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
y("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
y("\\@hspace", "\\hskip #1\\relax");
y("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
y("\\ordinarycolon", ":");
y("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
y("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
y("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
y("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
y("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
y("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
y("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
y("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
y("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
y("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
y("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
y("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
y("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
y("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
y("∷", "\\dblcolon");
y("∹", "\\eqcolon");
y("≔", "\\coloneqq");
y("≕", "\\eqqcolon");
y("⩴", "\\Coloneqq");
y("\\ratio", "\\vcentcolon");
y("\\coloncolon", "\\dblcolon");
y("\\colonequals", "\\coloneqq");
y("\\coloncolonequals", "\\Coloneqq");
y("\\equalscolon", "\\eqqcolon");
y("\\equalscoloncolon", "\\Eqqcolon");
y("\\colonminus", "\\coloneq");
y("\\coloncolonminus", "\\Coloneq");
y("\\minuscolon", "\\eqcolon");
y("\\minuscoloncolon", "\\Eqcolon");
y("\\coloncolonapprox", "\\Colonapprox");
y("\\coloncolonsim", "\\Colonsim");
y("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
y("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
y("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
y("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
y("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
y("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
y("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
y("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
y("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
y("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
y("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
y("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
y("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
y("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
y("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
y("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
y("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
y("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
y("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
y("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
y("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
y("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
y("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
y("\\imath", "\\html@mathml{\\@imath}{ı}");
y("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
y("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
y("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
y("⟦", "\\llbracket");
y("⟧", "\\rrbracket");
y("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
y("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
y("⦃", "\\lBrace");
y("⦄", "\\rBrace");
y("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
y("⦵", "\\minuso");
y("\\darr", "\\downarrow");
y("\\dArr", "\\Downarrow");
y("\\Darr", "\\Downarrow");
y("\\lang", "\\langle");
y("\\rang", "\\rangle");
y("\\uarr", "\\uparrow");
y("\\uArr", "\\Uparrow");
y("\\Uarr", "\\Uparrow");
y("\\N", "\\mathbb{N}");
y("\\R", "\\mathbb{R}");
y("\\Z", "\\mathbb{Z}");
y("\\alef", "\\aleph");
y("\\alefsym", "\\aleph");
y("\\Alpha", "\\mathrm{A}");
y("\\Beta", "\\mathrm{B}");
y("\\bull", "\\bullet");
y("\\Chi", "\\mathrm{X}");
y("\\clubs", "\\clubsuit");
y("\\cnums", "\\mathbb{C}");
y("\\Complex", "\\mathbb{C}");
y("\\Dagger", "\\ddagger");
y("\\diamonds", "\\diamondsuit");
y("\\empty", "\\emptyset");
y("\\Epsilon", "\\mathrm{E}");
y("\\Eta", "\\mathrm{H}");
y("\\exist", "\\exists");
y("\\harr", "\\leftrightarrow");
y("\\hArr", "\\Leftrightarrow");
y("\\Harr", "\\Leftrightarrow");
y("\\hearts", "\\heartsuit");
y("\\image", "\\Im");
y("\\infin", "\\infty");
y("\\Iota", "\\mathrm{I}");
y("\\isin", "\\in");
y("\\Kappa", "\\mathrm{K}");
y("\\larr", "\\leftarrow");
y("\\lArr", "\\Leftarrow");
y("\\Larr", "\\Leftarrow");
y("\\lrarr", "\\leftrightarrow");
y("\\lrArr", "\\Leftrightarrow");
y("\\Lrarr", "\\Leftrightarrow");
y("\\Mu", "\\mathrm{M}");
y("\\natnums", "\\mathbb{N}");
y("\\Nu", "\\mathrm{N}");
y("\\Omicron", "\\mathrm{O}");
y("\\plusmn", "\\pm");
y("\\rarr", "\\rightarrow");
y("\\rArr", "\\Rightarrow");
y("\\Rarr", "\\Rightarrow");
y("\\real", "\\Re");
y("\\reals", "\\mathbb{R}");
y("\\Reals", "\\mathbb{R}");
y("\\Rho", "\\mathrm{P}");
y("\\sdot", "\\cdot");
y("\\sect", "\\S");
y("\\spades", "\\spadesuit");
y("\\sub", "\\subset");
y("\\sube", "\\subseteq");
y("\\supe", "\\supseteq");
y("\\Tau", "\\mathrm{T}");
y("\\thetasym", "\\vartheta");
y("\\weierp", "\\wp");
y("\\Zeta", "\\mathrm{Z}");
y("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
y("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
y("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
y("\\bra", "\\mathinner{\\langle{#1}|}");
y("\\ket", "\\mathinner{|{#1}\\rangle}");
y("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
y("\\Bra", "\\left\\langle#1\\right|");
y("\\Ket", "\\left|#1\\right\\rangle");
var k3 = (n) => (e) => {
  var t = e.consumeArg().tokens, r = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), o = e.macros.get("\\|");
  e.macros.beginGroup();
  var s = (f) => (d) => {
    n && (d.macros.set("|", l), a.length && d.macros.set("\\|", o));
    var p = f;
    if (!f && a.length) {
      var b = d.future();
      b.text === "|" && (d.popToken(), p = !0);
    }
    return {
      tokens: p ? a : r,
      numArgs: 0
    };
  };
  e.macros.set("|", s(!1)), a.length && e.macros.set("\\|", s(!0));
  var u = e.consumeArg().tokens, c = e.expandTokens([
    ...i,
    ...u,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: c.reverse(),
    numArgs: 0
  };
};
y("\\bra@ket", k3(!1));
y("\\bra@set", k3(!0));
y("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
y("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
y("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
y("\\angln", "{\\angl n}");
y("\\blue", "\\textcolor{##6495ed}{#1}");
y("\\orange", "\\textcolor{##ffa500}{#1}");
y("\\pink", "\\textcolor{##ff00af}{#1}");
y("\\red", "\\textcolor{##df0030}{#1}");
y("\\green", "\\textcolor{##28ae7b}{#1}");
y("\\gray", "\\textcolor{gray}{#1}");
y("\\purple", "\\textcolor{##9d38bd}{#1}");
y("\\blueA", "\\textcolor{##ccfaff}{#1}");
y("\\blueB", "\\textcolor{##80f6ff}{#1}");
y("\\blueC", "\\textcolor{##63d9ea}{#1}");
y("\\blueD", "\\textcolor{##11accd}{#1}");
y("\\blueE", "\\textcolor{##0c7f99}{#1}");
y("\\tealA", "\\textcolor{##94fff5}{#1}");
y("\\tealB", "\\textcolor{##26edd5}{#1}");
y("\\tealC", "\\textcolor{##01d1c1}{#1}");
y("\\tealD", "\\textcolor{##01a995}{#1}");
y("\\tealE", "\\textcolor{##208170}{#1}");
y("\\greenA", "\\textcolor{##b6ffb0}{#1}");
y("\\greenB", "\\textcolor{##8af281}{#1}");
y("\\greenC", "\\textcolor{##74cf70}{#1}");
y("\\greenD", "\\textcolor{##1fab54}{#1}");
y("\\greenE", "\\textcolor{##0d923f}{#1}");
y("\\goldA", "\\textcolor{##ffd0a9}{#1}");
y("\\goldB", "\\textcolor{##ffbb71}{#1}");
y("\\goldC", "\\textcolor{##ff9c39}{#1}");
y("\\goldD", "\\textcolor{##e07d10}{#1}");
y("\\goldE", "\\textcolor{##a75a05}{#1}");
y("\\redA", "\\textcolor{##fca9a9}{#1}");
y("\\redB", "\\textcolor{##ff8482}{#1}");
y("\\redC", "\\textcolor{##f9685d}{#1}");
y("\\redD", "\\textcolor{##e84d39}{#1}");
y("\\redE", "\\textcolor{##bc2612}{#1}");
y("\\maroonA", "\\textcolor{##ffbde0}{#1}");
y("\\maroonB", "\\textcolor{##ff92c6}{#1}");
y("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
y("\\maroonD", "\\textcolor{##ca337c}{#1}");
y("\\maroonE", "\\textcolor{##9e034e}{#1}");
y("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
y("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
y("\\purpleC", "\\textcolor{##aa87ff}{#1}");
y("\\purpleD", "\\textcolor{##7854ab}{#1}");
y("\\purpleE", "\\textcolor{##543b78}{#1}");
y("\\mintA", "\\textcolor{##f5f9e8}{#1}");
y("\\mintB", "\\textcolor{##edf2df}{#1}");
y("\\mintC", "\\textcolor{##e0e5cc}{#1}");
y("\\grayA", "\\textcolor{##f6f7f7}{#1}");
y("\\grayB", "\\textcolor{##f0f1f2}{#1}");
y("\\grayC", "\\textcolor{##e3e5e6}{#1}");
y("\\grayD", "\\textcolor{##d6d8da}{#1}");
y("\\grayE", "\\textcolor{##babec2}{#1}");
y("\\grayF", "\\textcolor{##888d93}{#1}");
y("\\grayG", "\\textcolor{##626569}{#1}");
y("\\grayH", "\\textcolor{##3b3e40}{#1}");
y("\\grayI", "\\textcolor{##21242c}{#1}");
y("\\kaBlue", "\\textcolor{##314453}{#1}");
y("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function y5() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let bn = y5();
function D3(n) {
  bn = n;
}
const E3 = /[&<>"']/, r9 = new RegExp(E3.source, "g"), A3 = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, n9 = new RegExp(A3.source, "g"), a9 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ro = (n) => a9[n];
function ht(n, e) {
  if (e) {
    if (E3.test(n))
      return n.replace(r9, ro);
  } else if (A3.test(n))
    return n.replace(n9, ro);
  return n;
}
const i9 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function l9(n) {
  return n.replace(i9, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const s9 = /(^|[^\[])\^/g;
function r0(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(s9, "$1"), t = t.replace(a, l), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function no(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const f1 = { exec: () => null };
function ao(n, e) {
  const t = n.replace(/\|/g, (i, l, o) => {
    let s = !1, u = l;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), r = t.split(/ \|/);
  let a = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; a < r.length; a++)
    r[a] = r[a].trim().replace(/\\\|/g, "|");
  return r;
}
function fa(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let a = 0;
  for (; a < r; ) {
    const i = n.charAt(r - a - 1);
    if (i === e && !t)
      a++;
    else if (i !== e && t)
      a++;
    else
      break;
  }
  return n.slice(0, r - a);
}
function o9(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function io(n, e, t, r) {
  const a = e.href, i = e.title ? ht(e.title) : null, l = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: r.inlineTokens(l)
    };
    return r.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: ht(l)
  };
}
function u9(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= r.length ? a.slice(r.length) : a;
  }).join(`
`);
}
class Ra {
  // set by the lexer
  constructor(e) {
    u0(this, "options");
    u0(this, "rules");
    // set by the lexer
    u0(this, "lexer");
    this.options = e || bn;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : fa(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], a = u9(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const a = fa(r, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (r = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = fa(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(r);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const a = r.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = a ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = a ? r : "[*+-]");
      const l = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (w) => " ".repeat(3 * w.length)), d = e.split(`
`, 1)[0], p = 0;
        this.options.pedantic ? (p = 2, s = f.trimStart()) : (p = t[2].search(/[^ ]/), p = p > 4 ? 1 : p, s = f.slice(p), p += t[1].length);
        let b = !1;
        if (!f && /^ *$/.test(d) && (o += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const w = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), v = new RegExp(`^ {0,${Math.min(3, p - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:\`\`\`|~~~)`), A = new RegExp(`^ {0,${Math.min(3, p - 1)}}#`);
          for (; e; ) {
            const x = e.split(`
`, 1)[0];
            if (d = x, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || A.test(d) || w.test(d) || v.test(e))
              break;
            if (d.search(/[^ ]/) >= p || !d.trim())
              s += `
` + d.slice(p);
            else {
              if (b || f.search(/[^ ]/) >= 4 || _.test(f) || A.test(f) || v.test(f))
                break;
              s += `
` + d;
            }
            !b && !d.trim() && (b = !0), o += x + `
`, e = e.substring(x.length + 1), f = d.slice(p);
          }
        }
        i.loose || (u ? i.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let E = null, k;
        this.options.gfm && (E = /^\[[ xX]\] /.exec(s), E && (k = E[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: o,
          task: !!E,
          checked: k,
          loose: !1,
          text: s,
          tokens: []
        }), i.raw += o;
      }
      i.items[i.items.length - 1].raw = o.trimEnd(), i.items[i.items.length - 1].text = s.trimEnd(), i.raw = i.raw.trimEnd();
      for (let c = 0; c < i.items.length; c++)
        if (this.lexer.state.top = !1, i.items[c].tokens = this.lexer.blockTokens(i.items[c].text, []), !i.loose) {
          const f = i.items[c].tokens.filter((p) => p.type === "space"), d = f.length > 0 && f.some((p) => /\n.*\n/.test(p.raw));
          i.loose = d;
        }
      if (i.loose)
        for (let c = 0; c < i.items.length; c++)
          i.items[c].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = ao(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === a.length) {
      for (const o of a)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of r)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of i)
        l.rows.push(ao(o, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: ht(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const l = fa(r.slice(0, -1), "\\");
        if ((r.length - l.length) % 2 === 0)
          return;
      } else {
        const l = o9(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(r) ? a = a.slice(1) : a = a.slice(1, -1)), io(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const a = (r[2] || r[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = r[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return io(r, i, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const l = [...a[0]].length - 1;
      let o, s, u = l, c = 0;
      const f = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = f.exec(t)) != null; ) {
        if (o = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !o)
          continue;
        if (s = [...o].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...a[0]][0].length, p = e.slice(0, l + a.index + d + s);
        if (Math.min(l, s) % 2) {
          const E = p.slice(1, -1);
          return {
            type: "em",
            raw: p,
            text: E,
            tokens: this.lexer.inlineTokens(E)
          };
        }
        const b = p.slice(2, -2);
        return {
          type: "strong",
          raw: p,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(r), i = /^ /.test(r) && / $/.test(r);
      return a && i && (r = r.substring(1, r.length - 1)), r = ht(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, a;
      return t[2] === "@" ? (r = ht(t[1]), a = "mailto:" + r) : (r = ht(t[1]), a = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = ht(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (l !== t[0]);
        a = ht(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = ht(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const c9 = /^(?: *(?:\n|$))+/, h9 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, f9 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Q1 = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, d9 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, F3 = /(?:[*+-]|\d{1,9}[.)])/, S3 = r0(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, F3).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), k5 = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, m9 = /^[^\n]+/, D5 = /(?!\s*\])(?:\\.|[^\[\]\\])+/, p9 = r0(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", D5).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), g9 = r0(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, F3).getRegex(), oi = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", E5 = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, _9 = r0("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", E5).replace("tag", oi).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), x3 = r0(k5).replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oi).getRegex(), v9 = r0(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", x3).getRegex(), A5 = {
  blockquote: v9,
  code: h9,
  def: p9,
  fences: f9,
  heading: d9,
  hr: Q1,
  html: _9,
  lheading: S3,
  list: g9,
  newline: c9,
  paragraph: x3,
  table: f1,
  text: m9
}, lo = r0("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oi).getRegex(), b9 = {
  ...A5,
  table: lo,
  paragraph: r0(k5).replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", lo).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oi).getRegex()
}, w9 = {
  ...A5,
  html: r0(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", E5).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: f1,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: r0(k5).replace("hr", Q1).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", S3).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, C3 = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, y9 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, T3 = /^( {2,}|\\)\n(?!\s*$)/, k9 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, M1 = "\\p{P}\\p{S}", D9 = r0(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, M1).getRegex(), E9 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, A9 = r0(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, M1).getRegex(), F9 = r0("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, M1).getRegex(), S9 = r0("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, M1).getRegex(), x9 = r0(/\\([punct])/, "gu").replace(/punct/g, M1).getRegex(), C9 = r0(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), T9 = r0(E5).replace("(?:-->|$)", "-->").getRegex(), Q9 = r0("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", T9).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Oa = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, M9 = r0(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Oa).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Q3 = r0(/^!?\[(label)\]\[(ref)\]/).replace("label", Oa).replace("ref", D5).getRegex(), M3 = r0(/^!?\[(ref)\](?:\[\])?/).replace("ref", D5).getRegex(), B9 = r0("reflink|nolink(?!\\()", "g").replace("reflink", Q3).replace("nolink", M3).getRegex(), F5 = {
  _backpedal: f1,
  // only used for GFM url
  anyPunctuation: x9,
  autolink: C9,
  blockSkip: E9,
  br: T3,
  code: y9,
  del: f1,
  emStrongLDelim: A9,
  emStrongRDelimAst: F9,
  emStrongRDelimUnd: S9,
  escape: C3,
  link: M9,
  nolink: M3,
  punctuation: D9,
  reflink: Q3,
  reflinkSearch: B9,
  tag: Q9,
  text: k9,
  url: f1
}, z9 = {
  ...F5,
  link: r0(/^!?\[(label)\]\((.*?)\)/).replace("label", Oa).getRegex(),
  reflink: r0(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Oa).getRegex()
}, Il = {
  ...F5,
  escape: r0(C3).replace("])", "~|])").getRegex(),
  url: r0(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, L9 = {
  ...Il,
  br: r0(T3).replace("{2,}", "*").getRegex(),
  text: r0(Il.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, da = {
  normal: A5,
  gfm: b9,
  pedantic: w9
}, t1 = {
  normal: F5,
  gfm: Il,
  breaks: L9,
  pedantic: z9
};
class nr {
  constructor(e) {
    u0(this, "tokens");
    u0(this, "options");
    u0(this, "state");
    u0(this, "tokenizer");
    u0(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || bn, this.options.tokenizer = this.options.tokenizer || new Ra(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: da.normal,
      inline: t1.normal
    };
    this.options.pedantic ? (t.block = da.pedantic, t.inline = t1.pedantic) : this.options.gfm && (t.block = da.gfm, this.options.breaks ? t.inline = t1.breaks : t.inline = t1.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: da,
      inline: t1
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new nr(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new nr(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let r, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (r = o.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (i = e.substring(0, o + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r), l = i.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, a, i, l = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (r = c.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const f = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((p) => {
            d = p.call({ lexer: this }, f), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (i = e.substring(0, c + 1));
        }
        if (r = this.tokenizer.inlineText(i)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (u = r.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class qa {
  constructor(e) {
    u0(this, "options");
    this.options = e || bn;
  }
  code(e, t, r) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + ht(a) + '">' + (r ? e : ht(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : ht(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const a = t ? "ol" : "ul", i = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const a = no(e);
    if (a === null)
      return r;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + r + "</a>", i;
  }
  image(e, t, r) {
    const a = no(e);
    if (a === null)
      return r;
    e = a;
    let i = `<img src="${e}" alt="${r}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class S5 {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class ar {
  constructor(e) {
    u0(this, "options");
    u0(this, "renderer");
    u0(this, "textRenderer");
    this.options = e || bn, this.options.renderer = this.options.renderer || new qa(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new S5();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new ar(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new ar(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          r += o || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          r += this.renderer.heading(this.parseInline(l.tokens), l.depth, l9(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          r += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let o = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const f = l.rows[c];
            s = "";
            for (let d = 0; d < f.length; d++)
              s += this.renderer.tablecell(this.parseInline(f[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          r += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const l = i, o = this.parse(l.tokens);
          r += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = i, o = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let f = 0; f < l.items.length; f++) {
            const d = l.items[f], p = d.checked, b = d.task;
            let E = "";
            if (d.task) {
              const k = this.renderer.checkbox(!!p);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = k + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = k + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: k + " "
              }) : E += k + " ";
            }
            E += this.parse(d.tokens, u), c += this.renderer.listitem(E, b, !!p);
          }
          r += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const l = i;
          r += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          r += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          r += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          r += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          r += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          r += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          r += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          r += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          r += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          r += t.codespan(l.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const l = i;
          r += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
}
class d1 {
  constructor(e) {
    u0(this, "options");
    this.options = e || bn;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
u0(d1, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var _n, Nl, B3;
class I9 {
  constructor(...e) {
    is(this, _n);
    u0(this, "defaults", y5());
    u0(this, "options", this.setOptions);
    u0(this, "parse", j1(this, _n, Nl).call(this, nr.lex, ar.parse));
    u0(this, "parseInline", j1(this, _n, Nl).call(this, nr.lexInline, ar.parseInline));
    u0(this, "Parser", ar);
    u0(this, "Renderer", qa);
    u0(this, "TextRenderer", S5);
    u0(this, "Lexer", nr);
    u0(this, "Tokenizer", Ra);
    u0(this, "Hooks", d1);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let r = [];
    for (const l of e)
      switch (r = r.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const s of o.header)
            r = r.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const u of s)
              r = r.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            r = r.concat(this.walkTokens(u, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const a = { ...r };
      if (a.async = this.defaults.async || a.async || !1, r.extensions && (r.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...o) {
            let s = i.renderer.apply(this, o);
            return s === !1 && (s = l.apply(this, o)), s;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), r.renderer) {
        const i = this.defaults.renderer || new qa(this.defaults);
        for (const l in r.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = r.renderer[o], u = i[o];
          i[o] = (...c) => {
            let f = s.apply(i, c);
            return f === !1 && (f = u.apply(i, c)), f || "";
          };
        }
        a.renderer = i;
      }
      if (r.tokenizer) {
        const i = this.defaults.tokenizer || new Ra(this.defaults);
        for (const l in r.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, s = r.tokenizer[o], u = i[o];
          i[o] = (...c) => {
            let f = s.apply(i, c);
            return f === !1 && (f = u.apply(i, c)), f;
          };
        }
        a.tokenizer = i;
      }
      if (r.hooks) {
        const i = this.defaults.hooks || new d1();
        for (const l in r.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = r.hooks[o], u = i[o];
          d1.passThroughHooks.has(l) ? i[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(i, c)).then((d) => u.call(i, d));
            const f = s.call(i, c);
            return u.call(i, f);
          } : i[o] = (...c) => {
            let f = s.apply(i, c);
            return f === !1 && (f = u.apply(i, c)), f;
          };
        }
        a.hooks = i;
      }
      if (r.walkTokens) {
        const i = this.defaults.walkTokens, l = r.walkTokens;
        a.walkTokens = function(o) {
          let s = [];
          return s.push(l.call(this, o)), i && (s = s.concat(i.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return nr.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ar.parse(e, t ?? this.defaults);
  }
}
_n = new WeakSet(), Nl = function(e, t) {
  return (r, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = j1(this, _n, B3).call(this, !!l.silent, !!l.async);
    if (typeof r > "u" || r === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(r) : r).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(o);
    try {
      l.hooks && (r = l.hooks.preprocess(r));
      let s = e(r, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, B3 = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + ht(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const hn = new I9();
function t0(n, e) {
  return hn.parse(n, e);
}
t0.options = t0.setOptions = function(n) {
  return hn.setOptions(n), t0.defaults = hn.defaults, D3(t0.defaults), t0;
};
t0.getDefaults = y5;
t0.defaults = bn;
t0.use = function(...n) {
  return hn.use(...n), t0.defaults = hn.defaults, D3(t0.defaults), t0;
};
t0.walkTokens = function(n, e) {
  return hn.walkTokens(n, e);
};
t0.parseInline = hn.parseInline;
t0.Parser = ar;
t0.parser = ar.parse;
t0.Renderer = qa;
t0.TextRenderer = S5;
t0.Lexer = nr;
t0.lexer = nr.lex;
t0.Tokenizer = Ra;
t0.Hooks = d1;
t0.parse = t0;
t0.options;
t0.setOptions;
t0.use;
t0.walkTokens;
t0.parseInline;
ar.parse;
nr.lex;
const N9 = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, R9 = Object.hasOwnProperty;
class z3 {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let a = O9(e, t === !0);
    const i = a;
    for (; R9.call(r.occurrences, a); )
      r.occurrences[i]++, a = i + "-" + r.occurrences[i];
    return r.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function O9(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(N9, "").replace(/ /g, "-"));
}
new z3();
var so = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, q9 = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function v(_) {
          return _ instanceof s ? new s(_.type, v(_.content), _.alias) : Array.isArray(_) ? _.map(v) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(v) {
          return Object.prototype.toString.call(v).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(v) {
          return v.__id || Object.defineProperty(v, "__id", { value: ++i }), v.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function v(_, A) {
          A = A || {};
          var x, Q;
          switch (o.util.type(_)) {
            case "Object":
              if (Q = o.util.objId(_), A[Q])
                return A[Q];
              x = /** @type {Record<string, any>} */
              {}, A[Q] = x;
              for (var z in _)
                _.hasOwnProperty(z) && (x[z] = v(_[z], A));
              return (
                /** @type {any} */
                x
              );
            case "Array":
              return Q = o.util.objId(_), A[Q] ? A[Q] : (x = [], A[Q] = x, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(P, B) {
                x[B] = v(P, A);
              }), /** @type {any} */
              x);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(v) {
          for (; v; ) {
            var _ = a.exec(v.className);
            if (_)
              return _[1].toLowerCase();
            v = v.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(v, _) {
          v.className = v.className.replace(RegExp(a, "gi"), ""), v.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (x) {
            var v = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(x.stack) || [])[1];
            if (v) {
              var _ = document.getElementsByTagName("script");
              for (var A in _)
                if (_[A].src == v)
                  return _[A];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(v, _, A) {
          for (var x = "no-" + _; v; ) {
            var Q = v.classList;
            if (Q.contains(_))
              return !0;
            if (Q.contains(x))
              return !1;
            v = v.parentElement;
          }
          return !!A;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(v, _) {
          var A = o.util.clone(o.languages[v]);
          for (var x in _)
            A[x] = _[x];
          return A;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(v, _, A, x) {
          x = x || /** @type {any} */
          o.languages;
          var Q = x[v], z = {};
          for (var P in Q)
            if (Q.hasOwnProperty(P)) {
              if (P == _)
                for (var B in A)
                  A.hasOwnProperty(B) && (z[B] = A[B]);
              A.hasOwnProperty(P) || (z[P] = Q[P]);
            }
          var N = x[v];
          return x[v] = z, o.languages.DFS(o.languages, function(j, $) {
            $ === N && j != v && (this[j] = z);
          }), z;
        },
        // Traverse a language definition with Depth First Search
        DFS: function v(_, A, x, Q) {
          Q = Q || {};
          var z = o.util.objId;
          for (var P in _)
            if (_.hasOwnProperty(P)) {
              A.call(_, P, _[P], x || P);
              var B = _[P], N = o.util.type(B);
              N === "Object" && !Q[z(B)] ? (Q[z(B)] = !0, v(B, A, null, Q)) : N === "Array" && !Q[z(B)] && (Q[z(B)] = !0, v(B, A, P, Q));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(v, _) {
        o.highlightAllUnder(document, v, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(v, _, A) {
        var x = {
          callback: A,
          container: v,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", x), x.elements = Array.prototype.slice.apply(x.container.querySelectorAll(x.selector)), o.hooks.run("before-all-elements-highlight", x);
        for (var Q = 0, z; z = x.elements[Q++]; )
          o.highlightElement(z, _ === !0, x.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(v, _, A) {
        var x = o.util.getLanguage(v), Q = o.languages[x];
        o.util.setLanguage(v, x);
        var z = v.parentElement;
        z && z.nodeName.toLowerCase() === "pre" && o.util.setLanguage(z, x);
        var P = v.textContent, B = {
          element: v,
          language: x,
          grammar: Q,
          code: P
        };
        function N($) {
          B.highlightedCode = $, o.hooks.run("before-insert", B), B.element.innerHTML = B.highlightedCode, o.hooks.run("after-highlight", B), o.hooks.run("complete", B), A && A.call(B.element);
        }
        if (o.hooks.run("before-sanity-check", B), z = B.element.parentElement, z && z.nodeName.toLowerCase() === "pre" && !z.hasAttribute("tabindex") && z.setAttribute("tabindex", "0"), !B.code) {
          o.hooks.run("complete", B), A && A.call(B.element);
          return;
        }
        if (o.hooks.run("before-highlight", B), !B.grammar) {
          N(o.util.encode(B.code));
          return;
        }
        if (_ && r.Worker) {
          var j = new Worker(o.filename);
          j.onmessage = function($) {
            N($.data);
          }, j.postMessage(JSON.stringify({
            language: B.language,
            code: B.code,
            immediateClose: !0
          }));
        } else
          N(o.highlight(B.code, B.grammar, B.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(v, _, A) {
        var x = {
          code: v,
          grammar: _,
          language: A
        };
        if (o.hooks.run("before-tokenize", x), !x.grammar)
          throw new Error('The language "' + x.language + '" has no grammar.');
        return x.tokens = o.tokenize(x.code, x.grammar), o.hooks.run("after-tokenize", x), s.stringify(o.util.encode(x.tokens), x.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(v, _) {
        var A = _.rest;
        if (A) {
          for (var x in A)
            _[x] = A[x];
          delete _.rest;
        }
        var Q = new f();
        return d(Q, Q.head, v), c(v, Q, _, Q.head, 0), b(Q);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(v, _) {
          var A = o.hooks.all;
          A[v] = A[v] || [], A[v].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(v, _) {
          var A = o.hooks.all[v];
          if (!(!A || !A.length))
            for (var x = 0, Q; Q = A[x++]; )
              Q(_);
        }
      },
      Token: s
    };
    r.Prism = o;
    function s(v, _, A, x) {
      this.type = v, this.content = _, this.alias = A, this.length = (x || "").length | 0;
    }
    s.stringify = function v(_, A) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var x = "";
        return _.forEach(function(N) {
          x += v(N, A);
        }), x;
      }
      var Q = {
        type: _.type,
        content: v(_.content, A),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: A
      }, z = _.alias;
      z && (Array.isArray(z) ? Array.prototype.push.apply(Q.classes, z) : Q.classes.push(z)), o.hooks.run("wrap", Q);
      var P = "";
      for (var B in Q.attributes)
        P += " " + B + '="' + (Q.attributes[B] || "").replace(/"/g, "&quot;") + '"';
      return "<" + Q.tag + ' class="' + Q.classes.join(" ") + '"' + P + ">" + Q.content + "</" + Q.tag + ">";
    };
    function u(v, _, A, x) {
      v.lastIndex = _;
      var Q = v.exec(A);
      if (Q && x && Q[1]) {
        var z = Q[1].length;
        Q.index += z, Q[0] = Q[0].slice(z);
      }
      return Q;
    }
    function c(v, _, A, x, Q, z) {
      for (var P in A)
        if (!(!A.hasOwnProperty(P) || !A[P])) {
          var B = A[P];
          B = Array.isArray(B) ? B : [B];
          for (var N = 0; N < B.length; ++N) {
            if (z && z.cause == P + "," + N)
              return;
            var j = B[N], $ = j.inside, W = !!j.lookbehind, se = !!j.greedy, ke = j.alias;
            if (se && !j.pattern.global) {
              var Fe = j.pattern.toString().match(/[imsuy]*$/)[0];
              j.pattern = RegExp(j.pattern.source, Fe + "g");
            }
            for (var xe = j.pattern || j, he = x.next, Ee = Q; he !== _.tail && !(z && Ee >= z.reach); Ee += he.value.length, he = he.next) {
              var ie = he.value;
              if (_.length > v.length)
                return;
              if (!(ie instanceof s)) {
                var ce = 1, ve;
                if (se) {
                  if (ve = u(xe, Ee, v, W), !ve || ve.index >= v.length)
                    break;
                  var He = ve.index, oe = ve.index + ve[0].length, me = Ee;
                  for (me += he.value.length; He >= me; )
                    he = he.next, me += he.value.length;
                  if (me -= he.value.length, Ee = me, he.value instanceof s)
                    continue;
                  for (var U = he; U !== _.tail && (me < oe || typeof U.value == "string"); U = U.next)
                    ce++, me += U.value.length;
                  ce--, ie = v.slice(Ee, me), ve.index -= Ee;
                } else if (ve = u(xe, 0, ie, W), !ve)
                  continue;
                var He = ve.index, ne = ve[0], fe = ie.slice(0, He), Z = ie.slice(He + ne.length), Qe = Ee + ie.length;
                z && Qe > z.reach && (z.reach = Qe);
                var Le = he.prev;
                fe && (Le = d(_, Le, fe), Ee += fe.length), p(_, Le, ce);
                var Ne = new s(P, $ ? o.tokenize(ne, $) : ne, ke, ne);
                if (he = d(_, Le, Ne), Z && d(_, he, Z), ce > 1) {
                  var Ie = {
                    cause: P + "," + N,
                    reach: Qe
                  };
                  c(v, _, A, he.prev, Ee, Ie), z && Ie.reach > z.reach && (z.reach = Ie.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var v = { value: null, prev: null, next: null }, _ = { value: null, prev: v, next: null };
      v.next = _, this.head = v, this.tail = _, this.length = 0;
    }
    function d(v, _, A) {
      var x = _.next, Q = { value: A, prev: _, next: x };
      return _.next = Q, x.prev = Q, v.length++, Q;
    }
    function p(v, _, A) {
      for (var x = _.next, Q = 0; Q < A && x !== v.tail; Q++)
        x = x.next;
      _.next = x, x.prev = _, v.length -= Q;
    }
    function b(v) {
      for (var _ = [], A = v.head.next; A !== v.tail; )
        _.push(A.value), A = A.next;
      return _;
    }
    if (!r.document)
      return r.addEventListener && (o.disableWorkerMessageHandler || r.addEventListener("message", function(v) {
        var _ = JSON.parse(v.data), A = _.language, x = _.code, Q = _.immediateClose;
        r.postMessage(o.highlight(x, o.languages[A], A)), Q && r.close();
      }, !1)), o;
    var E = o.util.currentScript();
    E && (o.filename = E.src, E.hasAttribute("data-manual") && (o.manual = !0));
    function k() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var w = document.readyState;
      w === "loading" || w === "interactive" && E && E.defer ? document.addEventListener("DOMContentLoaded", k) : window.requestAnimationFrame ? window.requestAnimationFrame(k) : window.setTimeout(k, 16);
    }
    return o;
  }(e);
  n.exports && (n.exports = t), typeof so < "u" && (so.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var i = r.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", a = function(E, k) {
      return "✖ Error " + E + " while fetching file: " + k;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", f = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function d(E, k, w) {
      var v = new XMLHttpRequest();
      v.open("GET", E, !0), v.onreadystatechange = function() {
        v.readyState == 4 && (v.status < 400 && v.responseText ? k(v.responseText) : v.status >= 400 ? w(a(v.status, v.statusText)) : w(i));
      }, v.send(null);
    }
    function p(E) {
      var k = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(E || "");
      if (k) {
        var w = Number(k[1]), v = k[2], _ = k[3];
        return v ? _ ? [w, Number(_)] : [w, void 0] : [w, w];
      }
    }
    t.hooks.add("before-highlightall", function(E) {
      E.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(E) {
      var k = (
        /** @type {HTMLPreElement} */
        E.element
      );
      if (k.matches(f)) {
        E.code = "", k.setAttribute(o, s);
        var w = k.appendChild(document.createElement("CODE"));
        w.textContent = r;
        var v = k.getAttribute("data-src"), _ = E.language;
        if (_ === "none") {
          var A = (/\.(\w+)$/.exec(v) || [, "none"])[1];
          _ = l[A] || A;
        }
        t.util.setLanguage(w, _), t.util.setLanguage(k, _);
        var x = t.plugins.autoloader;
        x && x.loadLanguages(_), d(
          v,
          function(Q) {
            k.setAttribute(o, u);
            var z = p(k.getAttribute("data-range"));
            if (z) {
              var P = Q.split(/\r\n?|\n/g), B = z[0], N = z[1] == null ? P.length : z[1];
              B < 0 && (B += P.length), B = Math.max(0, Math.min(B - 1, P.length)), N < 0 && (N += P.length), N = Math.max(0, Math.min(N, P.length)), Q = P.slice(B, N).join(`
`), k.hasAttribute("data-start") || k.setAttribute("data-start", String(B + 1));
            }
            w.textContent = Q, t.highlightElement(w);
          },
          function(Q) {
            k.setAttribute(o, c), w.textContent = Q;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(k) {
        for (var w = (k || document).querySelectorAll(f), v = 0, _; _ = w[v++]; )
          t.highlightElement(_);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(q9);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = r.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = n.languages.bash[a[l]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new z3();
const P9 = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const a = n[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, H9 = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], V9 = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], U9 = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], j9 = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], G9 = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], W9 = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
[
  ...H9,
  ...V9.map((n) => `svg:${n}`),
  ...U9.map((n) => `math:${n}`)
], P9([
  Object.fromEntries(j9.map((n) => [n, ["*"]])),
  Object.fromEntries(G9.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(W9.map((n) => [n, ["math:*"]]))
]);
function Bn(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function Sa() {
}
const Z9 = (n) => n;
function Y9(n, e) {
  return n != n ? e == e : n !== e || n && typeof n == "object" || typeof n == "function";
}
const L3 = typeof window < "u";
let oo = L3 ? () => window.performance.now() : () => Date.now(), I3 = L3 ? (n) => requestAnimationFrame(n) : Sa;
const In = /* @__PURE__ */ new Set();
function N3(n) {
  In.forEach((e) => {
    e.c(n) || (In.delete(e), e.f());
  }), In.size !== 0 && I3(N3);
}
function X9(n) {
  let e;
  return In.size === 0 && I3(N3), {
    promise: new Promise((t) => {
      In.add(e = { c: n, f: t });
    }),
    abort() {
      In.delete(e);
    }
  };
}
function x5(n, { delay: e = 0, duration: t = 400, easing: r = Z9 } = {}) {
  const a = +getComputedStyle(n).opacity;
  return {
    delay: e,
    duration: t,
    easing: r,
    css: (i) => `opacity: ${i * a}`
  };
}
const Cn = [];
function K9(n, e = Sa) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function a(o) {
    if (Y9(n, o) && (n = o, t)) {
      const s = !Cn.length;
      for (const u of r)
        u[1](), Cn.push(u, n);
      if (s) {
        for (let u = 0; u < Cn.length; u += 2)
          Cn[u][0](Cn[u + 1]);
        Cn.length = 0;
      }
    }
  }
  function i(o) {
    a(o(n));
  }
  function l(o, s = Sa) {
    const u = [o, s];
    return r.add(u), r.size === 1 && (t = e(a, i) || Sa), o(n), () => {
      r.delete(u), r.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function uo(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function Rl(n, e, t, r) {
  if (typeof t == "number" || uo(t)) {
    const a = r - t, i = (t - e) / (n.dt || 1 / 60), l = n.opts.stiffness * a, o = n.opts.damping * i, s = (l - o) * n.inv_mass, u = (i + s) * n.dt;
    return Math.abs(u) < n.opts.precision && Math.abs(a) < n.opts.precision ? r : (n.settled = !1, uo(t) ? new Date(t.getTime() + u) : t + u);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => Rl(n, e[i], t[i], r[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = Rl(n, e[i], t[i], r[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function co(n, e = {}) {
  const t = K9(n), { stiffness: r = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, o, s, u = n, c = n, f = 1, d = 0, p = !1;
  function b(k, w = {}) {
    c = k;
    const v = s = {};
    return n == null || w.hard || E.stiffness >= 1 && E.damping >= 1 ? (p = !0, l = oo(), u = k, t.set(n = c), Promise.resolve()) : (w.soft && (d = 1 / ((w.soft === !0 ? 0.5 : +w.soft) * 60), f = 0), o || (l = oo(), p = !1, o = X9((_) => {
      if (p)
        return p = !1, o = null, !1;
      f = Math.min(f + d, 1);
      const A = {
        inv_mass: f,
        opts: E,
        settled: !0,
        dt: (_ - l) * 60 / 1e3
      }, x = Rl(A, u, n, c);
      return l = _, u = n, t.set(n = x), A.settled && (o = null), !A.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        v === s && _();
      });
    }));
  }
  const E = {
    set: b,
    update: (k, w) => b(k(c, n), w),
    subscribe: t.subscribe,
    stiffness: r,
    damping: a,
    precision: i
  };
  return E;
}
const {
  SvelteComponent: J9,
  append_hydration: Mt,
  attr: je,
  children: vt,
  claim_element: $9,
  claim_svg_element: Bt,
  component_subscribe: ho,
  detach: ct,
  element: e8,
  init: t8,
  insert_hydration: r8,
  noop: fo,
  safe_not_equal: n8,
  set_style: ma,
  svg_element: zt,
  toggle_class: mo
} = window.__gradio__svelte__internal, { onMount: a8 } = window.__gradio__svelte__internal;
function i8(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d;
  return {
    c() {
      e = e8("div"), t = zt("svg"), r = zt("g"), a = zt("path"), i = zt("path"), l = zt("path"), o = zt("path"), s = zt("g"), u = zt("path"), c = zt("path"), f = zt("path"), d = zt("path"), this.h();
    },
    l(p) {
      e = $9(p, "DIV", { class: !0 });
      var b = vt(e);
      t = Bt(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var E = vt(t);
      r = Bt(E, "g", { style: !0 });
      var k = vt(r);
      a = Bt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), vt(a).forEach(ct), i = Bt(k, "path", { d: !0, fill: !0, class: !0 }), vt(i).forEach(ct), l = Bt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), vt(l).forEach(ct), o = Bt(k, "path", { d: !0, fill: !0, class: !0 }), vt(o).forEach(ct), k.forEach(ct), s = Bt(E, "g", { style: !0 });
      var w = vt(s);
      u = Bt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), vt(u).forEach(ct), c = Bt(w, "path", { d: !0, fill: !0, class: !0 }), vt(c).forEach(ct), f = Bt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), vt(f).forEach(ct), d = Bt(w, "path", { d: !0, fill: !0, class: !0 }), vt(d).forEach(ct), w.forEach(ct), E.forEach(ct), b.forEach(ct), this.h();
    },
    h() {
      je(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), je(a, "fill", "#FF7C00"), je(a, "fill-opacity", "0.4"), je(a, "class", "svelte-43sxxs"), je(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), je(i, "fill", "#FF7C00"), je(i, "class", "svelte-43sxxs"), je(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), je(l, "fill", "#FF7C00"), je(l, "fill-opacity", "0.4"), je(l, "class", "svelte-43sxxs"), je(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), je(o, "fill", "#FF7C00"), je(o, "class", "svelte-43sxxs"), ma(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), je(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), je(u, "fill", "#FF7C00"), je(u, "fill-opacity", "0.4"), je(u, "class", "svelte-43sxxs"), je(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), je(c, "fill", "#FF7C00"), je(c, "class", "svelte-43sxxs"), je(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), je(f, "fill", "#FF7C00"), je(f, "fill-opacity", "0.4"), je(f, "class", "svelte-43sxxs"), je(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), je(d, "fill", "#FF7C00"), je(d, "class", "svelte-43sxxs"), ma(s, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), je(t, "viewBox", "-1200 -1200 3000 3000"), je(t, "fill", "none"), je(t, "xmlns", "http://www.w3.org/2000/svg"), je(t, "class", "svelte-43sxxs"), je(e, "class", "svelte-43sxxs"), mo(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(p, b) {
      r8(p, e, b), Mt(e, t), Mt(t, r), Mt(r, a), Mt(r, i), Mt(r, l), Mt(r, o), Mt(t, s), Mt(s, u), Mt(s, c), Mt(s, f), Mt(s, d);
    },
    p(p, [b]) {
      b & /*$top*/
      2 && ma(r, "transform", "translate(" + /*$top*/
      p[1][0] + "px, " + /*$top*/
      p[1][1] + "px)"), b & /*$bottom*/
      4 && ma(s, "transform", "translate(" + /*$bottom*/
      p[2][0] + "px, " + /*$bottom*/
      p[2][1] + "px)"), b & /*margin*/
      1 && mo(
        e,
        "margin",
        /*margin*/
        p[0]
      );
    },
    i: fo,
    o: fo,
    d(p) {
      p && ct(e);
    }
  };
}
function l8(n, e, t) {
  let r, a;
  var i = this && this.__awaiter || function(p, b, E, k) {
    function w(v) {
      return v instanceof E ? v : new E(function(_) {
        _(v);
      });
    }
    return new (E || (E = Promise))(function(v, _) {
      function A(z) {
        try {
          Q(k.next(z));
        } catch (P) {
          _(P);
        }
      }
      function x(z) {
        try {
          Q(k.throw(z));
        } catch (P) {
          _(P);
        }
      }
      function Q(z) {
        z.done ? v(z.value) : w(z.value).then(A, x);
      }
      Q((k = k.apply(p, b || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const o = co([0, 0]);
  ho(n, o, (p) => t(1, r = p));
  const s = co([0, 0]);
  ho(n, s, (p) => t(2, a = p));
  let u;
  function c() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function f() {
    return i(this, void 0, void 0, function* () {
      yield c(), u || f();
    });
  }
  function d() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), f();
    });
  }
  return a8(() => (d(), () => u = !0)), n.$$set = (p) => {
    "margin" in p && t(0, l = p.margin);
  }, [l, r, a, o, s];
}
class s8 extends J9 {
  constructor(e) {
    super(), t8(this, e, l8, i8, n8, { margin: 0 });
  }
}
const {
  SvelteComponent: o8,
  append_hydration: rn,
  attr: Ht,
  binding_callbacks: po,
  check_outros: Ol,
  children: ir,
  claim_component: R3,
  claim_element: lr,
  claim_space: Dt,
  claim_text: p0,
  create_component: O3,
  create_slot: q3,
  destroy_component: P3,
  destroy_each: H3,
  detach: pe,
  element: sr,
  empty: St,
  ensure_array_like: Pa,
  get_all_dirty_from_scope: V3,
  get_slot_changes: U3,
  group_outros: ql,
  init: u8,
  insert_hydration: Se,
  mount_component: j3,
  noop: Pl,
  safe_not_equal: c8,
  set_data: xt,
  set_style: Gr,
  space: Et,
  text: g0,
  toggle_class: bt,
  transition_in: Pt,
  transition_out: or,
  update_slot_base: G3
} = window.__gradio__svelte__internal, { tick: h8 } = window.__gradio__svelte__internal, { onDestroy: f8 } = window.__gradio__svelte__internal, { createEventDispatcher: d8 } = window.__gradio__svelte__internal, m8 = (n) => ({}), go = (n) => ({}), p8 = (n) => ({}), _o = (n) => ({});
function vo(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r[43] = t, r;
}
function bo(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r;
}
function g8(n) {
  let e, t, r, a, i = (
    /*i18n*/
    n[1]("common.error") + ""
  ), l, o, s;
  t = new Rh({
    props: {
      Icon: lu,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const u = (
    /*#slots*/
    n[30].error
  ), c = q3(
    u,
    n,
    /*$$scope*/
    n[29],
    go
  );
  return {
    c() {
      e = sr("div"), O3(t.$$.fragment), r = Et(), a = sr("span"), l = g0(i), o = Et(), c && c.c(), this.h();
    },
    l(f) {
      e = lr(f, "DIV", { class: !0 });
      var d = ir(e);
      R3(t.$$.fragment, d), d.forEach(pe), r = Dt(f), a = lr(f, "SPAN", { class: !0 });
      var p = ir(a);
      l = p0(p, i), p.forEach(pe), o = Dt(f), c && c.l(f), this.h();
    },
    h() {
      Ht(e, "class", "clear-status svelte-17v219f"), Ht(a, "class", "error svelte-17v219f");
    },
    m(f, d) {
      Se(f, e, d), j3(t, e, null), Se(f, r, d), Se(f, a, d), rn(a, l), Se(f, o, d), c && c.m(f, d), s = !0;
    },
    p(f, d) {
      const p = {};
      d[0] & /*i18n*/
      2 && (p.label = /*i18n*/
      f[1]("common.clear")), t.$set(p), (!s || d[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      f[1]("common.error") + "") && xt(l, i), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && G3(
        c,
        u,
        f,
        /*$$scope*/
        f[29],
        s ? U3(
          u,
          /*$$scope*/
          f[29],
          d,
          m8
        ) : V3(
          /*$$scope*/
          f[29]
        ),
        go
      );
    },
    i(f) {
      s || (Pt(t.$$.fragment, f), Pt(c, f), s = !0);
    },
    o(f) {
      or(t.$$.fragment, f), or(c, f), s = !1;
    },
    d(f) {
      f && (pe(e), pe(r), pe(a), pe(o)), P3(t), c && c.d(f);
    }
  };
}
function _8(n) {
  let e, t, r, a, i, l, o, s, u, c = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && wo(n)
  );
  function f(_, A) {
    if (
      /*progress*/
      _[7]
    ) return w8;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return b8;
    if (
      /*queue_position*/
      _[2] === 0
    ) return v8;
  }
  let d = f(n), p = d && d(n), b = (
    /*timer*/
    n[5] && Do(n)
  );
  const E = [E8, D8], k = [];
  function w(_, A) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = w(n)) && (l = k[i] = E[i](n));
  let v = !/*timer*/
  n[5] && To(n);
  return {
    c() {
      c && c.c(), e = Et(), t = sr("div"), p && p.c(), r = Et(), b && b.c(), a = Et(), l && l.c(), o = Et(), v && v.c(), s = St(), this.h();
    },
    l(_) {
      c && c.l(_), e = Dt(_), t = lr(_, "DIV", { class: !0 });
      var A = ir(t);
      p && p.l(A), r = Dt(A), b && b.l(A), A.forEach(pe), a = Dt(_), l && l.l(_), o = Dt(_), v && v.l(_), s = St(), this.h();
    },
    h() {
      Ht(t, "class", "progress-text svelte-17v219f"), bt(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), bt(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(_, A) {
      c && c.m(_, A), Se(_, e, A), Se(_, t, A), p && p.m(t, null), rn(t, r), b && b.m(t, null), Se(_, a, A), ~i && k[i].m(_, A), Se(_, o, A), v && v.m(_, A), Se(_, s, A), u = !0;
    },
    p(_, A) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, A) : (c = wo(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = f(_)) && p ? p.p(_, A) : (p && p.d(1), p = d && d(_), p && (p.c(), p.m(t, r))), /*timer*/
      _[5] ? b ? b.p(_, A) : (b = Do(_), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || A[0] & /*variant*/
      256) && bt(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || A[0] & /*variant*/
      256) && bt(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let x = i;
      i = w(_), i === x ? ~i && k[i].p(_, A) : (l && (ql(), or(k[x], 1, 1, () => {
        k[x] = null;
      }), Ol()), ~i ? (l = k[i], l ? l.p(_, A) : (l = k[i] = E[i](_), l.c()), Pt(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      _[5] ? v && (ql(), or(v, 1, 1, () => {
        v = null;
      }), Ol()) : v ? (v.p(_, A), A[0] & /*timer*/
      32 && Pt(v, 1)) : (v = To(_), v.c(), Pt(v, 1), v.m(s.parentNode, s));
    },
    i(_) {
      u || (Pt(l), Pt(v), u = !0);
    },
    o(_) {
      or(l), or(v), u = !1;
    },
    d(_) {
      _ && (pe(e), pe(t), pe(a), pe(o), pe(s)), c && c.d(_), p && p.d(), b && b.d(), ~i && k[i].d(_), v && v.d(_);
    }
  };
}
function wo(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = sr("div"), this.h();
    },
    l(r) {
      e = lr(r, "DIV", { class: !0 }), ir(e).forEach(pe), this.h();
    },
    h() {
      Ht(e, "class", "eta-bar svelte-17v219f"), Gr(e, "transform", t);
    },
    m(r, a) {
      Se(r, e, a);
    },
    p(r, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && Gr(e, "transform", t);
    },
    d(r) {
      r && pe(e);
    }
  };
}
function v8(n) {
  let e;
  return {
    c() {
      e = g0("processing |");
    },
    l(t) {
      e = p0(t, "processing |");
    },
    m(t, r) {
      Se(t, e, r);
    },
    p: Pl,
    d(t) {
      t && pe(e);
    }
  };
}
function b8(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, a, i, l;
  return {
    c() {
      e = g0("queue: "), r = g0(t), a = g0("/"), i = g0(
        /*queue_size*/
        n[3]
      ), l = g0(" |");
    },
    l(o) {
      e = p0(o, "queue: "), r = p0(o, t), a = p0(o, "/"), i = p0(
        o,
        /*queue_size*/
        n[3]
      ), l = p0(o, " |");
    },
    m(o, s) {
      Se(o, e, s), Se(o, r, s), Se(o, a, s), Se(o, i, s), Se(o, l, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && xt(r, t), s[0] & /*queue_size*/
      8 && xt(
        i,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (pe(e), pe(r), pe(a), pe(i), pe(l));
    }
  };
}
function w8(n) {
  let e, t = Pa(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = ko(bo(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = St();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = St();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      Se(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = Pa(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = bo(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = ko(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && pe(e), H3(r, a);
    }
  };
}
function yo(n) {
  let e, t = (
    /*p*/
    n[41].unit + ""
  ), r, a, i = " ", l;
  function o(c, f) {
    return (
      /*p*/
      c[41].length != null ? k8 : y8
    );
  }
  let s = o(n), u = s(n);
  return {
    c() {
      u.c(), e = Et(), r = g0(t), a = g0(" | "), l = g0(i);
    },
    l(c) {
      u.l(c), e = Dt(c), r = p0(c, t), a = p0(c, " | "), l = p0(c, i);
    },
    m(c, f) {
      u.m(c, f), Se(c, e, f), Se(c, r, f), Se(c, a, f), Se(c, l, f);
    },
    p(c, f) {
      s === (s = o(c)) && u ? u.p(c, f) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[41].unit + "") && xt(r, t);
    },
    d(c) {
      c && (pe(e), pe(r), pe(a), pe(l)), u.d(c);
    }
  };
}
function y8(n) {
  let e = Bn(
    /*p*/
    n[41].index || 0
  ) + "", t;
  return {
    c() {
      t = g0(e);
    },
    l(r) {
      t = p0(r, e);
    },
    m(r, a) {
      Se(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = Bn(
        /*p*/
        r[41].index || 0
      ) + "") && xt(t, e);
    },
    d(r) {
      r && pe(t);
    }
  };
}
function k8(n) {
  let e = Bn(
    /*p*/
    n[41].index || 0
  ) + "", t, r, a = Bn(
    /*p*/
    n[41].length
  ) + "", i;
  return {
    c() {
      t = g0(e), r = g0("/"), i = g0(a);
    },
    l(l) {
      t = p0(l, e), r = p0(l, "/"), i = p0(l, a);
    },
    m(l, o) {
      Se(l, t, o), Se(l, r, o), Se(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      128 && e !== (e = Bn(
        /*p*/
        l[41].index || 0
      ) + "") && xt(t, e), o[0] & /*progress*/
      128 && a !== (a = Bn(
        /*p*/
        l[41].length
      ) + "") && xt(i, a);
    },
    d(l) {
      l && (pe(t), pe(r), pe(i));
    }
  };
}
function ko(n) {
  let e, t = (
    /*p*/
    n[41].index != null && yo(n)
  );
  return {
    c() {
      t && t.c(), e = St();
    },
    l(r) {
      t && t.l(r), e = St();
    },
    m(r, a) {
      t && t.m(r, a), Se(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].index != null ? t ? t.p(r, a) : (t = yo(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && pe(e), t && t.d(r);
    }
  };
}
function Do(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, a;
  return {
    c() {
      e = g0(
        /*formatted_timer*/
        n[20]
      ), r = g0(t), a = g0("s");
    },
    l(i) {
      e = p0(
        i,
        /*formatted_timer*/
        n[20]
      ), r = p0(i, t), a = p0(i, "s");
    },
    m(i, l) {
      Se(i, e, l), Se(i, r, l), Se(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && xt(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && xt(r, t);
    },
    d(i) {
      i && (pe(e), pe(r), pe(a));
    }
  };
}
function D8(n) {
  let e, t;
  return e = new s8({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      O3(e.$$.fragment);
    },
    l(r) {
      R3(e.$$.fragment, r);
    },
    m(r, a) {
      j3(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      r[8] === "default"), e.$set(i);
    },
    i(r) {
      t || (Pt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      or(e.$$.fragment, r), t = !1;
    },
    d(r) {
      P3(e, r);
    }
  };
}
function E8(n) {
  let e, t, r, a, i, l = `${/*last_progress_level*/
  n[15] * 100}%`, o = (
    /*progress*/
    n[7] != null && Eo(n)
  );
  return {
    c() {
      e = sr("div"), t = sr("div"), o && o.c(), r = Et(), a = sr("div"), i = sr("div"), this.h();
    },
    l(s) {
      e = lr(s, "DIV", { class: !0 });
      var u = ir(e);
      t = lr(u, "DIV", { class: !0 });
      var c = ir(t);
      o && o.l(c), c.forEach(pe), r = Dt(u), a = lr(u, "DIV", { class: !0 });
      var f = ir(a);
      i = lr(f, "DIV", { class: !0 }), ir(i).forEach(pe), f.forEach(pe), u.forEach(pe), this.h();
    },
    h() {
      Ht(t, "class", "progress-level-inner svelte-17v219f"), Ht(i, "class", "progress-bar svelte-17v219f"), Gr(i, "width", l), Ht(a, "class", "progress-bar-wrap svelte-17v219f"), Ht(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      Se(s, e, u), rn(e, t), o && o.m(t, null), rn(e, r), rn(e, a), rn(a, i), n[31](i);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = Eo(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Gr(i, "width", l);
    },
    i: Pl,
    o: Pl,
    d(s) {
      s && pe(e), o && o.d(), n[31](null);
    }
  };
}
function Eo(n) {
  let e, t = Pa(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = Co(vo(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = St();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = St();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      Se(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = Pa(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = vo(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = Co(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && pe(e), H3(r, a);
    }
  };
}
function Ao(n) {
  let e, t, r, a, i = (
    /*i*/
    n[43] !== 0 && A8()
  ), l = (
    /*p*/
    n[41].desc != null && Fo(n)
  ), o = (
    /*p*/
    n[41].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null && So()
  ), s = (
    /*progress_level*/
    n[14] != null && xo(n)
  );
  return {
    c() {
      i && i.c(), e = Et(), l && l.c(), t = Et(), o && o.c(), r = Et(), s && s.c(), a = St();
    },
    l(u) {
      i && i.l(u), e = Dt(u), l && l.l(u), t = Dt(u), o && o.l(u), r = Dt(u), s && s.l(u), a = St();
    },
    m(u, c) {
      i && i.m(u, c), Se(u, e, c), l && l.m(u, c), Se(u, t, c), o && o.m(u, c), Se(u, r, c), s && s.m(u, c), Se(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[41].desc != null ? l ? l.p(u, c) : (l = Fo(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[41].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[43]
      ] != null ? o || (o = So(), o.c(), o.m(r.parentNode, r)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = xo(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (pe(e), pe(t), pe(r), pe(a)), i && i.d(u), l && l.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function A8(n) {
  let e;
  return {
    c() {
      e = g0(" /");
    },
    l(t) {
      e = p0(t, " /");
    },
    m(t, r) {
      Se(t, e, r);
    },
    d(t) {
      t && pe(e);
    }
  };
}
function Fo(n) {
  let e = (
    /*p*/
    n[41].desc + ""
  ), t;
  return {
    c() {
      t = g0(e);
    },
    l(r) {
      t = p0(r, e);
    },
    m(r, a) {
      Se(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[41].desc + "") && xt(t, e);
    },
    d(r) {
      r && pe(t);
    }
  };
}
function So(n) {
  let e;
  return {
    c() {
      e = g0("-");
    },
    l(t) {
      e = p0(t, "-");
    },
    m(t, r) {
      Se(t, e, r);
    },
    d(t) {
      t && pe(e);
    }
  };
}
function xo(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[43]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = g0(e), r = g0("%");
    },
    l(a) {
      t = p0(a, e), r = p0(a, "%");
    },
    m(a, i) {
      Se(a, t, i), Se(a, r, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[43]
      ] || 0)).toFixed(1) + "") && xt(t, e);
    },
    d(a) {
      a && (pe(t), pe(r));
    }
  };
}
function Co(n) {
  let e, t = (
    /*p*/
    (n[41].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null) && Ao(n)
  );
  return {
    c() {
      t && t.c(), e = St();
    },
    l(r) {
      t && t.l(r), e = St();
    },
    m(r, a) {
      t && t.m(r, a), Se(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[43]
      ] != null ? t ? t.p(r, a) : (t = Ao(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && pe(e), t && t.d(r);
    }
  };
}
function To(n) {
  let e, t, r, a;
  const i = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), l = q3(
    i,
    n,
    /*$$scope*/
    n[29],
    _o
  );
  return {
    c() {
      e = sr("p"), t = g0(
        /*loading_text*/
        n[9]
      ), r = Et(), l && l.c(), this.h();
    },
    l(o) {
      e = lr(o, "P", { class: !0 });
      var s = ir(e);
      t = p0(
        s,
        /*loading_text*/
        n[9]
      ), s.forEach(pe), r = Dt(o), l && l.l(o), this.h();
    },
    h() {
      Ht(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      Se(o, e, s), rn(e, t), Se(o, r, s), l && l.m(o, s), a = !0;
    },
    p(o, s) {
      (!a || s[0] & /*loading_text*/
      512) && xt(
        t,
        /*loading_text*/
        o[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && G3(
        l,
        i,
        o,
        /*$$scope*/
        o[29],
        a ? U3(
          i,
          /*$$scope*/
          o[29],
          s,
          p8
        ) : V3(
          /*$$scope*/
          o[29]
        ),
        _o
      );
    },
    i(o) {
      a || (Pt(l, o), a = !0);
    },
    o(o) {
      or(l, o), a = !1;
    },
    d(o) {
      o && (pe(e), pe(r)), l && l.d(o);
    }
  };
}
function F8(n) {
  let e, t, r, a, i;
  const l = [_8, g8], o = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(n)) && (r = o[t] = l[t](n)), {
    c() {
      e = sr("div"), r && r.c(), this.h();
    },
    l(u) {
      e = lr(u, "DIV", { class: !0 });
      var c = ir(e);
      r && r.l(c), c.forEach(pe), this.h();
    },
    h() {
      Ht(e, "class", a = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), bt(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), bt(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), bt(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), bt(
        e,
        "border",
        /*border*/
        n[12]
      ), Gr(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), Gr(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      Se(u, e, c), ~t && o[t].m(e, null), n[33](e), i = !0;
    },
    p(u, c) {
      let f = t;
      t = s(u), t === f ? ~t && o[t].p(u, c) : (r && (ql(), or(o[f], 1, 1, () => {
        o[f] = null;
      }), Ol()), ~t ? (r = o[t], r ? r.p(u, c) : (r = o[t] = l[t](u), r.c()), Pt(r, 1), r.m(e, null)) : r = null), (!i || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ht(e, "class", a), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && bt(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!i || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && bt(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && bt(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!i || c[0] & /*variant, show_progress, border*/
      4416) && bt(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Gr(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Gr(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      i || (Pt(r), i = !0);
    },
    o(u) {
      or(r), i = !1;
    },
    d(u) {
      u && pe(e), ~t && o[t].d(), n[33](null);
    }
  };
}
var S8 = function(n, e, t, r) {
  function a(i) {
    return i instanceof t ? i : new t(function(l) {
      l(i);
    });
  }
  return new (t || (t = Promise))(function(i, l) {
    function o(c) {
      try {
        u(r.next(c));
      } catch (f) {
        l(f);
      }
    }
    function s(c) {
      try {
        u(r.throw(c));
      } catch (f) {
        l(f);
      }
    }
    function u(c) {
      c.done ? i(c.value) : a(c.value).then(o, s);
    }
    u((r = r.apply(n, e || [])).next());
  });
};
let pa = [], nl = !1;
const x8 = typeof window < "u", W3 = x8 ? window.requestAnimationFrame : (n) => {
};
function C8(n) {
  return S8(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (pa.push(e), !nl) nl = !0;
      else return;
      yield h8(), W3(() => {
        let r = [0, 0];
        for (let a = 0; a < pa.length; a++) {
          const l = pa[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= r[0]) && (r[0] = l.top + window.scrollY, r[1] = a);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), nl = !1, pa = [];
      });
    }
  });
}
function T8(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e;
  this && this.__awaiter;
  const l = d8();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: f } = e, { scroll_to_output: d = !1 } = e, { timer: p = !0 } = e, { show_progress: b = "full" } = e, { message: E = null } = e, { progress: k = null } = e, { variant: w = "default" } = e, { loading_text: v = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: A = !1 } = e, { border: x = !1 } = e, { autoscroll: Q } = e, z, P = !1, B = 0, N = 0, j = null, $ = null, W = 0, se = null, ke, Fe = null, xe = !0;
  const he = () => {
    t(0, s = t(27, j = t(19, ce = null))), t(25, B = performance.now()), t(26, N = 0), P = !0, Ee();
  };
  function Ee() {
    W3(() => {
      t(26, N = (performance.now() - B) / 1e3), P && Ee();
    });
  }
  function ie() {
    t(26, N = 0), t(0, s = t(27, j = t(19, ce = null))), P && (P = !1);
  }
  f8(() => {
    P && ie();
  });
  let ce = null;
  function ve(U) {
    po[U ? "unshift" : "push"](() => {
      Fe = U, t(16, Fe), t(7, k), t(14, se), t(15, ke);
    });
  }
  const oe = () => {
    l("clear_status");
  };
  function me(U) {
    po[U ? "unshift" : "push"](() => {
      z = U, t(13, z);
    });
  }
  return n.$$set = (U) => {
    "i18n" in U && t(1, o = U.i18n), "eta" in U && t(0, s = U.eta), "queue_position" in U && t(2, u = U.queue_position), "queue_size" in U && t(3, c = U.queue_size), "status" in U && t(4, f = U.status), "scroll_to_output" in U && t(22, d = U.scroll_to_output), "timer" in U && t(5, p = U.timer), "show_progress" in U && t(6, b = U.show_progress), "message" in U && t(23, E = U.message), "progress" in U && t(7, k = U.progress), "variant" in U && t(8, w = U.variant), "loading_text" in U && t(9, v = U.loading_text), "absolute" in U && t(10, _ = U.absolute), "translucent" in U && t(11, A = U.translucent), "border" in U && t(12, x = U.border), "autoscroll" in U && t(24, Q = U.autoscroll), "$$scope" in U && t(29, i = U.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = j), s != null && j !== s && (t(28, $ = (performance.now() - B) / 1e3 + s), t(19, ce = $.toFixed(1)), t(27, j = s))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, W = $ === null || $ <= 0 || !N ? null : Math.min(N / $, 1)), n.$$.dirty[0] & /*progress*/
    128 && k != null && t(18, xe = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (k != null ? t(14, se = k.map((U) => {
      if (U.index != null && U.length != null)
        return U.index / U.length;
      if (U.progress != null)
        return U.progress;
    })) : t(14, se = null), se ? (t(15, ke = se[se.length - 1]), Fe && (ke === 0 ? t(16, Fe.style.transition = "0", Fe) : t(16, Fe.style.transition = "150ms", Fe))) : t(15, ke = void 0)), n.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? he() : ie()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && z && d && (f === "pending" || f === "complete") && C8(z, Q), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = N.toFixed(1));
  }, [
    s,
    o,
    u,
    c,
    f,
    p,
    b,
    k,
    w,
    v,
    _,
    A,
    x,
    z,
    se,
    ke,
    Fe,
    W,
    xe,
    ce,
    r,
    l,
    d,
    E,
    Q,
    B,
    N,
    j,
    $,
    i,
    a,
    ve,
    oe,
    me
  ];
}
class Q8 extends o8 {
  constructor(e) {
    super(), u8(
      this,
      e,
      T8,
      F8,
      c8,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.1.7 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.7/LICENSE */
const {
  entries: Z3,
  setPrototypeOf: Qo,
  isFrozen: M8,
  getPrototypeOf: B8,
  getOwnPropertyDescriptor: z8
} = Object;
let {
  freeze: tt,
  seal: Ct,
  create: Y3
} = Object, {
  apply: Hl,
  construct: Vl
} = typeof Reflect < "u" && Reflect;
tt || (tt = function(e) {
  return e;
});
Ct || (Ct = function(e) {
  return e;
});
Hl || (Hl = function(e, t, r) {
  return e.apply(t, r);
});
Vl || (Vl = function(e, t) {
  return new e(...t);
});
const ga = mt(Array.prototype.forEach), Mo = mt(Array.prototype.pop), r1 = mt(Array.prototype.push), xa = mt(String.prototype.toLowerCase), al = mt(String.prototype.toString), Bo = mt(String.prototype.match), n1 = mt(String.prototype.replace), L8 = mt(String.prototype.indexOf), I8 = mt(String.prototype.trim), Lt = mt(Object.prototype.hasOwnProperty), $0 = mt(RegExp.prototype.test), a1 = N8(TypeError);
function mt(n) {
  return function(e) {
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      r[a - 1] = arguments[a];
    return Hl(n, e, r);
  };
}
function N8(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return Vl(n, t);
  };
}
function Oe(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : xa;
  Qo && Qo(n, null);
  let r = e.length;
  for (; r--; ) {
    let a = e[r];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (M8(e) || (e[r] = i), a = i);
    }
    n[a] = !0;
  }
  return n;
}
function R8(n) {
  for (let e = 0; e < n.length; e++)
    Lt(n, e) || (n[e] = null);
  return n;
}
function tn(n) {
  const e = Y3(null);
  for (const [t, r] of Z3(n))
    Lt(n, t) && (Array.isArray(r) ? e[t] = R8(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = tn(r) : e[t] = r);
  return e;
}
function i1(n, e) {
  for (; n !== null; ) {
    const r = z8(n, e);
    if (r) {
      if (r.get)
        return mt(r.get);
      if (typeof r.value == "function")
        return mt(r.value);
    }
    n = B8(n);
  }
  function t() {
    return null;
  }
  return t;
}
const zo = tt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), il = tt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), ll = tt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), O8 = tt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), sl = tt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), q8 = tt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Lo = tt(["#text"]), Io = tt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), ol = tt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), No = tt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), _a = tt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), P8 = Ct(/\{\{[\w\W]*|[\w\W]*\}\}/gm), H8 = Ct(/<%[\w\W]*|[\w\W]*%>/gm), V8 = Ct(/\${[\w\W]*}/gm), U8 = Ct(/^data-[\-\w.\u00B7-\uFFFF]/), j8 = Ct(/^aria-[\-\w]+$/), X3 = Ct(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), G8 = Ct(/^(?:\w+script|data):/i), W8 = Ct(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), K3 = Ct(/^html$/i), Z8 = Ct(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ro = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: P8,
  ERB_EXPR: H8,
  TMPLIT_EXPR: V8,
  DATA_ATTR: U8,
  ARIA_ATTR: j8,
  IS_ALLOWED_URI: X3,
  IS_SCRIPT_OR_DATA: G8,
  ATTR_WHITESPACE: W8,
  DOCTYPE_NAME: K3,
  CUSTOM_ELEMENT: Z8
});
const l1 = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, Y8 = function() {
  return typeof window > "u" ? null : window;
}, X8 = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (r = t.getAttribute(a));
  const i = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
};
function J3() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Y8();
  const e = (de) => J3(de);
  if (e.version = "3.1.7", e.removed = [], !n || !n.document || n.document.nodeType !== l1.document)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, a = r.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: o,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: f,
    DOMParser: d,
    trustedTypes: p
  } = n, b = s.prototype, E = i1(b, "cloneNode"), k = i1(b, "remove"), w = i1(b, "nextSibling"), v = i1(b, "childNodes"), _ = i1(b, "parentNode");
  if (typeof l == "function") {
    const de = t.createElement("template");
    de.content && de.content.ownerDocument && (t = de.content.ownerDocument);
  }
  let A, x = "";
  const {
    implementation: Q,
    createNodeIterator: z,
    createDocumentFragment: P,
    getElementsByTagName: B
  } = t, {
    importNode: N
  } = r;
  let j = {};
  e.isSupported = typeof Z3 == "function" && typeof _ == "function" && Q && Q.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: $,
    ERB_EXPR: W,
    TMPLIT_EXPR: se,
    DATA_ATTR: ke,
    ARIA_ATTR: Fe,
    IS_SCRIPT_OR_DATA: xe,
    ATTR_WHITESPACE: he,
    CUSTOM_ELEMENT: Ee
  } = Ro;
  let {
    IS_ALLOWED_URI: ie
  } = Ro, ce = null;
  const ve = Oe({}, [...zo, ...il, ...ll, ...sl, ...Lo]);
  let oe = null;
  const me = Oe({}, [...Io, ...ol, ...No, ..._a]);
  let U = Object.seal(Y3(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), He = null, ne = null, fe = !0, Z = !0, Qe = !1, Le = !0, Ne = !1, Ie = !0, Ve = !1, Ce = !1, b0 = !1, K = !1, qe = !1, Pe = !1, e0 = !0, Re = !1;
  const B0 = "user-content-";
  let h0 = !0, C0 = !1, Ue = {}, C = null;
  const X = Oe({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Me = null;
  const Ae = Oe({}, ["audio", "video", "img", "source", "image", "track"]);
  let We = null;
  const o0 = Oe({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), q = "http://www.w3.org/1998/Math/MathML", ut = "http://www.w3.org/2000/svg", nt = "http://www.w3.org/1999/xhtml";
  let z0 = nt, at = !1, Xt = null;
  const H1 = Oe({}, [q, ut, nt], al);
  let Br = null;
  const Dn = ["application/xhtml+xml", "text/html"], V1 = "text/html";
  let i0 = null, En = null;
  const A4 = t.createElement("form"), V5 = function(M) {
    return M instanceof RegExp || M instanceof Function;
  }, gi = function() {
    let M = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(En && En === M)) {
      if ((!M || typeof M != "object") && (M = {}), M = tn(M), Br = // eslint-disable-next-line unicorn/prefer-includes
      Dn.indexOf(M.PARSER_MEDIA_TYPE) === -1 ? V1 : M.PARSER_MEDIA_TYPE, i0 = Br === "application/xhtml+xml" ? al : xa, ce = Lt(M, "ALLOWED_TAGS") ? Oe({}, M.ALLOWED_TAGS, i0) : ve, oe = Lt(M, "ALLOWED_ATTR") ? Oe({}, M.ALLOWED_ATTR, i0) : me, Xt = Lt(M, "ALLOWED_NAMESPACES") ? Oe({}, M.ALLOWED_NAMESPACES, al) : H1, We = Lt(M, "ADD_URI_SAFE_ATTR") ? Oe(
        tn(o0),
        // eslint-disable-line indent
        M.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        i0
        // eslint-disable-line indent
      ) : o0, Me = Lt(M, "ADD_DATA_URI_TAGS") ? Oe(
        tn(Ae),
        // eslint-disable-line indent
        M.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        i0
        // eslint-disable-line indent
      ) : Ae, C = Lt(M, "FORBID_CONTENTS") ? Oe({}, M.FORBID_CONTENTS, i0) : X, He = Lt(M, "FORBID_TAGS") ? Oe({}, M.FORBID_TAGS, i0) : {}, ne = Lt(M, "FORBID_ATTR") ? Oe({}, M.FORBID_ATTR, i0) : {}, Ue = Lt(M, "USE_PROFILES") ? M.USE_PROFILES : !1, fe = M.ALLOW_ARIA_ATTR !== !1, Z = M.ALLOW_DATA_ATTR !== !1, Qe = M.ALLOW_UNKNOWN_PROTOCOLS || !1, Le = M.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ne = M.SAFE_FOR_TEMPLATES || !1, Ie = M.SAFE_FOR_XML !== !1, Ve = M.WHOLE_DOCUMENT || !1, K = M.RETURN_DOM || !1, qe = M.RETURN_DOM_FRAGMENT || !1, Pe = M.RETURN_TRUSTED_TYPE || !1, b0 = M.FORCE_BODY || !1, e0 = M.SANITIZE_DOM !== !1, Re = M.SANITIZE_NAMED_PROPS || !1, h0 = M.KEEP_CONTENT !== !1, C0 = M.IN_PLACE || !1, ie = M.ALLOWED_URI_REGEXP || X3, z0 = M.NAMESPACE || nt, U = M.CUSTOM_ELEMENT_HANDLING || {}, M.CUSTOM_ELEMENT_HANDLING && V5(M.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (U.tagNameCheck = M.CUSTOM_ELEMENT_HANDLING.tagNameCheck), M.CUSTOM_ELEMENT_HANDLING && V5(M.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (U.attributeNameCheck = M.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), M.CUSTOM_ELEMENT_HANDLING && typeof M.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (U.allowCustomizedBuiltInElements = M.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Ne && (Z = !1), qe && (K = !0), Ue && (ce = Oe({}, Lo), oe = [], Ue.html === !0 && (Oe(ce, zo), Oe(oe, Io)), Ue.svg === !0 && (Oe(ce, il), Oe(oe, ol), Oe(oe, _a)), Ue.svgFilters === !0 && (Oe(ce, ll), Oe(oe, ol), Oe(oe, _a)), Ue.mathMl === !0 && (Oe(ce, sl), Oe(oe, No), Oe(oe, _a))), M.ADD_TAGS && (ce === ve && (ce = tn(ce)), Oe(ce, M.ADD_TAGS, i0)), M.ADD_ATTR && (oe === me && (oe = tn(oe)), Oe(oe, M.ADD_ATTR, i0)), M.ADD_URI_SAFE_ATTR && Oe(We, M.ADD_URI_SAFE_ATTR, i0), M.FORBID_CONTENTS && (C === X && (C = tn(C)), Oe(C, M.FORBID_CONTENTS, i0)), h0 && (ce["#text"] = !0), Ve && Oe(ce, ["html", "head", "body"]), ce.table && (Oe(ce, ["tbody"]), delete He.tbody), M.TRUSTED_TYPES_POLICY) {
        if (typeof M.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw a1('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof M.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw a1('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        A = M.TRUSTED_TYPES_POLICY, x = A.createHTML("");
      } else
        A === void 0 && (A = X8(p, a)), A !== null && typeof x == "string" && (x = A.createHTML(""));
      tt && tt(M), En = M;
    }
  }, U5 = Oe({}, ["mi", "mo", "mn", "ms", "mtext"]), j5 = Oe({}, ["annotation-xml"]), F4 = Oe({}, ["title", "style", "font", "a", "script"]), G5 = Oe({}, [...il, ...ll, ...O8]), W5 = Oe({}, [...sl, ...q8]), S4 = function(M) {
    let J = _(M);
    (!J || !J.tagName) && (J = {
      namespaceURI: z0,
      tagName: "template"
    });
    const ue = xa(M.tagName), l0 = xa(J.tagName);
    return Xt[M.namespaceURI] ? M.namespaceURI === ut ? J.namespaceURI === nt ? ue === "svg" : J.namespaceURI === q ? ue === "svg" && (l0 === "annotation-xml" || U5[l0]) : !!G5[ue] : M.namespaceURI === q ? J.namespaceURI === nt ? ue === "math" : J.namespaceURI === ut ? ue === "math" && j5[l0] : !!W5[ue] : M.namespaceURI === nt ? J.namespaceURI === ut && !j5[l0] || J.namespaceURI === q && !U5[l0] ? !1 : !W5[ue] && (F4[ue] || !G5[ue]) : !!(Br === "application/xhtml+xml" && Xt[M.namespaceURI]) : !1;
  }, Kt = function(M) {
    r1(e.removed, {
      element: M
    });
    try {
      _(M).removeChild(M);
    } catch {
      k(M);
    }
  }, U1 = function(M, J) {
    try {
      r1(e.removed, {
        attribute: J.getAttributeNode(M),
        from: J
      });
    } catch {
      r1(e.removed, {
        attribute: null,
        from: J
      });
    }
    if (J.removeAttribute(M), M === "is" && !oe[M])
      if (K || qe)
        try {
          Kt(J);
        } catch {
        }
      else
        try {
          J.setAttribute(M, "");
        } catch {
        }
  }, Z5 = function(M) {
    let J = null, ue = null;
    if (b0)
      M = "<remove></remove>" + M;
    else {
      const L0 = Bo(M, /^[\r\n\t ]+/);
      ue = L0 && L0[0];
    }
    Br === "application/xhtml+xml" && z0 === nt && (M = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + M + "</body></html>");
    const l0 = A ? A.createHTML(M) : M;
    if (z0 === nt)
      try {
        J = new d().parseFromString(l0, Br);
      } catch {
      }
    if (!J || !J.documentElement) {
      J = Q.createDocument(z0, "template", null);
      try {
        J.documentElement.innerHTML = at ? x : l0;
      } catch {
      }
    }
    const j0 = J.body || J.documentElement;
    return M && ue && j0.insertBefore(t.createTextNode(ue), j0.childNodes[0] || null), z0 === nt ? B.call(J, Ve ? "html" : "body")[0] : Ve ? J.documentElement : j0;
  }, Y5 = function(M) {
    return z.call(
      M.ownerDocument || M,
      M,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, X5 = function(M) {
    return M instanceof f && (typeof M.nodeName != "string" || typeof M.textContent != "string" || typeof M.removeChild != "function" || !(M.attributes instanceof c) || typeof M.removeAttribute != "function" || typeof M.setAttribute != "function" || typeof M.namespaceURI != "string" || typeof M.insertBefore != "function" || typeof M.hasChildNodes != "function");
  }, K5 = function(M) {
    return typeof o == "function" && M instanceof o;
  }, dr = function(M, J, ue) {
    j[M] && ga(j[M], (l0) => {
      l0.call(e, J, ue, En);
    });
  }, J5 = function(M) {
    let J = null;
    if (dr("beforeSanitizeElements", M, null), X5(M))
      return Kt(M), !0;
    const ue = i0(M.nodeName);
    if (dr("uponSanitizeElement", M, {
      tagName: ue,
      allowedTags: ce
    }), M.hasChildNodes() && !K5(M.firstElementChild) && $0(/<[/\w]/g, M.innerHTML) && $0(/<[/\w]/g, M.textContent) || M.nodeType === l1.progressingInstruction || Ie && M.nodeType === l1.comment && $0(/<[/\w]/g, M.data))
      return Kt(M), !0;
    if (!ce[ue] || He[ue]) {
      if (!He[ue] && es(ue) && (U.tagNameCheck instanceof RegExp && $0(U.tagNameCheck, ue) || U.tagNameCheck instanceof Function && U.tagNameCheck(ue)))
        return !1;
      if (h0 && !C[ue]) {
        const l0 = _(M) || M.parentNode, j0 = v(M) || M.childNodes;
        if (j0 && l0) {
          const L0 = j0.length;
          for (let it = L0 - 1; it >= 0; --it) {
            const Jt = E(j0[it], !0);
            Jt.__removalCount = (M.__removalCount || 0) + 1, l0.insertBefore(Jt, w(M));
          }
        }
      }
      return Kt(M), !0;
    }
    return M instanceof s && !S4(M) || (ue === "noscript" || ue === "noembed" || ue === "noframes") && $0(/<\/no(script|embed|frames)/i, M.innerHTML) ? (Kt(M), !0) : (Ne && M.nodeType === l1.text && (J = M.textContent, ga([$, W, se], (l0) => {
      J = n1(J, l0, " ");
    }), M.textContent !== J && (r1(e.removed, {
      element: M.cloneNode()
    }), M.textContent = J)), dr("afterSanitizeElements", M, null), !1);
  }, $5 = function(M, J, ue) {
    if (e0 && (J === "id" || J === "name") && (ue in t || ue in A4))
      return !1;
    if (!(Z && !ne[J] && $0(ke, J))) {
      if (!(fe && $0(Fe, J))) {
        if (!oe[J] || ne[J]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(es(M) && (U.tagNameCheck instanceof RegExp && $0(U.tagNameCheck, M) || U.tagNameCheck instanceof Function && U.tagNameCheck(M)) && (U.attributeNameCheck instanceof RegExp && $0(U.attributeNameCheck, J) || U.attributeNameCheck instanceof Function && U.attributeNameCheck(J)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            J === "is" && U.allowCustomizedBuiltInElements && (U.tagNameCheck instanceof RegExp && $0(U.tagNameCheck, ue) || U.tagNameCheck instanceof Function && U.tagNameCheck(ue)))
          ) return !1;
        } else if (!We[J]) {
          if (!$0(ie, n1(ue, he, ""))) {
            if (!((J === "src" || J === "xlink:href" || J === "href") && M !== "script" && L8(ue, "data:") === 0 && Me[M])) {
              if (!(Qe && !$0(xe, n1(ue, he, "")))) {
                if (ue)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, es = function(M) {
    return M !== "annotation-xml" && Bo(M, Ee);
  }, ts = function(M) {
    dr("beforeSanitizeAttributes", M, null);
    const {
      attributes: J
    } = M;
    if (!J)
      return;
    const ue = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: oe
    };
    let l0 = J.length;
    for (; l0--; ) {
      const j0 = J[l0], {
        name: L0,
        namespaceURI: it,
        value: Jt
      } = j0, Un = i0(L0);
      let K0 = L0 === "value" ? Jt : I8(Jt);
      if (ue.attrName = Un, ue.attrValue = K0, ue.keepAttr = !0, ue.forceKeepAttr = void 0, dr("uponSanitizeAttribute", M, ue), K0 = ue.attrValue, ue.forceKeepAttr || (U1(L0, M), !ue.keepAttr))
        continue;
      if (!Le && $0(/\/>/i, K0)) {
        U1(L0, M);
        continue;
      }
      Ne && ga([$, W, se], (ns) => {
        K0 = n1(K0, ns, " ");
      });
      const rs = i0(M.nodeName);
      if ($5(rs, Un, K0)) {
        if (Re && (Un === "id" || Un === "name") && (U1(L0, M), K0 = B0 + K0), Ie && $0(/((--!?|])>)|<\/(style|title)/i, K0)) {
          U1(L0, M);
          continue;
        }
        if (A && typeof p == "object" && typeof p.getAttributeType == "function" && !it)
          switch (p.getAttributeType(rs, Un)) {
            case "TrustedHTML": {
              K0 = A.createHTML(K0);
              break;
            }
            case "TrustedScriptURL": {
              K0 = A.createScriptURL(K0);
              break;
            }
          }
        try {
          it ? M.setAttributeNS(it, L0, K0) : M.setAttribute(L0, K0), X5(M) ? Kt(M) : Mo(e.removed);
        } catch {
        }
      }
    }
    dr("afterSanitizeAttributes", M, null);
  }, x4 = function de(M) {
    let J = null;
    const ue = Y5(M);
    for (dr("beforeSanitizeShadowDOM", M, null); J = ue.nextNode(); )
      dr("uponSanitizeShadowNode", J, null), !J5(J) && (J.content instanceof i && de(J.content), ts(J));
    dr("afterSanitizeShadowDOM", M, null);
  };
  return e.sanitize = function(de) {
    let M = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, J = null, ue = null, l0 = null, j0 = null;
    if (at = !de, at && (de = "<!-->"), typeof de != "string" && !K5(de))
      if (typeof de.toString == "function") {
        if (de = de.toString(), typeof de != "string")
          throw a1("dirty is not a string, aborting");
      } else
        throw a1("toString is not a function");
    if (!e.isSupported)
      return de;
    if (Ce || gi(M), e.removed = [], typeof de == "string" && (C0 = !1), C0) {
      if (de.nodeName) {
        const Jt = i0(de.nodeName);
        if (!ce[Jt] || He[Jt])
          throw a1("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (de instanceof o)
      J = Z5("<!---->"), ue = J.ownerDocument.importNode(de, !0), ue.nodeType === l1.element && ue.nodeName === "BODY" || ue.nodeName === "HTML" ? J = ue : J.appendChild(ue);
    else {
      if (!K && !Ne && !Ve && // eslint-disable-next-line unicorn/prefer-includes
      de.indexOf("<") === -1)
        return A && Pe ? A.createHTML(de) : de;
      if (J = Z5(de), !J)
        return K ? null : Pe ? x : "";
    }
    J && b0 && Kt(J.firstChild);
    const L0 = Y5(C0 ? de : J);
    for (; l0 = L0.nextNode(); )
      J5(l0) || (l0.content instanceof i && x4(l0.content), ts(l0));
    if (C0)
      return de;
    if (K) {
      if (qe)
        for (j0 = P.call(J.ownerDocument); J.firstChild; )
          j0.appendChild(J.firstChild);
      else
        j0 = J;
      return (oe.shadowroot || oe.shadowrootmode) && (j0 = N.call(r, j0, !0)), j0;
    }
    let it = Ve ? J.outerHTML : J.innerHTML;
    return Ve && ce["!doctype"] && J.ownerDocument && J.ownerDocument.doctype && J.ownerDocument.doctype.name && $0(K3, J.ownerDocument.doctype.name) && (it = "<!DOCTYPE " + J.ownerDocument.doctype.name + `>
` + it), Ne && ga([$, W, se], (Jt) => {
      it = n1(it, Jt, " ");
    }), A && Pe ? A.createHTML(it) : it;
  }, e.setConfig = function() {
    let de = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    gi(de), Ce = !0;
  }, e.clearConfig = function() {
    En = null, Ce = !1;
  }, e.isValidAttribute = function(de, M, J) {
    En || gi({});
    const ue = i0(de), l0 = i0(M);
    return $5(ue, l0, J);
  }, e.addHook = function(de, M) {
    typeof M == "function" && (j[de] = j[de] || [], r1(j[de], M));
  }, e.removeHook = function(de) {
    if (j[de])
      return Mo(j[de]);
  }, e.removeHooks = function(de) {
    j[de] && (j[de] = []);
  }, e.removeAllHooks = function() {
    j = {};
  }, e;
}
J3();
const {
  SvelteComponent: K8,
  attr: J8,
  children: $8,
  claim_element: eh,
  detach: Ul,
  element: th,
  empty: Oo,
  init: rh,
  insert_hydration: $3,
  noop: qo,
  safe_not_equal: nh,
  set_style: Po
} = window.__gradio__svelte__internal;
function Ho(n) {
  let e, t = `${/*time_limit*/
  n[0]}s`;
  return {
    c() {
      e = th("div"), this.h();
    },
    l(r) {
      e = eh(r, "DIV", { class: !0 }), $8(e).forEach(Ul), this.h();
    },
    h() {
      J8(e, "class", "streaming-bar svelte-ga0jj6"), Po(e, "animation-duration", t);
    },
    m(r, a) {
      $3(r, e, a);
    },
    p(r, a) {
      a & /*time_limit*/
      1 && t !== (t = `${/*time_limit*/
      r[0]}s`) && Po(e, "animation-duration", t);
    },
    d(r) {
      r && Ul(e);
    }
  };
}
function ah(n) {
  let e, t = (
    /*time_limit*/
    n[0] && Ho(n)
  );
  return {
    c() {
      t && t.c(), e = Oo();
    },
    l(r) {
      t && t.l(r), e = Oo();
    },
    m(r, a) {
      t && t.m(r, a), $3(r, e, a);
    },
    p(r, [a]) {
      /*time_limit*/
      r[0] ? t ? t.p(r, a) : (t = Ho(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: qo,
    o: qo,
    d(r) {
      r && Ul(e), t && t.d(r);
    }
  };
}
function ih(n, e, t) {
  let { time_limit: r } = e;
  return n.$$set = (a) => {
    "time_limit" in a && t(0, r = a.time_limit);
  }, [r];
}
class e4 extends K8 {
  constructor(e) {
    super(), rh(this, e, ih, ah, nh, { time_limit: 0 });
  }
}
const {
  SvelteComponent: lh,
  append_hydration: ul,
  attr: va,
  children: Vo,
  claim_component: sh,
  claim_element: Uo,
  claim_space: oh,
  claim_text: uh,
  create_component: ch,
  destroy_component: hh,
  detach: cl,
  element: jo,
  init: fh,
  insert_hydration: dh,
  mount_component: mh,
  safe_not_equal: ph,
  set_data: gh,
  space: _h,
  text: vh,
  toggle_class: Pr,
  transition_in: bh,
  transition_out: wh
} = window.__gradio__svelte__internal;
function yh(n) {
  let e, t, r, a, i, l;
  return r = new /*Icon*/
  n[1]({}), {
    c() {
      e = jo("label"), t = jo("span"), ch(r.$$.fragment), a = _h(), i = vh(
        /*label*/
        n[0]
      ), this.h();
    },
    l(o) {
      e = Uo(o, "LABEL", {
        for: !0,
        "data-testid": !0,
        class: !0
      });
      var s = Vo(e);
      t = Uo(s, "SPAN", { class: !0 });
      var u = Vo(t);
      sh(r.$$.fragment, u), u.forEach(cl), a = oh(s), i = uh(
        s,
        /*label*/
        n[0]
      ), s.forEach(cl), this.h();
    },
    h() {
      va(t, "class", "svelte-168uj4v"), va(e, "for", ""), va(e, "data-testid", "block-label"), va(e, "class", "svelte-168uj4v"), Pr(e, "hide", !/*show_label*/
      n[2]), Pr(e, "sr-only", !/*show_label*/
      n[2]), Pr(
        e,
        "float",
        /*float*/
        n[4]
      ), Pr(
        e,
        "hide-label",
        /*disable*/
        n[3]
      );
    },
    m(o, s) {
      dh(o, e, s), ul(e, t), mh(r, t, null), ul(e, a), ul(e, i), l = !0;
    },
    p(o, [s]) {
      (!l || s & /*label*/
      1) && gh(
        i,
        /*label*/
        o[0]
      ), (!l || s & /*show_label*/
      4) && Pr(e, "hide", !/*show_label*/
      o[2]), (!l || s & /*show_label*/
      4) && Pr(e, "sr-only", !/*show_label*/
      o[2]), (!l || s & /*float*/
      16) && Pr(
        e,
        "float",
        /*float*/
        o[4]
      ), (!l || s & /*disable*/
      8) && Pr(
        e,
        "hide-label",
        /*disable*/
        o[3]
      );
    },
    i(o) {
      l || (bh(r.$$.fragment, o), l = !0);
    },
    o(o) {
      wh(r.$$.fragment, o), l = !1;
    },
    d(o) {
      o && cl(e), hh(r);
    }
  };
}
function kh(n, e, t) {
  let { label: r = null } = e, { Icon: a } = e, { show_label: i = !0 } = e, { disable: l = !1 } = e, { float: o = !0 } = e;
  return n.$$set = (s) => {
    "label" in s && t(0, r = s.label), "Icon" in s && t(1, a = s.Icon), "show_label" in s && t(2, i = s.show_label), "disable" in s && t(3, l = s.disable), "float" in s && t(4, o = s.float);
  }, [r, a, i, l, o];
}
class ui extends lh {
  constructor(e) {
    super(), fh(this, e, kh, yh, ph, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: Dh,
  append_hydration: jl,
  attr: gr,
  bubble: Eh,
  check_outros: Ah,
  children: Gl,
  claim_component: Fh,
  claim_element: Wl,
  claim_space: Sh,
  claim_text: xh,
  construct_svelte_component: Go,
  create_component: Wo,
  destroy_component: Zo,
  detach: m1,
  element: Zl,
  group_outros: Ch,
  init: Th,
  insert_hydration: t4,
  listen: Qh,
  mount_component: Yo,
  safe_not_equal: Mh,
  set_data: Bh,
  set_style: ba,
  space: zh,
  text: Lh,
  toggle_class: lt,
  transition_in: Xo,
  transition_out: Ko
} = window.__gradio__svelte__internal;
function Jo(n) {
  let e, t;
  return {
    c() {
      e = Zl("span"), t = Lh(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = Wl(r, "SPAN", { class: !0 });
      var a = Gl(e);
      t = xh(
        a,
        /*label*/
        n[1]
      ), a.forEach(m1), this.h();
    },
    h() {
      gr(e, "class", "svelte-vk34kx");
    },
    m(r, a) {
      t4(r, e, a), jl(e, t);
    },
    p(r, a) {
      a & /*label*/
      2 && Bh(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && m1(e);
    }
  };
}
function Ih(n) {
  let e, t, r, a, i, l, o, s = (
    /*show_label*/
    n[2] && Jo(n)
  );
  var u = (
    /*Icon*/
    n[0]
  );
  function c(f, d) {
    return {};
  }
  return u && (a = Go(u, c())), {
    c() {
      e = Zl("button"), s && s.c(), t = zh(), r = Zl("div"), a && Wo(a.$$.fragment), this.h();
    },
    l(f) {
      e = Wl(f, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var d = Gl(e);
      s && s.l(d), t = Sh(d), r = Wl(d, "DIV", { class: !0 });
      var p = Gl(r);
      a && Fh(a.$$.fragment, p), p.forEach(m1), d.forEach(m1), this.h();
    },
    h() {
      gr(r, "class", "svelte-vk34kx"), lt(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), lt(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), lt(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], gr(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), gr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), gr(
        e,
        "title",
        /*label*/
        n[1]
      ), gr(e, "class", "svelte-vk34kx"), lt(
        e,
        "pending",
        /*pending*/
        n[3]
      ), lt(
        e,
        "padded",
        /*padded*/
        n[5]
      ), lt(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), lt(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), ba(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), ba(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(f, d) {
      t4(f, e, d), s && s.m(e, null), jl(e, t), jl(e, r), a && Yo(a, r, null), i = !0, l || (o = Qh(
        e,
        "click",
        /*click_handler*/
        n[13]
      ), l = !0);
    },
    p(f, [d]) {
      if (/*show_label*/
      f[2] ? s ? s.p(f, d) : (s = Jo(f), s.c(), s.m(e, t)) : s && (s.d(1), s = null), d & /*Icon*/
      1 && u !== (u = /*Icon*/
      f[0])) {
        if (a) {
          Ch();
          const p = a;
          Ko(p.$$.fragment, 1, 0, () => {
            Zo(p, 1);
          }), Ah();
        }
        u ? (a = Go(u, c()), Wo(a.$$.fragment), Xo(a.$$.fragment, 1), Yo(a, r, null)) : a = null;
      }
      (!i || d & /*size*/
      16) && lt(
        r,
        "small",
        /*size*/
        f[4] === "small"
      ), (!i || d & /*size*/
      16) && lt(
        r,
        "large",
        /*size*/
        f[4] === "large"
      ), (!i || d & /*size*/
      16) && lt(
        r,
        "medium",
        /*size*/
        f[4] === "medium"
      ), (!i || d & /*disabled*/
      128) && (e.disabled = /*disabled*/
      f[7]), (!i || d & /*label*/
      2) && gr(
        e,
        "aria-label",
        /*label*/
        f[1]
      ), (!i || d & /*hasPopup*/
      256) && gr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        f[8]
      ), (!i || d & /*label*/
      2) && gr(
        e,
        "title",
        /*label*/
        f[1]
      ), (!i || d & /*pending*/
      8) && lt(
        e,
        "pending",
        /*pending*/
        f[3]
      ), (!i || d & /*padded*/
      32) && lt(
        e,
        "padded",
        /*padded*/
        f[5]
      ), (!i || d & /*highlight*/
      64) && lt(
        e,
        "highlight",
        /*highlight*/
        f[6]
      ), (!i || d & /*transparent*/
      512) && lt(
        e,
        "transparent",
        /*transparent*/
        f[9]
      ), d & /*disabled, _color*/
      2176 && ba(e, "color", !/*disabled*/
      f[7] && /*_color*/
      f[11] ? (
        /*_color*/
        f[11]
      ) : "var(--block-label-text-color)"), d & /*disabled, background*/
      1152 && ba(e, "--bg-color", /*disabled*/
      f[7] ? "auto" : (
        /*background*/
        f[10]
      ));
    },
    i(f) {
      i || (a && Xo(a.$$.fragment, f), i = !0);
    },
    o(f) {
      a && Ko(a.$$.fragment, f), i = !1;
    },
    d(f) {
      f && m1(e), s && s.d(), a && Zo(a), l = !1, o();
    }
  };
}
function Nh(n, e, t) {
  let r, { Icon: a } = e, { label: i = "" } = e, { show_label: l = !1 } = e, { pending: o = !1 } = e, { size: s = "small" } = e, { padded: u = !0 } = e, { highlight: c = !1 } = e, { disabled: f = !1 } = e, { hasPopup: d = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: E = "var(--block-background-fill)" } = e;
  function k(w) {
    Eh.call(this, n, w);
  }
  return n.$$set = (w) => {
    "Icon" in w && t(0, a = w.Icon), "label" in w && t(1, i = w.label), "show_label" in w && t(2, l = w.show_label), "pending" in w && t(3, o = w.pending), "size" in w && t(4, s = w.size), "padded" in w && t(5, u = w.padded), "highlight" in w && t(6, c = w.highlight), "disabled" in w && t(7, f = w.disabled), "hasPopup" in w && t(8, d = w.hasPopup), "color" in w && t(12, p = w.color), "transparent" in w && t(9, b = w.transparent), "background" in w && t(10, E = w.background);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = c ? "var(--color-accent)" : p);
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    c,
    f,
    d,
    b,
    E,
    r,
    p,
    k
  ];
}
class Rh extends Dh {
  constructor(e) {
    super(), Th(this, e, Nh, Ih, Mh, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Oh,
  append_hydration: qh,
  attr: hl,
  binding_callbacks: Ph,
  children: $o,
  claim_element: e2,
  create_slot: Hh,
  detach: fl,
  element: t2,
  get_all_dirty_from_scope: Vh,
  get_slot_changes: Uh,
  init: jh,
  insert_hydration: Gh,
  safe_not_equal: Wh,
  toggle_class: Hr,
  transition_in: Zh,
  transition_out: Yh,
  update_slot_base: Xh
} = window.__gradio__svelte__internal;
function Kh(n) {
  let e, t, r;
  const a = (
    /*#slots*/
    n[5].default
  ), i = Hh(
    a,
    n,
    /*$$scope*/
    n[4],
    null
  );
  return {
    c() {
      e = t2("div"), t = t2("div"), i && i.c(), this.h();
    },
    l(l) {
      e = e2(l, "DIV", { class: !0, "aria-label": !0 });
      var o = $o(e);
      t = e2(o, "DIV", { class: !0 });
      var s = $o(t);
      i && i.l(s), s.forEach(fl), o.forEach(fl), this.h();
    },
    h() {
      hl(t, "class", "icon svelte-3w3rth"), hl(e, "class", "empty svelte-3w3rth"), hl(e, "aria-label", "Empty value"), Hr(
        e,
        "small",
        /*size*/
        n[0] === "small"
      ), Hr(
        e,
        "large",
        /*size*/
        n[0] === "large"
      ), Hr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        n[1]
      ), Hr(
        e,
        "small_parent",
        /*parent_height*/
        n[3]
      );
    },
    m(l, o) {
      Gh(l, e, o), qh(e, t), i && i.m(t, null), n[6](e), r = !0;
    },
    p(l, [o]) {
      i && i.p && (!r || o & /*$$scope*/
      16) && Xh(
        i,
        a,
        l,
        /*$$scope*/
        l[4],
        r ? Uh(
          a,
          /*$$scope*/
          l[4],
          o,
          null
        ) : Vh(
          /*$$scope*/
          l[4]
        ),
        null
      ), (!r || o & /*size*/
      1) && Hr(
        e,
        "small",
        /*size*/
        l[0] === "small"
      ), (!r || o & /*size*/
      1) && Hr(
        e,
        "large",
        /*size*/
        l[0] === "large"
      ), (!r || o & /*unpadded_box*/
      2) && Hr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        l[1]
      ), (!r || o & /*parent_height*/
      8) && Hr(
        e,
        "small_parent",
        /*parent_height*/
        l[3]
      );
    },
    i(l) {
      r || (Zh(i, l), r = !0);
    },
    o(l) {
      Yh(i, l), r = !1;
    },
    d(l) {
      l && fl(e), i && i.d(l), n[6](null);
    }
  };
}
function Jh(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e, { size: l = "small" } = e, { unpadded_box: o = !1 } = e, s;
  function u(f) {
    var d;
    if (!f) return !1;
    const { height: p } = f.getBoundingClientRect(), { height: b } = ((d = f.parentElement) === null || d === void 0 ? void 0 : d.getBoundingClientRect()) || { height: p };
    return p > b + 2;
  }
  function c(f) {
    Ph[f ? "unshift" : "push"](() => {
      s = f, t(2, s);
    });
  }
  return n.$$set = (f) => {
    "size" in f && t(0, l = f.size), "unpadded_box" in f && t(1, o = f.unpadded_box), "$$scope" in f && t(4, i = f.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*el*/
    4 && t(3, r = u(s));
  }, [l, o, s, r, i, a, c];
}
class r4 extends Oh {
  constructor(e) {
    super(), jh(this, e, Jh, Kh, Wh, { size: 0, unpadded_box: 1 });
  }
}
const $h = /^(#\s*)(.+)$/m;
function ef(n) {
  const e = n.trim(), t = e.match($h);
  if (!t)
    return [!1, e || !1];
  const [r, , a] = t, i = a.trim();
  if (e === r)
    return [i, !1];
  const l = t.index !== void 0 ? t.index + r.length : 0, s = e.substring(l).trim() || !1;
  return [i, s];
}
const {
  SvelteComponent: tf,
  append_hydration: ln,
  attr: k1,
  check_outros: rf,
  children: D1,
  claim_component: n4,
  claim_element: E1,
  claim_space: ci,
  claim_text: nn,
  create_component: a4,
  destroy_component: i4,
  detach: W0,
  element: A1,
  empty: Ha,
  group_outros: nf,
  init: af,
  insert_hydration: jt,
  mount_component: l4,
  safe_not_equal: lf,
  set_data: F1,
  space: hi,
  text: an,
  toggle_class: r2,
  transition_in: Va,
  transition_out: Ua
} = window.__gradio__svelte__internal;
function sf(n) {
  let e, t;
  return e = new Hu({}), {
    c() {
      a4(e.$$.fragment);
    },
    l(r) {
      n4(e.$$.fragment, r);
    },
    m(r, a) {
      l4(e, r, a), t = !0;
    },
    i(r) {
      t || (Va(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Ua(e.$$.fragment, r), t = !1;
    },
    d(r) {
      i4(e, r);
    }
  };
}
function of(n) {
  let e, t;
  return e = new bu({}), {
    c() {
      a4(e.$$.fragment);
    },
    l(r) {
      n4(e.$$.fragment, r);
    },
    m(r, a) {
      l4(e, r, a), t = !0;
    },
    i(r) {
      t || (Va(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Ua(e.$$.fragment, r), t = !1;
    },
    d(r) {
      i4(e, r);
    }
  };
}
function uf(n) {
  let e = (
    /*i18n*/
    n[1](
      /*defs*/
      n[7][
        /*type*/
        n[0]
      ] || /*defs*/
      n[7].file
    ) + ""
  ), t, r, a, i = (
    /*mode*/
    n[3] !== "short" && n2(n)
  );
  return {
    c() {
      t = an(e), r = hi(), i && i.c(), a = Ha();
    },
    l(l) {
      t = nn(l, e), r = ci(l), i && i.l(l), a = Ha();
    },
    m(l, o) {
      jt(l, t, o), jt(l, r, o), i && i.m(l, o), jt(l, a, o);
    },
    p(l, o) {
      o & /*i18n, type*/
      3 && e !== (e = /*i18n*/
      l[1](
        /*defs*/
        l[7][
          /*type*/
          l[0]
        ] || /*defs*/
        l[7].file
      ) + "") && F1(t, e), /*mode*/
      l[3] !== "short" ? i ? i.p(l, o) : (i = n2(l), i.c(), i.m(a.parentNode, a)) : i && (i.d(1), i = null);
    },
    d(l) {
      l && (W0(t), W0(r), W0(a)), i && i.d(l);
    }
  };
}
function cf(n) {
  let e, t, r = (
    /*heading*/
    n[6] && a2(n)
  ), a = (
    /*paragraph*/
    n[5] && i2(n)
  );
  return {
    c() {
      r && r.c(), e = hi(), a && a.c(), t = Ha();
    },
    l(i) {
      r && r.l(i), e = ci(i), a && a.l(i), t = Ha();
    },
    m(i, l) {
      r && r.m(i, l), jt(i, e, l), a && a.m(i, l), jt(i, t, l);
    },
    p(i, l) {
      /*heading*/
      i[6] ? r ? r.p(i, l) : (r = a2(i), r.c(), r.m(e.parentNode, e)) : r && (r.d(1), r = null), /*paragraph*/
      i[5] ? a ? a.p(i, l) : (a = i2(i), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    d(i) {
      i && (W0(e), W0(t)), r && r.d(i), a && a.d(i);
    }
  };
}
function n2(n) {
  let e, t, r = (
    /*i18n*/
    n[1]("common.or") + ""
  ), a, i, l, o = (
    /*message*/
    (n[2] || /*i18n*/
    n[1]("upload_text.click_to_upload")) + ""
  ), s;
  return {
    c() {
      e = A1("span"), t = an("- "), a = an(r), i = an(" -"), l = hi(), s = an(o), this.h();
    },
    l(u) {
      e = E1(u, "SPAN", { class: !0 });
      var c = D1(e);
      t = nn(c, "- "), a = nn(c, r), i = nn(c, " -"), c.forEach(W0), l = ci(u), s = nn(u, o), this.h();
    },
    h() {
      k1(e, "class", "or svelte-1xg7h5n");
    },
    m(u, c) {
      jt(u, e, c), ln(e, t), ln(e, a), ln(e, i), jt(u, l, c), jt(u, s, c);
    },
    p(u, c) {
      c & /*i18n*/
      2 && r !== (r = /*i18n*/
      u[1]("common.or") + "") && F1(a, r), c & /*message, i18n*/
      6 && o !== (o = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && F1(s, o);
    },
    d(u) {
      u && (W0(e), W0(l), W0(s));
    }
  };
}
function a2(n) {
  let e, t;
  return {
    c() {
      e = A1("h2"), t = an(
        /*heading*/
        n[6]
      ), this.h();
    },
    l(r) {
      e = E1(r, "H2", { class: !0 });
      var a = D1(e);
      t = nn(
        a,
        /*heading*/
        n[6]
      ), a.forEach(W0), this.h();
    },
    h() {
      k1(e, "class", "svelte-1xg7h5n");
    },
    m(r, a) {
      jt(r, e, a), ln(e, t);
    },
    p(r, a) {
      a & /*heading*/
      64 && F1(
        t,
        /*heading*/
        r[6]
      );
    },
    d(r) {
      r && W0(e);
    }
  };
}
function i2(n) {
  let e, t;
  return {
    c() {
      e = A1("p"), t = an(
        /*paragraph*/
        n[5]
      ), this.h();
    },
    l(r) {
      e = E1(r, "P", { class: !0 });
      var a = D1(e);
      t = nn(
        a,
        /*paragraph*/
        n[5]
      ), a.forEach(W0), this.h();
    },
    h() {
      k1(e, "class", "svelte-1xg7h5n");
    },
    m(r, a) {
      jt(r, e, a), ln(e, t);
    },
    p(r, a) {
      a & /*paragraph*/
      32 && F1(
        t,
        /*paragraph*/
        r[5]
      );
    },
    d(r) {
      r && W0(e);
    }
  };
}
function hf(n) {
  let e, t, r, a, i, l;
  const o = [of, sf], s = [];
  function u(p, b) {
    return (
      /*type*/
      p[0] === "clipboard" ? 0 : 1
    );
  }
  r = u(n), a = s[r] = o[r](n);
  function c(p, b) {
    return (
      /*heading*/
      p[6] || /*paragraph*/
      p[5] ? cf : uf
    );
  }
  let f = c(n), d = f(n);
  return {
    c() {
      e = A1("div"), t = A1("span"), a.c(), i = hi(), d.c(), this.h();
    },
    l(p) {
      e = E1(p, "DIV", { class: !0 });
      var b = D1(e);
      t = E1(b, "SPAN", { class: !0 });
      var E = D1(t);
      a.l(E), E.forEach(W0), i = ci(b), d.l(b), b.forEach(W0), this.h();
    },
    h() {
      k1(t, "class", "icon-wrap svelte-1xg7h5n"), r2(
        t,
        "hovered",
        /*hovered*/
        n[4]
      ), k1(e, "class", "wrap svelte-1xg7h5n");
    },
    m(p, b) {
      jt(p, e, b), ln(e, t), s[r].m(t, null), ln(e, i), d.m(e, null), l = !0;
    },
    p(p, [b]) {
      let E = r;
      r = u(p), r !== E && (nf(), Ua(s[E], 1, 1, () => {
        s[E] = null;
      }), rf(), a = s[r], a || (a = s[r] = o[r](p), a.c()), Va(a, 1), a.m(t, null)), (!l || b & /*hovered*/
      16) && r2(
        t,
        "hovered",
        /*hovered*/
        p[4]
      ), f === (f = c(p)) && d ? d.p(p, b) : (d.d(1), d = f(p), d && (d.c(), d.m(e, null)));
    },
    i(p) {
      l || (Va(a), l = !0);
    },
    o(p) {
      Ua(a), l = !1;
    },
    d(p) {
      p && W0(e), s[r].d(), d.d();
    }
  };
}
function ff(n, e, t) {
  let r, a, { type: i = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: s = "full" } = e, { hovered: u = !1 } = e, { placeholder: c = void 0 } = e;
  const f = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return n.$$set = (d) => {
    "type" in d && t(0, i = d.type), "i18n" in d && t(1, l = d.i18n), "message" in d && t(2, o = d.message), "mode" in d && t(3, s = d.mode), "hovered" in d && t(4, u = d.hovered), "placeholder" in d && t(8, c = d.placeholder);
  }, n.$$.update = () => {
    n.$$.dirty & /*placeholder*/
    256 && t(6, [r, a] = c ? ef(c) : [!1, !1], r, (t(5, a), t(8, c)));
  }, [i, l, o, s, u, a, r, f, c];
}
class df extends tf {
  constructor(e) {
    super(), af(this, e, ff, hf, lf, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4,
      placeholder: 8
    });
  }
}
const {
  SvelteComponent: mf,
  append_hydration: wa,
  attr: dl,
  check_outros: pf,
  children: ml,
  claim_component: gf,
  claim_element: pl,
  claim_space: _f,
  claim_text: vf,
  construct_svelte_component: l2,
  create_component: s2,
  destroy_component: o2,
  detach: ya,
  element: gl,
  group_outros: bf,
  init: wf,
  insert_hydration: yf,
  listen: kf,
  mount_component: u2,
  safe_not_equal: Df,
  set_data: Ef,
  set_style: Af,
  space: Ff,
  text: Sf,
  transition_in: c2,
  transition_out: h2
} = window.__gradio__svelte__internal, { createEventDispatcher: xf } = window.__gradio__svelte__internal;
function Cf(n) {
  let e, t, r, a, i, l, o, s, u;
  var c = (
    /*icon*/
    n[0]
  );
  function f(d, p) {
    return {};
  }
  return c && (a = l2(c, f())), {
    c() {
      e = gl("button"), t = gl("div"), r = gl("span"), a && s2(a.$$.fragment), i = Ff(), l = Sf(
        /*text*/
        n[1]
      ), this.h();
    },
    l(d) {
      e = pl(d, "BUTTON", { class: !0 });
      var p = ml(e);
      t = pl(p, "DIV", { class: !0 });
      var b = ml(t);
      r = pl(b, "SPAN", { class: !0 });
      var E = ml(r);
      a && gf(a.$$.fragment, E), E.forEach(ya), i = _f(b), l = vf(
        b,
        /*text*/
        n[1]
      ), b.forEach(ya), p.forEach(ya), this.h();
    },
    h() {
      dl(r, "class", "icon-wrap svelte-fjcd9c"), dl(t, "class", "wrap svelte-fjcd9c"), dl(e, "class", "svelte-fjcd9c"), Af(e, "height", "100%");
    },
    m(d, p) {
      yf(d, e, p), wa(e, t), wa(t, r), a && u2(a, r, null), wa(t, i), wa(t, l), o = !0, s || (u = kf(
        e,
        "click",
        /*click_handler*/
        n[3]
      ), s = !0);
    },
    p(d, [p]) {
      if (p & /*icon*/
      1 && c !== (c = /*icon*/
      d[0])) {
        if (a) {
          bf();
          const b = a;
          h2(b.$$.fragment, 1, 0, () => {
            o2(b, 1);
          }), pf();
        }
        c ? (a = l2(c, f()), s2(a.$$.fragment), c2(a.$$.fragment, 1), u2(a, r, null)) : a = null;
      }
      (!o || p & /*text*/
      2) && Ef(
        l,
        /*text*/
        d[1]
      );
    },
    i(d) {
      o || (a && c2(a.$$.fragment, d), o = !0);
    },
    o(d) {
      a && h2(a.$$.fragment, d), o = !1;
    },
    d(d) {
      d && ya(e), a && o2(a), s = !1, u();
    }
  };
}
function Tf(n, e, t) {
  let r, { icon: a = Es } = e;
  const i = xf(), l = () => i("click");
  return n.$$set = (o) => {
    "icon" in o && t(0, a = o.icon);
  }, n.$$.update = () => {
    n.$$.dirty & /*icon*/
    1 && t(1, r = a === Es ? "Click to Access Webcam" : "Click to Access Microphone");
  }, [a, r, i, l];
}
class C5 extends mf {
  constructor(e) {
    super(), wf(this, e, Tf, Cf, Df, { icon: 0 });
  }
}
function T5() {
  return navigator.mediaDevices.enumerateDevices();
}
function Qf(n, e) {
  e.srcObject = n, e.muted = !0, e.play();
}
async function ja(n, e, t, r) {
  const a = r || {
    width: { ideal: 500 },
    height: { ideal: 500 }
  }, i = {
    video: t ? { deviceId: { exact: t }, ...a } : a,
    audio: n
  };
  return navigator.mediaDevices.getUserMedia(i).then((l) => (Qf(l, e), l));
}
function S1(n, e = "videoinput") {
  return n.filter(
    (r) => r.kind === e
  );
}
function Mf(n, e) {
  return n.addEventListener(
    "icegatheringstatechange",
    () => {
      console.debug(n.iceGatheringState);
    },
    !1
  ), n.addEventListener(
    "iceconnectionstatechange",
    () => {
      console.debug(n.iceConnectionState);
    },
    !1
  ), n.addEventListener(
    "signalingstatechange",
    () => {
      console.debug(n.signalingState);
    },
    !1
  ), n.addEventListener("track", (t) => {
    console.debug("track event listener"), e && e.srcObject !== t.streams[0] && (console.debug("streams", t.streams), e.srcObject = t.streams[0], console.debug("node.srcOject", e.srcObject), t.track.kind === "audio" && (e.volume = 1, e.muted = !1, e.autoplay = !0, e.play().catch((r) => console.debug("Autoplay failed:", r))));
  }), n;
}
async function B1(n, e, t, r, a, i = "video", l = () => {
}, o = {}) {
  e = Mf(e, t);
  const s = e.createDataChannel("text");
  return s.onopen = () => {
    console.debug("Data channel is open"), s.send("handshake");
  }, s.onmessage = (u) => {
    console.debug("Received message:", u.data);
    let c;
    try {
      c = JSON.parse(u.data);
    } catch {
      console.debug("Error parsing JSON");
    }
    console.log("event_json", c), (u.data === "change" || u.data === "tick" || u.data === "stopword" || (c == null ? void 0 : c.type) === "warning" || (c == null ? void 0 : c.type) === "error") && (console.debug(`${u.data} event received`), l(c ?? u.data));
  }, n ? n.getTracks().forEach(async (u) => {
    console.debug("Track stream callback", u);
    const c = e.addTrack(u, n), d = { ...c.getParameters(), ...o };
    await c.setParameters(d), console.debug("sender params", c.getParameters());
  }) : (console.debug("Creating transceiver!"), e.addTransceiver(i, { direction: "recvonly" })), await zf(e, r, a), e;
}
function Bf(n, e) {
  return new Promise((t, r) => {
    n(e).then((a) => {
      console.debug("data", a), (a == null ? void 0 : a.status) === "failed" && (console.debug("rejecting"), r("error")), t(a);
    });
  });
}
async function zf(n, e, t) {
  return n.createOffer().then((r) => n.setLocalDescription(r)).then(() => new Promise((r) => {
    if (console.debug("ice gathering state", n.iceGatheringState), n.iceGatheringState === "complete")
      r();
    else {
      const a = () => {
        n.iceGatheringState === "complete" && (console.debug("ice complete"), n.removeEventListener("icegatheringstatechange", a), r());
      };
      n.addEventListener("icegatheringstatechange", a);
    }
  })).then(() => {
    var r = n.localDescription;
    return Bf(e, {
      sdp: r.sdp,
      type: r.type,
      webrtc_id: t
    });
  }).then((r) => r).then((r) => n.setRemoteDescription(r));
}
function Kr(n) {
  console.debug("Stopping peer connection"), n.getTransceivers && n.getTransceivers().forEach((e) => {
    e.stop && e.stop();
  }), n.getSenders() && n.getSenders().forEach((e) => {
    console.log("sender", e), e.track && e.track.stop && e.track.stop();
  }), setTimeout(() => {
    n.close();
  }, 500);
}
const {
  SvelteComponent: Lf,
  append_hydration: _l,
  attr: Wr,
  check_outros: s4,
  children: Ca,
  claim_component: If,
  claim_element: p1,
  claim_space: Nf,
  construct_svelte_component: f2,
  create_component: d2,
  destroy_component: m2,
  destroy_each: Rf,
  detach: br,
  element: g1,
  empty: Ga,
  ensure_array_like: p2,
  group_outros: o4,
  init: Of,
  insert_hydration: z1,
  mount_component: g2,
  noop: _2,
  safe_not_equal: qf,
  set_style: Rt,
  space: Pf,
  src_url_equal: v2,
  transition_in: Wa,
  transition_out: Za
} = window.__gradio__svelte__internal, { onDestroy: Hf } = window.__gradio__svelte__internal;
function b2(n, e, t) {
  const r = n.slice();
  return r[14] = e[t], r[16] = t, r;
}
function w2(n) {
  let e, t = p2(Array(3)), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = y2(b2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = Ga();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = Ga();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      z1(a, e, i);
    },
    p(a, i) {
      if (i & /*pulse_color, maxPulseScale, pulseIntensity*/
      44) {
        t = p2(Array(3));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = b2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = y2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && br(e), Rf(r, a);
    }
  };
}
function y2(n) {
  let e;
  return {
    c() {
      e = g1("div"), this.h();
    },
    l(t) {
      e = p1(t, "DIV", { class: !0 }), Ca(e).forEach(br), this.h();
    },
    h() {
      Wr(e, "class", "pulse-ring svelte-t6tj07"), Rt(
        e,
        "background",
        /*pulse_color*/
        n[2]
      ), Rt(e, "animation-delay", `${/*i*/
      n[16] * 0.4}s`), Rt(
        e,
        "--max-scale",
        /*maxPulseScale*/
        n[5]
      ), Rt(e, "opacity", 0.5 * /*pulseIntensity*/
      n[3]);
    },
    m(t, r) {
      z1(t, e, r);
    },
    p(t, r) {
      r & /*pulse_color*/
      4 && Rt(
        e,
        "background",
        /*pulse_color*/
        t[2]
      ), r & /*maxPulseScale*/
      32 && Rt(
        e,
        "--max-scale",
        /*maxPulseScale*/
        t[5]
      ), r & /*pulseIntensity*/
      8 && Rt(e, "opacity", 0.5 * /*pulseIntensity*/
      t[3]);
    },
    d(t) {
      t && br(e);
    }
  };
}
function Vf(n) {
  let e, t, r;
  var a = (
    /*icon*/
    n[0]
  );
  function i(l, o) {
    return {};
  }
  return a && (e = f2(a, i())), {
    c() {
      e && d2(e.$$.fragment), t = Ga();
    },
    l(l) {
      e && If(e.$$.fragment, l), t = Ga();
    },
    m(l, o) {
      e && g2(e, l, o), z1(l, t, o), r = !0;
    },
    p(l, o) {
      if (o & /*icon*/
      1 && a !== (a = /*icon*/
      l[0])) {
        if (e) {
          o4();
          const s = e;
          Za(s.$$.fragment, 1, 0, () => {
            m2(s, 1);
          }), s4();
        }
        a ? (e = f2(a, i()), d2(e.$$.fragment), Wa(e.$$.fragment, 1), g2(e, t.parentNode, t)) : e = null;
      }
    },
    i(l) {
      r || (e && Wa(e.$$.fragment, l), r = !0);
    },
    o(l) {
      e && Za(e.$$.fragment, l), r = !1;
    },
    d(l) {
      l && br(t), e && m2(e, l);
    }
  };
}
function Uf(n) {
  let e, t;
  return {
    c() {
      e = g1("img"), this.h();
    },
    l(r) {
      e = p1(r, "IMG", { src: !0, alt: !0, class: !0 }), this.h();
    },
    h() {
      v2(e.src, t = /*icon*/
      n[0]) || Wr(e, "src", t), Wr(e, "alt", "Audio visualization icon"), Wr(e, "class", "icon-image svelte-t6tj07");
    },
    m(r, a) {
      z1(r, e, a);
    },
    p(r, a) {
      a & /*icon*/
      1 && !v2(e.src, t = /*icon*/
      r[0]) && Wr(e, "src", t);
    },
    i: _2,
    o: _2,
    d(r) {
      r && br(e);
    }
  };
}
function jf(n) {
  let e, t, r, a, i, l, o, s = (
    /*pulseIntensity*/
    n[3] > 0 && w2(n)
  );
  const u = [Uf, Vf], c = [];
  function f(d, p) {
    return typeof /*icon*/
    d[0] == "string" ? 0 : 1;
  }
  return i = f(n), l = c[i] = u[i](n), {
    c() {
      e = g1("div"), t = g1("div"), s && s.c(), r = Pf(), a = g1("div"), l.c(), this.h();
    },
    l(d) {
      e = p1(d, "DIV", { class: !0 });
      var p = Ca(e);
      t = p1(p, "DIV", { class: !0 });
      var b = Ca(t);
      s && s.l(b), r = Nf(b), a = p1(b, "DIV", { class: !0 });
      var E = Ca(a);
      l.l(E), E.forEach(br), b.forEach(br), p.forEach(br), this.h();
    },
    h() {
      Wr(a, "class", "gradio-webrtc-pulsing-icon svelte-t6tj07"), Rt(a, "transform", `scale(${/*pulseScale*/
      n[4]})`), Rt(
        a,
        "background",
        /*icon_button_color*/
        n[1]
      ), Wr(t, "class", "gradio-webrtc-pulsing-icon-container svelte-t6tj07"), Wr(e, "class", "gradio-webrtc-icon-wrapper svelte-t6tj07");
    },
    m(d, p) {
      z1(d, e, p), _l(e, t), s && s.m(t, null), _l(t, r), _l(t, a), c[i].m(a, null), o = !0;
    },
    p(d, [p]) {
      /*pulseIntensity*/
      d[3] > 0 ? s ? s.p(d, p) : (s = w2(d), s.c(), s.m(t, r)) : s && (s.d(1), s = null);
      let b = i;
      i = f(d), i === b ? c[i].p(d, p) : (o4(), Za(c[b], 1, 1, () => {
        c[b] = null;
      }), s4(), l = c[i], l ? l.p(d, p) : (l = c[i] = u[i](d), l.c()), Wa(l, 1), l.m(a, null)), p & /*pulseScale*/
      16 && Rt(a, "transform", `scale(${/*pulseScale*/
      d[4]})`), p & /*icon_button_color*/
      2 && Rt(
        a,
        "background",
        /*icon_button_color*/
        d[1]
      );
    },
    i(d) {
      o || (Wa(l), o = !0);
    },
    o(d) {
      Za(l), o = !1;
    },
    d(d) {
      d && br(e), s && s.d(), c[i].d();
    }
  };
}
function Gf(n, e, t) {
  let r, { stream_state: a = "closed" } = e, { audio_source_callback: i } = e, { icon: l = void 0 } = e, { icon_button_color: o = "var(--color-accent)" } = e, { pulse_color: s = "var(--color-accent)" } = e, u, c, f, d, p = 1, b = 0;
  Hf(() => {
    d && cancelAnimationFrame(d), u && u.close();
  });
  function E() {
    u = new (window.AudioContext || window.webkitAudioContext)(), c = u.createAnalyser(), u.createMediaStreamSource(i()).connect(c), c.fftSize = 64, c.smoothingTimeConstant = 0.8, f = new Uint8Array(c.frequencyBinCount), k();
  }
  function k() {
    c.getByteFrequencyData(f);
    const v = Array.from(f).reduce((_, A) => _ + A, 0) / f.length / 255;
    t(4, p = 1 + v * 0.15), t(3, b = v), d = requestAnimationFrame(k);
  }
  return n.$$set = (w) => {
    "stream_state" in w && t(6, a = w.stream_state), "audio_source_callback" in w && t(7, i = w.audio_source_callback), "icon" in w && t(0, l = w.icon), "icon_button_color" in w && t(1, o = w.icon_button_color), "pulse_color" in w && t(2, s = w.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*stream_state*/
    64 && a === "open" && E(), n.$$.dirty & /*pulseIntensity*/
    8 && t(5, r = 1 + b * 10);
  }, [
    l,
    o,
    s,
    b,
    p,
    r,
    a,
    i
  ];
}
class u4 extends Lf {
  constructor(e) {
    super(), Of(this, e, Gf, jf, qf, {
      stream_state: 6,
      audio_source_callback: 7,
      icon: 0,
      icon_button_color: 1,
      pulse_color: 2
    });
  }
}
const {
  SvelteComponent: Wf,
  action_destroyer: Zf,
  add_render_callback: Yf,
  append_hydration: Te,
  attr: ee,
  binding_callbacks: vl,
  check_outros: sn,
  children: Be,
  claim_component: Gt,
  claim_element: Je,
  claim_space: H0,
  claim_svg_element: wt,
  claim_text: wn,
  create_component: Wt,
  create_in_transition: Xf,
  destroy_component: Zt,
  destroy_each: c4,
  detach: le,
  element: $e,
  empty: On,
  ensure_array_like: Ya,
  group_outros: on,
  init: Kf,
  insert_hydration: c0,
  listen: kr,
  mount_component: Yt,
  noop: h4,
  run_all: Q5,
  safe_not_equal: Jf,
  set_data: yn,
  set_input_value: qn,
  set_style: $f,
  space: V0,
  stop_propagation: f4,
  svg_element: yt,
  text: kn,
  toggle_class: D0,
  transition_in: Xe,
  transition_out: s0
} = window.__gradio__svelte__internal, { createEventDispatcher: ed, onMount: td } = window.__gradio__svelte__internal;
function k2(n, e, t) {
  const r = n.slice();
  return r[53] = e[t], r;
}
function D2(n, e, t) {
  const r = n.slice();
  return r[53] = e[t], r;
}
function E2(n) {
  let e, t, r;
  return t = new u4({
    props: {
      stream_state: (
        /*stream_state*/
        n[15]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        n[29]
      ),
      icon: (
        /*icon*/
        n[0] || Tl
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[1]
      ),
      pulse_color: (
        /*pulse_color*/
        n[2]
      )
    }
  }), {
    c() {
      e = $e("div"), Wt(t.$$.fragment), this.h();
    },
    l(a) {
      e = Je(a, "DIV", { class: !0 });
      var i = Be(e);
      Gt(t.$$.fragment, i), i.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "audio-indicator svelte-96ajhq");
    },
    m(a, i) {
      c0(a, e, i), Yt(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      32768 && (l.stream_state = /*stream_state*/
      a[15]), i[0] & /*icon*/
      1 && (l.icon = /*icon*/
      a[0] || Tl), i[0] & /*icon_button_color*/
      2 && (l.icon_button_color = /*icon_button_color*/
      a[1]), i[0] & /*pulse_color*/
      4 && (l.pulse_color = /*pulse_color*/
      a[2]), t.$set(l);
    },
    i(a) {
      r || (Xe(t.$$.fragment, a), r = !0);
    },
    o(a) {
      s0(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && le(e), Zt(t);
    }
  };
}
function rd(n) {
  let e;
  return {
    c() {
      e = $e("video"), this.h();
    },
    l(t) {
      e = Je(t, "VIDEO", { class: !0 }), Be(e).forEach(le), this.h();
    },
    h() {
      e.autoplay = !0, e.muted = /*volumeMuted*/
      n[16], e.playsInline = !0, ee(e, "class", "svelte-96ajhq"), D0(e, "hide", !/*webcam_accessed*/
      n[19]), D0(
        e,
        "flip",
        /*stream_state*/
        n[15] != "open" || /*stream_state*/
        n[15] === "open" && /*include_audio*/
        n[4]
      );
    },
    m(t, r) {
      c0(t, e, r), n[42](e);
    },
    p(t, r) {
      r[0] & /*volumeMuted*/
      65536 && (e.muted = /*volumeMuted*/
      t[16]), r[0] & /*webcam_accessed*/
      524288 && D0(e, "hide", !/*webcam_accessed*/
      t[19]), r[0] & /*stream_state, include_audio*/
      32784 && D0(
        e,
        "flip",
        /*stream_state*/
        t[15] != "open" || /*stream_state*/
        t[15] === "open" && /*include_audio*/
        t[4]
      );
    },
    d(t) {
      t && le(e), n[42](null);
    }
  };
}
function nd(n) {
  let e, t, r, a;
  return {
    c() {
      e = $e("div"), t = $e("video"), r = V0(), a = $e("video"), this.h();
    },
    l(i) {
      e = Je(i, "DIV", { class: !0 });
      var l = Be(e);
      t = Je(l, "VIDEO", { class: !0 }), Be(t).forEach(le), r = H0(l), a = Je(l, "VIDEO", { class: !0 }), Be(a).forEach(le), l.forEach(le), this.h();
    },
    h() {
      t.autoplay = !0, t.playsInline = !0, t.muted = !0, ee(t, "class", "svelte-96ajhq"), D0(
        t,
        "local-video",
        /*stream_state*/
        n[15] === "open"
      ), D0(
        t,
        "remote-video",
        /*stream_state*/
        n[15] !== "open"
      ), D0(t, "hide", !/*webcam_accessed*/
      n[19] || /*cameraOff*/
      n[18]), ee(a, "class", "remote-video svelte-96ajhq"), a.autoplay = !0, a.muted = /*volumeMuted*/
      n[16], a.playsInline = !0, D0(a, "hide", !/*webcam_received*/
      n[20] || /*stream_state*/
      n[15] != "open"), D0(
        a,
        "flip",
        /*stream_state*/
        n[15] != "open" || /*stream_state*/
        n[15] === "open" && /*include_audio*/
        n[4]
      ), ee(e, "class", "video-wrap svelte-96ajhq"), D0(
        e,
        "picinpic",
        /*show_local_video*/
        n[5] === "picture-in-picture"
      ), D0(
        e,
        "left-right",
        /*show_local_video*/
        n[5] === "left-right"
      ), D0(e, "hide", !/*webcam_accessed*/
      n[19]);
    },
    m(i, l) {
      c0(i, e, l), Te(e, t), n[40](t), Te(e, r), Te(e, a), n[41](a);
    },
    p(i, l) {
      l[0] & /*stream_state*/
      32768 && D0(
        t,
        "local-video",
        /*stream_state*/
        i[15] === "open"
      ), l[0] & /*stream_state*/
      32768 && D0(
        t,
        "remote-video",
        /*stream_state*/
        i[15] !== "open"
      ), l[0] & /*webcam_accessed, cameraOff*/
      786432 && D0(t, "hide", !/*webcam_accessed*/
      i[19] || /*cameraOff*/
      i[18]), l[0] & /*volumeMuted*/
      65536 && (a.muted = /*volumeMuted*/
      i[16]), l[0] & /*webcam_received, stream_state*/
      1081344 && D0(a, "hide", !/*webcam_received*/
      i[20] || /*stream_state*/
      i[15] != "open"), l[0] & /*stream_state, include_audio*/
      32784 && D0(
        a,
        "flip",
        /*stream_state*/
        i[15] != "open" || /*stream_state*/
        i[15] === "open" && /*include_audio*/
        i[4]
      ), l[0] & /*show_local_video*/
      32 && D0(
        e,
        "picinpic",
        /*show_local_video*/
        i[5] === "picture-in-picture"
      ), l[0] & /*show_local_video*/
      32 && D0(
        e,
        "left-right",
        /*show_local_video*/
        i[5] === "left-right"
      ), l[0] & /*webcam_accessed*/
      524288 && D0(e, "hide", !/*webcam_accessed*/
      i[19]);
    },
    d(i) {
      i && le(e), n[40](null), n[41](null);
    }
  };
}
function ad(n) {
  let e, t, r, a, i, l, o, s, u, c, f;
  const d = [od, sd, ld], p = [];
  function b(v, _) {
    return (
      /*stream_state*/
      v[15] === "waiting" ? 0 : (
        /*stream_state*/
        v[15] === "open" ? 1 : 2
      )
    );
  }
  r = b(n), a = p[r] = d[r](n);
  let E = ud(n), k = (
    /*include_audio*/
    n[4] === !0 && /*stream_state*/
    n[15] === "open" && A2(n)
  ), w = (
    /*options_open*/
    n[21] && /*selected_device*/
    n[12] && F2(n)
  );
  return {
    c() {
      e = $e("div"), t = $e("button"), a.c(), i = V0(), E && E.c(), l = V0(), k && k.c(), o = V0(), w && w.c(), s = On(), this.h();
    },
    l(v) {
      e = Je(v, "DIV", { class: !0 });
      var _ = Be(e);
      t = Je(_, "BUTTON", { "aria-label": !0, class: !0 });
      var A = Be(t);
      a.l(A), A.forEach(le), i = H0(_), E && E.l(_), l = H0(_), k && k.l(_), _.forEach(le), o = H0(v), w && w.l(v), s = On(), this.h();
    },
    h() {
      ee(t, "aria-label", "start stream"), ee(t, "class", "svelte-96ajhq"), ee(e, "class", "button-wrap svelte-96ajhq");
    },
    m(v, _) {
      c0(v, e, _), Te(e, t), p[r].m(t, null), Te(e, i), E && E.m(e, null), Te(e, l), k && k.m(e, null), c0(v, o, _), w && w.m(v, _), c0(v, s, _), u = !0, c || (f = kr(
        t,
        "click",
        /*start_webrtc*/
        n[27]
      ), c = !0);
    },
    p(v, _) {
      let A = r;
      r = b(v), r === A ? p[r].p(v, _) : (on(), s0(p[A], 1, 1, () => {
        p[A] = null;
      }), sn(), a = p[r], a ? a.p(v, _) : (a = p[r] = d[r](v), a.c()), Xe(a, 1), a.m(t, null)), E.p(v, _), /*include_audio*/
      v[4] === !0 && /*stream_state*/
      v[15] === "open" ? k ? (k.p(v, _), _[0] & /*include_audio, stream_state*/
      32784 && Xe(k, 1)) : (k = A2(v), k.c(), Xe(k, 1), k.m(e, null)) : k && (on(), s0(k, 1, 1, () => {
        k = null;
      }), sn()), /*options_open*/
      v[21] && /*selected_device*/
      v[12] ? w ? (w.p(v, _), _[0] & /*options_open, selected_device*/
      2101248 && Xe(w, 1)) : (w = F2(v), w.c(), Xe(w, 1), w.m(s.parentNode, s)) : w && (on(), s0(w, 1, 1, () => {
        w = null;
      }), sn());
    },
    i(v) {
      u || (Xe(a), Xe(E), Xe(k), Xe(w), u = !0);
    },
    o(v) {
      s0(a), s0(E), s0(k), s0(w), u = !1;
    },
    d(v) {
      v && (le(e), le(o), le(s)), p[r].d(), E && E.d(), k && k.d(), w && w.d(v), c = !1, f();
    }
  };
}
function id(n) {
  let e, t, r, a;
  return t = new C5({}), t.$on(
    "click",
    /*click_handler*/
    n[43]
  ), {
    c() {
      e = $e("div"), Wt(t.$$.fragment), this.h();
    },
    l(i) {
      e = Je(i, "DIV", { title: !0, style: !0 });
      var l = Be(e);
      Gt(t.$$.fragment, l), l.forEach(le), this.h();
    },
    h() {
      ee(e, "title", "grant webcam access"), $f(e, "height", "100%");
    },
    m(i, l) {
      c0(i, e, l), Yt(t, e, null), a = !0;
    },
    p: h4,
    i(i) {
      a || (Xe(t.$$.fragment, i), i && (r || Yf(() => {
        r = Xf(e, x5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      s0(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && le(e), Zt(t);
    }
  };
}
function ld(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].start || /*i18n*/
    n[6]("audio.record")) + ""
  ), l, o;
  return r = new z6({}), {
    c() {
      e = $e("div"), t = $e("div"), Wt(r.$$.fragment), a = V0(), l = kn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Gt(r.$$.fragment, c), c.forEach(le), a = H0(u), l = wn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "start recording"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      c0(s, e, u), Te(e, t), Yt(r, t, null), Te(e, a), Te(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].start || /*i18n*/
      s[6]("audio.record")) + "") && yn(l, i);
    },
    i(s) {
      o || (Xe(r.$$.fragment, s), o = !0);
    },
    o(s) {
      s0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Zt(r);
    }
  };
}
function sd(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].stop || /*i18n*/
    n[6]("audio.stop")) + ""
  ), l, o;
  return r = new L6({}), {
    c() {
      e = $e("div"), t = $e("div"), Wt(r.$$.fragment), a = V0(), l = kn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Gt(r.$$.fragment, c), c.forEach(le), a = H0(u), l = wn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "stop recording"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      c0(s, e, u), Te(e, t), Yt(r, t, null), Te(e, a), Te(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].stop || /*i18n*/
      s[6]("audio.stop")) + "") && yn(l, i);
    },
    i(s) {
      o || (Xe(r.$$.fragment, s), o = !0);
    },
    o(s) {
      s0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Zt(r);
    }
  };
}
function od(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].waiting || /*i18n*/
    n[6]("audio.waiting")) + ""
  ), l, o;
  return r = new r5({}), {
    c() {
      e = $e("div"), t = $e("div"), Wt(r.$$.fragment), a = V0(), l = kn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Gt(r.$$.fragment, c), c.forEach(le), a = H0(u), l = wn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "spinner"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      c0(s, e, u), Te(e, t), Yt(r, t, null), Te(e, a), Te(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].waiting || /*i18n*/
      s[6]("audio.waiting")) + "") && yn(l, i);
    },
    i(s) {
      o || (Xe(r.$$.fragment, s), o = !0);
    },
    o(s) {
      s0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Zt(r);
    }
  };
}
function ud(n) {
  let e, t, r, a, i;
  return t = new x1({}), {
    c() {
      e = $e("button"), Wt(t.$$.fragment), this.h();
    },
    l(l) {
      e = Je(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = Be(e);
      Gt(t.$$.fragment, o), o.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "icon svelte-96ajhq"), ee(e, "aria-label", "select input source");
    },
    m(l, o) {
      c0(l, e, o), Yt(t, e, null), r = !0, a || (i = kr(
        e,
        "click",
        /*click_handler_1*/
        n[44]
      ), a = !0);
    },
    p: h4,
    i(l) {
      r || (Xe(t.$$.fragment, l), r = !0);
    },
    o(l) {
      s0(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && le(e), Zt(t), a = !1, i();
    }
  };
}
function A2(n) {
  let e, t, r, a, i, l, o, s, u, c, f;
  function d(x, Q) {
    return (
      /*cameraOff*/
      x[18] ? cd : hd
    );
  }
  let p = d(n), b = p(n);
  function E(x, Q) {
    return (
      /*micMuted*/
      x[17] ? fd : dd
    );
  }
  let k = E(n), w = k(n);
  const v = [pd, md], _ = [];
  function A(x, Q) {
    return (
      /*volumeMuted*/
      x[16] ? 0 : 1
    );
  }
  return o = A(n), s = _[o] = v[o](n), {
    c() {
      e = $e("div"), t = $e("button"), b.c(), r = V0(), a = $e("button"), w.c(), i = V0(), l = $e("button"), s.c(), this.h();
    },
    l(x) {
      e = Je(x, "DIV", { class: !0 });
      var Q = Be(e);
      t = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var z = Be(t);
      b.l(z), z.forEach(le), r = H0(Q), a = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var P = Be(a);
      w.l(P), P.forEach(le), i = H0(Q), l = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var B = Be(l);
      s.l(B), B.forEach(le), Q.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon svelte-96ajhq"), ee(t, "aria-label", "select input source"), ee(a, "class", "icon svelte-96ajhq"), ee(a, "aria-label", "select input source"), ee(l, "class", "icon svelte-96ajhq"), ee(l, "aria-label", "select input source"), ee(e, "class", "action-wrap svelte-96ajhq");
    },
    m(x, Q) {
      c0(x, e, Q), Te(e, t), b.m(t, null), Te(e, r), Te(e, a), w.m(a, null), Te(e, i), Te(e, l), _[o].m(l, null), u = !0, c || (f = [
        kr(
          t,
          "click",
          /*handle_camera_off*/
          n[24]
        ),
        kr(
          a,
          "click",
          /*handle_mic_mute*/
          n[23]
        ),
        kr(
          l,
          "click",
          /*handle_volume_mute*/
          n[22]
        )
      ], c = !0);
    },
    p(x, Q) {
      p !== (p = d(x)) && (b.d(1), b = p(x), b && (b.c(), b.m(t, null))), k !== (k = E(x)) && (w.d(1), w = k(x), w && (w.c(), w.m(a, null)));
      let z = o;
      o = A(x), o !== z && (on(), s0(_[z], 1, 1, () => {
        _[z] = null;
      }), sn(), s = _[o], s || (s = _[o] = v[o](x), s.c()), Xe(s, 1), s.m(l, null));
    },
    i(x) {
      u || (Xe(s), u = !0);
    },
    o(x) {
      s0(s), u = !1;
    },
    d(x) {
      x && le(e), b.d(), w.d(), _[o].d(), c = !1, Q5(f);
    }
  };
}
function cd(n) {
  let e, t, r;
  return {
    c() {
      e = yt("svg"), t = yt("line"), r = yt("path"), this.h();
    },
    l(a) {
      e = wt(a, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var i = Be(e);
      t = wt(i, "line", {
        fill: !0,
        id: !0,
        stroke: !0,
        "stroke-width": !0,
        x1: !0,
        x2: !0,
        y1: !0,
        y2: !0
      }), Be(t).forEach(le), r = wt(i, "path", { d: !0 }), Be(r).forEach(le), i.forEach(le), this.h();
    },
    h() {
      ee(t, "fill", "none"), ee(t, "id", "svg_5"), ee(t, "stroke", "#000000"), ee(t, "stroke-width", "80"), ee(t, "x1", "860"), ee(t, "x2", "100"), ee(t, "y1", "100"), ee(t, "y2", "860"), ee(r, "d", "M864 248H728l-32.4-90.8a32.07 32.07 0 00-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8 22.9-64.2h250.5l22.9 64.2 17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160 160-71.6 160-160-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96 96 43 96 96-43 96-96 96z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "camera"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(a, i) {
      c0(a, e, i), Te(e, t), Te(e, r);
    },
    d(a) {
      a && le(e);
    }
  };
}
function hd(n) {
  let e, t;
  return {
    c() {
      e = yt("svg"), t = yt("path"), this.h();
    },
    l(r) {
      e = wt(r, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var a = Be(e);
      t = wt(a, "path", { d: !0 }), Be(t).forEach(le), a.forEach(le), this.h();
    },
    h() {
      ee(t, "d", "M864 248H728l-32.4-90.8a32.07 32.07 0 00-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8 22.9-64.2h250.5l22.9 64.2 17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160 160-71.6 160-160-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96 96 43 96 96-43 96-96 96z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "camera"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(r, a) {
      c0(r, e, a), Te(e, t);
    },
    d(r) {
      r && le(e);
    }
  };
}
function fd(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = yt("svg"), t = yt("defs"), r = yt("style"), a = yt("path"), i = yt("path"), this.h();
    },
    l(l) {
      e = wt(l, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var o = Be(e);
      t = wt(o, "defs", {});
      var s = Be(t);
      r = wt(s, "style", {});
      var u = Be(r);
      u.forEach(le), s.forEach(le), a = wt(o, "path", { d: !0 }), Be(a).forEach(le), i = wt(o, "path", { d: !0 }), Be(i).forEach(le), o.forEach(le), this.h();
    },
    h() {
      ee(a, "d", "M682 455V311l-76 76v68c-.1 50.7-42 92.1-94 92a95.8 95.8 0 01-52-15l-54 55c29.1 22.4 65.9 36 106 36 93.8 0 170-75.1 170-168z"), ee(i, "d", "M833 446h-60c-4.4 0-8 3.6-8 8 0 140.3-113.7 254-254 254-63 0-120.7-23-165-61l-54 54a334.01 334.01 0 00179 81v102H326c-13.9 0-24.9 14.3-25 32v36c.1 4.4 2.9 8 6 8h408c3.2 0 6-3.6 6-8v-36c0-17.7-11-32-25-32H547V782c165.3-17.9 294-157.9 294-328 0-4.4-3.6-8-8-8zm13.1-377.7l-43.5-41.9a8 8 0 00-11.2.1l-129 129C634.3 101.2 577 64 511 64c-93.9 0-170 75.3-170 168v224c0 6.7.4 13.3 1.2 19.8l-68 68A252.33 252.33 0 01258 454c-.2-4.4-3.8-8-8-8h-60c-4.4 0-8 3.6-8 8 0 53 12.5 103 34.6 147.4l-137 137a8.03 8.03 0 000 11.3l42.7 42.7c3.1 3.1 8.2 3.1 11.3 0L846.2 79.8l.1-.1c3.1-3.2 3-8.3-.2-11.4zM417 401V232c0-50.6 41.9-92 94-92 46 0 84.1 32.3 92.3 74.7L417 401z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "audio-muted"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(l, o) {
      c0(l, e, o), Te(e, t), Te(t, r), Te(e, a), Te(e, i);
    },
    d(l) {
      l && le(e);
    }
  };
}
function dd(n) {
  let e, t;
  return {
    c() {
      e = yt("svg"), t = yt("path"), this.h();
    },
    l(r) {
      e = wt(r, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var a = Be(e);
      t = wt(a, "path", { d: !0 }), Be(t).forEach(le), a.forEach(le), this.h();
    },
    h() {
      ee(t, "d", "M842 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 140.3-113.7 254-254 254S258 594.3 258 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 168.7 126.6 307.9 290 327.6V884H326.7c-13.7 0-24.7 14.3-24.7 32v36c0 4.4 2.8 8 6.2 8h407.6c3.4 0 6.2-3.6 6.2-8v-36c0-17.7-11-32-24.7-32H548V782.1c165.3-18 294-158 294-328.1zM512 624c93.9 0 170-75.2 170-168V232c0-92.8-76.1-168-170-168s-170 75.2-170 168v224c0 92.8 76.1 168 170 168zm-94-392c0-50.6 41.9-92 94-92s94 41.4 94 92v224c0 50.6-41.9 92-94 92s-94-41.4-94-92V232z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "audio"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(r, a) {
      c0(r, e, a), Te(e, t);
    },
    d(r) {
      r && le(e);
    }
  };
}
function md(n) {
  let e, t;
  return e = new t7({}), {
    c() {
      Wt(e.$$.fragment);
    },
    l(r) {
      Gt(e.$$.fragment, r);
    },
    m(r, a) {
      Yt(e, r, a), t = !0;
    },
    i(r) {
      t || (Xe(e.$$.fragment, r), t = !0);
    },
    o(r) {
      s0(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Zt(e, r);
    }
  };
}
function pd(n) {
  let e, t;
  return e = new u7({}), {
    c() {
      Wt(e.$$.fragment);
    },
    l(r) {
      Gt(e.$$.fragment, r);
    },
    m(r, a) {
      Yt(e, r, a), t = !0;
    },
    i(r) {
      t || (Xe(e.$$.fragment, r), t = !0);
    },
    o(r) {
      s0(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Zt(e, r);
    }
  };
}
function F2(n) {
  let e, t, r, a, i, l, o, s, u;
  a = new x1({});
  function c(b, E) {
    return (
      /*available_video_devices*/
      b[10].length === 0 ? _d : gd
    );
  }
  let f = c(n), d = f(n), p = (
    /*include_audio*/
    n[4] === !0 && x2(n)
  );
  return {
    c() {
      e = $e("div"), t = $e("select"), r = $e("button"), Wt(a.$$.fragment), i = V0(), d.c(), l = V0(), p && p.c(), this.h();
    },
    l(b) {
      e = Je(b, "DIV", { class: !0 });
      var E = Be(e);
      t = Je(E, "SELECT", { class: !0, "aria-label": !0 });
      var k = Be(t);
      r = Je(k, "BUTTON", { class: !0 });
      var w = Be(r);
      Gt(a.$$.fragment, w), i = H0(w), w.forEach(le), d.l(k), k.forEach(le), l = H0(E), p && p.l(E), E.forEach(le), this.h();
    },
    h() {
      ee(r, "class", "inset-icon svelte-96ajhq"), ee(t, "class", "select-wrap svelte-96ajhq"), ee(t, "aria-label", "select source"), ee(e, "class", "select-container svelte-96ajhq");
    },
    m(b, E) {
      c0(b, e, E), Te(e, t), Te(t, r), Yt(a, r, null), Te(r, i), d.m(t, null), Te(e, l), p && p.m(e, null), o = !0, s || (u = [
        kr(r, "click", f4(
          /*click_handler_2*/
          n[45]
        )),
        kr(
          t,
          "change",
          /*handle_device_change*/
          n[25]
        ),
        Zf(M5.call(
          null,
          e,
          /*handle_click_outside*/
          n[28]
        ))
      ], s = !0);
    },
    p(b, E) {
      f === (f = c(b)) && d ? d.p(b, E) : (d.d(1), d = f(b), d && (d.c(), d.m(t, null))), /*include_audio*/
      b[4] === !0 ? p ? (p.p(b, E), E[0] & /*include_audio*/
      16 && Xe(p, 1)) : (p = x2(b), p.c(), Xe(p, 1), p.m(e, null)) : p && (on(), s0(p, 1, 1, () => {
        p = null;
      }), sn());
    },
    i(b) {
      o || (Xe(a.$$.fragment, b), Xe(p), o = !0);
    },
    o(b) {
      s0(a.$$.fragment, b), s0(p), o = !1;
    },
    d(b) {
      b && le(e), Zt(a), d.d(), p && p.d(), s = !1, Q5(u);
    }
  };
}
function gd(n) {
  let e, t = Ya(
    /*available_video_devices*/
    n[10]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = S2(D2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = On();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = On();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      c0(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_video_devices, selected_device*/
      5120) {
        t = Ya(
          /*available_video_devices*/
          a[10]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = D2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = S2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && le(e), c4(r, a);
    }
  };
}
function _d(n) {
  let e, t = (
    /*i18n*/
    n[6]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = $e("option"), r = kn(t), this.h();
    },
    l(a) {
      e = Je(a, "OPTION", { class: !0 });
      var i = Be(e);
      r = wn(i, t), i.forEach(le), this.h();
    },
    h() {
      e.__value = "", qn(e, e.__value), ee(e, "class", "svelte-96ajhq");
    },
    m(a, i) {
      c0(a, e, i), Te(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      64 && t !== (t = /*i18n*/
      a[6]("common.no_devices") + "") && yn(r, t);
    },
    d(a) {
      a && le(e);
    }
  };
}
function S2(n) {
  let e, t = (
    /*device*/
    n[53].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = $e("option"), r = kn(t), a = V0(), this.h();
    },
    l(o) {
      e = Je(o, "OPTION", { class: !0 });
      var s = Be(e);
      r = wn(s, t), a = H0(s), s.forEach(le), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[53].deviceId, qn(e, e.__value), e.selected = l = /*selected_device*/
      n[12].deviceId === /*device*/
      n[53].deviceId, ee(e, "class", "svelte-96ajhq");
    },
    m(o, s) {
      c0(o, e, s), Te(e, r), Te(e, a);
    },
    p(o, s) {
      s[0] & /*available_video_devices*/
      1024 && t !== (t = /*device*/
      o[53].label + "") && yn(r, t), s[0] & /*available_video_devices*/
      1024 && i !== (i = /*device*/
      o[53].deviceId) && (e.__value = i, qn(e, e.__value)), s[0] & /*selected_device, available_video_devices*/
      5120 && l !== (l = /*selected_device*/
      o[12].deviceId === /*device*/
      o[53].deviceId) && (e.selected = l);
    },
    d(o) {
      o && le(e);
    }
  };
}
function x2(n) {
  let e, t, r, a, i, l, o;
  r = new x1({});
  function s(f, d) {
    return (
      /*available_audio_devices*/
      f[11].length === 0 ? bd : vd
    );
  }
  let u = s(n), c = u(n);
  return {
    c() {
      e = $e("select"), t = $e("button"), Wt(r.$$.fragment), a = V0(), c.c(), this.h();
    },
    l(f) {
      e = Je(f, "SELECT", { class: !0, "aria-label": !0 });
      var d = Be(e);
      t = Je(d, "BUTTON", { class: !0 });
      var p = Be(t);
      Gt(r.$$.fragment, p), a = H0(p), p.forEach(le), c.l(d), d.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "inset-icon svelte-96ajhq"), ee(e, "class", "select-wrap svelte-96ajhq"), ee(e, "aria-label", "select source");
    },
    m(f, d) {
      c0(f, e, d), Te(e, t), Yt(r, t, null), Te(t, a), c.m(e, null), i = !0, l || (o = [
        kr(t, "click", f4(
          /*click_handler_3*/
          n[46]
        )),
        kr(
          e,
          "change",
          /*handle_device_change*/
          n[25]
        )
      ], l = !0);
    },
    p(f, d) {
      u === (u = s(f)) && c ? c.p(f, d) : (c.d(1), c = u(f), c && (c.c(), c.m(e, null)));
    },
    i(f) {
      i || (Xe(r.$$.fragment, f), i = !0);
    },
    o(f) {
      s0(r.$$.fragment, f), i = !1;
    },
    d(f) {
      f && le(e), Zt(r), c.d(), l = !1, Q5(o);
    }
  };
}
function vd(n) {
  let e, t = Ya(
    /*available_audio_devices*/
    n[11]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = C2(k2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = On();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = On();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      c0(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_audio_devices, selected_audio_device*/
      10240) {
        t = Ya(
          /*available_audio_devices*/
          a[11]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = k2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = C2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && le(e), c4(r, a);
    }
  };
}
function bd(n) {
  let e, t = (
    /*i18n*/
    n[6]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = $e("option"), r = kn(t), this.h();
    },
    l(a) {
      e = Je(a, "OPTION", { class: !0 });
      var i = Be(e);
      r = wn(i, t), i.forEach(le), this.h();
    },
    h() {
      e.__value = "", qn(e, e.__value), ee(e, "class", "svelte-96ajhq");
    },
    m(a, i) {
      c0(a, e, i), Te(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      64 && t !== (t = /*i18n*/
      a[6]("common.no_devices") + "") && yn(r, t);
    },
    d(a) {
      a && le(e);
    }
  };
}
function C2(n) {
  let e, t = (
    /*device*/
    n[53].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = $e("option"), r = kn(t), a = V0(), this.h();
    },
    l(o) {
      e = Je(o, "OPTION", { class: !0 });
      var s = Be(e);
      r = wn(s, t), a = H0(s), s.forEach(le), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[53].deviceId, qn(e, e.__value), e.selected = l = /*selected_audio_device*/
      n[13].deviceId === /*device*/
      n[53].deviceId, ee(e, "class", "svelte-96ajhq");
    },
    m(o, s) {
      c0(o, e, s), Te(e, r), Te(e, a);
    },
    p(o, s) {
      s[0] & /*available_audio_devices*/
      2048 && t !== (t = /*device*/
      o[53].label + "") && yn(r, t), s[0] & /*available_audio_devices*/
      2048 && i !== (i = /*device*/
      o[53].deviceId) && (e.__value = i, qn(e, e.__value)), s[0] & /*selected_audio_device, available_audio_devices*/
      10240 && l !== (l = /*selected_audio_device*/
      o[13].deviceId === /*device*/
      o[53].deviceId) && (e.selected = l);
    },
    d(o) {
      o && le(e);
    }
  };
}
function wd(n) {
  let e, t, r, a, i, l, o, s;
  t = new e4({
    props: { time_limit: (
      /*_time_limit*/
      n[14]
    ) }
  });
  let u = (
    /*stream_state*/
    n[15] === "open" && /*include_audio*/
    n[4] && E2(n)
  );
  function c(k, w) {
    return (
      /*show_local_video*/
      k[5] ? nd : rd
    );
  }
  let f = c(n), d = f(n);
  const p = [id, ad], b = [];
  function E(k, w) {
    return (
      /*webcam_accessed*/
      k[19] ? 1 : 0
    );
  }
  return l = E(n), o = b[l] = p[l](n), {
    c() {
      e = $e("div"), Wt(t.$$.fragment), r = V0(), u && u.c(), a = V0(), d.c(), i = V0(), o.c(), this.h();
    },
    l(k) {
      e = Je(k, "DIV", { class: !0 });
      var w = Be(e);
      Gt(t.$$.fragment, w), r = H0(w), u && u.l(w), a = H0(w), d.l(w), i = H0(w), o.l(w), w.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "wrap svelte-96ajhq");
    },
    m(k, w) {
      c0(k, e, w), Yt(t, e, null), Te(e, r), u && u.m(e, null), Te(e, a), d.m(e, null), Te(e, i), b[l].m(e, null), s = !0;
    },
    p(k, w) {
      const v = {};
      w[0] & /*_time_limit*/
      16384 && (v.time_limit = /*_time_limit*/
      k[14]), t.$set(v), /*stream_state*/
      k[15] === "open" && /*include_audio*/
      k[4] ? u ? (u.p(k, w), w[0] & /*stream_state, include_audio*/
      32784 && Xe(u, 1)) : (u = E2(k), u.c(), Xe(u, 1), u.m(e, a)) : u && (on(), s0(u, 1, 1, () => {
        u = null;
      }), sn()), f === (f = c(k)) && d ? d.p(k, w) : (d.d(1), d = f(k), d && (d.c(), d.m(e, i)));
      let _ = l;
      l = E(k), l === _ ? b[l].p(k, w) : (on(), s0(b[_], 1, 1, () => {
        b[_] = null;
      }), sn(), o = b[l], o ? o.p(k, w) : (o = b[l] = p[l](k), o.c()), Xe(o, 1), o.m(e, null));
    },
    i(k) {
      s || (Xe(t.$$.fragment, k), Xe(u), Xe(o), s = !0);
    },
    o(k) {
      s0(t.$$.fragment, k), s0(u), s0(o), s = !1;
    },
    d(k) {
      k && le(e), Zt(t), u && u.d(), d.d(), b[l].d();
    }
  };
}
function M5(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function yd(n, e, t) {
  var r = this && this.__awaiter || function(K, qe, Pe, e0) {
    function Re(B0) {
      return B0 instanceof Pe ? B0 : new Pe(function(h0) {
        h0(B0);
      });
    }
    return new (Pe || (Pe = Promise))(function(B0, h0) {
      function C0(X) {
        try {
          C(e0.next(X));
        } catch (Me) {
          h0(Me);
        }
      }
      function Ue(X) {
        try {
          C(e0.throw(X));
        } catch (Me) {
          h0(Me);
        }
      }
      function C(X) {
        X.done ? B0(X.value) : Re(X.value).then(C0, Ue);
      }
      C((e0 = e0.apply(K, qe || [])).next());
    });
  };
  let a, i, l = [], o = [], s = null, u = null, c = null, { time_limit: f = null } = e, d = "closed", { on_change_cb: p } = e, { mode: b } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: E = {} } = e, { icon: k = void 0 } = e, { icon_button_color: w = "var(--color-accent)" } = e, { pulse_color: v = "var(--color-accent)" } = e, { button_labels: _ } = e;
  const A = (K) => {
    K === "closed" ? (t(14, c = null), t(15, d = "closed")) : K === "waiting" ? t(15, d = "waiting") : t(15, d = "open");
  };
  let { track_constraints: x = null } = e, { rtc_configuration: Q } = e, { stream_every: z = 1 } = e, { server: P } = e, { include_audio: B } = e, { show_local_video: N } = e, { i18n: j } = e, $ = !1, W = !1, se = !1;
  const ke = () => {
    t(16, $ = !$);
  }, Fe = () => {
    t(17, W = !W), ce.getTracks().forEach((K) => {
      K.kind.includes("audio") && (K.enabled = !W);
    });
  }, xe = () => {
    t(18, se = !se), ce.getTracks().forEach((K) => {
      K.kind.includes("video") && (K.enabled = !se);
    });
  }, he = ed();
  td(() => document.createElement("canvas"));
  const Ee = (K) => r(void 0, void 0, void 0, function* () {
    const Pe = K.target.value;
    let e0, Re;
    B && o.find((h0) => h0.deviceId === Pe) ? Re = Pe : e0 = Pe, yield ja(
      Re ? { deviceId: { exact: Re } } : B,
      N ? a : i,
      e0,
      x
    ).then((h0) => r(void 0, void 0, void 0, function* () {
      ce = h0, t(12, s = l.find((C0) => C0.deviceId === e0) || null), t(13, u = B && o.find((C0) => C0.deviceId === Re) || null), t(21, ne = !1);
    }));
  });
  function ie() {
    return r(this, void 0, void 0, function* () {
      try {
        const K = N ? a : i;
        t(17, W = !1), t(18, se = !1), t(16, $ = !1), ja(B, K, null, x).then((qe) => r(this, void 0, void 0, function* () {
          t(19, ve = !0);
          let Pe = yield T5();
          return ce = qe, Pe;
        })).then((qe) => {
          t(10, l = S1(qe, "videoinput")), t(11, o = S1(qe, "audioinput")), ce.getTracks().map((e0) => {
            var Re;
            return (Re = e0.getSettings()) === null || Re === void 0 ? void 0 : Re.deviceId;
          }).forEach((e0) => {
            const Re = qe.find((B0) => B0.deviceId === e0);
            Re && (Re != null && Re.kind.includes("video")) ? t(12, s = Re) : Re && (Re != null && Re.kind.includes("audio")) && t(13, u = Re);
          }), !s && t(12, s = l[0]);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && he("error", j("image.no_webcam_support"));
      } catch (K) {
        if (K instanceof DOMException && K.name == "NotAllowedError")
          he("error", j("image.allow_webcam_access"));
        else
          throw K;
      }
    });
  }
  let ce, ve = !1, oe = !1, me, { webrtc_id: U } = e;
  function He() {
    return r(this, void 0, void 0, function* () {
      d === "closed" ? (me = new RTCPeerConnection(Q), me.addEventListener("connectionstatechange", (K) => r(this, void 0, void 0, function* () {
        switch (me.connectionState) {
          case "connected":
            t(15, d = "open"), t(14, c = f);
            break;
          case "disconnected":
            t(15, d = "closed"), t(14, c = null), Kr(me), yield ie();
            break;
        }
      })), t(15, d = "waiting"), t(30, U = Math.random().toString(36).substring(2)), B1(ce, me, b === "send" ? null : i, P.offer, U, "video", p, E).then((K) => {
        me = K, t(20, oe = !0);
      }).catch(() => {
        console.info("catching"), t(15, d = "closed"), t(20, oe = !1), he("error", "Too many concurrent users. Come back later!");
      })) : (Kr(me), t(15, d = "closed"), t(20, oe = !1), t(14, c = null), yield ie());
    });
  }
  let ne = !1;
  function fe(K) {
    K.preventDefault(), K.stopPropagation(), t(21, ne = !1);
  }
  const Z = () => i.srcObject;
  function Qe(K) {
    vl[K ? "unshift" : "push"](() => {
      a = K, t(8, a);
    });
  }
  function Le(K) {
    vl[K ? "unshift" : "push"](() => {
      i = K, t(9, i);
    });
  }
  function Ne(K) {
    vl[K ? "unshift" : "push"](() => {
      i = K, t(9, i);
    });
  }
  const Ie = async () => ie(), Ve = () => t(21, ne = !0), Ce = () => t(21, ne = !1), b0 = () => t(21, ne = !1);
  return n.$$set = (K) => {
    "time_limit" in K && t(31, f = K.time_limit), "on_change_cb" in K && t(32, p = K.on_change_cb), "mode" in K && t(33, b = K.mode), "rtp_params" in K && t(34, E = K.rtp_params), "icon" in K && t(0, k = K.icon), "icon_button_color" in K && t(1, w = K.icon_button_color), "pulse_color" in K && t(2, v = K.pulse_color), "button_labels" in K && t(3, _ = K.button_labels), "track_constraints" in K && t(36, x = K.track_constraints), "rtc_configuration" in K && t(37, Q = K.rtc_configuration), "stream_every" in K && t(38, z = K.stream_every), "server" in K && t(39, P = K.server), "include_audio" in K && t(4, B = K.include_audio), "show_local_video" in K && t(5, N = K.show_local_video), "i18n" in K && t(6, j = K.i18n), "webrtc_id" in K && t(30, U = K.webrtc_id);
  }, [
    k,
    w,
    v,
    _,
    B,
    N,
    j,
    M5,
    a,
    i,
    l,
    o,
    s,
    u,
    c,
    d,
    $,
    W,
    se,
    ve,
    oe,
    ne,
    ke,
    Fe,
    xe,
    Ee,
    ie,
    He,
    fe,
    Z,
    U,
    f,
    p,
    b,
    E,
    A,
    x,
    Q,
    z,
    P,
    Qe,
    Le,
    Ne,
    Ie,
    Ve,
    Ce,
    b0
  ];
}
class kd extends Wf {
  constructor(e) {
    super(), Kf(
      this,
      e,
      yd,
      wd,
      Jf,
      {
        time_limit: 31,
        on_change_cb: 32,
        mode: 33,
        rtp_params: 34,
        icon: 0,
        icon_button_color: 1,
        pulse_color: 2,
        button_labels: 3,
        modify_stream: 35,
        track_constraints: 36,
        rtc_configuration: 37,
        stream_every: 38,
        server: 39,
        include_audio: 4,
        show_local_video: 5,
        i18n: 6,
        webrtc_id: 30,
        click_outside: 7
      },
      null,
      [-1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[35];
  }
  get click_outside() {
    return M5;
  }
}
const {
  SvelteComponent: Dd,
  add_flush_callback: Ed,
  attr: T2,
  bind: Ad,
  binding_callbacks: Fd,
  bubble: ka,
  children: Sd,
  claim_component: Q2,
  claim_element: xd,
  claim_space: Cd,
  create_component: M2,
  destroy_component: B2,
  detach: bl,
  element: Td,
  init: Qd,
  insert_hydration: z2,
  mount_component: L2,
  safe_not_equal: Md,
  space: Bd,
  transition_in: I2,
  transition_out: N2
} = window.__gradio__svelte__internal, { createEventDispatcher: zd } = window.__gradio__svelte__internal;
function Ld(n) {
  let e, t, r, a, i, l;
  e = new ui({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: t5,
      label: (
        /*label*/
        n[1] || "Video"
      )
    }
  });
  function o(u) {
    n[20](u);
  }
  let s = {
    rtc_configuration: (
      /*rtc_configuration*/
      n[9]
    ),
    include_audio: (
      /*include_audio*/
      n[3]
    ),
    show_local_video: (
      /*show_local_video*/
      n[4]
    ),
    time_limit: (
      /*time_limit*/
      n[6]
    ),
    track_constraints: (
      /*track_constraints*/
      n[10]
    ),
    mode: (
      /*mode*/
      n[11]
    ),
    rtp_params: (
      /*rtp_params*/
      n[13]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[12]
    ),
    icon: (
      /*icon*/
      n[14]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[15]
    ),
    pulse_color: (
      /*pulse_color*/
      n[16]
    ),
    button_labels: (
      /*button_labels*/
      n[7]
    ),
    i18n: (
      /*i18n*/
      n[5]
    ),
    stream_every: 0.5,
    server: (
      /*server*/
      n[8]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (s.webrtc_id = /*value*/
    n[0]), a = new kd({ props: s }), Fd.push(() => Ad(a, "webrtc_id", o)), a.$on(
      "error",
      /*error_handler*/
      n[21]
    ), a.$on(
      "start_recording",
      /*start_recording_handler*/
      n[22]
    ), a.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[23]
    ), a.$on(
      "tick",
      /*tick_handler*/
      n[24]
    ), {
      c() {
        M2(e.$$.fragment), t = Bd(), r = Td("div"), M2(a.$$.fragment), this.h();
      },
      l(u) {
        Q2(e.$$.fragment, u), t = Cd(u), r = xd(u, "DIV", { "data-testid": !0, class: !0 });
        var c = Sd(r);
        Q2(a.$$.fragment, c), c.forEach(bl), this.h();
      },
      h() {
        T2(r, "data-testid", "video"), T2(r, "class", "video-container svelte-iln0va");
      },
      m(u, c) {
        L2(e, u, c), z2(u, t, c), z2(u, r, c), L2(a, r, null), l = !0;
      },
      p(u, [c]) {
        const f = {};
        c & /*show_label*/
        4 && (f.show_label = /*show_label*/
        u[2]), c & /*label*/
        2 && (f.label = /*label*/
        u[1] || "Video"), e.$set(f);
        const d = {};
        c & /*rtc_configuration*/
        512 && (d.rtc_configuration = /*rtc_configuration*/
        u[9]), c & /*include_audio*/
        8 && (d.include_audio = /*include_audio*/
        u[3]), c & /*show_local_video*/
        16 && (d.show_local_video = /*show_local_video*/
        u[4]), c & /*time_limit*/
        64 && (d.time_limit = /*time_limit*/
        u[6]), c & /*track_constraints*/
        1024 && (d.track_constraints = /*track_constraints*/
        u[10]), c & /*mode*/
        2048 && (d.mode = /*mode*/
        u[11]), c & /*rtp_params*/
        8192 && (d.rtp_params = /*rtp_params*/
        u[13]), c & /*on_change_cb*/
        4096 && (d.on_change_cb = /*on_change_cb*/
        u[12]), c & /*icon*/
        16384 && (d.icon = /*icon*/
        u[14]), c & /*icon_button_color*/
        32768 && (d.icon_button_color = /*icon_button_color*/
        u[15]), c & /*pulse_color*/
        65536 && (d.pulse_color = /*pulse_color*/
        u[16]), c & /*button_labels*/
        128 && (d.button_labels = /*button_labels*/
        u[7]), c & /*i18n*/
        32 && (d.i18n = /*i18n*/
        u[5]), c & /*server*/
        256 && (d.server = /*server*/
        u[8]), !i && c & /*value*/
        1 && (i = !0, d.webrtc_id = /*value*/
        u[0], Ed(() => i = !1)), a.$set(d);
      },
      i(u) {
        l || (I2(e.$$.fragment, u), I2(a.$$.fragment, u), l = !0);
      },
      o(u) {
        N2(e.$$.fragment, u), N2(a.$$.fragment, u), l = !1;
      },
      d(u) {
        u && (bl(t), bl(r)), B2(e, u), B2(a);
      }
    }
  );
}
let Id = !1;
function Nd(n, e, t) {
  let { value: r = null } = e, { label: a = void 0 } = e, { show_label: i = !0 } = e, { include_audio: l } = e, { show_local_video: o } = e, { i18n: s } = e, { active_source: u = "webcam" } = e, { handle_reset_value: c = () => {
  } } = e, { stream_handler: f } = e, { time_limit: d = null } = e, { button_labels: p } = e, { server: b } = e, { rtc_configuration: E } = e, { track_constraints: k = {} } = e, { mode: w } = e, { on_change_cb: v } = e, { rtp_params: _ = {} } = e, { icon: A = void 0 } = e, { icon_button_color: x = "var(--color-accent)" } = e, { pulse_color: Q = "var(--color-accent)" } = e;
  const z = zd();
  function P(W) {
    r = W, t(0, r);
  }
  function B(W) {
    ka.call(this, n, W);
  }
  function N(W) {
    ka.call(this, n, W);
  }
  function j(W) {
    ka.call(this, n, W);
  }
  function $(W) {
    ka.call(this, n, W);
  }
  return n.$$set = (W) => {
    "value" in W && t(0, r = W.value), "label" in W && t(1, a = W.label), "show_label" in W && t(2, i = W.show_label), "include_audio" in W && t(3, l = W.include_audio), "show_local_video" in W && t(4, o = W.show_local_video), "i18n" in W && t(5, s = W.i18n), "active_source" in W && t(17, u = W.active_source), "handle_reset_value" in W && t(18, c = W.handle_reset_value), "stream_handler" in W && t(19, f = W.stream_handler), "time_limit" in W && t(6, d = W.time_limit), "button_labels" in W && t(7, p = W.button_labels), "server" in W && t(8, b = W.server), "rtc_configuration" in W && t(9, E = W.rtc_configuration), "track_constraints" in W && t(10, k = W.track_constraints), "mode" in W && t(11, w = W.mode), "on_change_cb" in W && t(12, v = W.on_change_cb), "rtp_params" in W && t(13, _ = W.rtp_params), "icon" in W && t(14, A = W.icon), "icon_button_color" in W && t(15, x = W.icon_button_color), "pulse_color" in W && t(16, Q = W.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && console.log("value", r);
  }, z("drag", Id), [
    r,
    a,
    i,
    l,
    o,
    s,
    d,
    p,
    b,
    E,
    k,
    w,
    v,
    _,
    A,
    x,
    Q,
    u,
    c,
    f,
    P,
    B,
    N,
    j,
    $
  ];
}
class Rd extends Dd {
  constructor(e) {
    super(), Qd(this, e, Nd, Ld, Md, {
      value: 0,
      label: 1,
      show_label: 2,
      include_audio: 3,
      show_local_video: 4,
      i18n: 5,
      active_source: 17,
      handle_reset_value: 18,
      stream_handler: 19,
      time_limit: 6,
      button_labels: 7,
      server: 8,
      rtc_configuration: 9,
      track_constraints: 10,
      mode: 11,
      on_change_cb: 12,
      rtp_params: 13,
      icon: 14,
      icon_button_color: 15,
      pulse_color: 16
    });
  }
}
var R2;
(function(n) {
  n.LOAD = "LOAD", n.EXEC = "EXEC", n.WRITE_FILE = "WRITE_FILE", n.READ_FILE = "READ_FILE", n.DELETE_FILE = "DELETE_FILE", n.RENAME = "RENAME", n.CREATE_DIR = "CREATE_DIR", n.LIST_DIR = "LIST_DIR", n.DELETE_DIR = "DELETE_DIR", n.ERROR = "ERROR", n.DOWNLOAD = "DOWNLOAD", n.PROGRESS = "PROGRESS", n.LOG = "LOG", n.MOUNT = "MOUNT", n.UNMOUNT = "UNMOUNT";
})(R2 || (R2 = {}));
const Xp = (n) => {
  let e = ["B", "KB", "MB", "GB", "PB"], t = 0;
  for (; n > 1024; )
    n /= 1024, t++;
  let r = e[t];
  return n.toFixed(1) + " " + r;
}, Kp = () => !0;
function Jp(n, { autoplay: e }) {
  async function t() {
    e && await n.play();
  }
  return n.addEventListener("loadeddata", t), {
    destroy() {
      n.removeEventListener("loadeddata", t);
    }
  };
}
const {
  SvelteComponent: Od,
  append_hydration: qd,
  attr: wl,
  binding_callbacks: Pd,
  children: O2,
  claim_element: q2,
  claim_text: $p,
  detach: _1,
  element: P2,
  empty: Xa,
  init: Hd,
  insert_hydration: B5,
  is_function: H2,
  listen: yl,
  noop: V2,
  run_all: Vd,
  safe_not_equal: Ud,
  set_data: eg,
  src_url_equal: U2,
  text: tg,
  toggle_class: Tn
} = window.__gradio__svelte__internal;
function j2(n) {
  let e;
  function t(i, l) {
    return jd;
  }
  let a = t()(n);
  return {
    c() {
      a.c(), e = Xa();
    },
    l(i) {
      a.l(i), e = Xa();
    },
    m(i, l) {
      a.m(i, l), B5(i, e, l);
    },
    p(i, l) {
      a.p(i, l);
    },
    d(i) {
      i && _1(e), a.d(i);
    }
  };
}
function jd(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = P2("div"), t = P2("video"), this.h();
    },
    l(l) {
      e = q2(l, "DIV", { class: !0 });
      var o = O2(e);
      t = q2(o, "VIDEO", { src: !0 }), O2(t).forEach(_1), o.forEach(_1), this.h();
    },
    h() {
      var l;
      U2(t.src, r = /*value*/
      (l = n[2]) == null ? void 0 : l.video.url) || wl(t, "src", r), wl(e, "class", "container svelte-13u05e4"), Tn(
        e,
        "table",
        /*type*/
        n[0] === "table"
      ), Tn(
        e,
        "gallery",
        /*type*/
        n[0] === "gallery"
      ), Tn(
        e,
        "selected",
        /*selected*/
        n[1]
      );
    },
    m(l, o) {
      B5(l, e, o), qd(e, t), n[6](t), a || (i = [
        yl(
          t,
          "loadeddata",
          /*init*/
          n[4]
        ),
        yl(t, "mouseover", function() {
          H2(
            /*video*/
            n[3].play.bind(
              /*video*/
              n[3]
            )
          ) && n[3].play.bind(
            /*video*/
            n[3]
          ).apply(this, arguments);
        }),
        yl(t, "mouseout", function() {
          H2(
            /*video*/
            n[3].pause.bind(
              /*video*/
              n[3]
            )
          ) && n[3].pause.bind(
            /*video*/
            n[3]
          ).apply(this, arguments);
        })
      ], a = !0);
    },
    p(l, o) {
      var s;
      n = l, o & /*value*/
      4 && !U2(t.src, r = /*value*/
      (s = n[2]) == null ? void 0 : s.video.url) && wl(t, "src", r), o & /*type*/
      1 && Tn(
        e,
        "table",
        /*type*/
        n[0] === "table"
      ), o & /*type*/
      1 && Tn(
        e,
        "gallery",
        /*type*/
        n[0] === "gallery"
      ), o & /*selected*/
      2 && Tn(
        e,
        "selected",
        /*selected*/
        n[1]
      );
    },
    d(l) {
      l && _1(e), n[6](null), a = !1, Vd(i);
    }
  };
}
function Gd(n) {
  let e, t = (
    /*value*/
    n[2] && j2(n)
  );
  return {
    c() {
      t && t.c(), e = Xa();
    },
    l(r) {
      t && t.l(r), e = Xa();
    },
    m(r, a) {
      t && t.m(r, a), B5(r, e, a);
    },
    p(r, [a]) {
      /*value*/
      r[2] ? t ? t.p(r, a) : (t = j2(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: V2,
    o: V2,
    d(r) {
      r && _1(e), t && t.d(r);
    }
  };
}
function Wd(n, e, t) {
  var r = this && this.__awaiter || function(f, d, p, b) {
    function E(k) {
      return k instanceof p ? k : new p(function(w) {
        w(k);
      });
    }
    return new (p || (p = Promise))(function(k, w) {
      function v(x) {
        try {
          A(b.next(x));
        } catch (Q) {
          w(Q);
        }
      }
      function _(x) {
        try {
          A(b.throw(x));
        } catch (Q) {
          w(Q);
        }
      }
      function A(x) {
        x.done ? k(x.value) : E(x.value).then(v, _);
      }
      A((b = b.apply(f, d || [])).next());
    });
  };
  let { type: a } = e, { selected: i = !1 } = e, { value: l } = e, { loop: o } = e, s;
  function u() {
    return r(this, void 0, void 0, function* () {
      t(3, s.muted = !0, s), t(3, s.playsInline = !0, s), t(3, s.controls = !1, s), s.setAttribute("muted", ""), yield s.play(), s.pause();
    });
  }
  function c(f) {
    Pd[f ? "unshift" : "push"](() => {
      s = f, t(3, s);
    });
  }
  return n.$$set = (f) => {
    "type" in f && t(0, a = f.type), "selected" in f && t(1, i = f.selected), "value" in f && t(2, l = f.value), "loop" in f && t(5, o = f.loop);
  }, [a, i, l, s, u, o, c];
}
class rg extends Od {
  constructor(e) {
    super(), Hd(this, e, Wd, Gd, Ud, { type: 0, selected: 1, value: 2, loop: 5 });
  }
}
const {
  SvelteComponent: Zd,
  append_hydration: G2,
  assign: W2,
  attr: Qn,
  binding_callbacks: Yd,
  bubble: Xd,
  check_outros: Kd,
  children: Z2,
  claim_component: z5,
  claim_element: kl,
  claim_space: Y2,
  create_component: L5,
  destroy_component: I5,
  detach: s1,
  element: Dl,
  exclude_internal_props: X2,
  group_outros: Jd,
  init: $d,
  insert_hydration: El,
  listen: er,
  mount_component: N5,
  run_all: em,
  safe_not_equal: tm,
  space: K2,
  toggle_class: J2,
  transition_in: zn,
  transition_out: v1
} = window.__gradio__svelte__internal, { createEventDispatcher: rm, onMount: nm } = window.__gradio__svelte__internal;
function $2(n) {
  let e, t;
  return e = new r4({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [am] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      L5(e.$$.fragment);
    },
    l(r) {
      z5(e.$$.fragment, r);
    },
    m(r, a) {
      N5(e, r, a), t = !0;
    },
    i(r) {
      t || (zn(e.$$.fragment, r), t = !0);
    },
    o(r) {
      v1(e.$$.fragment, r), t = !1;
    },
    d(r) {
      I5(e, r);
    }
  };
}
function am(n) {
  let e, t;
  return e = new t5({}), {
    c() {
      L5(e.$$.fragment);
    },
    l(r) {
      z5(e.$$.fragment, r);
    },
    m(r, a) {
      N5(e, r, a), t = !0;
    },
    i(r) {
      t || (zn(e.$$.fragment, r), t = !0);
    },
    o(r) {
      v1(e.$$.fragment, r), t = !1;
    },
    d(r) {
      I5(e, r);
    }
  };
}
function im(n) {
  let e, t, r, a, i, l, o, s, u, c;
  e = new ui({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: t5,
      label: (
        /*label*/
        n[1] || "Video"
      )
    }
  });
  let f = (
    /*value*/
    n[0] === "__webrtc_value__" && $2(n)
  );
  return {
    c() {
      L5(e.$$.fragment), t = K2(), f && f.c(), r = K2(), a = Dl("div"), i = Dl("video"), l = Dl("track"), this.h();
    },
    l(d) {
      z5(e.$$.fragment, d), t = Y2(d), f && f.l(d), r = Y2(d), a = kl(d, "DIV", { class: !0 });
      var p = Z2(a);
      i = kl(p, "VIDEO", {
        "data-testid": !0,
        crossorigin: !0,
        class: !0
      });
      var b = Z2(i);
      l = kl(b, "TRACK", { kind: !0 }), b.forEach(s1), p.forEach(s1), this.h();
    },
    h() {
      Qn(l, "kind", "captions"), i.autoplay = !0, Qn(i, "data-testid", o = /*$$props*/
      n[5]["data-testid"]), Qn(i, "crossorigin", "anonymous"), Qn(i, "class", "svelte-1xabgau"), J2(
        i,
        "hidden",
        /*value*/
        n[0] === "__webrtc_value__"
      ), Qn(a, "class", "wrap svelte-1xabgau");
    },
    m(d, p) {
      N5(e, d, p), El(d, t, p), f && f.m(d, p), El(d, r, p), El(d, a, p), G2(a, i), G2(i, l), n[12](i), s = !0, u || (c = [
        er(
          i,
          "loadeddata",
          /*dispatch*/
          n[4].bind(null, "loadeddata")
        ),
        er(
          i,
          "click",
          /*dispatch*/
          n[4].bind(null, "click")
        ),
        er(
          i,
          "play",
          /*dispatch*/
          n[4].bind(null, "play")
        ),
        er(
          i,
          "pause",
          /*dispatch*/
          n[4].bind(null, "pause")
        ),
        er(
          i,
          "ended",
          /*dispatch*/
          n[4].bind(null, "ended")
        ),
        er(
          i,
          "mouseover",
          /*dispatch*/
          n[4].bind(null, "mouseover")
        ),
        er(
          i,
          "mouseout",
          /*dispatch*/
          n[4].bind(null, "mouseout")
        ),
        er(
          i,
          "focus",
          /*dispatch*/
          n[4].bind(null, "focus")
        ),
        er(
          i,
          "blur",
          /*dispatch*/
          n[4].bind(null, "blur")
        ),
        er(
          i,
          "load",
          /*load_handler*/
          n[11]
        )
      ], u = !0);
    },
    p(d, [p]) {
      const b = {};
      p & /*show_label*/
      4 && (b.show_label = /*show_label*/
      d[2]), p & /*label*/
      2 && (b.label = /*label*/
      d[1] || "Video"), e.$set(b), /*value*/
      d[0] === "__webrtc_value__" ? f ? p & /*value*/
      1 && zn(f, 1) : (f = $2(d), f.c(), zn(f, 1), f.m(r.parentNode, r)) : f && (Jd(), v1(f, 1, 1, () => {
        f = null;
      }), Kd()), (!s || p & /*$$props*/
      32 && o !== (o = /*$$props*/
      d[5]["data-testid"])) && Qn(i, "data-testid", o), (!s || p & /*value*/
      1) && J2(
        i,
        "hidden",
        /*value*/
        d[0] === "__webrtc_value__"
      );
    },
    i(d) {
      s || (zn(e.$$.fragment, d), zn(f), s = !0);
    },
    o(d) {
      v1(e.$$.fragment, d), v1(f), s = !1;
    },
    d(d) {
      d && (s1(t), s1(r), s1(a)), I5(e, d), f && f.d(d), n[12](null), u = !1, em(c);
    }
  };
}
function lm(n, e, t) {
  var r = this && this.__awaiter || function(w, v, _, A) {
    function x(Q) {
      return Q instanceof _ ? Q : new _(function(z) {
        z(Q);
      });
    }
    return new (_ || (_ = Promise))(function(Q, z) {
      function P(j) {
        try {
          N(A.next(j));
        } catch ($) {
          z($);
        }
      }
      function B(j) {
        try {
          N(A.throw(j));
        } catch ($) {
          z($);
        }
      }
      function N(j) {
        j.done ? Q(j.value) : x(j.value).then(P, B);
      }
      N((A = A.apply(w, v || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { on_change_cb: s } = e, { server: u } = e, c, f = Math.random().toString(36).substring(2), d;
  const p = rm();
  let b = "closed";
  nm(() => {
    window.setInterval(
      () => {
        b == "open" && p("tick");
      },
      1e3
    );
  });
  function E(w) {
    Xd.call(this, n, w);
  }
  function k(w) {
    Yd[w ? "unshift" : "push"](() => {
      c = w, t(3, c);
    });
  }
  return n.$$set = (w) => {
    t(5, e = W2(W2({}, e), X2(w))), "value" in w && t(0, a = w.value), "label" in w && t(1, i = w.label), "show_label" in w && t(2, l = w.show_label), "rtc_configuration" in w && t(6, o = w.rtc_configuration), "on_change_cb" in w && t(7, s = w.on_change_cb), "server" in w && t(8, u = w.server);
  }, n.$$.update = () => {
    n.$$.dirty & /*value, _webrtc_id, rtc_configuration, pc, video_element, server, on_change_cb*/
    1993 && a === "start_webrtc_stream" && (t(9, f = Math.random().toString(36).substring(2)), t(0, a = f), t(10, d = new RTCPeerConnection(o)), d.addEventListener("connectionstatechange", (w) => r(void 0, void 0, void 0, function* () {
      switch (d.connectionState) {
        case "connected":
          console.log("connected"), b = "open";
          break;
        case "disconnected":
          console.log("closed"), Kr(d);
          break;
      }
    })), B1(null, d, c, u.offer, f, "video", s).then((w) => {
      t(10, d = w);
    }).catch(() => {
      console.log("catching"), p("error", "Too many concurrent users. Come back later!");
    }));
  }, e = X2(e), [
    a,
    i,
    l,
    c,
    p,
    e,
    o,
    s,
    u,
    f,
    d,
    E,
    k
  ];
}
class sm extends Zd {
  constructor(e) {
    super(), $d(this, e, lm, im, tm, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 6,
      on_change_cb: 7,
      server: 8
    });
  }
}
const {
  SvelteComponent: om,
  append_hydration: Ta,
  attr: fn,
  check_outros: um,
  children: dn,
  claim_component: cm,
  claim_element: mn,
  claim_space: e6,
  create_component: hm,
  destroy_component: fm,
  destroy_each: t6,
  detach: At,
  element: pn,
  ensure_array_like: Da,
  group_outros: dm,
  init: mm,
  insert_hydration: L1,
  mount_component: pm,
  noop: Ka,
  safe_not_equal: gm,
  set_style: b1,
  space: r6,
  transition_in: Yl,
  transition_out: Xl
} = window.__gradio__svelte__internal, { onDestroy: _m } = window.__gradio__svelte__internal;
function n6(n, e, t) {
  const r = n.slice();
  return r[14] = e[t], r;
}
function a6(n, e, t) {
  const r = n.slice();
  return r[14] = e[t], r;
}
function vm(n) {
  let e, t, r, a, i = Da(Array(
    /*numBars*/
    n[0] / 2
  )), l = [];
  for (let u = 0; u < i.length; u += 1)
    l[u] = i6(a6(n, i, u));
  let o = Da(Array(
    /*numBars*/
    n[0] / 2
  )), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = l6(n6(n, o, u));
  return {
    c() {
      e = pn("div");
      for (let u = 0; u < l.length; u += 1)
        l[u].c();
      t = r6(), r = pn("div"), a = r6();
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      this.h();
    },
    l(u) {
      e = mn(u, "DIV", { class: !0 });
      var c = dn(e);
      for (let f = 0; f < l.length; f += 1)
        l[f].l(c);
      t = e6(c), r = mn(c, "DIV", { class: !0 }), dn(r).forEach(At), a = e6(c);
      for (let f = 0; f < s.length; f += 1)
        s[f].l(c);
      c.forEach(At), this.h();
    },
    h() {
      fn(r, "class", "split-container svelte-e61oqx"), fn(e, "class", "gradio-webrtc-boxContainer svelte-e61oqx"), b1(
        e,
        "width",
        /*containerWidth*/
        n[6]
      );
    },
    m(u, c) {
      L1(u, e, c);
      for (let f = 0; f < l.length; f += 1)
        l[f] && l[f].m(e, null);
      Ta(e, t), Ta(e, r), Ta(e, a);
      for (let f = 0; f < s.length; f += 1)
        s[f] && s[f].m(e, null);
    },
    p(u, c) {
      if (c & /*numBars*/
      1) {
        i = Da(Array(
          /*numBars*/
          u[0] / 2
        ));
        let f;
        for (f = 0; f < i.length; f += 1) {
          const d = a6(u, i, f);
          l[f] ? l[f].p(d, c) : (l[f] = i6(), l[f].c(), l[f].m(e, t));
        }
        for (; f < l.length; f += 1)
          l[f].d(1);
        l.length = i.length;
      }
      if (c & /*numBars*/
      1) {
        o = Da(Array(
          /*numBars*/
          u[0] / 2
        ));
        let f;
        for (f = 0; f < o.length; f += 1) {
          const d = n6(u, o, f);
          s[f] ? s[f].p(d, c) : (s[f] = l6(), s[f].c(), s[f].m(e, null));
        }
        for (; f < s.length; f += 1)
          s[f].d(1);
        s.length = o.length;
      }
      c & /*containerWidth*/
      64 && b1(
        e,
        "width",
        /*containerWidth*/
        u[6]
      );
    },
    i: Ka,
    o: Ka,
    d(u) {
      u && At(e), t6(l, u), t6(s, u);
    }
  };
}
function bm(n) {
  let e, t, r, a;
  return r = new u4({
    props: {
      stream_state: (
        /*stream_state*/
        n[1]
      ),
      pulse_color: (
        /*pulse_color*/
        n[5]
      ),
      icon: (
        /*icon*/
        n[3]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[4]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        n[2]
      )
    }
  }), {
    c() {
      e = pn("div"), t = pn("div"), hm(r.$$.fragment), this.h();
    },
    l(i) {
      e = mn(i, "DIV", { class: !0 });
      var l = dn(e);
      t = mn(l, "DIV", { class: !0 });
      var o = dn(t);
      cm(r.$$.fragment, o), o.forEach(At), l.forEach(At), this.h();
    },
    h() {
      fn(t, "class", "gradio-webrtc-icon svelte-e61oqx"), b1(t, "transform", `scale(${ym})`), b1(
        t,
        "background",
        /*icon_button_color*/
        n[4]
      ), fn(e, "class", "gradio-webrtc-icon-container svelte-e61oqx");
    },
    m(i, l) {
      L1(i, e, l), Ta(e, t), pm(r, t, null), a = !0;
    },
    p(i, l) {
      const o = {};
      l & /*stream_state*/
      2 && (o.stream_state = /*stream_state*/
      i[1]), l & /*pulse_color*/
      32 && (o.pulse_color = /*pulse_color*/
      i[5]), l & /*icon*/
      8 && (o.icon = /*icon*/
      i[3]), l & /*icon_button_color*/
      16 && (o.icon_button_color = /*icon_button_color*/
      i[4]), l & /*audio_source_callback*/
      4 && (o.audio_source_callback = /*audio_source_callback*/
      i[2]), r.$set(o), l & /*icon_button_color*/
      16 && b1(
        t,
        "background",
        /*icon_button_color*/
        i[4]
      );
    },
    i(i) {
      a || (Yl(r.$$.fragment, i), a = !0);
    },
    o(i) {
      Xl(r.$$.fragment, i), a = !1;
    },
    d(i) {
      i && At(e), fm(r);
    }
  };
}
function i6(n) {
  let e;
  return {
    c() {
      e = pn("div"), this.h();
    },
    l(t) {
      e = mn(t, "DIV", { class: !0 }), dn(e).forEach(At), this.h();
    },
    h() {
      fn(e, "class", "gradio-webrtc-box svelte-e61oqx");
    },
    m(t, r) {
      L1(t, e, r);
    },
    p: Ka,
    d(t) {
      t && At(e);
    }
  };
}
function l6(n) {
  let e;
  return {
    c() {
      e = pn("div"), this.h();
    },
    l(t) {
      e = mn(t, "DIV", { class: !0 }), dn(e).forEach(At), this.h();
    },
    h() {
      fn(e, "class", "gradio-webrtc-box svelte-e61oqx");
    },
    m(t, r) {
      L1(t, e, r);
    },
    p: Ka,
    d(t) {
      t && At(e);
    }
  };
}
function wm(n) {
  let e, t, r, a;
  const i = [bm, vm], l = [];
  function o(s, u) {
    return (
      /*icon*/
      s[3] ? 0 : 1
    );
  }
  return t = o(n), r = l[t] = i[t](n), {
    c() {
      e = pn("div"), r.c(), this.h();
    },
    l(s) {
      e = mn(s, "DIV", { class: !0 });
      var u = dn(e);
      r.l(u), u.forEach(At), this.h();
    },
    h() {
      fn(e, "class", "gradio-webrtc-waveContainer svelte-e61oqx");
    },
    m(s, u) {
      L1(s, e, u), l[t].m(e, null), a = !0;
    },
    p(s, [u]) {
      let c = t;
      t = o(s), t === c ? l[t].p(s, u) : (dm(), Xl(l[c], 1, 1, () => {
        l[c] = null;
      }), um(), r = l[t], r ? r.p(s, u) : (r = l[t] = i[t](s), r.c()), Yl(r, 1), r.m(e, null));
    },
    i(s) {
      a || (Yl(r), a = !0);
    },
    o(s) {
      Xl(r), a = !1;
    },
    d(s) {
      s && At(e), l[t].d();
    }
  };
}
let ym = 1;
function km(n) {
  const e = [0, 2, 4, 6, 8, 10, 12, 14, 15, 13, 11, 9, 7, 5, 3, 1];
  if (n < 0 || n >= e.length)
    throw new Error("Index must be between 0 and 15");
  return e[n];
}
function Dm(n, e, t) {
  let r, { numBars: a = 16 } = e, { stream_state: i = "closed" } = e, { audio_source_callback: l } = e, { icon: o = void 0 } = e, { icon_button_color: s = "var(--color-accent)" } = e, { pulse_color: u = "var(--color-accent)" } = e, { wave_color: c = "var(--color-accent)" } = e, f, d, p, b;
  _m(() => {
    b && cancelAnimationFrame(b), f && f.close();
  });
  function E() {
    f = new (window.AudioContext || window.webkitAudioContext)(), d = f.createAnalyser(), f.createMediaStreamSource(l()).connect(d), d.fftSize = 64, d.smoothingTimeConstant = 0.8, p = new Uint8Array(d.frequencyBinCount), k();
  }
  function k() {
    d.getByteFrequencyData(p);
    const w = document.querySelectorAll(".gradio-webrtc-waveContainer .gradio-webrtc-box");
    for (let v = 0; v < w.length; v++) {
      const _ = p[km(v)] / 255;
      w[v].style.transform = `scaleY(${Math.max(0.1, _)})`, w[v].style.background = c, w[v].style.opacity = 0.5;
    }
    b = requestAnimationFrame(k);
  }
  return n.$$set = (w) => {
    "numBars" in w && t(0, a = w.numBars), "stream_state" in w && t(1, i = w.stream_state), "audio_source_callback" in w && t(2, l = w.audio_source_callback), "icon" in w && t(3, o = w.icon), "icon_button_color" in w && t(4, s = w.icon_button_color), "pulse_color" in w && t(5, u = w.pulse_color), "wave_color" in w && t(7, c = w.wave_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*icon, numBars*/
    9 && t(6, r = o ? "128px" : `calc((var(--boxSize) + var(--gutter)) * ${a} + 80px)`), n.$$.dirty & /*stream_state*/
    2 && i === "open" && E();
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    r,
    c
  ];
}
class R5 extends om {
  constructor(e) {
    super(), mm(this, e, Dm, wm, gm, {
      numBars: 0,
      stream_state: 1,
      audio_source_callback: 2,
      icon: 3,
      icon_button_color: 4,
      pulse_color: 5,
      wave_color: 7
    });
  }
}
const {
  SvelteComponent: Em,
  attr: d4,
  binding_callbacks: Am,
  bubble: Fm,
  check_outros: s6,
  children: m4,
  claim_component: fi,
  claim_element: p4,
  claim_space: Al,
  create_component: di,
  destroy_component: mi,
  detach: Ur,
  element: g4,
  empty: o6,
  group_outros: u6,
  init: Sm,
  insert_hydration: Mn,
  listen: Fl,
  mount_component: pi,
  run_all: xm,
  safe_not_equal: Cm,
  space: Sl,
  toggle_class: Tm,
  transition_in: tr,
  transition_out: jr
} = window.__gradio__svelte__internal, { createEventDispatcher: Qm } = window.__gradio__svelte__internal, { onMount: Mm } = window.__gradio__svelte__internal;
function c6(n) {
  let e, t, r;
  return t = new R5({
    props: {
      audio_source_callback: (
        /*func*/
        n[17]
      ),
      stream_state: (
        /*stream_state*/
        n[7]
      ),
      icon: (
        /*icon*/
        n[4]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[5]
      ),
      pulse_color: (
        /*pulse_color*/
        n[6]
      )
    }
  }), {
    c() {
      e = g4("div"), di(t.$$.fragment), this.h();
    },
    l(a) {
      e = p4(a, "DIV", { class: !0 });
      var i = m4(e);
      fi(t.$$.fragment, i), i.forEach(Ur), this.h();
    },
    h() {
      d4(e, "class", "audio-container svelte-v2iok3");
    },
    m(a, i) {
      Mn(a, e, i), pi(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i & /*audio_player*/
      256 && (l.audio_source_callback = /*func*/
      a[17]), i & /*stream_state*/
      128 && (l.stream_state = /*stream_state*/
      a[7]), i & /*icon*/
      16 && (l.icon = /*icon*/
      a[4]), i & /*icon_button_color*/
      32 && (l.icon_button_color = /*icon_button_color*/
      a[5]), i & /*pulse_color*/
      64 && (l.pulse_color = /*pulse_color*/
      a[6]), t.$set(l);
    },
    i(a) {
      r || (tr(t.$$.fragment, a), r = !0);
    },
    o(a) {
      jr(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && Ur(e), mi(t);
    }
  };
}
function h6(n) {
  let e, t;
  return e = new r4({
    props: {
      size: "small",
      $$slots: { default: [Bm] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      di(e.$$.fragment);
    },
    l(r) {
      fi(e.$$.fragment, r);
    },
    m(r, a) {
      pi(e, r, a), t = !0;
    },
    i(r) {
      t || (tr(e.$$.fragment, r), t = !0);
    },
    o(r) {
      jr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      mi(e, r);
    }
  };
}
function Bm(n) {
  let e, t;
  return e = new e5({}), {
    c() {
      di(e.$$.fragment);
    },
    l(r) {
      fi(e.$$.fragment, r);
    },
    m(r, a) {
      pi(e, r, a), t = !0;
    },
    i(r) {
      t || (tr(e.$$.fragment, r), t = !0);
    },
    o(r) {
      jr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      mi(e, r);
    }
  };
}
function zm(n) {
  let e, t, r, a, i, l, o, s, u;
  e = new ui({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: e5,
      float: !1,
      label: (
        /*label*/
        n[1] || /*i18n*/
        n[3]("audio.audio")
      )
    }
  });
  let c = (
    /*value*/
    n[0] !== "__webrtc_value__" && c6(n)
  ), f = (
    /*value*/
    n[0] === "__webrtc_value__" && h6(n)
  );
  return {
    c() {
      di(e.$$.fragment), t = Sl(), r = g4("audio"), a = Sl(), c && c.c(), i = Sl(), f && f.c(), l = o6(), this.h();
    },
    l(d) {
      fi(e.$$.fragment, d), t = Al(d), r = p4(d, "AUDIO", { class: !0 }), m4(r).forEach(Ur), a = Al(d), c && c.l(d), i = Al(d), f && f.l(d), l = o6(), this.h();
    },
    h() {
      d4(r, "class", "standard-player svelte-v2iok3"), Tm(r, "hidden", !0);
    },
    m(d, p) {
      pi(e, d, p), Mn(d, t, p), Mn(d, r, p), n[14](r), Mn(d, a, p), c && c.m(d, p), Mn(d, i, p), f && f.m(d, p), Mn(d, l, p), o = !0, s || (u = [
        Fl(
          r,
          "load",
          /*load_handler*/
          n[13]
        ),
        Fl(
          r,
          "ended",
          /*ended_handler*/
          n[15]
        ),
        Fl(
          r,
          "play",
          /*play_handler*/
          n[16]
        )
      ], s = !0);
    },
    p(d, [p]) {
      const b = {};
      p & /*show_label*/
      4 && (b.show_label = /*show_label*/
      d[2]), p & /*label, i18n*/
      10 && (b.label = /*label*/
      d[1] || /*i18n*/
      d[3]("audio.audio")), e.$set(b), /*value*/
      d[0] !== "__webrtc_value__" ? c ? (c.p(d, p), p & /*value*/
      1 && tr(c, 1)) : (c = c6(d), c.c(), tr(c, 1), c.m(i.parentNode, i)) : c && (u6(), jr(c, 1, 1, () => {
        c = null;
      }), s6()), /*value*/
      d[0] === "__webrtc_value__" ? f ? p & /*value*/
      1 && tr(f, 1) : (f = h6(d), f.c(), tr(f, 1), f.m(l.parentNode, l)) : f && (u6(), jr(f, 1, 1, () => {
        f = null;
      }), s6());
    },
    i(d) {
      o || (tr(e.$$.fragment, d), tr(c), tr(f), o = !0);
    },
    o(d) {
      jr(e.$$.fragment, d), jr(c), jr(f), o = !1;
    },
    d(d) {
      d && (Ur(t), Ur(r), Ur(a), Ur(i), Ur(l)), mi(e, d), n[14](null), c && c.d(d), f && f.d(d), s = !1, xm(u);
    }
  };
}
function Lm(n, e, t) {
  var r = this && this.__awaiter || function(B, N, j, $) {
    function W(se) {
      return se instanceof j ? se : new j(function(ke) {
        ke(se);
      });
    }
    return new (j || (j = Promise))(function(se, ke) {
      function Fe(Ee) {
        try {
          he($.next(Ee));
        } catch (ie) {
          ke(ie);
        }
      }
      function xe(Ee) {
        try {
          he($.throw(Ee));
        } catch (ie) {
          ke(ie);
        }
      }
      function he(Ee) {
        Ee.done ? se(Ee.value) : W(Ee.value).then(Fe, xe);
      }
      he(($ = $.apply(B, N || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { i18n: s } = e, { on_change_cb: u } = e, { icon: c = void 0 } = e, { icon_button_color: f = "var(--color-accent)" } = e, { pulse_color: d = "var(--color-accent)" } = e, { server: p } = e, b = "closed", E, k, w = Math.random().toString(36).substring(2);
  const v = Qm();
  Mm(() => {
    window.setInterval(
      () => {
        b == "open" && v("tick");
      },
      1e3
    );
  });
  function _(B) {
    return r(this, void 0, void 0, function* () {
      return B === "start_webrtc_stream" && (t(7, b = "waiting"), w = Math.random().toString(36).substring(2), B = w, console.log("set value to ", B), k = new RTCPeerConnection(o), k.addEventListener("connectionstatechange", (j) => r(this, void 0, void 0, function* () {
        switch (k.connectionState) {
          case "connected":
            console.info("connected"), t(7, b = "open");
            break;
          case "disconnected":
            console.info("closed"), Kr(k);
            break;
        }
      })), B1(null, k, E, p.offer, w, "audio", u).then((j) => {
        k = j;
      }).catch(() => {
        console.info("catching"), v("error", "Too many concurrent users. Come back later!");
      })), B;
    });
  }
  function A(B) {
    Fm.call(this, n, B);
  }
  function x(B) {
    Am[B ? "unshift" : "push"](() => {
      E = B, t(8, E);
    });
  }
  const Q = () => v("stop"), z = () => v("play"), P = () => E.srcObject;
  return n.$$set = (B) => {
    "value" in B && t(0, a = B.value), "label" in B && t(1, i = B.label), "show_label" in B && t(2, l = B.show_label), "rtc_configuration" in B && t(10, o = B.rtc_configuration), "i18n" in B && t(3, s = B.i18n), "on_change_cb" in B && t(11, u = B.on_change_cb), "icon" in B && t(4, c = B.icon), "icon_button_color" in B && t(5, f = B.icon_button_color), "pulse_color" in B && t(6, d = B.pulse_color), "server" in B && t(12, p = B.server);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && _(a).then((B) => {
      t(0, a = B);
    });
  }, [
    a,
    i,
    l,
    s,
    c,
    f,
    d,
    b,
    E,
    v,
    o,
    u,
    p,
    A,
    x,
    Q,
    z,
    P
  ];
}
class Im extends Em {
  constructor(e) {
    super(), Sm(this, e, Lm, zm, Cm, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 10,
      i18n: 3,
      on_change_cb: 11,
      icon: 4,
      icon_button_color: 5,
      pulse_color: 6,
      server: 12
    });
  }
}
const {
  SvelteComponent: Nm,
  action_destroyer: Rm,
  add_render_callback: Om,
  append_hydration: x0,
  attr: v0,
  binding_callbacks: qm,
  bubble: Pm,
  check_outros: Qa,
  children: Z0,
  claim_component: Er,
  claim_element: Y0,
  claim_space: Vt,
  claim_text: I1,
  create_component: Ar,
  create_in_transition: Hm,
  destroy_component: Fr,
  destroy_each: Vm,
  detach: Ke,
  element: X0,
  empty: f6,
  ensure_array_like: d6,
  group_outros: Ma,
  init: Um,
  insert_hydration: ot,
  listen: un,
  mount_component: Sr,
  noop: _4,
  run_all: v4,
  safe_not_equal: jm,
  set_data: N1,
  set_input_value: Kl,
  set_style: Gm,
  space: Ut,
  stop_propagation: Wm,
  text: R1,
  toggle_class: Ja,
  transition_in: S0,
  transition_out: P0
} = window.__gradio__svelte__internal, { createEventDispatcher: Zm } = window.__gradio__svelte__internal, { onMount: Ym } = window.__gradio__svelte__internal;
function m6(n, e, t) {
  const r = n.slice();
  return r[42] = e[t], r;
}
function Xm(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p;
  e = new R5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        n[16]
      ),
      stream_state: (
        /*stream_state*/
        n[11]
      ),
      icon: (
        /*icon*/
        n[4]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[5]
      ),
      pulse_color: (
        /*pulse_color*/
        n[6]
      )
    }
  }), r = new e4({
    props: { time_limit: (
      /*_time_limit*/
      n[10]
    ) }
  });
  const b = [ep, $m, Jm], E = [];
  function k(_, A) {
    return (
      /*stream_state*/
      _[11] === "waiting" ? 0 : (
        /*stream_state*/
        _[11] === "open" ? 1 : 2
      )
    );
  }
  o = k(n), s = E[o] = b[o](n);
  let w = (
    /*stream_state*/
    n[11] === "closed" && p6(n)
  ), v = (
    /*options_open*/
    n[9] && /*selected_device*/
    n[14] && g6(n)
  );
  return {
    c() {
      Ar(e.$$.fragment), t = Ut(), Ar(r.$$.fragment), a = Ut(), i = X0("div"), l = X0("button"), s.c(), u = Ut(), w && w.c(), c = Ut(), v && v.c(), this.h();
    },
    l(_) {
      Er(e.$$.fragment, _), t = Vt(_), Er(r.$$.fragment, _), a = Vt(_), i = Y0(_, "DIV", { class: !0 });
      var A = Z0(i);
      l = Y0(A, "BUTTON", { "aria-label": !0, class: !0 });
      var x = Z0(l);
      s.l(x), x.forEach(Ke), u = Vt(A), w && w.l(A), c = Vt(A), v && v.l(A), A.forEach(Ke), this.h();
    },
    h() {
      v0(l, "aria-label", "start stream"), v0(l, "class", "svelte-c1guob"), v0(i, "class", "button-wrap svelte-c1guob"), Ja(
        i,
        "pulse",
        /*stopword_recognized*/
        n[8]
      );
    },
    m(_, A) {
      Sr(e, _, A), ot(_, t, A), Sr(r, _, A), ot(_, a, A), ot(_, i, A), x0(i, l), E[o].m(l, null), x0(i, u), w && w.m(i, null), x0(i, c), v && v.m(i, null), f = !0, d || (p = un(
        l,
        "click",
        /*start_stream*/
        n[19]
      ), d = !0);
    },
    p(_, A) {
      const x = {};
      A[0] & /*stream_state*/
      2048 && (x.stream_state = /*stream_state*/
      _[11]), A[0] & /*icon*/
      16 && (x.icon = /*icon*/
      _[4]), A[0] & /*icon_button_color*/
      32 && (x.icon_button_color = /*icon_button_color*/
      _[5]), A[0] & /*pulse_color*/
      64 && (x.pulse_color = /*pulse_color*/
      _[6]), e.$set(x);
      const Q = {};
      A[0] & /*_time_limit*/
      1024 && (Q.time_limit = /*_time_limit*/
      _[10]), r.$set(Q);
      let z = o;
      o = k(_), o === z ? E[o].p(_, A) : (Ma(), P0(E[z], 1, 1, () => {
        E[z] = null;
      }), Qa(), s = E[o], s ? s.p(_, A) : (s = E[o] = b[o](_), s.c()), S0(s, 1), s.m(l, null)), /*stream_state*/
      _[11] === "closed" ? w ? (w.p(_, A), A[0] & /*stream_state*/
      2048 && S0(w, 1)) : (w = p6(_), w.c(), S0(w, 1), w.m(i, c)) : w && (Ma(), P0(w, 1, 1, () => {
        w = null;
      }), Qa()), /*options_open*/
      _[9] && /*selected_device*/
      _[14] ? v ? (v.p(_, A), A[0] & /*options_open, selected_device*/
      16896 && S0(v, 1)) : (v = g6(_), v.c(), S0(v, 1), v.m(i, null)) : v && (Ma(), P0(v, 1, 1, () => {
        v = null;
      }), Qa()), (!f || A[0] & /*stopword_recognized*/
      256) && Ja(
        i,
        "pulse",
        /*stopword_recognized*/
        _[8]
      );
    },
    i(_) {
      f || (S0(e.$$.fragment, _), S0(r.$$.fragment, _), S0(s), S0(w), S0(v), f = !0);
    },
    o(_) {
      P0(e.$$.fragment, _), P0(r.$$.fragment, _), P0(s), P0(w), P0(v), f = !1;
    },
    d(_) {
      _ && (Ke(t), Ke(a), Ke(i)), Fr(e, _), Fr(r, _), E[o].d(), w && w.d(), v && v.d(), d = !1, p();
    }
  };
}
function Km(n) {
  let e, t, r, a;
  return t = new C5({ props: { icon: Tl } }), t.$on(
    "click",
    /*click_handler*/
    n[34]
  ), {
    c() {
      e = X0("div"), Ar(t.$$.fragment), this.h();
    },
    l(i) {
      e = Y0(i, "DIV", { title: !0, style: !0 });
      var l = Z0(e);
      Er(t.$$.fragment, l), l.forEach(Ke), this.h();
    },
    h() {
      v0(e, "title", "grant webcam access"), Gm(e, "height", "100%");
    },
    m(i, l) {
      ot(i, e, l), Sr(t, e, null), a = !0;
    },
    p: _4,
    i(i) {
      a || (S0(t.$$.fragment, i), i && (r || Om(() => {
        r = Hm(e, x5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      P0(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Ke(e), Fr(t);
    }
  };
}
function Jm(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].start || /*i18n*/
    n[3]("audio.record")) + ""
  ), l, o;
  return r = new z6({}), {
    c() {
      e = X0("div"), t = X0("div"), Ar(r.$$.fragment), a = Ut(), l = R1(i), this.h();
    },
    l(s) {
      e = Y0(s, "DIV", { class: !0 });
      var u = Z0(e);
      t = Y0(u, "DIV", { class: !0, title: !0 });
      var c = Z0(t);
      Er(r.$$.fragment, c), c.forEach(Ke), a = Vt(u), l = I1(u, i), u.forEach(Ke), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "start recording"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      ot(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].start || /*i18n*/
      s[3]("audio.record")) + "") && N1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ke(e), Fr(r);
    }
  };
}
function $m(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].stop || /*i18n*/
    n[3]("audio.stop")) + ""
  ), l, o;
  return r = new L6({}), {
    c() {
      e = X0("div"), t = X0("div"), Ar(r.$$.fragment), a = Ut(), l = R1(i), this.h();
    },
    l(s) {
      e = Y0(s, "DIV", { class: !0 });
      var u = Z0(e);
      t = Y0(u, "DIV", { class: !0, title: !0 });
      var c = Z0(t);
      Er(r.$$.fragment, c), c.forEach(Ke), a = Vt(u), l = I1(u, i), u.forEach(Ke), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "stop recording"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      ot(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].stop || /*i18n*/
      s[3]("audio.stop")) + "") && N1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ke(e), Fr(r);
    }
  };
}
function ep(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].waiting || /*i18n*/
    n[3]("audio.waiting")) + ""
  ), l, o;
  return r = new r5({}), {
    c() {
      e = X0("div"), t = X0("div"), Ar(r.$$.fragment), a = Ut(), l = R1(i), this.h();
    },
    l(s) {
      e = Y0(s, "DIV", { class: !0 });
      var u = Z0(e);
      t = Y0(u, "DIV", { class: !0, title: !0 });
      var c = Z0(t);
      Er(r.$$.fragment, c), c.forEach(Ke), a = Vt(u), l = I1(u, i), u.forEach(Ke), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "spinner"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      ot(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].waiting || /*i18n*/
      s[3]("audio.waiting")) + "") && N1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ke(e), Fr(r);
    }
  };
}
function p6(n) {
  let e, t, r, a, i;
  return t = new x1({}), {
    c() {
      e = X0("button"), Ar(t.$$.fragment), this.h();
    },
    l(l) {
      e = Y0(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = Z0(e);
      Er(t.$$.fragment, o), o.forEach(Ke), this.h();
    },
    h() {
      v0(e, "class", "icon svelte-c1guob"), v0(e, "aria-label", "select input source");
    },
    m(l, o) {
      ot(l, e, o), Sr(t, e, null), r = !0, a || (i = un(
        e,
        "click",
        /*click_handler_1*/
        n[35]
      ), a = !0);
    },
    p: _4,
    i(l) {
      r || (S0(t.$$.fragment, l), r = !0);
    },
    o(l) {
      P0(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && Ke(e), Fr(t), a = !1, i();
    }
  };
}
function g6(n) {
  let e, t, r, a, i, l, o;
  r = new x1({});
  function s(f, d) {
    return (
      /*available_audio_devices*/
      f[13].length === 0 ? rp : tp
    );
  }
  let u = s(n), c = u(n);
  return {
    c() {
      e = X0("select"), t = X0("button"), Ar(r.$$.fragment), a = Ut(), c.c(), this.h();
    },
    l(f) {
      e = Y0(f, "SELECT", { class: !0, "aria-label": !0 });
      var d = Z0(e);
      t = Y0(d, "BUTTON", { class: !0 });
      var p = Z0(t);
      Er(r.$$.fragment, p), a = Vt(p), p.forEach(Ke), c.l(d), d.forEach(Ke), this.h();
    },
    h() {
      v0(t, "class", "inset-icon svelte-c1guob"), v0(e, "class", "select-wrap svelte-c1guob"), v0(e, "aria-label", "select source");
    },
    m(f, d) {
      ot(f, e, d), x0(e, t), Sr(r, t, null), x0(t, a), c.m(e, null), i = !0, l || (o = [
        un(t, "click", Wm(
          /*click_handler_2*/
          n[36]
        )),
        Rm(ap.call(
          null,
          e,
          /*handle_click_outside*/
          n[20]
        )),
        un(
          e,
          "change",
          /*handle_device_change*/
          n[21]
        )
      ], l = !0);
    },
    p(f, d) {
      u === (u = s(f)) && c ? c.p(f, d) : (c.d(1), c = u(f), c && (c.c(), c.m(e, null)));
    },
    i(f) {
      i || (S0(r.$$.fragment, f), i = !0);
    },
    o(f) {
      P0(r.$$.fragment, f), i = !1;
    },
    d(f) {
      f && Ke(e), Fr(r), c.d(), l = !1, v4(o);
    }
  };
}
function tp(n) {
  let e, t = d6(
    /*available_audio_devices*/
    n[13]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = _6(m6(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = f6();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = f6();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      ot(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_audio_devices, selected_device*/
      24576) {
        t = d6(
          /*available_audio_devices*/
          a[13]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = m6(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = _6(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && Ke(e), Vm(r, a);
    }
  };
}
function rp(n) {
  let e, t = (
    /*i18n*/
    n[3]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = X0("option"), r = R1(t), this.h();
    },
    l(a) {
      e = Y0(a, "OPTION", { class: !0 });
      var i = Z0(e);
      r = I1(i, t), i.forEach(Ke), this.h();
    },
    h() {
      e.__value = "", Kl(e, e.__value), v0(e, "class", "svelte-c1guob");
    },
    m(a, i) {
      ot(a, e, i), x0(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      8 && t !== (t = /*i18n*/
      a[3]("common.no_devices") + "") && N1(r, t);
    },
    d(a) {
      a && Ke(e);
    }
  };
}
function _6(n) {
  let e, t = (
    /*device*/
    n[42].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = X0("option"), r = R1(t), a = Ut(), this.h();
    },
    l(o) {
      e = Y0(o, "OPTION", { class: !0 });
      var s = Z0(e);
      r = I1(s, t), a = Vt(s), s.forEach(Ke), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[42].deviceId, Kl(e, e.__value), e.selected = l = /*selected_device*/
      n[14].deviceId === /*device*/
      n[42].deviceId, v0(e, "class", "svelte-c1guob");
    },
    m(o, s) {
      ot(o, e, s), x0(e, r), x0(e, a);
    },
    p(o, s) {
      s[0] & /*available_audio_devices*/
      8192 && t !== (t = /*device*/
      o[42].label + "") && N1(r, t), s[0] & /*available_audio_devices*/
      8192 && i !== (i = /*device*/
      o[42].deviceId) && (e.__value = i, Kl(e, e.__value)), s[0] & /*selected_device, available_audio_devices*/
      24576 && l !== (l = /*selected_device*/
      o[14].deviceId === /*device*/
      o[42].deviceId) && (e.selected = l);
    },
    d(o) {
      o && Ke(e);
    }
  };
}
function np(n) {
  let e, t, r, a, i, l, o, s, u, c;
  e = new ui({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: e5,
      float: !1,
      label: (
        /*label*/
        n[1] || /*i18n*/
        n[3]("audio.audio")
      )
    }
  });
  const f = [Km, Xm], d = [];
  function p(b, E) {
    return (
      /*mic_accessed*/
      b[15] ? 1 : 0
    );
  }
  return l = p(n), o = d[l] = f[l](n), {
    c() {
      Ar(e.$$.fragment), t = Ut(), r = X0("div"), a = X0("audio"), i = Ut(), o.c(), this.h();
    },
    l(b) {
      Er(e.$$.fragment, b), t = Vt(b), r = Y0(b, "DIV", { class: !0 });
      var E = Z0(r);
      a = Y0(E, "AUDIO", { class: !0 }), Z0(a).forEach(Ke), i = Vt(E), o.l(E), E.forEach(Ke), this.h();
    },
    h() {
      v0(a, "class", "standard-player svelte-c1guob"), Ja(
        a,
        "hidden",
        /*value*/
        n[0] === "__webrtc_value__"
      ), v0(r, "class", "audio-container svelte-c1guob");
    },
    m(b, E) {
      Sr(e, b, E), ot(b, t, E), ot(b, r, E), x0(r, a), n[31](a), x0(r, i), d[l].m(r, null), s = !0, u || (c = [
        un(
          a,
          "load",
          /*load_handler*/
          n[30]
        ),
        un(
          a,
          "ended",
          /*ended_handler*/
          n[32]
        ),
        un(
          a,
          "play",
          /*play_handler*/
          n[33]
        )
      ], u = !0);
    },
    p(b, E) {
      const k = {};
      E[0] & /*show_label*/
      4 && (k.show_label = /*show_label*/
      b[2]), E[0] & /*label, i18n*/
      10 && (k.label = /*label*/
      b[1] || /*i18n*/
      b[3]("audio.audio")), e.$set(k), (!s || E[0] & /*value*/
      1) && Ja(
        a,
        "hidden",
        /*value*/
        b[0] === "__webrtc_value__"
      );
      let w = l;
      l = p(b), l === w ? d[l].p(b, E) : (Ma(), P0(d[w], 1, 1, () => {
        d[w] = null;
      }), Qa(), o = d[l], o ? o.p(b, E) : (o = d[l] = f[l](b), o.c()), S0(o, 1), o.m(r, null));
    },
    i(b) {
      s || (S0(e.$$.fragment, b), S0(o), s = !0);
    },
    o(b) {
      P0(e.$$.fragment, b), P0(o), s = !1;
    },
    d(b) {
      b && (Ke(t), Ke(r)), Fr(e, b), n[31](null), d[l].d(), u = !1, v4(c);
    }
  };
}
function ap(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function ip(n, e, t) {
  var r = this && this.__awaiter || function(Z, Qe, Le, Ne) {
    function Ie(Ve) {
      return Ve instanceof Le ? Ve : new Le(function(Ce) {
        Ce(Ve);
      });
    }
    return new (Le || (Le = Promise))(function(Ve, Ce) {
      function b0(Pe) {
        try {
          qe(Ne.next(Pe));
        } catch (e0) {
          Ce(e0);
        }
      }
      function K(Pe) {
        try {
          qe(Ne.throw(Pe));
        } catch (e0) {
          Ce(e0);
        }
      }
      function qe(Pe) {
        Pe.done ? Ve(Pe.value) : Ie(Pe.value).then(b0, K);
      }
      qe((Ne = Ne.apply(Z, Qe || [])).next());
    });
  };
  let { mode: a } = e, { value: i = null } = e, { label: l = void 0 } = e, { show_label: o = !0 } = e, { rtc_configuration: s = null } = e, { i18n: u } = e, { time_limit: c = null } = e, { track_constraints: f = {} } = e, { rtp_params: d = {} } = e, { on_change_cb: p } = e, { icon: b = void 0 } = e, { icon_button_color: E = "var(--color-accent)" } = e, { pulse_color: k = "var(--color-accent)" } = e, { button_labels: w } = e, v = !1, _;
  Ym(() => {
    i === "__webrtc_value__" && t(29, _ = new Audio("https://huggingface.co/datasets/freddyaboulton/bucket/resolve/main/pop-sounds.mp3"));
  });
  let A = (Z) => {
    console.log("msg", Z), Z === "stopword" ? (console.log("stopword recognized"), t(8, v = !0), setTimeout(
      () => {
        t(8, v = !1);
      },
      3e3
    )) : (console.log("calling on_change_cb with msg", Z), p(Z));
  }, x = !1, Q = null, { server: z } = e, P = "closed", B, N, j = null, $, W, se = null, ke = !1;
  const Fe = () => (console.log("stream in callback", $), a === "send" ? $ : B.srcObject), xe = Zm();
  function he() {
    return r(this, void 0, void 0, function* () {
      try {
        const Qe = se ? Object.assign(
          {
            deviceId: { exact: se.deviceId }
          },
          f
        ) : f;
        $ = yield navigator.mediaDevices.getUserMedia({ audio: Qe });
      } catch (Qe) {
        if (!navigator.mediaDevices) {
          xe("error", u("audio.no_device_support"));
          return;
        }
        if (Qe instanceof DOMException && Qe.name == "NotAllowedError") {
          xe("error", u("audio.allow_recording_access"));
          return;
        }
        throw Qe;
      }
      t(13, W = S1(yield T5(), "audioinput")), t(15, ke = !0);
      const Z = $.getTracks().map((Qe) => {
        var Le;
        return (Le = Qe.getSettings()) === null || Le === void 0 ? void 0 : Le.deviceId;
      })[0];
      t(14, se = Z && W.find((Qe) => Qe.deviceId === Z) || W[0]);
    });
  }
  function Ee() {
    return r(this, void 0, void 0, function* () {
      if (P === "open") {
        Kr(N), t(11, P = "closed"), t(10, Q = null), yield he();
        return;
      }
      j = Math.random().toString(36).substring(2), t(0, i = j), N = new RTCPeerConnection(s), N.addEventListener("connectionstatechange", (Z) => r(this, void 0, void 0, function* () {
        switch (N.connectionState) {
          case "connected":
            console.info("connected"), t(11, P = "open"), t(10, Q = c);
            break;
          case "disconnected":
            console.info("closed"), t(11, P = "closed"), t(10, Q = null), Kr(N);
            break;
        }
      })), t(11, P = "waiting"), $ = null;
      try {
        yield he();
      } catch (Z) {
        if (!navigator.mediaDevices) {
          xe("error", u("audio.no_device_support"));
          return;
        }
        if (Z instanceof DOMException && Z.name == "NotAllowedError") {
          xe("error", u("audio.allow_recording_access"));
          return;
        }
        throw Z;
      }
      $ != null && B1($, N, a === "send" ? null : B, z.offer, j, "audio", A, d).then((Z) => {
        N = Z;
      }).catch(() => {
        console.info("catching"), xe("error", "Too many concurrent users. Come back later!");
      });
    });
  }
  function ie(Z) {
    Z.preventDefault(), Z.stopPropagation(), t(9, x = !1);
  }
  const ce = (Z) => r(void 0, void 0, void 0, function* () {
    const Le = Z.target.value;
    $ = yield navigator.mediaDevices.getUserMedia({
      audio: Object.assign({ deviceId: { exact: Le } }, f)
    }), t(14, se = W.find((Ne) => Ne.deviceId === Le) || null), t(9, x = !1);
  });
  function ve(Z) {
    Pm.call(this, n, Z);
  }
  function oe(Z) {
    qm[Z ? "unshift" : "push"](() => {
      B = Z, t(12, B);
    });
  }
  const me = () => xe("stop"), U = () => xe("play"), He = async () => he(), ne = () => t(9, x = !0), fe = () => t(9, x = !1);
  return n.$$set = (Z) => {
    "mode" in Z && t(22, a = Z.mode), "value" in Z && t(0, i = Z.value), "label" in Z && t(1, l = Z.label), "show_label" in Z && t(2, o = Z.show_label), "rtc_configuration" in Z && t(23, s = Z.rtc_configuration), "i18n" in Z && t(3, u = Z.i18n), "time_limit" in Z && t(24, c = Z.time_limit), "track_constraints" in Z && t(25, f = Z.track_constraints), "rtp_params" in Z && t(26, d = Z.rtp_params), "on_change_cb" in Z && t(27, p = Z.on_change_cb), "icon" in Z && t(4, b = Z.icon), "icon_button_color" in Z && t(5, E = Z.icon_button_color), "pulse_color" in Z && t(6, k = Z.pulse_color), "button_labels" in Z && t(7, w = Z.button_labels), "server" in Z && t(28, z = Z.server);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*stopword_recognized, notification_sound*/
    536871168 && v && _.play();
  }, [
    i,
    l,
    o,
    u,
    b,
    E,
    k,
    w,
    v,
    x,
    Q,
    P,
    B,
    W,
    se,
    ke,
    Fe,
    xe,
    he,
    Ee,
    ie,
    ce,
    a,
    s,
    c,
    f,
    d,
    p,
    z,
    _,
    ve,
    oe,
    me,
    U,
    He,
    ne,
    fe
  ];
}
class lp extends Nm {
  constructor(e) {
    super(), Um(
      this,
      e,
      ip,
      np,
      jm,
      {
        mode: 22,
        value: 0,
        label: 1,
        show_label: 2,
        rtc_configuration: 23,
        i18n: 3,
        time_limit: 24,
        track_constraints: 25,
        rtp_params: 26,
        on_change_cb: 27,
        icon: 4,
        icon_button_color: 5,
        pulse_color: 6,
        button_labels: 7,
        server: 28
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: sp,
  action_destroyer: v6,
  add_render_callback: op,
  append_hydration: R,
  attr: D,
  binding_callbacks: o1,
  check_outros: xl,
  children: O,
  claim_component: O5,
  claim_element: Ze,
  claim_space: O0,
  claim_svg_element: H,
  claim_text: b4,
  create_component: q5,
  create_in_transition: up,
  destroy_component: P5,
  destroy_each: b6,
  detach: L,
  element: Ye,
  ensure_array_like: Ea,
  get_svelte_dataset: Vn,
  group_outros: Cl,
  init: cp,
  insert_hydration: A0,
  is_function: w6,
  listen: Ot,
  mount_component: H5,
  noop: gn,
  null_to_empty: Aa,
  run_all: hp,
  safe_not_equal: fp,
  set_data: w4,
  set_style: _e,
  space: q0,
  stop_propagation: y4,
  svg_element: V,
  text: k4,
  toggle_class: Vr,
  transition_in: It,
  transition_out: _r
} = window.__gradio__svelte__internal, { createEventDispatcher: dp, onMount: mp } = window.__gradio__svelte__internal;
function y6(n, e, t) {
  const r = n.slice();
  return r[63] = e[t], r[65] = t, r;
}
function k6(n, e, t) {
  const r = n.slice();
  return r[63] = e[t], r[65] = t, r;
}
function D6(n) {
  let e, t, r, a;
  return t = new C5({}), t.$on(
    "click",
    /*click_handler*/
    n[45]
  ), {
    c() {
      e = Ye("div"), q5(t.$$.fragment), this.h();
    },
    l(i) {
      e = Ze(i, "DIV", { style: !0 });
      var l = O(e);
      O5(t.$$.fragment, l), l.forEach(L), this.h();
    },
    h() {
      _e(e, "height", "100%");
    },
    m(i, l) {
      A0(i, e, l), H5(t, e, null), a = !0;
    },
    p: gn,
    i(i) {
      a || (It(t.$$.fragment, i), i && (r || op(() => {
        r = up(e, x5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      _r(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && L(e), P5(t);
    }
  };
}
function pp(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("clipPath"), l = V("rect"), o = V("g"), s = V("g"), u = V("g"), c = V("rect"), f = V("g"), d = V("path"), p = V("g"), b = V("path"), E = V("g"), k = V("path"), this.h();
    },
    l(w) {
      e = H(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var v = O(e);
      t = H(v, "defs", {});
      var _ = O(t);
      r = H(_, "clipPath", { id: !0 });
      var A = O(r);
      a = H(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), A.forEach(L), i = H(_, "clipPath", { id: !0 });
      var x = O(i);
      l = H(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(l).forEach(L), x.forEach(L), _.forEach(L), o = H(v, "g", { "clip-path": !0 });
      var Q = O(o);
      s = H(Q, "g", { "clip-path": !0 });
      var z = O(s);
      u = H(z, "g", {});
      var P = O(u);
      c = H(P, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(c).forEach(L), P.forEach(L), f = H(z, "g", {});
      var B = O(f);
      d = H(B, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(d).forEach(L), B.forEach(L), p = H(z, "g", {});
      var N = O(p);
      b = H(N, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(b).forEach(L), N.forEach(L), E = H(z, "g", {});
      var j = O(E);
      k = H(j, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(k).forEach(L), j.forEach(L), z.forEach(L), Q.forEach(L), v.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_279"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_279/13_007"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), _e(c, "mix-blend-mode", "passthrough"), D(d, "d", "M0.83317090625,15.8333259765625L0.83317090625,4.1666259765625Q0.83317090625,4.0845497765625,0.84918290625,4.0040509765625Q0.86519490625,3.9235519765625,0.89660490625,3.8477229765625Q0.92801390625,3.7718949765625,0.97361290625,3.7036509765625Q1.01921190625,3.6354069765625,1.07724790625,3.5773699765625Q1.13528490625,3.5193339765625,1.2035289062499999,3.4737349765625Q1.27177290625,3.4281359765625,1.34760090625,3.3967269765625Q1.42342990625,3.3653169765625,1.50392890625,3.3493049765625003Q1.58442770625,3.3332929765625,1.66650390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,15.8333259765625Q15.83320390625,15.9153259765625,15.81720390625,15.9958259765625Q15.80110390625,16.0763259765625,15.76970390625,16.152225976562498Q15.73830390625,16.2280259765625,15.69270390625,16.2962259765625Q15.64710390625,16.3645259765625,15.58910390625,16.4225259765625Q15.53100390625,16.4806259765625,15.46280390625,16.5262259765625Q15.39460390625,16.5718259765625,15.31870390625,16.6032259765625Q15.24290390625,16.6346259765625,15.16240390625,16.6506259765625Q15.08190390625,16.6666259765625,14.99980390625,16.6666259765625L1.66650390625,16.6666259765625Q1.58442770625,16.6666259765625,1.50392890625,16.6506259765625Q1.42342990625,16.6346259765625,1.34760090625,16.6032259765625Q1.27177290625,16.5718259765625,1.2035289062499999,16.5262259765625Q1.13528490625,16.4806259765625,1.07724790625,16.4225259765625Q1.01921190625,16.3645259765625,0.97361290625,16.2962259765625Q0.92801390625,16.2280259765625,0.89660490625,16.152225976562498Q0.86519490625,16.0763259765625,0.84918290625,15.9958259765625Q0.83317090625,15.9153259765625,0.83317090625,15.8333259765625ZM2.49983690625,4.9999589765625L2.49983690625,14.9999259765625L14.16650390625,14.9999259765625L14.16650390625,4.9999589765625L2.49983690625,4.9999589765625Z"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), _e(d, "mix-blend-mode", "passthrough"), D(b, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), _e(b, "mix-blend-mode", "passthrough"), D(k, "d", "M7.65749209375,7.3101989765625L10.11698609375,9.3597759765625Q10.17518609375,9.4082759765625,10.22367609375,9.4664759765625Q10.32979609375,9.5938159765625,10.37910609375,9.7520659765625Q10.42841609375,9.9103259765625,10.41340609375,10.0754059765625Q10.39839609375,10.2404859765625,10.321366093750001,10.3872559765625Q10.24432609375,10.5340259765625,10.11698609375,10.6401459765625L7.65748809375,12.6897259765625Q7.54118509375,12.7998059765625,7.39241009375,12.8590459765625Q7.24363409375,12.9182959765625,7.08349609375,12.9182959765625Q7.00125579375,12.9182959765625,6.92059609375,12.9022459765625Q6.83993609375,12.8862059765625,6.76395509375,12.8547359765625Q6.6879750937499995,12.8232559765625,6.61959509375,12.7775659765625Q6.55121509375,12.731875976562499,6.49306209375,12.673725976562501Q6.43490909375,12.6155759765625,6.38921909375,12.547195976562499Q6.34352909375,12.478815976562501,6.31205709375,12.4028359765625Q6.28058509375,12.3268559765625,6.26454009375,12.2461959765625Q6.24849609375,12.1655359765625,6.24849609375,12.0832959765625Q6.24849609375,11.9848059765625,6.27141009375,11.8890159765625Q6.29432409375,11.7932359765625,6.33889509375,11.7054159765625Q6.38346609375,11.6175859765625,6.44724609375,11.5425459765625Q6.51102709375,11.4674959765625,6.59051809375,11.4093459765625L8.28178609375,9.9999559765625L6.59051809375,8.5905679765625Q6.51102709375,8.5324209765625,6.44724609375,8.4573769765625Q6.38346509375,8.3823319765625,6.33889509375,8.2945069765625Q6.29432409375,8.2066819765625,6.27141009375,8.1108979765625Q6.24849609375,8.0151131765625,6.24849609375,7.9166259765625Q6.24849609375,7.8343856765625,6.26454009375,7.7537259765625Q6.28058509375,7.6730659765625,6.31205709375,7.5970849765625Q6.34352909375,7.5211049765624995,6.38921909375,7.4527249765625Q6.43490909375,7.3843449765625,6.49306209375,7.3261919765625Q6.55121509375,7.2680389765625,6.61959509375,7.2223489765625Q6.6879750937499995,7.1766589765625,6.76395509375,7.1451869765625Q6.83993609375,7.1137149765625,6.92059609375,7.0976699765625Q7.00125579375,7.0816259765625,7.08349609375,7.0816259765625Q7.24363509375,7.0816259765625,7.39241209375,7.1408709765625Q7.54118909375,7.2001159765625005,7.65749209375,7.3101989765625Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), _e(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_279/13_007)"), D(o, "clip-path", "url(#master_svg0_13_279)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, v) {
      A0(w, e, v), R(e, t), R(t, r), R(r, a), R(t, i), R(i, l), R(e, o), R(o, s), R(s, u), R(u, c), R(s, f), R(f, d), R(s, p), R(p, b), R(s, E), R(E, k);
    },
    d(w) {
      w && L(e);
    }
  };
}
function gp(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("clipPath"), l = V("rect"), o = V("g"), s = V("g"), u = V("g"), c = V("rect"), f = V("g"), d = V("path"), p = V("g"), b = V("path"), E = V("g"), k = V("path"), this.h();
    },
    l(w) {
      e = H(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var v = O(e);
      t = H(v, "defs", {});
      var _ = O(t);
      r = H(_, "clipPath", { id: !0 });
      var A = O(r);
      a = H(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), A.forEach(L), i = H(_, "clipPath", { id: !0 });
      var x = O(i);
      l = H(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(l).forEach(L), x.forEach(L), _.forEach(L), o = H(v, "g", { "clip-path": !0 });
      var Q = O(o);
      s = H(Q, "g", { "clip-path": !0 });
      var z = O(s);
      u = H(z, "g", {});
      var P = O(u);
      c = H(P, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(c).forEach(L), P.forEach(L), f = H(z, "g", {});
      var B = O(f);
      d = H(B, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(d).forEach(L), B.forEach(L), p = H(z, "g", {});
      var N = O(p);
      b = H(N, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(b).forEach(L), N.forEach(L), E = H(z, "g", {});
      var j = O(E);
      k = H(j, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(k).forEach(L), j.forEach(L), z.forEach(L), Q.forEach(L), v.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_287/13_279"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_287/13_279/13_018"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), _e(c, "mix-blend-mode", "passthrough"), D(d, "d", "M7.55256390625,4.9999589765625Q7.52622390625,5.0016259765625,7.49983390625,5.0016259765625Q7.41759390625,5.0016259765625,7.33693390625,4.9855819765625Q7.25627390625,4.9695369765625,7.18029390625,4.9380649765625Q7.10431390625,4.9065929765625,7.03593390625,4.8609029765625Q6.96755390625,4.8152129765625,6.90940390625,4.7570599765625Q6.85125390625,4.6989069765625,6.80556390625,4.6305269765625Q6.75986390625,4.5621469765625005,6.72839390625,4.4861669765625Q6.69692390625,4.4101859765625,6.68088390625,4.3295259765625Q6.66483390625,4.2488662765625,6.66483390625,4.1666259765625Q6.66483390625,4.0843856765625,6.68088390625,4.0037259765625Q6.69692390625,3.9230659765625,6.72839390625,3.8470849765625Q6.75986390625,3.7711049765625,6.80556390625,3.7027249765625Q6.85125390625,3.6343449765624998,6.90940390625,3.5761919765625Q6.96755390625,3.5180389765625,7.03593390625,3.4723489765625Q7.10431390625,3.4266589765625,7.18029390625,3.3951869765625Q7.25627390625,3.3637149765625,7.33693390625,3.3476699765625Q7.41759390625,3.3316259765625,7.49983390625,3.3316259765625Q7.52622390625,3.3316259765625,7.55256390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,11.1972259765625Q15.83480390625,11.2235659765625,15.83480390625,11.2499559765625Q15.83480390625,11.332195976562499,15.81880390625,11.4128559765625Q15.80270390625,11.493515976562499,15.77130390625,11.5694959765625Q15.73980390625,11.645475976562501,15.69410390625,11.713855976562499Q15.64840390625,11.7822359765625,15.59030390625,11.840395976562501Q15.53210390625,11.898545976562499,15.46370390625,11.9442359765625Q15.39540390625,11.9899259765625,15.31940390625,12.0213959765625Q15.24340390625,12.0528659765625,15.16270390625,12.0689159765625Q15.08210390625,12.084955976562501,14.99980390625,12.084955976562501Q14.91760390625,12.084955976562501,14.83690390625,12.0689159765625Q14.75630390625,12.0528659765625,14.68030390625,12.0213959765625Q14.60430390625,11.9899259765625,14.53590390625,11.9442359765625Q14.46760390625,11.898545976562499,14.40940390625,11.840395976562501Q14.35120390625,11.7822359765625,14.30560390625,11.713855976562499Q14.25990390625,11.645475976562501,14.22840390625,11.5694959765625Q14.19690390625,11.493515976562499,14.18090390625,11.4128559765625Q14.16480390625,11.332195976562499,14.16480390625,11.2499559765625Q14.16480390625,11.2235659765625,14.16650390625,11.1972259765625L14.16650390625,4.9999589765625L7.55256390625,4.9999589765625ZM2.49983690625,5.0526899765625Q2.50150390625,5.0263509765625,2.50150390625,4.9999589765625Q2.50150390625,4.9177189765625,2.48545990625,4.8370589765625Q2.46941490625,4.7563989765625,2.43794290625,4.6804189765625Q2.40647090625,4.6044379765625,2.36078090625,4.5360579765625Q2.31509090625,4.4676779765625,2.25693790625,4.4095249765625Q2.1987849062500002,4.3513719765625,2.13040490625,4.3056819765625Q2.06202490625,4.2599918765625,1.98604490625,4.2285198765625Q1.91006390625,4.1970478765625,1.82940390625,4.1810035765625Q1.74874420625,4.1649593165625,1.66650390625,4.1649593065625Q1.58426360625,4.1649593165625,1.50360390625,4.1810035765625Q1.42294390625,4.1970478765625,1.34696290625,4.2285198765625Q1.27098290625,4.2599918765625,1.20260290625,4.3056819765625Q1.13422290625,4.3513719765625,1.0760699062499999,4.4095249765625Q1.01791690625,4.4676779765625,0.97222690625,4.5360579765625Q0.92653690625,4.6044379765625,0.89506490625,4.6804189765625Q0.86359290625,4.7563989765625,0.84754790625,4.8370589765625Q0.83150390625,4.9177189765625,0.83150390625,4.9999589765625Q0.83150390625,5.0263509765625,0.83317090625,5.0526899765625L0.83317090625,15.8333259765625Q0.83317090625,15.9153259765625,0.84918290625,15.9958259765625Q0.86519490625,16.0763259765625,0.89660490625,16.152225976562498Q0.92801390625,16.2280259765625,0.97361290625,16.2962259765625Q1.01921190625,16.3645259765625,1.07724790625,16.4225259765625Q1.13528490625,16.4806259765625,1.2035289062499999,16.5262259765625Q1.27177290625,16.5718259765625,1.34760090625,16.6032259765625Q1.42342990625,16.6346259765625,1.50392890625,16.6506259765625Q1.58442770625,16.6666259765625,1.66650390625,16.6666259765625L12.44710390625,16.6666259765625Q12.47340390625,16.6683259765625,12.49980390625,16.6683259765625Q12.58210390625,16.6683259765625,12.66270390625,16.652225976562498Q12.74340390625,16.6362259765625,12.81940390625,16.6047259765625Q12.89540390625,16.573225976562497,12.96370390625,16.5275259765625Q13.03210390625,16.4819259765625,13.09030390625,16.4237259765625Q13.14840390625,16.365525976562502,13.19410390625,16.2972259765625Q13.23980390625,16.2288259765625,13.27130390625,16.1528259765625Q13.30270390625,16.0768259765625,13.31880390625,15.9962259765625Q13.33480390625,15.9155259765625,13.33480390625,15.8333259765625Q13.33480390625,15.7510259765625,13.31880390625,15.6704259765625Q13.30270390625,15.5897259765625,13.27130390625,15.5137259765625Q13.23980390625,15.4377259765625,13.19410390625,15.3694259765625Q13.14840390625,15.3010259765625,13.09030390625,15.2428259765625Q13.03210390625,15.1847259765625,12.96370390625,15.1390259765625Q12.89540390625,15.0933259765625,12.81940390625,15.0618259765625Q12.74340390625,15.0304259765625,12.66270390625,15.0143259765625Q12.58210390625,14.9983259765625,12.49980390625,14.9983259765625Q12.47340390625,14.9983259765625,12.44710390625,14.9999259765625L2.49983690625,14.9999259765625L2.49983690625,5.0526899765625Z"), D(d, "fill-rule", "evenodd"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), _e(d, "mix-blend-mode", "passthrough"), D(b, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), _e(b, "mix-blend-mode", "passthrough"), D(k, "d", "M1.1145349062499998,2.2931679765625Q0.97958490625,2.1742799765625,0.90554390625,2.0103779765625Q0.83150390625,1.8464759765625,0.83150390625,1.6666259765625Q0.83150390625,1.5843856765625,0.84754790625,1.5037259765625Q0.86359290625,1.4230659765625,0.89506490625,1.3470849765625Q0.92653690625,1.2711049765625,0.97222690625,1.2027249765625Q1.01791690625,1.1343449765625,1.0760699062499999,1.0761919765624999Q1.13422290625,1.0180389765625,1.20260290625,0.9723489765625Q1.27098290625,0.9266589765625,1.34696290625,0.8951869765625Q1.42294390625,0.8637149765625,1.50360390625,0.8476699765625Q1.58426360625,0.8316259765625,1.66650390625,0.8316259765625Q1.84635390625,0.8316259765625,2.01025590625,0.9056659765625Q2.17415790625,0.9797069765625,2.29304590625,1.1146569765624998L18.88520390625,17.7067259765625Q19.02010390625,17.8256259765625,19.09410390625,17.9895259765625Q19.16820390625,18.1534259765625,19.16820390625,18.3333259765625Q19.16820390625,18.4155259765625,19.15210390625,18.4962259765625Q19.13610390625,18.5768259765625,19.10460390625,18.6528259765625Q19.07310390625,18.7288259765625,19.02740390625,18.7972259765625Q18.98170390625,18.8655259765625,18.92360390625,18.9237259765625Q18.86540390625,18.9818259765625,18.79710390625,19.0275259765625Q18.72870390625,19.0732259765625,18.65270390625,19.1047259765625Q18.57670390625,19.1362259765625,18.49610390625,19.1522259765625Q18.41540390625,19.1683259765625,18.33320390625,19.1683259765625Q18.15330390625,19.1683259765625,17.98940390625,19.0942259765625Q17.82550390625,19.0202259765625,17.70660390625,18.8853259765625L1.1145349062499998,2.2931679765625Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), _e(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_287/13_279/13_018)"), D(o, "clip-path", "url(#master_svg0_13_287/13_279)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, v) {
      A0(w, e, v), R(e, t), R(t, r), R(r, a), R(t, i), R(i, l), R(e, o), R(o, s), R(s, u), R(u, c), R(s, f), R(f, d), R(s, p), R(p, b), R(s, E), R(E, k);
    },
    d(w) {
      w && L(e);
    }
  };
}
function E6(n) {
  let e, t = '<div class="corner-inner svelte-g68djp"></div>', r, a;
  return {
    c() {
      e = Ye("div"), e.innerHTML = t, this.h();
    },
    l(i) {
      e = Ze(i, "DIV", { class: !0, "data-svelte-h": !0 }), Vn(e) !== "svelte-1m3ekyt" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "corner svelte-g68djp");
    },
    m(i, l) {
      A0(i, e, l), r || (a = Ot(
        e,
        "click",
        /*open_camera_list*/
        n[34]
      ), r = !0);
    },
    p: gn,
    d(i) {
      i && L(e), r = !1, a();
    }
  };
}
function A6(n) {
  let e, t = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="none" version="1.1" width="14.000000357627869" height="10.000000357627869" viewBox="0 0 14.000000357627869 10.000000357627869"><g><path d="M13.802466686534881,1.1380186865348816Q13.89646668653488,1.0444176865348815,13.947366686534881,0.9218876865348815Q13.998366686534881,0.7993576865348816,13.998366686534881,0.6666666865348816Q13.998366686534881,0.6011698865348816,13.98556668653488,0.5369316865348817Q13.972766686534882,0.4726936865348816,13.947666686534882,0.4121826865348816Q13.922666686534882,0.3516706865348816,13.886266686534881,0.2972126865348816Q13.849866686534881,0.2427536865348816,13.803566686534882,0.19644068653488161Q13.757266686534882,0.15012768653488162,13.702766686534881,0.11373968653488165Q13.648366686534882,0.07735168653488156,13.587866686534882,0.052286686534881555Q13.527266686534881,0.02722268653488158,13.463066686534882,0.014444686534881623Q13.398866686534882,0.0016666865348815563,13.333366686534882,0.0016666865348815563Q13.201466686534882,0.0016666865348815563,13.079566686534882,0.051981686534881555Q12.957666686534882,0.10229768653488158,12.864266686534881,0.1953146865348816L12.863066686534882,0.19413268653488158L4.624996686534882,8.392776686534882L1.1369396865348815,4.921396686534882L1.1357636865348817,4.922586686534881Q1.0422996865348817,4.829566686534881,0.9204146865348816,4.779246686534882Q0.7985286865348816,4.728936686534881,0.6666666865348816,4.728936686534881Q0.6011698865348816,4.728936686534881,0.5369316865348817,4.741706686534882Q0.4726936865348816,4.754486686534881,0.4121826865348816,4.779556686534882Q0.3516706865348816,4.804616686534882,0.2972126865348816,4.8410066865348815Q0.2427536865348816,4.8773966865348815,0.19644068653488161,4.9237066865348815Q0.15012768653488162,4.970016686534882,0.11373968653488165,5.024476686534881Q0.07735168653488156,5.078936686534882,0.052286686534881555,5.139446686534882Q0.02722268653488158,5.199956686534882,0.014444686534881623,5.2641966865348815Q0.0016666865348815563,5.328436686534881,0.0016666865348815563,5.3939366865348815Q0.0016666865348815563,5.526626686534882,0.05259268653488158,5.649156686534882Q0.10351768653488158,5.771686686534881,0.1975696865348816,5.865286686534882L0.1963936865348816,5.866466686534881L4.1547266865348815,9.805866686534882Q4.201126686534882,9.852046686534882,4.255616686534882,9.888306686534882Q4.310106686534882,9.924576686534882,4.3706166865348814,9.949556686534882Q4.431126686534881,9.974536686534881,4.495326686534882,9.987266686534882Q4.559536686534882,9.999996686534882,4.624996686534882,9.999996686534882Q4.690456686534882,9.999996686534882,4.754666686534882,9.987266686534882Q4.818876686534882,9.974536686534881,4.879386686534882,9.949556686534882Q4.939886686534882,9.924576686534882,4.994386686534882,9.888306686534882Q5.048876686534881,9.852046686534882,5.0952766865348815,9.805866686534882L13.803566686534882,1.1392006865348816L13.802466686534881,1.1380186865348816Z" fill-rule="evenodd" fill="#E0E0FC" fill-opacity="1" style="mix-blend-mode:passthrough"></path></g></svg>';
  return {
    c() {
      e = Ye("div"), e.innerHTML = t, this.h();
    },
    l(r) {
      e = Ze(r, "DIV", { class: !0, "data-svelte-h": !0 }), Vn(e) !== "svelte-c8s251" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "active-icon svelte-g68djp");
    },
    m(r, a) {
      A0(r, e, a);
    },
    d(r) {
      r && L(e);
    }
  };
}
function F6(n) {
  let e, t = (
    /*device*/
    n[63].label + ""
  ), r, a, i, l, o, s = (
    /*selected_video_device*/
    n[5] && /*device*/
    n[63].deviceId === /*selected_video_device*/
    n[5].deviceId && A6()
  );
  function u(...c) {
    return (
      /*click_handler_1*/
      n[50](
        /*device*/
        n[63],
        ...c
      )
    );
  }
  return {
    c() {
      e = Ye("div"), r = k4(t), a = q0(), s && s.c(), i = q0(), this.h();
    },
    l(c) {
      e = Ze(c, "DIV", { class: !0 });
      var f = O(e);
      r = b4(f, t), a = O0(f), s && s.l(f), i = O0(f), f.forEach(L), this.h();
    },
    h() {
      D(e, "class", "selector svelte-g68djp");
    },
    m(c, f) {
      A0(c, e, f), R(e, r), R(e, a), s && s.m(e, null), R(e, i), l || (o = Ot(e, "click", y4(u)), l = !0);
    },
    p(c, f) {
      n = c, f[0] & /*available_video_devices*/
      8 && t !== (t = /*device*/
      n[63].label + "") && w4(r, t), /*selected_video_device*/
      n[5] && /*device*/
      n[63].deviceId === /*selected_video_device*/
      n[5].deviceId ? s || (s = A6(), s.c(), s.m(e, i)) : s && (s.d(1), s = null);
    },
    d(c) {
      c && L(e), s && s.d(), l = !1, o();
    }
  };
}
function _p(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("clipPath"), l = V("rect"), o = V("g"), s = V("g"), u = V("g"), c = V("rect"), f = V("g"), d = V("path"), p = V("g"), b = V("path"), E = V("g"), k = V("path"), this.h();
    },
    l(w) {
      e = H(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var v = O(e);
      t = H(v, "defs", {});
      var _ = O(t);
      r = H(_, "clipPath", { id: !0 });
      var A = O(r);
      a = H(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), A.forEach(L), i = H(_, "clipPath", { id: !0 });
      var x = O(i);
      l = H(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(l).forEach(L), x.forEach(L), _.forEach(L), o = H(v, "g", { "clip-path": !0 });
      var Q = O(o);
      s = H(Q, "g", { "clip-path": !0 });
      var z = O(s);
      u = H(z, "g", {});
      var P = O(u);
      c = H(P, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(c).forEach(L), P.forEach(L), f = H(z, "g", {});
      var B = O(f);
      d = H(B, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(d).forEach(L), B.forEach(L), p = H(z, "g", {});
      var N = O(p);
      b = H(N, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(b).forEach(L), N.forEach(L), E = H(z, "g", {});
      var j = O(E);
      k = H(j, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(k).forEach(L), j.forEach(L), z.forEach(L), Q.forEach(L), v.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_278"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_278/13_029"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), _e(c, "mix-blend-mode", "passthrough"), D(d, "d", "M6.249918953125,9.9999559765625L6.249918953125,4.5832959765625Q6.249918953125,3.0299959765624997,7.348267953125,1.9316419765625Q8.446621953125,0.8332929765625,9.999921953125,0.8332929765625Q11.553221953125,0.8332929765625,12.651571953125,1.9316419765625Q13.749921953125,3.0299959765624997,13.749921953125,4.5832959765625L13.749921953125,9.9999559765625Q13.749921953125,11.5532559765625,12.651571953125,12.6516259765625Q11.553221953125,13.7499259765625,9.999921953125,13.7499259765625Q8.446621953125,13.7499259765625,7.348267953125,12.6516259765625Q6.249918953125,11.5532559765625,6.249918953125,9.9999559765625ZM7.916584953125,9.9999559765625Q7.916584953125,10.8629059765625,8.526781953124999,11.4730959765625Q9.136971953125,12.0833259765625,9.999921953125,12.0833259765625Q10.862861953125,12.0833259765625,11.473061953125,11.4730959765625Q12.083251953125,10.8629059765625,12.083251953125,9.9999559765625L12.083251953125,4.5832959765625Q12.083251953125,3.7203459765625,11.473061953125,3.1101559765625Q10.862861953125,2.4999589765625,9.999921953125,2.4999589765625Q9.136971953125,2.4999589765625,8.526781953124999,3.1101559765625Q7.916584953125,3.7203459765625,7.916584953125,4.5832959765625L7.916584953125,9.9999559765625Z"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), _e(d, "mix-blend-mode", "passthrough"), D(b, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q12.93402,16.6667040234375,15.0087,14.5920540234375Q17.0636,12.5370940234375,17.0831,9.6390003234375Q17.085,9.6112181234375,17.085,9.5833740234375Q17.085,9.5011337234375,17.069000000000003,9.4204740234375Q17.0529,9.3398140234375,17.0214,9.2638330234375Q16.990000000000002,9.1878530234375,16.9443,9.1194730234375Q16.898600000000002,9.0510930234375,16.840400000000002,8.9929400234375Q16.7823,8.9347870234375,16.713900000000002,8.8890970234375Q16.6455,8.8434070234375,16.569499999999998,8.8119350234375Q16.4936,8.7804630234375,16.4129,8.7644180234375Q16.3322,8.7483740234375,16.25,8.7483740234375Q16.1678,8.7483740234375,16.0871,8.7644180234375Q16.0064,8.7804630234375,15.9305,8.8119350234375Q15.8545,8.8434070234375,15.7861,8.8890970234375Q15.7177,8.9347870234375,15.6596,8.9929400234375Q15.6014,9.0510930234375,15.5557,9.1194730234375Q15.51,9.1878530234375,15.4786,9.2638330234375Q15.4471,9.3398140234375,15.431,9.4204740234375Q15.415,9.5011337234375,15.415,9.5833740234375Q15.415,9.6081817234375,15.4165,9.6329456234375Q15.3991,11.8445940234375,13.8302,13.413544023437499Q12.24366,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), _e(b, "mix-blend-mode", "passthrough"), D(k, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), _e(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_278/13_029)"), D(o, "clip-path", "url(#master_svg0_13_278)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, v) {
      A0(w, e, v), R(e, t), R(t, r), R(r, a), R(t, i), R(i, l), R(e, o), R(o, s), R(s, u), R(u, c), R(s, f), R(f, d), R(s, p), R(p, b), R(s, E), R(E, k);
    },
    d(w) {
      w && L(e);
    }
  };
}
function vp(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k, w, v;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("clipPath"), l = V("rect"), o = V("g"), s = V("g"), u = V("g"), c = V("path"), f = V("g"), d = V("path"), p = V("g"), b = V("path"), E = V("g"), k = V("path"), w = V("g"), v = V("path"), this.h();
    },
    l(_) {
      e = H(_, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var A = O(e);
      t = H(A, "defs", {});
      var x = O(t);
      r = H(x, "clipPath", { id: !0 });
      var Q = O(r);
      a = H(Q, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), Q.forEach(L), i = H(x, "clipPath", { id: !0 });
      var z = O(i);
      l = H(z, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(l).forEach(L), z.forEach(L), x.forEach(L), o = H(A, "g", { "clip-path": !0 });
      var P = O(o);
      s = H(P, "g", { "clip-path": !0 });
      var B = O(s);
      u = H(B, "g", {});
      var N = O(u);
      c = H(N, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(c).forEach(L), N.forEach(L), f = H(B, "g", {});
      var j = O(f);
      d = H(j, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(d).forEach(L), j.forEach(L), p = H(B, "g", {});
      var $ = O(p);
      b = H($, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(b).forEach(L), $.forEach(L), E = H(B, "g", {});
      var W = O(E);
      k = H(W, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(k).forEach(L), W.forEach(L), w = H(B, "g", {});
      var se = O(w);
      v = H(se, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(v).forEach(L), se.forEach(L), B.forEach(L), P.forEach(L), A.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_287/13_278"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_287/13_278/13_040"), D(c, "d", "M7.34851109375,12.6516259765625Q8.44685609375,13.7499259765625,10.00016609375,13.7499259765625Q11.55346609375,13.7499259765625,12.65181609375,12.6516259765625Q13.75016609375,11.5532659765625,13.75016609375,9.9999559765625L13.75016609375,4.5832959765625Q13.75016609375,3.0299959765624997,12.65181609375,1.9316429765625Q11.55346609375,0.8332929765625,10.00016609375,0.8332919765625Q8.44685609375,0.8332929765625,7.34851109375,1.9316429765625Q6.25016309375,3.0299959765624997,6.25016309375,4.5832959765625L6.25016309375,9.9999559765625Q6.25016309375,11.5532659765625,7.34851109375,12.6516259765625ZM11.47330609375,11.4730959765625Q10.86310609375,12.0833259765625,10.00016609375,12.0833259765625Q9.13721609375,12.0833259765625,8.527026093749999,11.4730959765625Q7.91682909375,10.8629059765625,7.91682909375,9.9999559765625L7.91683009375,4.5832959765625Q7.91683009375,3.7203459765625,8.527026093749999,3.1101559765625Q9.13721609375,2.4999589765625,10.00016609375,2.4999589765625Q10.86310609375,2.4999589765625,11.47330609375,3.1101559765625Q12.08349609375,3.7203459765625,12.08349609375,4.5832959765625L12.08349609375,9.9999559765625Q12.08349609375,10.8629059765625,11.47330609375,11.4730959765625Z"), D(c, "fill-rule", "evenodd"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "1"), _e(c, "mix-blend-mode", "passthrough"), D(d, "d", "M17.08315046875,9.6393233234375Q17.08502046875,9.6113801234375,17.08502046875,9.5833740234375Q17.08502046875,9.5011337234375,17.06898046875,9.4204740234375Q17.05293046875,9.3398140234375,17.02146046875,9.2638330234375Q16.98999046875,9.1878530234375,16.94430046875,9.1194730234375Q16.89861046875,9.0510930234375,16.84046046875,8.9929400234375Q16.78230046875,8.9347870234375,16.71392346875,8.8890970234375Q16.64554246875,8.8434070234375,16.56956246875,8.8119350234375Q16.49358246875,8.7804630234375,16.41292246875,8.7644180234375Q16.33226246875,8.7483740234375,16.25002246875,8.7483740234375Q16.16778146875,8.7483740234375,16.08712146875,8.7644180234375Q16.00646146875,8.7804630234375,15.93048146875,8.8119350234375Q15.85450146875,8.8434070234375,15.78612106875,8.8890970234375Q15.71774076875,8.9347870234375,15.65958806875,8.9929400234375Q15.60143546875,9.0510930234375,15.55574546875,9.1194730234375Q15.51005446875,9.1878530234375,15.47858246875,9.2638330234375Q15.44711046875,9.3398140234375,15.43106646875,9.4204740234375Q15.41502246875,9.5011337234375,15.41502246875,9.5833740234375Q15.41502246875,9.6080265234375,15.41647646875,9.6326360234375Q15.40712446875,10.7164940234375,14.98582546875,11.7046140234375Q14.89498046875,11.8831040234375,14.89498046875,12.0833740234375Q14.89498046875,12.1656140234375,14.91102446875,12.2462740234375Q14.92706946875,12.3269340234375,14.95854146875,12.4029140234375Q14.99001346875,12.4788940234375,15.03570346875,12.5472740234375Q15.08139346875,12.6156540234375,15.13954646875,12.6738040234375Q15.19769946875,12.7319640234375,15.26607946875,12.7776540234375Q15.33445946875,12.8233440234375,15.41043946875,12.8548140234375Q15.48642046875,12.8862840234375,15.56708046875,12.9023340234375Q15.64774016875,12.9183740234375,15.72998046875,12.9183740234375Q15.79409136875,12.9183740234375,15.85745046875,12.9085840234375Q15.92081046875,12.8988040234375,15.98193346875,12.8794540234375Q16.04305546875,12.8601140234375,16.10050846875,12.8316640234375Q16.15796246875,12.8032140234375,16.21039846875,12.7663240234375Q16.26283546875,12.7294440234375,16.309026468749998,12.6849840234375Q16.35521746875,12.6405240234375,16.39408046875,12.5895340234375Q16.43294246875,12.538544023437499,16.46356646875,12.4822240234375Q16.49418946875,12.4258940234375,16.51585446875,12.3655540234375Q17.07244046875,11.0643540234375,17.08315046875,9.6393233234375Z"), D(d, "fill-rule", "evenodd"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), _e(d, "mix-blend-mode", "passthrough"), D(b, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q11.1917,16.6667040234375,12.30806,16.2819440234375Q12.37346,16.2636640234375,12.43505,16.235064023437502Q12.49663,16.2064640234375,12.55279,16.1682840234375Q12.60894,16.1301040234375,12.65819,16.0833540234375Q12.70744,16.036604023437498,12.74849,15.9825140234375Q12.78954,15.9284240234375,12.82131,15.868404023437499Q12.85308,15.8083940234375,12.87473,15.7440340234375Q12.89639,15.6796740234375,12.90736,15.6126640234375Q12.91833,15.5456540234375,12.91833,15.4777440234375Q12.91833,15.3955040234375,12.90229,15.3148440234375Q12.88624,15.2341840234375,12.85477,15.1582040234375Q12.8233,15.082224023437501,12.77761,15.0138440234375Q12.73192,14.9454640234375,12.67377,14.8873140234375Q12.61561,14.8291640234375,12.54723,14.783474023437499Q12.47885,14.7377840234375,12.40287,14.7063140234375Q12.32689,14.6748340234375,12.24623,14.658794023437501Q12.16557,14.6427540234375,12.08333,14.642744023437501Q11.91469,14.642744023437501,11.75926,14.7082040234375Q10.9093,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), _e(b, "mix-blend-mode", "passthrough"), D(k, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), _e(k, "mix-blend-mode", "passthrough"), D(v, "d", "M1.9480309999999998,3.126542Q1.813081,3.007654,1.7390400000000001,2.843752Q1.665,2.67985,1.665,2.5Q1.665,2.4177597,1.681044,2.3371Q1.697089,2.25644,1.728561,2.180459Q1.760033,2.104479,1.805723,2.036099Q1.851413,1.967719,1.9095659999999999,1.9095659999999999Q1.967719,1.851413,2.036099,1.805723Q2.104479,1.760033,2.180459,1.728561Q2.25644,1.697089,2.3371,1.681044Q2.4177597,1.665,2.5,1.665Q2.67985,1.665,2.843752,1.7390400000000001Q3.007654,1.813081,3.126542,1.9480309999999998L18.052,16.8735Q18.1869,16.9923,18.261,17.1562Q18.335,17.3202,18.335,17.5Q18.335,17.5822,18.319000000000003,17.6629Q18.3029,17.7436,18.2714,17.819499999999998Q18.240000000000002,17.8955,18.1943,17.963900000000002Q18.148600000000002,18.0323,18.090400000000002,18.090400000000002Q18.0323,18.148600000000002,17.963900000000002,18.1943Q17.8955,18.240000000000002,17.819499999999998,18.2714Q17.7436,18.3029,17.6629,18.319000000000003Q17.5822,18.335,17.5,18.335Q17.3202,18.335,17.1562,18.261Q16.9923,18.1869,16.8735,18.052L1.9480309999999998,3.126542Z"), D(v, "fill-rule", "evenodd"), D(v, "fill", "#FFFFFF"), D(v, "fill-opacity", "1"), _e(v, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_287/13_278/13_040)"), D(o, "clip-path", "url(#master_svg0_13_287/13_278)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(_, A) {
      A0(_, e, A), R(e, t), R(t, r), R(r, a), R(t, i), R(i, l), R(e, o), R(o, s), R(s, u), R(u, c), R(s, f), R(f, d), R(s, p), R(p, b), R(s, E), R(E, k), R(s, w), R(w, v);
    },
    d(_) {
      _ && L(e);
    }
  };
}
function S6(n) {
  let e, t = '<div class="corner-inner svelte-g68djp"></div>', r, a;
  return {
    c() {
      e = Ye("div"), e.innerHTML = t, this.h();
    },
    l(i) {
      e = Ze(i, "DIV", { class: !0, "data-svelte-h": !0 }), Vn(e) !== "svelte-1hp0en1" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "corner svelte-g68djp");
    },
    m(i, l) {
      A0(i, e, l), r || (a = Ot(
        e,
        "click",
        /*open_mic_list*/
        n[33]
      ), r = !0);
    },
    p: gn,
    d(i) {
      i && L(e), r = !1, a();
    }
  };
}
function x6(n) {
  let e, t = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="none" version="1.1" width="14.000000357627869" height="10.000000357627869" viewBox="0 0 14.000000357627869 10.000000357627869"><g><path d="M13.802466686534881,1.1380186865348816Q13.89646668653488,1.0444176865348815,13.947366686534881,0.9218876865348815Q13.998366686534881,0.7993576865348816,13.998366686534881,0.6666666865348816Q13.998366686534881,0.6011698865348816,13.98556668653488,0.5369316865348817Q13.972766686534882,0.4726936865348816,13.947666686534882,0.4121826865348816Q13.922666686534882,0.3516706865348816,13.886266686534881,0.2972126865348816Q13.849866686534881,0.2427536865348816,13.803566686534882,0.19644068653488161Q13.757266686534882,0.15012768653488162,13.702766686534881,0.11373968653488165Q13.648366686534882,0.07735168653488156,13.587866686534882,0.052286686534881555Q13.527266686534881,0.02722268653488158,13.463066686534882,0.014444686534881623Q13.398866686534882,0.0016666865348815563,13.333366686534882,0.0016666865348815563Q13.201466686534882,0.0016666865348815563,13.079566686534882,0.051981686534881555Q12.957666686534882,0.10229768653488158,12.864266686534881,0.1953146865348816L12.863066686534882,0.19413268653488158L4.624996686534882,8.392776686534882L1.1369396865348815,4.921396686534882L1.1357636865348817,4.922586686534881Q1.0422996865348817,4.829566686534881,0.9204146865348816,4.779246686534882Q0.7985286865348816,4.728936686534881,0.6666666865348816,4.728936686534881Q0.6011698865348816,4.728936686534881,0.5369316865348817,4.741706686534882Q0.4726936865348816,4.754486686534881,0.4121826865348816,4.779556686534882Q0.3516706865348816,4.804616686534882,0.2972126865348816,4.8410066865348815Q0.2427536865348816,4.8773966865348815,0.19644068653488161,4.9237066865348815Q0.15012768653488162,4.970016686534882,0.11373968653488165,5.024476686534881Q0.07735168653488156,5.078936686534882,0.052286686534881555,5.139446686534882Q0.02722268653488158,5.199956686534882,0.014444686534881623,5.2641966865348815Q0.0016666865348815563,5.328436686534881,0.0016666865348815563,5.3939366865348815Q0.0016666865348815563,5.526626686534882,0.05259268653488158,5.649156686534882Q0.10351768653488158,5.771686686534881,0.1975696865348816,5.865286686534882L0.1963936865348816,5.866466686534881L4.1547266865348815,9.805866686534882Q4.201126686534882,9.852046686534882,4.255616686534882,9.888306686534882Q4.310106686534882,9.924576686534882,4.3706166865348814,9.949556686534882Q4.431126686534881,9.974536686534881,4.495326686534882,9.987266686534882Q4.559536686534882,9.999996686534882,4.624996686534882,9.999996686534882Q4.690456686534882,9.999996686534882,4.754666686534882,9.987266686534882Q4.818876686534882,9.974536686534881,4.879386686534882,9.949556686534882Q4.939886686534882,9.924576686534882,4.994386686534882,9.888306686534882Q5.048876686534881,9.852046686534882,5.0952766865348815,9.805866686534882L13.803566686534882,1.1392006865348816L13.802466686534881,1.1380186865348816Z" fill-rule="evenodd" fill="#E0E0FC" fill-opacity="1" style="mix-blend-mode:passthrough"></path></g></svg>';
  return {
    c() {
      e = Ye("div"), e.innerHTML = t, this.h();
    },
    l(r) {
      e = Ze(r, "DIV", { class: !0, "data-svelte-h": !0 }), Vn(e) !== "svelte-c8s251" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "active-icon svelte-g68djp");
    },
    m(r, a) {
      A0(r, e, a);
    },
    d(r) {
      r && L(e);
    }
  };
}
function C6(n) {
  let e, t = (
    /*device*/
    n[63].label + ""
  ), r, a, i, l, o, s = (
    /*selected_audio_device*/
    n[6] && /*device*/
    n[63].deviceId === /*selected_audio_device*/
    n[6].deviceId && x6()
  );
  function u(...c) {
    return (
      /*click_handler_2*/
      n[52](
        /*device*/
        n[63],
        ...c
      )
    );
  }
  return {
    c() {
      e = Ye("div"), r = k4(t), a = q0(), s && s.c(), i = q0(), this.h();
    },
    l(c) {
      e = Ze(c, "DIV", { class: !0 });
      var f = O(e);
      r = b4(f, t), a = O0(f), s && s.l(f), i = O0(f), f.forEach(L), this.h();
    },
    h() {
      D(e, "class", "selector svelte-g68djp");
    },
    m(c, f) {
      A0(c, e, f), R(e, r), R(e, a), s && s.m(e, null), R(e, i), l || (o = Ot(e, "click", y4(u)), l = !0);
    },
    p(c, f) {
      n = c, f[0] & /*available_audio_devices*/
      16 && t !== (t = /*device*/
      n[63].label + "") && w4(r, t), /*selected_audio_device*/
      n[6] && /*device*/
      n[63].deviceId === /*selected_audio_device*/
      n[6].deviceId ? s || (s = x6(), s.c(), s.m(e, i)) : s && (s.d(1), s = null);
    },
    d(c) {
      c && L(e), s && s.d(), l = !1, o();
    }
  };
}
function bp(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("clipPath"), l = V("rect"), o = V("g"), s = V("g"), u = V("g"), c = V("rect"), f = V("g"), d = V("path"), p = V("g"), b = V("path"), E = V("g"), k = V("path"), this.h();
    },
    l(w) {
      e = H(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var v = O(e);
      t = H(v, "defs", {});
      var _ = O(t);
      r = H(_, "clipPath", { id: !0 });
      var A = O(r);
      a = H(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), A.forEach(L), i = H(_, "clipPath", { id: !0 });
      var x = O(i);
      l = H(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(l).forEach(L), x.forEach(L), _.forEach(L), o = H(v, "g", { "clip-path": !0 });
      var Q = O(o);
      s = H(Q, "g", { "clip-path": !0 });
      var z = O(s);
      u = H(z, "g", {});
      var P = O(u);
      c = H(P, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(c).forEach(L), P.forEach(L), f = H(z, "g", {});
      var B = O(f);
      d = H(B, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(d).forEach(L), B.forEach(L), p = H(z, "g", {});
      var N = O(p);
      b = H(N, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(b).forEach(L), N.forEach(L), E = H(z, "g", {});
      var j = O(E);
      k = H(j, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(k).forEach(L), j.forEach(L), z.forEach(L), Q.forEach(L), v.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_280"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_280/13_053"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), _e(c, "mix-blend-mode", "passthrough"), D(d, "d", "M4.443888046875,5.42117L2.500081046875,5.42117Q1.809725046875,5.42117,1.321573046875,5.90931Q0.833415046875,6.39747,0.833415046875,7.08783L0.833415046875,12.8496Q0.833415046875,13.54,1.321574046875,14.0281Q1.809725046875,14.5163,2.500081046875,14.5163L4.439858046875,14.5163Q6.771998046875,18.3333,10.000078046875,18.3333Q10.082158046875,18.3333,10.162658046875,18.3173Q10.243158046875,18.301299999999998,10.318988046875,18.2699Q10.394808046875,18.238500000000002,10.463058046875,18.1929Q10.531298046875,18.1473,10.589338046875,18.0893Q10.647378046875,18.0312,10.692968046875,17.963Q10.738568046875,17.8947,10.769978046875,17.8189Q10.801388046875,17.7431,10.817398046875,17.662599999999998Q10.833418046875,17.5821,10.833418046875,17.5L10.833418046875,2.5Q10.833418046875,2.4179238,10.817398046875,2.337425Q10.801388046875,2.256926,10.769978046875,2.181097Q10.738568046875,2.105269,10.692968046875,2.037025Q10.647368046875,1.968781,10.589338046875,1.910744Q10.531298046875,1.852708,10.463058046875,1.807109Q10.394808046875,1.76151,10.318988046875,1.7301009999999999Q10.243158046875,1.698691,10.162658046875,1.682679Q10.082158046875,1.666667,10.000078046875,1.666667Q6.776438046875,1.666667,4.443888046875,5.42117ZM4.916118046875,7.08783Q5.025838046875,7.08783,5.131818046875,7.05943Q5.237798046875,7.03103,5.3328180468749995,6.97617Q5.427828046875,6.92131,5.505408046875,6.84372Q5.582988046875,6.76614,5.637838046875,6.67111Q7.228838046875,3.91495,9.166748046875,3.434681L9.166748046875,16.563299999999998Q7.232128046875,16.074199999999998,5.6407880468750005,13.2715Q5.586248046875,13.1754,5.508548046875,13.0969Q5.4308580468750005,13.0184,5.335388046875,12.9628Q5.239908046875,12.9072,5.1332580468749995,12.8784Q5.026598046875,12.8496,4.916118046875,12.8496L2.500081046875,12.8496L2.500082046875,7.08783L4.916118046875,7.08783Z"), D(d, "fill-rule", "evenodd"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), _e(d, "mix-blend-mode", "passthrough"), D(b, "d", "M12.813896953124999,6.903831Q12.740067953125,6.845187,12.681175953125,6.771557Q12.622282953125,6.697926,12.581291953125,6.613017Q12.540300953125,6.528109,12.519276953125,6.436197Q12.498251953125,6.3442856,12.498251953125,6.25Q12.498251953125,6.1677597,12.514295953125,6.0871Q12.530340953125,6.00644,12.561812953125,5.930459Q12.593284953125,5.8544789999999995,12.638974953125,5.786099Q12.684664953125,5.717719,12.742817953125,5.659566Q12.800970953125,5.601413,12.869350953125,5.555723Q12.937730953125,5.510033,13.013710953125,5.478561Q13.089691953125,5.447089,13.170351953125,5.431044Q13.251011653125,5.415,13.333251953125,5.415Q13.501904953125,5.415,13.657335953125,5.4804580000000005Q13.812766953125,5.545916,13.930607953125,5.66657Q14.362131953125001,6.059567,14.707911953125,6.532997Q15.248111953125001,7.2726299999999995,15.535961953125,8.14354Q15.833251953125,9.04304,15.833251953125,10Q15.833251953125,10.94869,15.540941953125,11.84127Q15.257921953125,12.70551,14.726221953125,13.4418Q14.373671953125,13.92992,13.930609953125,14.33343Q13.812768953125,14.45408,13.657336953125,14.51954Q13.501904953125,14.585,13.333251953125,14.585Q13.251011653125,14.585,13.170351953125,14.56895Q13.089691953125,14.55291,13.013710953125,14.52144Q12.937730953125,14.48997,12.869350953125,14.44428Q12.800970953125,14.39859,12.742817953125,14.34043Q12.684664953125,14.28228,12.638974953125,14.213899999999999Q12.593284953125,14.145520000000001,12.561812953125,14.06954Q12.530340953125,13.99356,12.514295953125,13.9129Q12.498251953125,13.832239999999999,12.498251953125,13.75Q12.498251953125,13.655719999999999,12.519276953125,13.5638Q12.540300953125,13.47189,12.581291953125,13.386980000000001Q12.622282953125,13.30207,12.681174953125,13.228439999999999Q12.740067953125,13.154810000000001,12.813895953125,13.09617Q13.125969953125,12.8109,13.375114153125,12.46595Q14.166584953125,11.36993,14.166584953125,10Q14.166584953125,8.61762,13.362005753125,7.516Q13.117749953125,7.181583,12.813896953124999,6.903831Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), _e(b, "mix-blend-mode", "passthrough"), D(k, "d", "M14.863105578125,2.228405984375Q16.823672578125,3.456592984375,17.969842578125,5.468508984375Q19.166602578125,7.569218984375,19.166602578125,10.000018984375Q19.166602578125,12.469708984375,17.933552578125,14.594658984375Q16.751772578125,16.631258984375002,14.739248578125,17.847858984375Q14.525103578125,17.995758984375,14.264892578125,17.995758984375Q14.182652278125,17.995758984375,14.101992578125,17.979658984375Q14.021332578125,17.963658984375,13.945351578125,17.932158984375Q13.869371578125,17.900658984375,13.800991578125,17.854958984375Q13.732611578125,17.809358984375002,13.674458578125,17.751158984375Q13.616305578125,17.692958984375,13.570615578125,17.624658984375Q13.524925578125,17.556258984375,13.493453578125,17.480258984375Q13.461981578125,17.404258984374998,13.445936578125,17.323658984375Q13.429892578125,17.242958984375,13.429892578125,17.160758984375Q13.429892578125,17.045958984374998,13.460862578124999,16.935458984375Q13.491831578125,16.824858984375,13.551473578125,16.726858984375Q13.611115578125,16.628758984375,13.695005578125,16.550458984375Q13.778896578125,16.472058984375,13.880811578125,16.419258984375Q15.525652578125,15.423558984375,16.492012578125,13.758158984375Q17.499932578125,12.021168984375,17.499932578125,10.000018984375Q17.499932578125,8.010658984374999,16.521692578125,6.293508984375Q15.584492578125,4.648418984375,13.982075578125,3.643182984375Q13.882499578125,3.589574984375,13.800770578125,3.511412984375Q13.719041578125,3.433249984375,13.661047578125,3.336162984375Q13.603053578125,3.239076984375,13.572972578125,3.130062984375Q13.542891578125,3.021047984375,13.542891578125,2.907958984375Q13.542891578125,2.825718684375,13.558936578125,2.745058984375Q13.574980578125,2.664398984375,13.606452578125,2.588417984375Q13.637924578125,2.512437984375,13.683614578125,2.444057984375Q13.729305578125,2.3756779843749998,13.787457578125,2.317524984375Q13.845610578125,2.259371984375,13.913990578125,2.213681984375Q13.982370578125,2.167991984375,14.058351578125,2.136519984375Q14.134331578125,2.105047984375,14.214991478125,2.089002984375Q14.295651478125,2.072958984375,14.377891578125,2.072958984375Q14.508378578125,2.072958984375,14.632644578125,2.112769984375Q14.756910578125,2.152579984375,14.863105578125,2.228405984375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), _e(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_280/13_053)"), D(o, "clip-path", "url(#master_svg0_13_280)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, v) {
      A0(w, e, v), R(e, t), R(t, r), R(r, a), R(t, i), R(i, l), R(e, o), R(o, s), R(s, u), R(u, c), R(s, f), R(f, d), R(s, p), R(p, b), R(s, E), R(E, k);
    },
    d(w) {
      w && L(e);
    }
  };
}
function wp(n) {
  let e, t, r, a, i, l, o, s, u, c, f;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("g"), l = V("g"), o = V("path"), s = V("g"), u = V("path"), c = V("g"), f = V("path"), this.h();
    },
    l(d) {
      e = H(d, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var p = O(e);
      t = H(p, "defs", {});
      var b = O(t);
      r = H(b, "clipPath", { id: !0 });
      var E = O(r);
      a = H(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), E.forEach(L), b.forEach(L), i = H(p, "g", { "clip-path": !0 });
      var k = O(i);
      l = H(k, "g", {});
      var w = O(l);
      o = H(w, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(o).forEach(L), w.forEach(L), s = H(k, "g", {});
      var v = O(s);
      u = H(v, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(u).forEach(L), v.forEach(L), c = H(k, "g", {});
      var _ = O(c);
      f = H(_, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), O(f).forEach(L), _.forEach(L), k.forEach(L), p.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_20_113"), D(o, "d", "M17.52452171875,9.078936578124999Q17.659471718749998,8.960048578125,17.73351171875,8.796145578125Q17.80755171875,8.632242578125,17.80755171875,8.452392578125Q17.80755171875,8.370152278125,17.79151171875,8.289492578125Q17.77546171875,8.208832578125,17.74399171875,8.132851578125Q17.71252171875,8.056871578125,17.66683171875,7.988491578125Q17.62114171875,7.920111578125,17.56299171875,7.861958578125Q17.50483171875,7.803805578125,17.43645171875,7.758115578125Q17.36807171875,7.712425578125,17.29209171875,7.680953578125Q17.21611171875,7.649481578125,17.13545171875,7.633436578125Q17.05479171875,7.617392578125,16.97255171875,7.617392578125Q16.79270171875,7.617392578125,16.62880171875,7.691433578125Q16.46490171875,7.765474578125,16.34601171875,7.900425578125L12.88504271875,11.361392578124999Q12.75009271875,11.480282578125,12.67605171875,11.644182578125001Q12.60201171875,11.808082578125,12.60201171875,11.987932578125001Q12.60201171875,12.070172578125,12.61805571875,12.150832578125Q12.63410071875,12.231492578125,12.66557271875,12.307472578125001Q12.69704471875,12.383452578125,12.74273471875,12.451832578125Q12.78842471875,12.520212578125001,12.84657771875,12.578362578124999Q12.90473071875,12.636522578125,12.97311071875,12.682212578125Q13.04149071875,12.727902578125,13.11747071875,12.759372578125Q13.19345171875,12.790842578125,13.27411171875,12.806892578125Q13.35477141875,12.822932578125,13.43701171875,12.822932578125Q13.61685971875,12.822932578125,13.78076071875,12.748892578125Q13.94466171875,12.674852578125,14.06354971875,12.539902578125L17.52452171875,9.078936578124999Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), _e(o, "mix-blend-mode", "passthrough"), D(u, "d", "M12.88553,9.078933578125Q12.75058,8.960045578125,12.67654,8.796143578125Q12.6025,8.632241578125,12.6025,8.452392578125Q12.6025,8.370152278125,12.618544,8.289492578125Q12.634589,8.208832578125,12.666061,8.132851578125Q12.697533,8.056871578125,12.743223,7.988491578125Q12.788913,7.920111578125,12.847066,7.861958578125Q12.905219,7.803805578125,12.973599,7.758115578125Q13.041979,7.712425578125,13.117959,7.680953578125Q13.19394,7.649481578125,13.2746,7.633436578125Q13.3552597,7.617392578125,13.4375,7.617392578125Q13.617349,7.617392578125,13.781251,7.691432578125Q13.945153,7.765472578125,14.064041,7.900422578125L17.52501,11.361392578124999Q17.659959999999998,11.480282578125,17.734,11.644182578125001Q17.80804,11.808082578125,17.80804,11.987932578125001Q17.80804,12.070172578125,17.792,12.150832578125Q17.77595,12.231492578125,17.74448,12.307472578125001Q17.71301,12.383452578125,17.66732,12.451832578125Q17.62163,12.520212578125001,17.56347,12.578362578124999Q17.50532,12.636522578125,17.43694,12.682212578125Q17.36856,12.727902578125,17.29258,12.759372578125Q17.2166,12.790842578125,17.13594,12.806892578125Q17.05528,12.822932578125,16.97304,12.822932578125Q16.79319,12.822932578125,16.62929,12.748892578125Q16.46539,12.674852578125,16.3465,12.539902578125L12.88553,9.078933578125Z"), D(u, "fill-rule", "evenodd"), D(u, "fill", "#FFFFFF"), D(u, "fill-opacity", "1"), _e(u, "mix-blend-mode", "passthrough"), D(f, "d", "M4.44364390625,5.42117L2.49983690625,5.42117Q1.80948090625,5.42117,1.32132890625,5.90931Q0.83317090625,6.39747,0.83317090625,7.08783L0.83317090625,12.8496Q0.83317090625,13.54,1.32132990625,14.0281Q1.80948090625,14.5163,2.49983690625,14.5163L4.43961390625,14.5163Q6.77175390625,18.3333,9.99983390625,18.3333Q10.08191390625,18.3333,10.16241390625,18.3173Q10.24291390625,18.301299999999998,10.31874390625,18.2699Q10.39456390625,18.238500000000002,10.46281390625,18.1929Q10.53105390625,18.1473,10.58909390625,18.0893Q10.64713390625,18.0312,10.69272390625,17.963Q10.73832390625,17.8947,10.76973390625,17.8189Q10.80114390625,17.7431,10.81715390625,17.662599999999998Q10.83317390625,17.5821,10.83317390625,17.5L10.83317390625,2.5Q10.83317390625,2.4179238,10.81715390625,2.337425Q10.80114390625,2.256926,10.76973390625,2.181097Q10.73832390625,2.105269,10.69272390625,2.037025Q10.64712390625,1.968781,10.58909390625,1.910744Q10.53105390625,1.852708,10.46281390625,1.807109Q10.39456390625,1.76151,10.31874390625,1.7301009999999999Q10.24291390625,1.698691,10.16241390625,1.682679Q10.08191390625,1.666667,9.99983390625,1.666667Q6.77619390625,1.666667,4.44364390625,5.42117ZM4.91587390625,7.08783Q5.02559390625,7.08783,5.13157390625,7.05943Q5.23755390625,7.03103,5.3325739062499995,6.97617Q5.42758390625,6.92131,5.50516390625,6.84372Q5.58274390625,6.76614,5.63759390625,6.67111Q7.22859390625,3.91495,9.16650390625,3.434681L9.16650390625,16.563299999999998Q7.23188390625,16.074199999999998,5.6405439062500005,13.2715Q5.58600390625,13.1754,5.50830390625,13.0969Q5.4306139062500005,13.0184,5.33514390625,12.9628Q5.23966390625,12.9072,5.1330139062499995,12.8784Q5.02635390625,12.8496,4.91587390625,12.8496L2.49983690625,12.8496L2.49983790625,7.08783L4.91587390625,7.08783Z"), D(f, "fill-rule", "evenodd"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), _e(f, "mix-blend-mode", "passthrough"), D(i, "clip-path", "url(#master_svg0_20_113)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(d, p) {
      A0(d, e, p), R(e, t), R(t, r), R(r, a), R(e, i), R(i, l), R(l, o), R(i, s), R(s, u), R(i, c), R(c, f);
    },
    d(d) {
      d && L(e);
    }
  };
}
function yp(n) {
  let e, t, r, a, i, l, o, s, u, c, f;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("g"), l = V("g"), o = V("path"), s = V("g"), u = V("path"), c = V("g"), f = V("path"), this.h();
    },
    l(d) {
      e = H(d, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var p = O(e);
      t = H(p, "defs", {});
      var b = O(t);
      r = H(b, "clipPath", { id: !0 });
      var E = O(r);
      a = H(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), E.forEach(L), b.forEach(L), i = H(p, "g", { "clip-path": !0 });
      var k = O(i);
      l = H(k, "g", {});
      var w = O(l);
      o = H(w, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), O(o).forEach(L), w.forEach(L), s = H(k, "g", {});
      var v = O(s);
      u = H(v, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), O(u).forEach(L), v.forEach(L), c = H(k, "g", {});
      var _ = O(c);
      f = H(_, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), O(f).forEach(L), _.forEach(L), k.forEach(L), p.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_533/13_323"), D(o, "d", "M7.5,5.0016259765625Q7.58224,5.0016259765625,7.6629,4.9855819765625Q7.74356,4.9695369765625,7.81954,4.9380649765625Q7.89552,4.9065929765625,7.9639,4.8609029765625Q8.03228,4.8152129765625,8.09043,4.7570599765625Q8.14859,4.6989069765625,8.19428,4.6305269765625Q8.23997,4.5621469765625005,8.27144,4.4861669765625Q8.30291,4.4101859765625,8.318950000000001,4.3295259765625Q8.335,4.2488662765625,8.335,4.1666259765625Q8.335,4.0843856765625,8.31896,4.0037259765625Q8.30291,3.9230659765625,8.27144,3.8470849765625Q8.23997,3.7711049765625,8.19428,3.7027249765625Q8.14859,3.6343449765624998,8.09043,3.5761919765625Q8.03228,3.5180389765625,7.9639,3.4723489765625Q7.89552,3.4266589765625,7.81954,3.3951869765625Q7.74356,3.3637149765625,7.6629,3.3476699765625Q7.58224,3.3316259765625,7.5,3.3316259765625Q7.47361,3.3316259765625,7.44727,3.3332929765625L4.16667,3.3332929765625Q3.131133,3.3332929765625,2.3989,4.0655259765625Q1.666667,4.7977589765625,1.666667,5.8332959765625L1.666667,14.1666259765625Q1.666667,15.2021259765625,2.3989,15.9344259765625Q3.131133,16.6666259765625,4.16667,16.6666259765625L7.44728,16.6666259765625Q7.47361,16.6683259765625,7.5,16.6683259765625Q7.58224,16.6683259765625,7.6629,16.652225976562498Q7.74356,16.6362259765625,7.81954,16.6047259765625Q7.89552,16.573225976562497,7.9639,16.5275259765625Q8.03228,16.4819259765625,8.09043,16.4237259765625Q8.14859,16.365525976562502,8.19428,16.2972259765625Q8.23997,16.2288259765625,8.27144,16.1528259765625Q8.30291,16.0768259765625,8.318950000000001,15.9962259765625Q8.335,15.9155259765625,8.335,15.8333259765625Q8.335,15.7510259765625,8.31896,15.6704259765625Q8.30291,15.5897259765625,8.27144,15.5137259765625Q8.23997,15.4377259765625,8.19428,15.3694259765625Q8.14859,15.3010259765625,8.09043,15.2428259765625Q8.03228,15.1847259765625,7.9639,15.1390259765625Q7.89552,15.0933259765625,7.81954,15.0618259765625Q7.74356,15.0304259765625,7.6629,15.0143259765625Q7.58224,14.9983259765625,7.5,14.9983259765625Q7.47361,14.9983259765625,7.44728,14.9999259765625L4.16667,14.9999259765625Q3.82149,14.9999259765625,3.57741,14.7559259765625Q3.333333,14.5118259765625,3.333333,14.1666259765625L3.333333,5.8332959765625Q3.333333,5.4881159765625,3.57741,5.2440359765625Q3.82149,4.9999589765625,4.16667,4.9999589765625L7.44727,4.9999589765625Q7.47361,5.0016259765625,7.5,5.0016259765625Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), D(u, "d", "M12.55273,4.9999589765625Q12.5263913,5.0016259765625,12.5,5.0016259765625Q12.4177597,5.0016259765625,12.3371,4.9855819765625Q12.25644,4.9695369765625,12.180459,4.9380649765625Q12.104479,4.9065929765625,12.036099,4.8609029765625Q11.967719,4.8152129765625,11.909566,4.7570599765625Q11.851413,4.6989069765625,11.805723,4.6305269765625Q11.760033,4.5621469765625005,11.728561,4.4861669765625Q11.697089,4.4101859765625,11.681044,4.3295259765625Q11.665,4.2488662765625,11.665,4.1666259765625Q11.665,4.0843856765625,11.681044,4.0037259765625Q11.697089,3.9230659765625,11.728561,3.8470849765625Q11.760033,3.7711049765625,11.805723,3.7027249765625Q11.851413,3.6343449765624998,11.909566,3.5761919765625Q11.967719,3.5180389765625,12.036099,3.4723489765625Q12.104479,3.4266589765625,12.180459,3.3951869765625Q12.25644,3.3637149765625,12.3371,3.3476699765625Q12.4177597,3.3316259765625,12.5,3.3316259765625Q12.5263913,3.3316259765625,12.55273,3.3332929765625L15.83333,3.3332929765625Q16.86887,3.3332929765625,17.6011,4.0655259765625Q18.33333,4.7977589765625,18.33333,5.8332959765625L18.33333,14.1666259765625Q18.33333,15.2021259765625,17.6011,15.9344259765625Q16.86887,16.6666259765625,15.83333,16.6666259765625L12.5527215,16.6666259765625Q12.5263871,16.6683259765625,12.5,16.6683259765625Q12.4177597,16.6683259765625,12.3371,16.652225976562498Q12.25644,16.6362259765625,12.180459,16.6047259765625Q12.104479,16.573225976562497,12.036099,16.5275259765625Q11.967719,16.4819259765625,11.909566,16.4237259765625Q11.851413,16.365525976562502,11.805723,16.2972259765625Q11.760033,16.2288259765625,11.728561,16.1528259765625Q11.697089,16.0768259765625,11.681044,15.9962259765625Q11.665,15.9155259765625,11.665,15.8333259765625Q11.665,15.7510259765625,11.681044,15.6704259765625Q11.697089,15.5897259765625,11.728561,15.5137259765625Q11.760033,15.4377259765625,11.805723,15.3694259765625Q11.851413,15.3010259765625,11.909566,15.2428259765625Q11.967719,15.1847259765625,12.036099,15.1390259765625Q12.104479,15.0933259765625,12.180459,15.0618259765625Q12.25644,15.0304259765625,12.3371,15.0143259765625Q12.4177597,14.9983259765625,12.5,14.9983259765625Q12.5263871,14.9983259765625,12.5527215,14.9999259765625L15.83333,14.9999259765625Q16.17851,14.9999259765625,16.42259,14.7559259765625Q16.66667,14.5118259765625,16.66667,14.1666259765625L16.66667,5.8332959765625Q16.66667,5.4881159765625,16.42259,5.2440359765625Q16.17851,4.9999589765625,15.83333,4.9999589765625L12.55273,4.9999589765625Z"), D(u, "fill-rule", "evenodd"), D(u, "fill", "#FFFFFF"), D(u, "fill-opacity", "1"), D(f, "d", "M10.833333,2.5527319Q10.835,2.5263923,10.835,2.5Q10.835,2.4177597,10.818956,2.3371Q10.802911,2.25644,10.771439,2.180459Q10.739967,2.104479,10.694277,2.036099Q10.648587,1.967719,10.590434,1.9095659999999999Q10.532281,1.851413,10.463901,1.805723Q10.395521,1.760033,10.319541,1.728561Q10.24356,1.697089,10.1629,1.681044Q10.0822403,1.665,10,1.665Q9.9177597,1.665,9.8371,1.681044Q9.75644,1.697089,9.680459,1.728561Q9.604479,1.760033,9.536099,1.805723Q9.467719,1.851413,9.409566,1.9095659999999999Q9.351413,1.967719,9.305723,2.036099Q9.260033,2.104479,9.228561,2.180459Q9.197089,2.25644,9.181044,2.3371Q9.165,2.4177597,9.165,2.5Q9.165,2.5263923,9.166667,2.5527319L9.166667,17.4473Q9.165,17.473599999999998,9.165,17.5Q9.165,17.5822,9.181044,17.6629Q9.197089,17.7436,9.228561,17.819499999999998Q9.260033,17.8955,9.305723,17.963900000000002Q9.351413,18.0323,9.409566,18.090400000000002Q9.467719,18.148600000000002,9.536099,18.1943Q9.604479,18.240000000000002,9.680459,18.2714Q9.75644,18.3029,9.8371,18.319000000000003Q9.9177597,18.335,10,18.335Q10.0822403,18.335,10.1629,18.319000000000003Q10.24356,18.3029,10.319541,18.2714Q10.395521,18.240000000000002,10.463901,18.1943Q10.532281,18.148600000000002,10.590434,18.090400000000002Q10.648587,18.0323,10.694277,17.963900000000002Q10.739967,17.8955,10.771439,17.819499999999998Q10.802911,17.7436,10.818956,17.6629Q10.835,17.5822,10.835,17.5Q10.835,17.473599999999998,10.833333,17.4473L10.833333,2.5527319Z"), D(f, "fill-rule", "evenodd"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), D(i, "clip-path", "url(#master_svg0_13_533/13_323)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(d, p) {
      A0(d, e, p), R(e, t), R(t, r), R(r, a), R(e, i), R(i, l), R(l, o), R(i, s), R(s, u), R(i, c), R(c, f);
    },
    d(d) {
      d && L(e);
    }
  };
}
function kp(n) {
  let e, t, r, a, i, l, o;
  return {
    c() {
      e = V("svg"), t = V("defs"), r = V("clipPath"), a = V("rect"), i = V("g"), l = V("g"), o = V("path"), this.h();
    },
    l(s) {
      e = H(s, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var u = O(e);
      t = H(u, "defs", {});
      var c = O(t);
      r = H(c, "clipPath", { id: !0 });
      var f = O(r);
      a = H(f, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), O(a).forEach(L), f.forEach(L), c.forEach(L), i = H(u, "g", { "clip-path": !0 });
      var d = O(i);
      l = H(d, "g", {});
      var p = O(l);
      o = H(p, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), O(o).forEach(L), p.forEach(L), d.forEach(L), u.forEach(L), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_323"), D(o, "d", "M16.66650390625,5.0000440234375L16.66650390625,9.1667040234375C16.66650390625,9.626944023437499,17.03960390625,10.0000440234375,17.49980390625,10.0000440234375C17.96010390625,10.0000440234375,18.33320390625,9.626944023437499,18.33320390625,9.1667040234375L18.33320390625,5.0000440234375Q18.33300390625,4.3097080234375,17.84490390625,3.8215540234375Q17.35690390625,3.3333740234375,16.66650390625,3.3333740234375L3.33317390625,3.3333740234375Q2.64293990625,3.3333981633375,2.15478490625,3.8215540234375Q1.66650390625,4.3096850234375,1.66650390625,5.0000440234375L1.66650390625,15.0000740234375Q1.66662937425,15.6903740234375,2.15478490625,16.1785740234375Q2.64281490625,16.6666740234375,3.33317390625,16.6666740234375L9.99983390625,16.6666740234375C10.22085390625,16.6666740234375,10.43281390625,16.5788740234375,10.58909390625,16.4226740234375C10.74537390625,16.2663740234375,10.83317390625,16.0543740234375,10.83317390625,15.8333740234375C10.83317390625,15.3731740234375,10.46007390625,15.0000740234375,9.99983390625,15.0000740234375L3.33317390625,15.0000740234375L3.33317390625,5.0000440234375L16.66650390625,5.0000440234375ZM11.66650390625,12.5000440234375L11.66650390625,15.0000740234375Q11.66650390625,15.0818740234375,11.67450390625,15.1633740234375Q11.68260390625,15.2448740234375,11.69850390625,15.3251740234375Q11.71450390625,15.4054740234375,11.73830390625,15.4838740234375Q11.76200390625,15.5621740234375,11.79340390625,15.6378740234375Q11.82470390625,15.7134740234375,11.86330390625,15.7856740234375Q11.90190390625,15.8578740234375,11.94740390625,15.9259740234375Q11.99290390625,15.9940740234375,12.04480390625,16.0573740234375Q12.09680390625,16.120674023437502,12.15470390625,16.1785740234375Q12.21260390625,16.236474023437502,12.27580390625,16.2883740234375Q12.33910390625,16.340374023437498,12.40720390625,16.3857740234375Q12.47530390625,16.4312740234375,12.54750390625,16.469874023437498Q12.61970390625,16.5084740234375,12.69540390625,16.5398740234375Q12.77100390625,16.5711740234375,12.84940390625,16.5949740234375Q12.92770390625,16.6186740234375,13.00800390625,16.634674023437498Q13.08830390625,16.6506740234375,13.16980390625,16.6586740234375Q13.25130390625,16.6666740234375,13.33320390625,16.6666740234375L17.49980390625,16.6666740234375Q17.58170390625,16.6666740234375,17.66320390625,16.6586740234375Q17.74470390625,16.6506740234375,17.82500390625,16.634674023437498Q17.90530390625,16.6186740234375,17.98360390625,16.5949740234375Q18.06200390625,16.5711740234375,18.13760390625,16.5398740234375Q18.21330390625,16.5084740234375,18.28550390625,16.469874023437498Q18.35770390625,16.4312740234375,18.42580390625,16.3857740234375Q18.49390390625,16.340374023437498,18.55720390625,16.2883740234375Q18.62040390625,16.236474023437502,18.67830390625,16.1785740234375Q18.73620390625,16.120674023437502,18.78820390625,16.0573740234375Q18.84010390625,15.9940740234375,18.88560390625,15.9259740234375Q18.93110390625,15.8578740234375,18.96970390625,15.7856740234375Q19.00830390625,15.7134740234375,19.03960390625,15.6378740234375Q19.07100390625,15.5621740234375,19.09470390625,15.4838740234375Q19.11850390625,15.4054740234375,19.13450390625,15.3251740234375Q19.15040390625,15.2448740234375,19.15850390625,15.1633740234375Q19.16650390625,15.0818740234375,19.16650390625,15.0000740234375L19.16650390625,12.5000440234375Q19.16650390625,12.4181640234375,19.15850390625,12.3366840234375Q19.15040390625,12.2551940234375,19.13450390625,12.1748940234375Q19.11850390625,12.0945840234375,19.09470390625,12.0162340234375Q19.07100390625,11.9378840234375,19.03960390625,11.8622340234375Q19.00830390625,11.7865840234375,18.96970390625,11.7143840234375Q18.93110390625,11.6421640234375,18.88560390625,11.5740940234375Q18.84010390625,11.5060140234375,18.78820390625,11.4427140234375Q18.73620390625,11.3794240234375,18.67830390625,11.3215340234375Q18.62040390625,11.2636340234375,18.55720390625,11.2116940234375Q18.49390390625,11.1597440234375,18.42580390625,11.1142540234375Q18.35770390625,11.068764023437499,18.28550390625,11.0301740234375Q18.21330390625,10.9915740234375,18.13760390625,10.9602440234375Q18.06200390625,10.9289040234375,17.98360390625,10.9051440234375Q17.90530390625,10.8813740234375,17.82500390625,10.8653940234375Q17.74470390625,10.8494240234375,17.66320390625,10.8414040234375Q17.58170390625,10.8333740234375,17.49980390625,10.8333740234375L13.33320390625,10.8333740234375Q13.25130390625,10.8333740234375,13.16980390625,10.8414040234375Q13.08830390625,10.8494240234375,13.00800390625,10.8653940234375Q12.92770390625,10.8813740234375,12.84940390625,10.9051440234375Q12.77100390625,10.9289040234375,12.69540390625,10.9602440234375Q12.61970390625,10.9915740234375,12.54750390625,11.0301740234375Q12.47530390625,11.068764023437499,12.40720390625,11.1142540234375Q12.33910390625,11.1597440234375,12.27580390625,11.2116940234375Q12.21260390625,11.2636340234375,12.15470390625,11.3215340234375Q12.09680390625,11.3794240234375,12.04480390625,11.4427140234375Q11.99290390625,11.5060140234375,11.94740390625,11.5740940234375Q11.90190390625,11.6421640234375,11.86330390625,11.7143840234375Q11.82470390625,11.7865940234375,11.79340390625,11.8622340234375Q11.76200390625,11.9378840234375,11.73830390625,12.0162340234375Q11.71450390625,12.0945840234375,11.69850390625,12.1748940234375Q11.68260390625,12.2551940234375,11.67450390625,12.3366840234375Q11.66650390625,12.4181640234375,11.66650390625,12.5000440234375Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), D(i, "clip-path", "url(#master_svg0_13_323)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(s, u) {
      A0(s, e, u), R(e, t), R(t, r), R(r, a), R(e, i), R(i, l), R(l, o);
    },
    d(s) {
      s && L(e);
    }
  };
}
function Dp(n) {
  let e;
  return {
    c() {
      e = Ye("div"), this.h();
    },
    l(t) {
      e = Ze(t, "DIV", { class: !0 }), O(e).forEach(L), this.h();
    },
    h() {
      D(e, "class", "stop-chat-inner svelte-g68djp");
    },
    m(t, r) {
      A0(t, e, r);
    },
    i: gn,
    o: gn,
    d(t) {
      t && L(e);
    }
  };
}
function Ep(n) {
  let e, t, r, a, i, l = "等待中", o;
  return r = new r5({}), {
    c() {
      e = Ye("div"), t = Ye("div"), q5(r.$$.fragment), a = q0(), i = Ye("span"), i.textContent = l, this.h();
    },
    l(s) {
      e = Ze(s, "DIV", { class: !0 });
      var u = O(e);
      t = Ze(u, "DIV", { class: !0, title: !0 });
      var c = O(t);
      O5(r.$$.fragment, c), c.forEach(L), a = O0(u), i = Ze(u, "SPAN", { "data-svelte-h": !0 }), Vn(i) !== "svelte-anmp8h" && (i.textContent = l), u.forEach(L), this.h();
    },
    h() {
      D(t, "class", "icon svelte-g68djp"), D(t, "title", "spinner"), D(e, "class", "waiting-icon-text svelte-g68djp");
    },
    m(s, u) {
      A0(s, e, u), R(e, t), H5(r, t, null), R(e, a), R(e, i), o = !0;
    },
    i(s) {
      o || (It(r.$$.fragment, s), o = !0);
    },
    o(s) {
      _r(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && L(e), P5(r);
    }
  };
}
function Ap(n) {
  let e, t = "点击开始对话";
  return {
    c() {
      e = Ye("span"), e.textContent = t;
    },
    l(r) {
      e = Ze(r, "SPAN", { "data-svelte-h": !0 }), Vn(e) !== "svelte-12otyi9" && (e.textContent = t);
    },
    m(r, a) {
      A0(r, e, a);
    },
    i: gn,
    o: gn,
    d(r) {
      r && L(e);
    }
  };
}
function T6(n) {
  let e, t, r;
  return t = new R5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        n[28]
      ),
      stream_state: (
        /*stream_state*/
        n[7]
      ),
      wave_color: (
        /*wave_color*/
        n[1]
      )
    }
  }), {
    c() {
      e = Ye("div"), q5(t.$$.fragment), this.h();
    },
    l(a) {
      e = Ze(a, "DIV", { class: !0 });
      var i = O(e);
      O5(t.$$.fragment, i), i.forEach(L), this.h();
    },
    h() {
      D(e, "class", "input-audio-wave svelte-g68djp");
    },
    m(a, i) {
      A0(a, e, i), H5(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      128 && (l.stream_state = /*stream_state*/
      a[7]), i[0] & /*wave_color*/
      2 && (l.wave_color = /*wave_color*/
      a[1]), t.$set(l);
    },
    i(a) {
      r || (It(t.$$.fragment, a), r = !0);
    },
    o(a) {
      _r(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && L(e), P5(t);
    }
  };
}
function Fp(n) {
  let e, t, r, a, i, l, o, s, u, c, f, d, p, b, E, k, w, v, _, A, x, Q, z, P, B, N, j, $, W, se, ke, Fe, xe, he, Ee, ie, ce, ve, oe = !/*webcam_accessed*/
  n[11] && D6(n);
  function me(C, X) {
    return (
      /*cameraOff*/
      C[10] ? gp : pp
    );
  }
  let U = me(n), He = U(n), ne = (
    /*stream_state*/
    n[7] === "closed" && E6(n)
  ), fe = Ea(
    /*available_video_devices*/
    n[3]
  ), Z = [];
  for (let C = 0; C < fe.length; C += 1)
    Z[C] = F6(k6(n, fe, C));
  function Qe(C, X) {
    return (
      /*micMuted*/
      C[9] ? vp : _p
    );
  }
  let Le = Qe(n), Ne = Le(n), Ie = (
    /*stream_state*/
    n[7] === "closed" && S6(n)
  ), Ve = Ea(
    /*available_audio_devices*/
    n[4]
  ), Ce = [];
  for (let C = 0; C < Ve.length; C += 1)
    Ce[C] = C6(y6(n, Ve, C));
  function b0(C, X) {
    return (
      /*volumeMuted*/
      C[8] ? wp : bp
    );
  }
  let K = b0(n), qe = K(n);
  function Pe(C, X) {
    return (
      /*videoShowType*/
      C[13] === "picture-in-picture" ? kp : yp
    );
  }
  let e0 = Pe(n), Re = e0(n);
  const B0 = [Ap, Ep, Dp], h0 = [];
  function C0(C, X) {
    return (
      /*stream_state*/
      C[7] === "closed" ? 0 : (
        /*stream_state*/
        C[7] === "waiting" ? 1 : 2
      )
    );
  }
  xe = C0(n), he = h0[xe] = B0[xe](n);
  let Ue = (
    /*stream_state*/
    n[7] === "open" && T6(n)
  );
  return {
    c() {
      e = Ye("div"), oe && oe.c(), t = q0(), r = Ye("div"), a = Ye("div"), i = Ye("video"), l = q0(), o = Ye("div"), s = Ye("video"), u = q0(), c = Ye("div"), f = Ye("div"), d = Ye("div"), He.c(), p = q0(), ne && ne.c(), b = q0(), E = Ye("div");
      for (let C = 0; C < Z.length; C += 1)
        Z[C].c();
      v = q0(), _ = Ye("div"), Ne.c(), A = q0(), Ie && Ie.c(), x = q0(), Q = Ye("div");
      for (let C = 0; C < Ce.length; C += 1)
        Ce[C].c();
      B = q0(), N = Ye("div"), qe.c(), j = q0(), $ = Ye("div"), W = Ye("div"), Re.c(), se = q0(), ke = Ye("div"), Fe = Ye("div"), he.c(), Ee = q0(), Ue && Ue.c(), this.h();
    },
    l(C) {
      e = Ze(C, "DIV", { class: !0 });
      var X = O(e);
      oe && oe.l(X), t = O0(X), r = Ze(X, "DIV", { class: !0 });
      var Me = O(r);
      a = Ze(Me, "DIV", { class: !0 });
      var Ae = O(a);
      i = Ze(Ae, "VIDEO", { class: !0 }), O(i).forEach(L), Ae.forEach(L), l = O0(Me), o = Ze(Me, "DIV", { class: !0 });
      var We = O(o);
      s = Ze(We, "VIDEO", { class: !0 }), O(s).forEach(L), We.forEach(L), u = O0(Me), c = Ze(Me, "DIV", { class: !0 });
      var o0 = O(c);
      f = Ze(o0, "DIV", { class: !0 });
      var q = O(f);
      d = Ze(q, "DIV", { class: !0 });
      var ut = O(d);
      He.l(ut), p = O0(ut), ne && ne.l(ut), b = O0(ut), E = Ze(ut, "DIV", { class: !0 });
      var nt = O(E);
      for (let i0 = 0; i0 < Z.length; i0 += 1)
        Z[i0].l(nt);
      nt.forEach(L), ut.forEach(L), v = O0(q), _ = Ze(q, "DIV", { class: !0 });
      var z0 = O(_);
      Ne.l(z0), A = O0(z0), Ie && Ie.l(z0), x = O0(z0), Q = Ze(z0, "DIV", { class: !0 });
      var at = O(Q);
      for (let i0 = 0; i0 < Ce.length; i0 += 1)
        Ce[i0].l(at);
      at.forEach(L), z0.forEach(L), B = O0(q), N = Ze(q, "DIV", { class: !0 });
      var Xt = O(N);
      qe.l(Xt), Xt.forEach(L), q.forEach(L), j = O0(o0), $ = Ze(o0, "DIV", { class: !0 });
      var H1 = O($);
      W = Ze(H1, "DIV", { class: !0 });
      var Br = O(W);
      Re.l(Br), Br.forEach(L), H1.forEach(L), o0.forEach(L), Me.forEach(L), se = O0(X), ke = Ze(X, "DIV", { class: !0 });
      var Dn = O(ke);
      Fe = Ze(Dn, "DIV", { class: !0 });
      var V1 = O(Fe);
      he.l(V1), V1.forEach(L), Ee = O0(Dn), Ue && Ue.l(Dn), Dn.forEach(L), X.forEach(L), this.h();
    },
    h() {
      D(i, "class", "local-video svelte-g68djp"), i.autoplay = !0, i.muted = !0, i.playsInline = !0, D(a, "class", "local-video-container svelte-g68djp"), _e(
        a,
        "left",
        /*localVideoPosition*/
        n[16].width < 10 ? "50%" : (
          /*localVideoPosition*/
          n[16].left + "px"
        )
      ), _e(
        a,
        "top",
        /*localVideoPosition*/
        n[16].height < 10 ? "50%" : (
          /*localVideoPosition*/
          n[16].top + "px"
        )
      ), _e(
        a,
        "width",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*localVideoPosition*/
          n[16].width + "px"
        ) : ""
      ), _e(
        a,
        "height",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*localVideoPosition*/
          n[16].height + "px"
        ) : ""
      ), D(s, "class", "remote-video svelte-g68djp"), s.autoplay = !0, s.playsInline = !0, s.muted = /*volumeMuted*/
      n[8], D(o, "class", "remote-video-container svelte-g68djp"), _e(
        o,
        "left",
        /*remoteVideoPosition*/
        n[19].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          n[19].left + "px"
        )
      ), _e(
        o,
        "top",
        /*remoteVideoPosition*/
        n[19].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          n[19].top + "px"
        )
      ), _e(
        o,
        "width",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          n[19].width + "px"
        ) : ""
      ), _e(
        o,
        "height",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          n[19].height + "px"
        ) : ""
      ), D(E, "class", k = Aa(`selectors ${/*actionsPosition*/
      n[20].isOverflow || /*videoShowType*/
      n[13] === "side-by-side" ? "left" : ""}`) + " svelte-g68djp"), _e(
        E,
        "display",
        /*cameraListShow*/
        n[22] && /*stream_state*/
        n[7] === "closed" ? "block" : "none"
      ), D(d, "class", "action svelte-g68djp"), D(Q, "class", z = Aa(`selectors ${/*actionsPosition*/
      n[20].isOverflow || /*videoShowType*/
      n[13] === "side-by-side" ? "left" : ""}`) + " svelte-g68djp"), _e(
        Q,
        "display",
        /*micListShow*/
        n[21] && /*stream_state*/
        n[7] === "closed" ? "block" : "none"
      ), D(_, "class", "action svelte-g68djp"), D(N, "class", "action svelte-g68djp"), D(f, "class", "action-group svelte-g68djp"), D(W, "class", "action svelte-g68djp"), D($, "class", "action-group svelte-g68djp"), D(c, "class", "actions svelte-g68djp"), _e(
        c,
        "left",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*actionsPosition*/
          n[20].left + "px"
        ) : ""
      ), _e(
        c,
        "bottom",
        /*videoShowType*/
        n[13] === "picture-in-picture" ? (
          /*actionsPosition*/
          n[20].bottom + "px"
        ) : ""
      ), D(r, "class", "video-container svelte-g68djp"), Vr(
        r,
        "picture-in-picture",
        /*videoShowType*/
        n[13] === "picture-in-picture"
      ), Vr(
        r,
        "side-by-side",
        /*videoShowType*/
        n[13] === "side-by-side"
      ), _e(
        r,
        "visibility",
        /*webcam_accessed*/
        n[11] ? "visible" : "hidden"
      ), D(Fe, "class", "chat-btn svelte-g68djp"), Vr(
        Fe,
        "start-chat",
        /*stream_state*/
        n[7] === "closed"
      ), Vr(
        Fe,
        "stop-chat",
        /*stream_state*/
        n[7] === "open"
      ), D(ke, "class", "player-controls svelte-g68djp"), D(e, "class", "wrap svelte-g68djp"), _e(
        e,
        "height",
        /*height*/
        n[0] > 100 ? "100%" : "90vh"
      );
    },
    m(C, X) {
      A0(C, e, X), oe && oe.m(e, null), R(e, t), R(e, r), R(r, a), R(a, i), n[46](i), n[47](a), R(r, l), R(r, o), R(o, s), n[48](s), n[49](o), R(r, u), R(r, c), R(c, f), R(f, d), He.m(d, null), R(d, p), ne && ne.m(d, null), R(d, b), R(d, E);
      for (let Me = 0; Me < Z.length; Me += 1)
        Z[Me] && Z[Me].m(E, null);
      R(f, v), R(f, _), Ne.m(_, null), R(_, A), Ie && Ie.m(_, null), R(_, x), R(_, Q);
      for (let Me = 0; Me < Ce.length; Me += 1)
        Ce[Me] && Ce[Me].m(Q, null);
      R(f, B), R(f, N), qe.m(N, null), R(c, j), R(c, $), R($, W), Re.m(W, null), n[54](r), R(e, se), R(e, ke), R(ke, Fe), h0[xe].m(Fe, null), R(ke, Ee), Ue && Ue.m(ke, null), ie = !0, ce || (ve = [
        Ot(
          i,
          "playing",
          /*computeLocalPosition*/
          n[31]
        ),
        Ot(
          s,
          "playing",
          /*computeRemotePosition*/
          n[32]
        ),
        Ot(
          d,
          "click",
          /*handle_camera_off*/
          n[25]
        ),
        v6(w = $a.call(
          null,
          d,
          /*click_outside_function*/
          n[51]
        )),
        Ot(
          _,
          "click",
          /*handle_mic_mute*/
          n[24]
        ),
        v6(P = $a.call(
          null,
          _,
          /*click_outside_function_1*/
          n[53]
        )),
        Ot(
          N,
          "click",
          /*handle_volume_mute*/
          n[23]
        ),
        Ot(
          W,
          "click",
          /*changeVideoShowType*/
          n[30]
        ),
        Ot(
          Fe,
          "click",
          /*start_webrtc*/
          n[29]
        )
      ], ce = !0);
    },
    p(C, X) {
      if (/*webcam_accessed*/
      C[11] ? oe && (Cl(), _r(oe, 1, 1, () => {
        oe = null;
      }), xl()) : oe ? (oe.p(C, X), X[0] & /*webcam_accessed*/
      2048 && It(oe, 1)) : (oe = D6(C), oe.c(), It(oe, 1), oe.m(e, t)), X[0] & /*localVideoPosition*/
      65536 && _e(
        a,
        "left",
        /*localVideoPosition*/
        C[16].width < 10 ? "50%" : (
          /*localVideoPosition*/
          C[16].left + "px"
        )
      ), X[0] & /*localVideoPosition*/
      65536 && _e(
        a,
        "top",
        /*localVideoPosition*/
        C[16].height < 10 ? "50%" : (
          /*localVideoPosition*/
          C[16].top + "px"
        )
      ), X[0] & /*videoShowType, localVideoPosition*/
      73728 && _e(
        a,
        "width",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*localVideoPosition*/
          C[16].width + "px"
        ) : ""
      ), X[0] & /*videoShowType, localVideoPosition*/
      73728 && _e(
        a,
        "height",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*localVideoPosition*/
          C[16].height + "px"
        ) : ""
      ), (!ie || X[0] & /*volumeMuted*/
      256) && (s.muted = /*volumeMuted*/
      C[8]), X[0] & /*remoteVideoPosition*/
      524288 && _e(
        o,
        "left",
        /*remoteVideoPosition*/
        C[19].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          C[19].left + "px"
        )
      ), X[0] & /*remoteVideoPosition*/
      524288 && _e(
        o,
        "top",
        /*remoteVideoPosition*/
        C[19].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          C[19].top + "px"
        )
      ), X[0] & /*videoShowType, remoteVideoPosition*/
      532480 && _e(
        o,
        "width",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          C[19].width + "px"
        ) : ""
      ), X[0] & /*videoShowType, remoteVideoPosition*/
      532480 && _e(
        o,
        "height",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          C[19].height + "px"
        ) : ""
      ), U !== (U = me(C)) && (He.d(1), He = U(C), He && (He.c(), He.m(d, p))), /*stream_state*/
      C[7] === "closed" ? ne ? ne.p(C, X) : (ne = E6(C), ne.c(), ne.m(d, b)) : ne && (ne.d(1), ne = null), X[0] & /*handle_device_change, available_video_devices, selected_video_device*/
      67108904) {
        fe = Ea(
          /*available_video_devices*/
          C[3]
        );
        let Ae;
        for (Ae = 0; Ae < fe.length; Ae += 1) {
          const We = k6(C, fe, Ae);
          Z[Ae] ? Z[Ae].p(We, X) : (Z[Ae] = F6(We), Z[Ae].c(), Z[Ae].m(E, null));
        }
        for (; Ae < Z.length; Ae += 1)
          Z[Ae].d(1);
        Z.length = fe.length;
      }
      if ((!ie || X[0] & /*actionsPosition, videoShowType*/
      1056768 && k !== (k = Aa(`selectors ${/*actionsPosition*/
      C[20].isOverflow || /*videoShowType*/
      C[13] === "side-by-side" ? "left" : ""}`) + " svelte-g68djp")) && D(E, "class", k), X[0] & /*cameraListShow, stream_state*/
      4194432 && _e(
        E,
        "display",
        /*cameraListShow*/
        C[22] && /*stream_state*/
        C[7] === "closed" ? "block" : "none"
      ), w && w6(w.update) && X[0] & /*cameraListShow*/
      4194304 && w.update.call(
        null,
        /*click_outside_function*/
        C[51]
      ), Le !== (Le = Qe(C)) && (Ne.d(1), Ne = Le(C), Ne && (Ne.c(), Ne.m(_, A))), /*stream_state*/
      C[7] === "closed" ? Ie ? Ie.p(C, X) : (Ie = S6(C), Ie.c(), Ie.m(_, x)) : Ie && (Ie.d(1), Ie = null), X[0] & /*handle_device_change, available_audio_devices, selected_audio_device*/
      67108944) {
        Ve = Ea(
          /*available_audio_devices*/
          C[4]
        );
        let Ae;
        for (Ae = 0; Ae < Ve.length; Ae += 1) {
          const We = y6(C, Ve, Ae);
          Ce[Ae] ? Ce[Ae].p(We, X) : (Ce[Ae] = C6(We), Ce[Ae].c(), Ce[Ae].m(Q, null));
        }
        for (; Ae < Ce.length; Ae += 1)
          Ce[Ae].d(1);
        Ce.length = Ve.length;
      }
      (!ie || X[0] & /*actionsPosition, videoShowType*/
      1056768 && z !== (z = Aa(`selectors ${/*actionsPosition*/
      C[20].isOverflow || /*videoShowType*/
      C[13] === "side-by-side" ? "left" : ""}`) + " svelte-g68djp")) && D(Q, "class", z), X[0] & /*micListShow, stream_state*/
      2097280 && _e(
        Q,
        "display",
        /*micListShow*/
        C[21] && /*stream_state*/
        C[7] === "closed" ? "block" : "none"
      ), P && w6(P.update) && X[0] & /*micListShow*/
      2097152 && P.update.call(
        null,
        /*click_outside_function_1*/
        C[53]
      ), K !== (K = b0(C)) && (qe.d(1), qe = K(C), qe && (qe.c(), qe.m(N, null))), e0 !== (e0 = Pe(C)) && (Re.d(1), Re = e0(C), Re && (Re.c(), Re.m(W, null))), X[0] & /*videoShowType, actionsPosition*/
      1056768 && _e(
        c,
        "left",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*actionsPosition*/
          C[20].left + "px"
        ) : ""
      ), X[0] & /*videoShowType, actionsPosition*/
      1056768 && _e(
        c,
        "bottom",
        /*videoShowType*/
        C[13] === "picture-in-picture" ? (
          /*actionsPosition*/
          C[20].bottom + "px"
        ) : ""
      ), (!ie || X[0] & /*videoShowType*/
      8192) && Vr(
        r,
        "picture-in-picture",
        /*videoShowType*/
        C[13] === "picture-in-picture"
      ), (!ie || X[0] & /*videoShowType*/
      8192) && Vr(
        r,
        "side-by-side",
        /*videoShowType*/
        C[13] === "side-by-side"
      ), X[0] & /*webcam_accessed*/
      2048 && _e(
        r,
        "visibility",
        /*webcam_accessed*/
        C[11] ? "visible" : "hidden"
      );
      let Me = xe;
      xe = C0(C), xe !== Me && (Cl(), _r(h0[Me], 1, 1, () => {
        h0[Me] = null;
      }), xl(), he = h0[xe], he || (he = h0[xe] = B0[xe](C), he.c()), It(he, 1), he.m(Fe, null)), (!ie || X[0] & /*stream_state*/
      128) && Vr(
        Fe,
        "start-chat",
        /*stream_state*/
        C[7] === "closed"
      ), (!ie || X[0] & /*stream_state*/
      128) && Vr(
        Fe,
        "stop-chat",
        /*stream_state*/
        C[7] === "open"
      ), /*stream_state*/
      C[7] === "open" ? Ue ? (Ue.p(C, X), X[0] & /*stream_state*/
      128 && It(Ue, 1)) : (Ue = T6(C), Ue.c(), It(Ue, 1), Ue.m(ke, null)) : Ue && (Cl(), _r(Ue, 1, 1, () => {
        Ue = null;
      }), xl()), X[0] & /*height*/
      1 && _e(
        e,
        "height",
        /*height*/
        C[0] > 100 ? "100%" : "90vh"
      );
    },
    i(C) {
      ie || (It(oe), It(he), It(Ue), ie = !0);
    },
    o(C) {
      _r(oe), _r(he), _r(Ue), ie = !1;
    },
    d(C) {
      C && L(e), oe && oe.d(), n[46](null), n[47](null), n[48](null), n[49](null), He.d(), ne && ne.d(), b6(Z, C), Ne.d(), Ie && Ie.d(), b6(Ce, C), qe.d(), Re.d(), n[54](null), h0[xe].d(), Ue && Ue.d(), ce = !1, hp(ve);
    }
  };
}
function $a(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function Sp(n, e, t) {
  var r = this && this.__awaiter || function(C, X, Me, Ae) {
    function We(o0) {
      return o0 instanceof Me ? o0 : new Me(function(q) {
        q(o0);
      });
    }
    return new (Me || (Me = Promise))(function(o0, q) {
      function ut(at) {
        try {
          z0(Ae.next(at));
        } catch (Xt) {
          q(Xt);
        }
      }
      function nt(at) {
        try {
          z0(Ae.throw(at));
        } catch (Xt) {
          q(Xt);
        }
      }
      function z0(at) {
        at.done ? o0(at.value) : We(at.value).then(ut, nt);
      }
      z0((Ae = Ae.apply(C, X || [])).next());
    });
  };
  let a = [], i = [], l = null, o = null, s = "closed", { on_change_cb: u } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: c = {} } = e, { button_labels: f } = e, { height: d } = e;
  const p = (C) => {
    C === "closed" ? t(7, s = "closed") : C === "waiting" ? t(7, s = "waiting") : t(7, s = "open");
  };
  let { track_constraints: b = null } = e, { rtc_configuration: E } = e, { stream_every: k = 1 } = e, { server: w } = e, { i18n: v } = e, _ = !1, A = !1, x = !1;
  const Q = () => {
    t(8, _ = !_);
  }, z = () => {
    t(9, A = !A), $.getTracks().forEach((C) => {
      C.kind.includes("audio") && (C.enabled = !A);
    });
  }, P = () => {
    t(10, x = !x), $.getTracks().forEach((C) => {
      C.kind.includes("video") && (C.enabled = !x);
    });
  }, B = dp(), N = (C) => r(void 0, void 0, void 0, function* () {
    const X = C;
    console.log(C, o, l);
    let Me = l ? l.deviceId : "", Ae = o ? o.deviceId : "";
    i.find((o0) => o0.deviceId === X) ? (Ae = X, t(21, Ne = !1), t(9, A = !1)) : a.find((o0) => o0.deviceId === X) && (Me = X, t(22, Ie = !1), t(10, x = !1)), yield ja(
      Ae ? { deviceId: { exact: Ae } } : !0,
      ve,
      Me,
      b
    ).then((o0) => r(void 0, void 0, void 0, function* () {
      $ = o0, o0 = o0, t(5, l = a.find((q) => q.deviceId === Me) || null), t(6, o = i.find((q) => q.deviceId === Ae) || null);
    }));
  });
  function j() {
    return r(this, void 0, void 0, function* () {
      try {
        const C = ve;
        t(9, A = !1), t(10, x = !1), t(8, _ = !1), ja(!0, C, null, b).then((X) => r(this, void 0, void 0, function* () {
          t(11, W = !0);
          let Me = yield T5();
          return $ = X, X = X, Me;
        })).then((X) => {
          t(3, a = S1(X, "videoinput")), t(4, i = S1(X, "audioinput")), console.log(a), console.log(i), $.getTracks().map((Ae) => {
            var We;
            return (We = Ae.getSettings()) === null || We === void 0 ? void 0 : We.deviceId;
          }).forEach((Ae) => {
            const We = X.find((o0) => o0.deviceId === Ae);
            We && (We != null && We.kind.includes("video")) ? t(5, l = We) : We && (We != null && We.kind.includes("audio")) && t(6, o = We);
          }), !l && t(5, l = a[0]);
        }).catch(() => {
          alert(v("image.no_webcam_support"));
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && (B("error", v("image.no_webcam_support")), alert(v("image.no_webcam_support")));
      } catch (C) {
        if (C instanceof DOMException && C.name == "NotAllowedError")
          B("error", v("image.allow_webcam_access"));
        else
          throw C;
      }
    });
  }
  let $, W = !1, se, { webrtc_id: ke } = e, { wave_color: Fe = "#7873F6" } = e;
  const xe = () => ve.srcObject;
  function he() {
    return r(this, void 0, void 0, function* () {
      if (s === "closed")
        se = new RTCPeerConnection(E), se.addEventListener("connectionstatechange", (C) => r(this, void 0, void 0, function* () {
          switch (se.connectionState) {
            case "connected":
              t(7, s = "open");
              break;
            case "disconnected":
              t(7, s = "closed"), Kr(se), yield j();
              break;
          }
        })), t(7, s = "waiting"), t(35, ke = Math.random().toString(36).substring(2)), B1($, se, U, w.offer, ke, "video", u, c).then((C) => {
          se = C, Le();
        }).catch(() => {
          console.info("catching"), t(7, s = "closed"), B("error", "Too many concurrent users. Come back later!");
        });
      else {
        if (s === "waiting")
          return;
        t(19, ne.init = !1, ne), Qe(), Kr(se), t(7, s = "closed"), yield j();
      }
    });
  }
  let Ee;
  const ie = { width: 0, height: 0 };
  let ce = "picture-in-picture", ve, oe, me = {
    left: 10,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, U, He, ne = {
    left: 0,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, fe = {
    left: 0,
    bottom: 0,
    init: !1,
    isOverflow: !1
  };
  mp(() => {
    Ee.getBoundingClientRect(), ie.width = Ee.clientWidth, ie.height = Ee.clientHeight, console.log(ie);
  });
  function Z() {
    ce === "picture-in-picture" ? t(13, ce = "side-by-side") : ce === "side-by-side" && t(13, ce = "picture-in-picture");
  }
  function Qe() {
    if (!(!ve || !oe || !ve.videoHeight))
      if (ne.init) {
        let C = ne.height / 4, X = C / ve.videoHeight * ve.videoWidth;
        t(16, me.left = ne.left + 14, me), t(16, me.top = ne.top + ne.height - C - 14, me), t(16, me.width = X, me), t(16, me.height = C, me), t(20, fe.left = ne.left + ne.width + 10, fe), t(
          20,
          fe.left = fe.left > ie.width ? fe.left - 60 : fe.left,
          fe
        ), t(20, fe.bottom = ie.height - ne.top - ne.height + 5, fe), t(20, fe.isOverflow = fe.left + 300 > ie.width, fe);
      } else {
        let C = ie.height - 24, X = C / ve.videoHeight * ve.videoWidth;
        X > ie.width && (X = ie.width), t(16, me.left = (ie.width - X) / 2, me), t(16, me.top = ie.height - C, me), t(16, me.width = X, me), t(16, me.height = C, me), t(20, fe.left = me.left + me.width + 10, fe), t(
          20,
          fe.left = fe.left > ie.width ? fe.left - 60 : fe.left,
          fe
        ), t(20, fe.bottom = ie.height - me.top - me.height + 5, fe), t(20, fe.isOverflow = fe.left + 300 > ie.width, fe);
      }
  }
  function Le() {
    if (!U.srcObject || !U.videoHeight) return;
    console.log(U.videoHeight, U.videoWidth);
    let C = ie.height - 24, X = C / U.videoHeight * U.videoWidth;
    X > ie.width && (X = ie.width), t(19, ne.left = (ie.width - X) / 2, ne), t(19, ne.top = ie.height - C, ne), t(19, ne.width = X, ne), t(19, ne.height = C, ne), t(19, ne.init = !0, ne), Qe();
  }
  let Ne = !1, Ie = !1;
  function Ve(C) {
    t(21, Ne = !0), C.preventDefault(), C.stopPropagation();
  }
  function Ce(C) {
    t(22, Ie = !0), C.preventDefault(), C.stopPropagation();
  }
  window.addEventListener("resize", () => {
    Ee.getBoundingClientRect(), ie.width = Ee.clientWidth, ie.height = Ee.clientHeight, Qe(), Le();
  });
  const b0 = async () => j();
  function K(C) {
    o1[C ? "unshift" : "push"](() => {
      ve = C, t(14, ve);
    });
  }
  function qe(C) {
    o1[C ? "unshift" : "push"](() => {
      oe = C, t(15, oe);
    });
  }
  function Pe(C) {
    o1[C ? "unshift" : "push"](() => {
      U = C, t(17, U);
    });
  }
  function e0(C) {
    o1[C ? "unshift" : "push"](() => {
      He = C, t(18, He);
    });
  }
  const Re = (C, X) => N(C.deviceId), B0 = () => t(22, Ie = !1), h0 = (C, X) => N(C.deviceId), C0 = () => t(21, Ne = !1);
  function Ue(C) {
    o1[C ? "unshift" : "push"](() => {
      Ee = C, t(12, Ee);
    });
  }
  return n.$$set = (C) => {
    "on_change_cb" in C && t(36, u = C.on_change_cb), "rtp_params" in C && t(37, c = C.rtp_params), "button_labels" in C && t(38, f = C.button_labels), "height" in C && t(0, d = C.height), "track_constraints" in C && t(40, b = C.track_constraints), "rtc_configuration" in C && t(41, E = C.rtc_configuration), "stream_every" in C && t(42, k = C.stream_every), "server" in C && t(43, w = C.server), "i18n" in C && t(44, v = C.i18n), "webrtc_id" in C && t(35, ke = C.webrtc_id), "wave_color" in C && t(1, Fe = C.wave_color);
  }, [
    d,
    Fe,
    $a,
    a,
    i,
    l,
    o,
    s,
    _,
    A,
    x,
    W,
    Ee,
    ce,
    ve,
    oe,
    me,
    U,
    He,
    ne,
    fe,
    Ne,
    Ie,
    Q,
    z,
    P,
    N,
    j,
    xe,
    he,
    Z,
    Qe,
    Le,
    Ve,
    Ce,
    ke,
    u,
    c,
    f,
    p,
    b,
    E,
    k,
    w,
    v,
    b0,
    K,
    qe,
    Pe,
    e0,
    Re,
    B0,
    h0,
    C0,
    Ue
  ];
}
class xp extends sp {
  constructor(e) {
    super(), cp(
      this,
      e,
      Sp,
      Fp,
      fp,
      {
        on_change_cb: 36,
        rtp_params: 37,
        button_labels: 38,
        height: 0,
        modify_stream: 39,
        track_constraints: 40,
        rtc_configuration: 41,
        stream_every: 42,
        server: 43,
        i18n: 44,
        webrtc_id: 35,
        wave_color: 1,
        click_outside: 2
      },
      null,
      [-1, -1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[39];
  }
  get click_outside() {
    return $a;
  }
}
const {
  SvelteComponent: Cp,
  add_flush_callback: O1,
  assign: Tp,
  bind: q1,
  binding_callbacks: P1,
  check_outros: D4,
  claim_component: Cr,
  claim_space: Qp,
  create_component: Tr,
  destroy_component: Qr,
  detach: Jl,
  empty: ei,
  flush: n0,
  get_spread_object: Mp,
  get_spread_update: Bp,
  group_outros: E4,
  init: zp,
  insert_hydration: $l,
  mount_component: Mr,
  safe_not_equal: Lp,
  space: Ip,
  transition_in: ft,
  transition_out: dt
} = window.__gradio__svelte__internal;
function Np(n) {
  let e, t;
  return e = new B6({
    props: {
      visible: (
        /*visible*/
        n[3]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        n[1]
      ),
      elem_classes: (
        /*elem_classes*/
        n[2]
      ),
      height: (
        /*height*/
        n[8]
      ),
      width: (
        /*width*/
        n[9]
      ),
      container: (
        /*container*/
        n[11]
      ),
      scale: (
        /*scale*/
        n[12]
      ),
      min_width: (
        /*min_width*/
        n[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [Up] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*visible*/
      8 && (i.visible = /*visible*/
      r[3]), a[0] & /*elem_id*/
      2 && (i.elem_id = /*elem_id*/
      r[1]), a[0] & /*elem_classes*/
      4 && (i.elem_classes = /*elem_classes*/
      r[2]), a[0] & /*height*/
      256 && (i.height = /*height*/
      r[8]), a[0] & /*width*/
      512 && (i.width = /*width*/
      r[9]), a[0] & /*container*/
      2048 && (i.container = /*container*/
      r[11]), a[0] & /*scale*/
      4096 && (i.scale = /*scale*/
      r[12]), a[0] & /*min_width*/
      8192 && (i.min_width = /*min_width*/
      r[13]), a[0] & /*label, show_label, server, rtc_configuration, value, gradio, mode, modality, icon, icon_button_color, pulse_color, show_local_video, time_limit, track_constraints, rtp_params, button_labels, loading_status*/
      66045169 | a[2] & /*$$scope*/
      8 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (ft(e.$$.fragment, r), t = !0);
    },
    o(r) {
      dt(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function Rp(n) {
  let e, t;
  return e = new B6({
    props: {
      visible: (
        /*visible*/
        n[3]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        n[1]
      ),
      elem_classes: (
        /*elem_classes*/
        n[2]
      ),
      height: (
        /*height*/
        n[8]
      ),
      width: (
        /*width*/
        n[9]
      ),
      container: (
        /*container*/
        n[11]
      ),
      scale: (
        /*scale*/
        n[12]
      ),
      min_width: (
        /*min_width*/
        n[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [jp] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*visible*/
      8 && (i.visible = /*visible*/
      r[3]), a[0] & /*elem_id*/
      2 && (i.elem_id = /*elem_id*/
      r[1]), a[0] & /*elem_classes*/
      4 && (i.elem_classes = /*elem_classes*/
      r[2]), a[0] & /*height*/
      256 && (i.height = /*height*/
      r[8]), a[0] & /*width*/
      512 && (i.width = /*width*/
      r[9]), a[0] & /*container*/
      2048 && (i.container = /*container*/
      r[11]), a[0] & /*scale*/
      4096 && (i.scale = /*scale*/
      r[12]), a[0] & /*min_width*/
      8192 && (i.min_width = /*min_width*/
      r[13]), a[0] & /*server, gradio, height, rtc_configuration, value*/
      50433 | a[2] & /*$$scope*/
      8 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (ft(e.$$.fragment, r), t = !0);
    },
    o(r) {
      dt(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function Op(n) {
  let e, t, r;
  function a(l) {
    n[61](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    time_limit: (
      /*time_limit*/
      n[16]
    ),
    track_constraints: (
      /*track_constraints*/
      n[22]
    ),
    mode: (
      /*mode*/
      n[18]
    ),
    rtp_params: (
      /*rtp_params*/
      n[21]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    button_labels: (
      /*button_labels*/
      n[4]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new lp({ props: i }), P1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_5*/
      n[62]
    ), e.$on(
      "error",
      /*error_handler_5*/
      n[63]
    ), e.$on(
      "warning",
      /*warning_handler*/
      n[64]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*time_limit*/
        65536 && (s.time_limit = /*time_limit*/
        l[16]), o[0] & /*track_constraints*/
        4194304 && (s.track_constraints = /*track_constraints*/
        l[22]), o[0] & /*mode*/
        262144 && (s.mode = /*mode*/
        l[18]), o[0] & /*rtp_params*/
        2097152 && (s.rtp_params = /*rtp_params*/
        l[21]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*button_labels*/
        16 && (s.button_labels = /*button_labels*/
        l[4]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], O1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ft(e.$$.fragment, l), r = !0);
      },
      o(l) {
        dt(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function qp(n) {
  let e, t, r;
  function a(l) {
    n[50](l);
  }
  let i = {
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    active_source: "webcam",
    include_audio: (
      /*modality*/
      n[17] === "audio-video"
    ),
    show_local_video: (
      /*mode*/
      n[18] === "send-receive" && /*modality*/
      n[17] === "audio-video" && /*show_local_video*/
      n[19]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    time_limit: (
      /*time_limit*/
      n[16]
    ),
    mode: (
      /*mode*/
      n[18]
    ),
    track_constraints: (
      /*track_constraints*/
      n[22]
    ),
    rtp_params: (
      /*rtp_params*/
      n[21]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    button_labels: (
      /*button_labels*/
      n[4]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    stream_handler: (
      /*func_1*/
      n[49]
    ),
    $$slots: { default: [Vp] },
    $$scope: { ctx: n }
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new Rd({ props: i }), P1.push(() => q1(e, "value", a)), e.$on(
      "clear",
      /*clear_handler_1*/
      n[51]
    ), e.$on(
      "play",
      /*play_handler_1*/
      n[52]
    ), e.$on(
      "pause",
      /*pause_handler_1*/
      n[53]
    ), e.$on(
      "upload",
      /*upload_handler_1*/
      n[54]
    ), e.$on(
      "stop",
      /*stop_handler_1*/
      n[55]
    ), e.$on(
      "end",
      /*end_handler_1*/
      n[56]
    ), e.$on(
      "start_recording",
      /*start_recording_handler_1*/
      n[57]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler_1*/
      n[58]
    ), e.$on(
      "tick",
      /*tick_handler_4*/
      n[59]
    ), e.$on(
      "error",
      /*error_handler_4*/
      n[60]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*modality*/
        131072 && (s.include_audio = /*modality*/
        l[17] === "audio-video"), o[0] & /*mode, modality, show_local_video*/
        917504 && (s.show_local_video = /*mode*/
        l[18] === "send-receive" && /*modality*/
        l[17] === "audio-video" && /*show_local_video*/
        l[19]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*time_limit*/
        65536 && (s.time_limit = /*time_limit*/
        l[16]), o[0] & /*mode*/
        262144 && (s.mode = /*mode*/
        l[18]), o[0] & /*track_constraints*/
        4194304 && (s.track_constraints = /*track_constraints*/
        l[22]), o[0] & /*rtp_params*/
        2097152 && (s.rtp_params = /*rtp_params*/
        l[21]), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*button_labels*/
        16 && (s.button_labels = /*button_labels*/
        l[4]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*gradio*/
        16384 && (s.stream_handler = /*func_1*/
        l[49]), o[0] & /*gradio*/
        16384 | o[2] & /*$$scope*/
        8 && (s.$$scope = { dirty: o, ctx: l }), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], O1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ft(e.$$.fragment, l), r = !0);
      },
      o(l) {
        dt(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Pp(n) {
  let e, t, r;
  function a(l) {
    n[46](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new Im({ props: i }), P1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_3*/
      n[47]
    ), e.$on(
      "error",
      /*error_handler_3*/
      n[48]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], O1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ft(e.$$.fragment, l), r = !0);
      },
      o(l) {
        dt(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Hp(n) {
  let e, t, r;
  function a(l) {
    n[43](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new sm({ props: i }), P1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_2*/
      n[44]
    ), e.$on(
      "error",
      /*error_handler_2*/
      n[45]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], O1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ft(e.$$.fragment, l), r = !0);
      },
      o(l) {
        dt(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Vp(n) {
  let e, t;
  return e = new df({
    props: {
      i18n: (
        /*gradio*/
        n[14].i18n
      ),
      type: "video"
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*gradio*/
      16384 && (i.i18n = /*gradio*/
      r[14].i18n), e.$set(i);
    },
    i(r) {
      t || (ft(e.$$.fragment, r), t = !0);
    },
    o(r) {
      dt(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function Up(n) {
  let e, t, r, a, i, l;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        n[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[14].i18n
    ) },
    /*loading_status*/
    n[7]
  ];
  let s = {};
  for (let d = 0; d < o.length; d += 1)
    s = Tp(s, o[d]);
  e = new Q8({ props: s }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[42]
  );
  const u = [Hp, Pp, qp, Op], c = [];
  function f(d, p) {
    return (
      /*mode*/
      d[18] == "receive" && /*modality*/
      d[17] === "video" ? 0 : (
        /*mode*/
        d[18] == "receive" && /*modality*/
        d[17] === "audio" ? 1 : (
          /*mode*/
          (d[18] === "send-receive" || /*mode*/
          d[18] == "send") && /*modality*/
          (d[17] === "video" || /*modality*/
          d[17] == "audio-video") ? 2 : (
            /*mode*/
            (d[18] === "send-receive" || /*mode*/
            d[18] === "send") && /*modality*/
            d[17] === "audio" ? 3 : -1
          )
        )
      )
    );
  }
  return ~(r = f(n)) && (a = c[r] = u[r](n)), {
    c() {
      Tr(e.$$.fragment), t = Ip(), a && a.c(), i = ei();
    },
    l(d) {
      Cr(e.$$.fragment, d), t = Qp(d), a && a.l(d), i = ei();
    },
    m(d, p) {
      Mr(e, d, p), $l(d, t, p), ~r && c[r].m(d, p), $l(d, i, p), l = !0;
    },
    p(d, p) {
      const b = p[0] & /*gradio, loading_status*/
      16512 ? Bp(o, [
        p[0] & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            d[14].autoscroll
          )
        },
        p[0] & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          d[14].i18n
        ) },
        p[0] & /*loading_status*/
        128 && Mp(
          /*loading_status*/
          d[7]
        )
      ]) : {};
      e.$set(b);
      let E = r;
      r = f(d), r === E ? ~r && c[r].p(d, p) : (a && (E4(), dt(c[E], 1, 1, () => {
        c[E] = null;
      }), D4()), ~r ? (a = c[r], a ? a.p(d, p) : (a = c[r] = u[r](d), a.c()), ft(a, 1), a.m(i.parentNode, i)) : a = null);
    },
    i(d) {
      l || (ft(e.$$.fragment, d), ft(a), l = !0);
    },
    o(d) {
      dt(e.$$.fragment, d), dt(a), l = !1;
    },
    d(d) {
      d && (Jl(t), Jl(i)), Qr(e, d), ~r && c[r].d(d);
    }
  };
}
function jp(n) {
  let e, t, r;
  function a(l) {
    n[29](l);
  }
  let i = {
    server: (
      /*server*/
      n[10]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    stream_handler: (
      /*func*/
      n[28]
    ),
    height: (
      /*height*/
      n[8]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.webrtc_id = /*value*/
    n[0]), e = new xp({ props: i }), P1.push(() => q1(e, "webrtc_id", a)), e.$on(
      "clear",
      /*clear_handler*/
      n[30]
    ), e.$on(
      "play",
      /*play_handler*/
      n[31]
    ), e.$on(
      "pause",
      /*pause_handler*/
      n[32]
    ), e.$on(
      "upload",
      /*upload_handler*/
      n[33]
    ), e.$on(
      "stop",
      /*stop_handler*/
      n[34]
    ), e.$on(
      "end",
      /*end_handler*/
      n[35]
    ), e.$on(
      "start_recording",
      /*start_recording_handler*/
      n[36]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[37]
    ), e.$on(
      "tick",
      /*tick_handler*/
      n[38]
    ), e.$on(
      "error",
      /*error_handler*/
      n[39]
    ), e.$on(
      "tick",
      /*tick_handler_1*/
      n[40]
    ), e.$on(
      "error",
      /*error_handler_1*/
      n[41]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*gradio*/
        16384 && (s.stream_handler = /*func*/
        l[28]), o[0] & /*height*/
        256 && (s.height = /*height*/
        l[8]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), !t && o[0] & /*value*/
        1 && (t = !0, s.webrtc_id = /*value*/
        l[0], O1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ft(e.$$.fragment, l), r = !0);
      },
      o(l) {
        dt(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Gp(n) {
  let e, t, r, a;
  const i = [Rp, Np], l = [];
  function o(s, u) {
    return (
      /*video_chat*/
      s[20] ? 0 : 1
    );
  }
  return e = o(n), t = l[e] = i[e](n), {
    c() {
      t.c(), r = ei();
    },
    l(s) {
      t.l(s), r = ei();
    },
    m(s, u) {
      l[e].m(s, u), $l(s, r, u), a = !0;
    },
    p(s, u) {
      let c = e;
      e = o(s), e === c ? l[e].p(s, u) : (E4(), dt(l[c], 1, 1, () => {
        l[c] = null;
      }), D4(), t = l[e], t ? t.p(s, u) : (t = l[e] = i[e](s), t.c()), ft(t, 1), t.m(r.parentNode, r));
    },
    i(s) {
      a || (ft(t), a = !0);
    },
    o(s) {
      dt(t), a = !1;
    },
    d(s) {
      s && Jl(r), l[e].d(s);
    }
  };
}
function Wp(n, e, t) {
  let { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { visible: i = !0 } = e, { value: l = "__webrtc_value__" } = e, { button_labels: o } = e, { label: s } = e, { root: u } = e, { show_label: c } = e, { loading_status: f } = e, { height: d } = e, { width: p } = e, { server: b } = e, { container: E = !1 } = e, { scale: k = null } = e, { min_width: w = void 0 } = e, { gradio: v } = e, { rtc_configuration: _ } = e, { time_limit: A = null } = e, { modality: x = "video" } = e, { mode: Q = "send-receive" } = e, { show_local_video: z = void 0 } = e, { video_chat: P = !1 } = e, { rtp_params: B = {} } = e, { track_constraints: N = {} } = e, { icon: j = void 0 } = e, { icon_button_color: $ = "var(--color-accent)" } = e, { pulse_color: W = "var(--color-accent)" } = e;
  const se = (q) => {
    ((q == null ? void 0 : q.type) === "info" || (q == null ? void 0 : q.type) === "warning" || (q == null ? void 0 : q.type) === "error") && (console.log("dispatching info", q.message), v.dispatch(
      (q == null ? void 0 : q.type) === "error" ? "error" : "warning",
      q.message
    )), v.dispatch(q === "change" ? "state_change" : "tick");
  }, ke = (...q) => v.client.stream(...q);
  function Fe(q) {
    l = q, t(0, l);
  }
  const xe = () => v.dispatch("clear"), he = () => v.dispatch("play"), Ee = () => v.dispatch("pause"), ie = () => v.dispatch("upload"), ce = () => v.dispatch("stop"), ve = () => v.dispatch("end"), oe = () => v.dispatch("start_recording"), me = () => v.dispatch("stop_recording"), U = () => v.dispatch("tick"), He = ({ detail: q }) => v.dispatch("error", q), ne = () => v.dispatch("tick"), fe = ({ detail: q }) => v.dispatch("error", q), Z = () => v.dispatch("clear_status", f);
  function Qe(q) {
    l = q, t(0, l);
  }
  const Le = () => v.dispatch("tick"), Ne = ({ detail: q }) => v.dispatch("error", q);
  function Ie(q) {
    l = q, t(0, l);
  }
  const Ve = () => v.dispatch("tick"), Ce = ({ detail: q }) => v.dispatch("error", q), b0 = (...q) => v.client.stream(...q);
  function K(q) {
    l = q, t(0, l);
  }
  const qe = () => v.dispatch("clear"), Pe = () => v.dispatch("play"), e0 = () => v.dispatch("pause"), Re = () => v.dispatch("upload"), B0 = () => v.dispatch("stop"), h0 = () => v.dispatch("end"), C0 = () => v.dispatch("start_recording"), Ue = () => v.dispatch("stop_recording"), C = () => v.dispatch("tick"), X = ({ detail: q }) => v.dispatch("error", q);
  function Me(q) {
    l = q, t(0, l);
  }
  const Ae = () => v.dispatch("tick"), We = ({ detail: q }) => v.dispatch("error", q), o0 = ({ detail: q }) => v.dispatch("warning", q);
  return n.$$set = (q) => {
    "elem_id" in q && t(1, r = q.elem_id), "elem_classes" in q && t(2, a = q.elem_classes), "visible" in q && t(3, i = q.visible), "value" in q && t(0, l = q.value), "button_labels" in q && t(4, o = q.button_labels), "label" in q && t(5, s = q.label), "root" in q && t(27, u = q.root), "show_label" in q && t(6, c = q.show_label), "loading_status" in q && t(7, f = q.loading_status), "height" in q && t(8, d = q.height), "width" in q && t(9, p = q.width), "server" in q && t(10, b = q.server), "container" in q && t(11, E = q.container), "scale" in q && t(12, k = q.scale), "min_width" in q && t(13, w = q.min_width), "gradio" in q && t(14, v = q.gradio), "rtc_configuration" in q && t(15, _ = q.rtc_configuration), "time_limit" in q && t(16, A = q.time_limit), "modality" in q && t(17, x = q.modality), "mode" in q && t(18, Q = q.mode), "show_local_video" in q && t(19, z = q.show_local_video), "video_chat" in q && t(20, P = q.video_chat), "rtp_params" in q && t(21, B = q.rtp_params), "track_constraints" in q && t(22, N = q.track_constraints), "icon" in q && t(23, j = q.icon), "icon_button_color" in q && t(24, $ = q.icon_button_color), "pulse_color" in q && t(25, W = q.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*value*/
    1 && console.log("value", l);
  }, [
    l,
    r,
    a,
    i,
    o,
    s,
    c,
    f,
    d,
    p,
    b,
    E,
    k,
    w,
    v,
    _,
    A,
    x,
    Q,
    z,
    P,
    B,
    N,
    j,
    $,
    W,
    se,
    u,
    ke,
    Fe,
    xe,
    he,
    Ee,
    ie,
    ce,
    ve,
    oe,
    me,
    U,
    He,
    ne,
    fe,
    Z,
    Qe,
    Le,
    Ne,
    Ie,
    Ve,
    Ce,
    b0,
    K,
    qe,
    Pe,
    e0,
    Re,
    B0,
    h0,
    C0,
    Ue,
    C,
    X,
    Me,
    Ae,
    We,
    o0
  ];
}
class ng extends Cp {
  constructor(e) {
    super(), zp(
      this,
      e,
      Wp,
      Gp,
      Lp,
      {
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 0,
        button_labels: 4,
        label: 5,
        root: 27,
        show_label: 6,
        loading_status: 7,
        height: 8,
        width: 9,
        server: 10,
        container: 11,
        scale: 12,
        min_width: 13,
        gradio: 14,
        rtc_configuration: 15,
        time_limit: 16,
        modality: 17,
        mode: 18,
        show_local_video: 19,
        video_chat: 20,
        rtp_params: 21,
        track_constraints: 22,
        icon: 23,
        icon_button_color: 24,
        pulse_color: 25
      },
      null,
      [-1, -1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), n0();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), n0();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), n0();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), n0();
  }
  get button_labels() {
    return this.$$.ctx[4];
  }
  set button_labels(e) {
    this.$$set({ button_labels: e }), n0();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), n0();
  }
  get root() {
    return this.$$.ctx[27];
  }
  set root(e) {
    this.$$set({ root: e }), n0();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), n0();
  }
  get loading_status() {
    return this.$$.ctx[7];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), n0();
  }
  get height() {
    return this.$$.ctx[8];
  }
  set height(e) {
    this.$$set({ height: e }), n0();
  }
  get width() {
    return this.$$.ctx[9];
  }
  set width(e) {
    this.$$set({ width: e }), n0();
  }
  get server() {
    return this.$$.ctx[10];
  }
  set server(e) {
    this.$$set({ server: e }), n0();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(e) {
    this.$$set({ container: e }), n0();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(e) {
    this.$$set({ scale: e }), n0();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), n0();
  }
  get gradio() {
    return this.$$.ctx[14];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), n0();
  }
  get rtc_configuration() {
    return this.$$.ctx[15];
  }
  set rtc_configuration(e) {
    this.$$set({ rtc_configuration: e }), n0();
  }
  get time_limit() {
    return this.$$.ctx[16];
  }
  set time_limit(e) {
    this.$$set({ time_limit: e }), n0();
  }
  get modality() {
    return this.$$.ctx[17];
  }
  set modality(e) {
    this.$$set({ modality: e }), n0();
  }
  get mode() {
    return this.$$.ctx[18];
  }
  set mode(e) {
    this.$$set({ mode: e }), n0();
  }
  get show_local_video() {
    return this.$$.ctx[19];
  }
  set show_local_video(e) {
    this.$$set({ show_local_video: e }), n0();
  }
  get video_chat() {
    return this.$$.ctx[20];
  }
  set video_chat(e) {
    this.$$set({ video_chat: e }), n0();
  }
  get rtp_params() {
    return this.$$.ctx[21];
  }
  set rtp_params(e) {
    this.$$set({ rtp_params: e }), n0();
  }
  get track_constraints() {
    return this.$$.ctx[22];
  }
  set track_constraints(e) {
    this.$$set({ track_constraints: e }), n0();
  }
  get icon() {
    return this.$$.ctx[23];
  }
  set icon(e) {
    this.$$set({ icon: e }), n0();
  }
  get icon_button_color() {
    return this.$$.ctx[24];
  }
  set icon_button_color(e) {
    this.$$set({ icon_button_color: e }), n0();
  }
  get pulse_color() {
    return this.$$.ctx[25];
  }
  set pulse_color(e) {
    this.$$set({ pulse_color: e }), n0();
  }
}
export {
  rg as BaseExample,
  Rd as BaseInteractiveVideo,
  ng as default,
  Jp as loaded,
  Kp as playable,
  Xp as prettyBytes
};
