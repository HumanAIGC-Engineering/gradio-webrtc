var k3 = Object.defineProperty;
var es = (n) => {
  throw TypeError(n);
};
var D3 = (n, e, t) => e in n ? k3(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var c0 = (n, e, t) => D3(n, typeof e != "symbol" ? e + "" : e, t), E3 = (n, e, t) => e.has(n) || es("Cannot " + t);
var ts = (n, e, t) => e.has(n) ? es("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t);
var H1 = (n, e, t) => (E3(n, e, "access private method"), t);
const {
  SvelteComponent: A3,
  assign: F3,
  children: S3,
  claim_element: x3,
  create_slot: C3,
  detach: rs,
  element: T3,
  get_all_dirty_from_scope: Q3,
  get_slot_changes: M3,
  get_spread_update: B3,
  init: z3,
  insert_hydration: L3,
  safe_not_equal: I3,
  set_dynamic_element_data: ns,
  set_style: I0,
  toggle_class: gt,
  transition_in: D4,
  transition_out: E4,
  update_slot_base: N3
} = window.__gradio__svelte__internal;
function R3(n) {
  let e, t, r;
  const a = (
    /*#slots*/
    n[22].default
  ), i = C3(
    a,
    n,
    /*$$scope*/
    n[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      n[10]
    ) },
    { id: (
      /*elem_id*/
      n[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      n[6].join(" ") + " svelte-1ezsyiy"
    }
  ], o = {};
  for (let s = 0; s < l.length; s += 1)
    o = F3(o, l[s]);
  return {
    c() {
      e = T3(
        /*tag*/
        n[18]
      ), i && i.c(), this.h();
    },
    l(s) {
      e = x3(
        s,
        /*tag*/
        (n[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var u = S3(e);
      i && i.l(u), u.forEach(rs), this.h();
    },
    h() {
      ns(
        /*tag*/
        n[18]
      )(e, o), gt(
        e,
        "hidden",
        /*visible*/
        n[13] === !1
      ), gt(
        e,
        "padded",
        /*padding*/
        n[9]
      ), gt(
        e,
        "flex",
        /*flex*/
        n[0]
      ), gt(
        e,
        "border_focus",
        /*border_mode*/
        n[8] === "focus"
      ), gt(
        e,
        "border_contrast",
        /*border_mode*/
        n[8] === "contrast"
      ), gt(e, "hide-container", !/*explicit_call*/
      n[11] && !/*container*/
      n[12]), I0(
        e,
        "height",
        /*get_dimension*/
        n[19](
          /*height*/
          n[1]
        )
      ), I0(
        e,
        "min-height",
        /*get_dimension*/
        n[19](
          /*min_height*/
          n[2]
        )
      ), I0(
        e,
        "max-height",
        /*get_dimension*/
        n[19](
          /*max_height*/
          n[3]
        )
      ), I0(e, "width", typeof /*width*/
      n[4] == "number" ? `calc(min(${/*width*/
      n[4]}px, 100%))` : (
        /*get_dimension*/
        n[19](
          /*width*/
          n[4]
        )
      )), I0(
        e,
        "border-style",
        /*variant*/
        n[7]
      ), I0(
        e,
        "overflow",
        /*allow_overflow*/
        n[14] ? (
          /*overflow_behavior*/
          n[15]
        ) : "hidden"
      ), I0(
        e,
        "flex-grow",
        /*scale*/
        n[16]
      ), I0(e, "min-width", `calc(min(${/*min_width*/
      n[17]}px, 100%))`), I0(e, "border-width", "var(--block-border-width)");
    },
    m(s, u) {
      L3(s, e, u), i && i.m(e, null), r = !0;
    },
    p(s, u) {
      i && i.p && (!r || u & /*$$scope*/
      2097152) && N3(
        i,
        a,
        s,
        /*$$scope*/
        s[21],
        r ? M3(
          a,
          /*$$scope*/
          s[21],
          u,
          null
        ) : Q3(
          /*$$scope*/
          s[21]
        ),
        null
      ), ns(
        /*tag*/
        s[18]
      )(e, o = B3(l, [
        (!r || u & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          s[10]
        ) },
        (!r || u & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          s[5]
        ) },
        (!r || u & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        s[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), gt(
        e,
        "hidden",
        /*visible*/
        s[13] === !1
      ), gt(
        e,
        "padded",
        /*padding*/
        s[9]
      ), gt(
        e,
        "flex",
        /*flex*/
        s[0]
      ), gt(
        e,
        "border_focus",
        /*border_mode*/
        s[8] === "focus"
      ), gt(
        e,
        "border_contrast",
        /*border_mode*/
        s[8] === "contrast"
      ), gt(e, "hide-container", !/*explicit_call*/
      s[11] && !/*container*/
      s[12]), u & /*height*/
      2 && I0(
        e,
        "height",
        /*get_dimension*/
        s[19](
          /*height*/
          s[1]
        )
      ), u & /*min_height*/
      4 && I0(
        e,
        "min-height",
        /*get_dimension*/
        s[19](
          /*min_height*/
          s[2]
        )
      ), u & /*max_height*/
      8 && I0(
        e,
        "max-height",
        /*get_dimension*/
        s[19](
          /*max_height*/
          s[3]
        )
      ), u & /*width*/
      16 && I0(e, "width", typeof /*width*/
      s[4] == "number" ? `calc(min(${/*width*/
      s[4]}px, 100%))` : (
        /*get_dimension*/
        s[19](
          /*width*/
          s[4]
        )
      )), u & /*variant*/
      128 && I0(
        e,
        "border-style",
        /*variant*/
        s[7]
      ), u & /*allow_overflow, overflow_behavior*/
      49152 && I0(
        e,
        "overflow",
        /*allow_overflow*/
        s[14] ? (
          /*overflow_behavior*/
          s[15]
        ) : "hidden"
      ), u & /*scale*/
      65536 && I0(
        e,
        "flex-grow",
        /*scale*/
        s[16]
      ), u & /*min_width*/
      131072 && I0(e, "min-width", `calc(min(${/*min_width*/
      s[17]}px, 100%))`);
    },
    i(s) {
      r || (D4(i, s), r = !0);
    },
    o(s) {
      E4(i, s), r = !1;
    },
    d(s) {
      s && rs(e), i && i.d(s);
    }
  };
}
function q3(n) {
  let e, t = (
    /*tag*/
    n[18] && R3(n)
  );
  return {
    c() {
      t && t.c();
    },
    l(r) {
      t && t.l(r);
    },
    m(r, a) {
      t && t.m(r, a), e = !0;
    },
    p(r, [a]) {
      /*tag*/
      r[18] && t.p(r, a);
    },
    i(r) {
      e || (D4(t, r), e = !0);
    },
    o(r) {
      E4(t, r), e = !1;
    },
    d(r) {
      t && t.d(r);
    }
  };
}
function O3(n, e, t) {
  let { $$slots: r = {}, $$scope: a } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: d = "solid" } = e, { border_mode: f = "base" } = e, { padding: p = !0 } = e, { type: b = "normal" } = e, { test_id: E = void 0 } = e, { explicit_call: k = !1 } = e, { container: w = !0 } = e, { visible: _ = !0 } = e, { allow_overflow: v = !0 } = e, { overflow_behavior: A = "auto" } = e, { scale: x = null } = e, { min_width: Q = 0 } = e, { flex: B = !1 } = e;
  _ || (B = !1);
  let O = b === "fieldset" ? "fieldset" : "div";
  const M = (I) => {
    if (I !== void 0) {
      if (typeof I == "number")
        return I + "px";
      if (typeof I == "string")
        return I;
    }
  };
  return n.$$set = (I) => {
    "height" in I && t(1, i = I.height), "min_height" in I && t(2, l = I.min_height), "max_height" in I && t(3, o = I.max_height), "width" in I && t(4, s = I.width), "elem_id" in I && t(5, u = I.elem_id), "elem_classes" in I && t(6, c = I.elem_classes), "variant" in I && t(7, d = I.variant), "border_mode" in I && t(8, f = I.border_mode), "padding" in I && t(9, p = I.padding), "type" in I && t(20, b = I.type), "test_id" in I && t(10, E = I.test_id), "explicit_call" in I && t(11, k = I.explicit_call), "container" in I && t(12, w = I.container), "visible" in I && t(13, _ = I.visible), "allow_overflow" in I && t(14, v = I.allow_overflow), "overflow_behavior" in I && t(15, A = I.overflow_behavior), "scale" in I && t(16, x = I.scale), "min_width" in I && t(17, Q = I.min_width), "flex" in I && t(0, B = I.flex), "$$scope" in I && t(21, a = I.$$scope);
  }, [
    B,
    i,
    l,
    o,
    s,
    u,
    c,
    d,
    f,
    p,
    E,
    k,
    w,
    _,
    v,
    A,
    x,
    Q,
    O,
    M,
    b,
    a,
    r
  ];
}
class A4 extends A3 {
  constructor(e) {
    super(), z3(this, e, O3, q3, I3, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
const P3 = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], as = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
P3.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: as[e][t],
      secondary: as[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: H3,
  append_hydration: V3,
  attr: xt,
  children: is,
  claim_svg_element: ls,
  detach: fi,
  init: U3,
  insert_hydration: j3,
  noop: di,
  safe_not_equal: G3,
  svg_element: ss
} = window.__gradio__svelte__internal;
function W3(n) {
  let e, t;
  return {
    c() {
      e = ss("svg"), t = ss("circle"), this.h();
    },
    l(r) {
      e = ls(r, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = is(e);
      t = ls(a, "circle", { cx: !0, cy: !0, r: !0 }), is(t).forEach(fi), a.forEach(fi), this.h();
    },
    h() {
      xt(t, "cx", "12"), xt(t, "cy", "12"), xt(t, "r", "10"), xt(e, "xmlns", "http://www.w3.org/2000/svg"), xt(e, "width", "100%"), xt(e, "height", "100%"), xt(e, "viewBox", "0 0 24 24"), xt(e, "stroke-width", "1.5"), xt(e, "stroke-linecap", "round"), xt(e, "stroke-linejoin", "round"), xt(e, "class", "feather feather-circle");
    },
    m(r, a) {
      j3(r, e, a), V3(e, t);
    },
    p: di,
    i: di,
    o: di,
    d(r) {
      r && fi(e);
    }
  };
}
class F4 extends H3 {
  constructor(e) {
    super(), U3(this, e, null, W3, G3, {});
  }
}
const {
  SvelteComponent: Z3,
  append_hydration: mi,
  attr: Ct,
  children: V1,
  claim_svg_element: U1,
  detach: Pn,
  init: Y3,
  insert_hydration: X3,
  noop: pi,
  safe_not_equal: K3,
  set_style: Kt,
  svg_element: j1
} = window.__gradio__svelte__internal;
function J3(n) {
  let e, t, r, a;
  return {
    c() {
      e = j1("svg"), t = j1("g"), r = j1("path"), a = j1("path"), this.h();
    },
    l(i) {
      e = U1(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = V1(e);
      t = U1(l, "g", { transform: !0 });
      var o = V1(t);
      r = U1(o, "path", { d: !0, style: !0 }), V1(r).forEach(Pn), o.forEach(Pn), a = U1(l, "path", { d: !0, style: !0 }), V1(a).forEach(Pn), l.forEach(Pn), this.h();
    },
    h() {
      Ct(r, "d", "M18,6L6.087,17.913"), Kt(r, "fill", "none"), Kt(r, "fill-rule", "nonzero"), Kt(r, "stroke-width", "2px"), Ct(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ct(a, "d", "M4.364,4.364L19.636,19.636"), Kt(a, "fill", "none"), Kt(a, "fill-rule", "nonzero"), Kt(a, "stroke-width", "2px"), Ct(e, "width", "100%"), Ct(e, "height", "100%"), Ct(e, "viewBox", "0 0 24 24"), Ct(e, "version", "1.1"), Ct(e, "xmlns", "http://www.w3.org/2000/svg"), Ct(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ct(e, "xml:space", "preserve"), Ct(e, "stroke", "currentColor"), Kt(e, "fill-rule", "evenodd"), Kt(e, "clip-rule", "evenodd"), Kt(e, "stroke-linecap", "round"), Kt(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      X3(i, e, l), mi(e, t), mi(t, r), mi(e, a);
    },
    p: pi,
    i: pi,
    o: pi,
    d(i) {
      i && Pn(e);
    }
  };
}
class $3 extends Z3 {
  constructor(e) {
    super(), Y3(this, e, null, J3, K3, {});
  }
}
const {
  SvelteComponent: eu,
  append_hydration: tu,
  attr: kn,
  children: os,
  claim_svg_element: us,
  detach: gi,
  init: ru,
  insert_hydration: nu,
  noop: _i,
  safe_not_equal: au,
  svg_element: cs
} = window.__gradio__svelte__internal;
function iu(n) {
  let e, t;
  return {
    c() {
      e = cs("svg"), t = cs("path"), this.h();
    },
    l(r) {
      e = us(r, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var a = os(e);
      t = us(a, "path", { d: !0 }), os(t).forEach(gi), a.forEach(gi), this.h();
    },
    h() {
      kn(t, "d", "M5 8l4 4 4-4z"), kn(e, "class", "dropdown-arrow svelte-145leq6"), kn(e, "xmlns", "http://www.w3.org/2000/svg"), kn(e, "width", "100%"), kn(e, "height", "100%"), kn(e, "viewBox", "0 0 18 18");
    },
    m(r, a) {
      nu(r, e, a), tu(e, t);
    },
    p: _i,
    i: _i,
    o: _i,
    d(r) {
      r && gi(e);
    }
  };
}
class x1 extends eu {
  constructor(e) {
    super(), ru(this, e, null, iu, au, {});
  }
}
const {
  SvelteComponent: lu,
  append_hydration: su,
  attr: G1,
  children: hs,
  claim_svg_element: fs,
  detach: vi,
  init: ou,
  insert_hydration: uu,
  noop: bi,
  safe_not_equal: cu,
  svg_element: ds
} = window.__gradio__svelte__internal;
function hu(n) {
  let e, t;
  return {
    c() {
      e = ds("svg"), t = ds("path"), this.h();
    },
    l(r) {
      e = fs(r, "svg", { xmlns: !0, viewBox: !0 });
      var a = hs(e);
      t = fs(a, "path", { fill: !0, d: !0 }), hs(t).forEach(vi), a.forEach(vi), this.h();
    },
    h() {
      G1(t, "fill", "currentColor"), G1(t, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a4 4 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2zm2.245 2.096L16 4.25q0-.078-.005-.154M13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5M15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3zm0 11a3 3 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A3 3 0 0 1 20 23zm5-7a1 1 0 1 1 0-2 1 1 0 0 1 0 2"), G1(e, "xmlns", "http://www.w3.org/2000/svg"), G1(e, "viewBox", "0 0 24 24");
    },
    m(r, a) {
      uu(r, e, a), su(e, t);
    },
    p: bi,
    i: bi,
    o: bi,
    d(r) {
      r && vi(e);
    }
  };
}
class fu extends lu {
  constructor(e) {
    super(), ou(this, e, null, hu, cu, {});
  }
}
const {
  SvelteComponent: du,
  append_hydration: W1,
  attr: k0,
  children: Hn,
  claim_svg_element: Vn,
  detach: Dn,
  init: mu,
  insert_hydration: pu,
  noop: wi,
  safe_not_equal: gu,
  svg_element: Un
} = window.__gradio__svelte__internal;
function _u(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = Un("svg"), t = Un("path"), r = Un("path"), a = Un("line"), i = Un("line"), this.h();
    },
    l(l) {
      e = Vn(l, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = Hn(e);
      t = Vn(o, "path", { d: !0 }), Hn(t).forEach(Dn), r = Vn(o, "path", { d: !0 }), Hn(r).forEach(Dn), a = Vn(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Hn(a).forEach(Dn), i = Vn(o, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Hn(i).forEach(Dn), o.forEach(Dn), this.h();
    },
    h() {
      k0(t, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), k0(r, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), k0(a, "x1", "12"), k0(a, "y1", "19"), k0(a, "x2", "12"), k0(a, "y2", "23"), k0(i, "x1", "8"), k0(i, "y1", "23"), k0(i, "x2", "16"), k0(i, "y2", "23"), k0(e, "xmlns", "http://www.w3.org/2000/svg"), k0(e, "width", "100%"), k0(e, "height", "100%"), k0(e, "viewBox", "0 0 24 24"), k0(e, "fill", "none"), k0(e, "stroke", "currentColor"), k0(e, "stroke-width", "2"), k0(e, "stroke-linecap", "round"), k0(e, "stroke-linejoin", "round"), k0(e, "class", "feather feather-mic");
    },
    m(l, o) {
      pu(l, e, o), W1(e, t), W1(e, r), W1(e, a), W1(e, i);
    },
    p: wi,
    i: wi,
    o: wi,
    d(l) {
      l && Dn(e);
    }
  };
}
class Al extends du {
  constructor(e) {
    super(), mu(this, e, null, _u, gu, {});
  }
}
const {
  SvelteComponent: vu,
  append_hydration: yi,
  attr: N0,
  children: Z1,
  claim_svg_element: Y1,
  detach: jn,
  init: bu,
  insert_hydration: wu,
  noop: ki,
  safe_not_equal: yu,
  svg_element: X1
} = window.__gradio__svelte__internal;
function ku(n) {
  let e, t, r, a;
  return {
    c() {
      e = X1("svg"), t = X1("path"), r = X1("circle"), a = X1("circle"), this.h();
    },
    l(i) {
      e = Y1(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = Z1(e);
      t = Y1(l, "path", { d: !0 }), Z1(t).forEach(jn), r = Y1(l, "circle", { cx: !0, cy: !0, r: !0 }), Z1(r).forEach(jn), a = Y1(l, "circle", { cx: !0, cy: !0, r: !0 }), Z1(a).forEach(jn), l.forEach(jn), this.h();
    },
    h() {
      N0(t, "d", "M9 18V5l12-2v13"), N0(r, "cx", "6"), N0(r, "cy", "18"), N0(r, "r", "3"), N0(a, "cx", "18"), N0(a, "cy", "16"), N0(a, "r", "3"), N0(e, "xmlns", "http://www.w3.org/2000/svg"), N0(e, "width", "100%"), N0(e, "height", "100%"), N0(e, "viewBox", "0 0 24 24"), N0(e, "fill", "none"), N0(e, "stroke", "currentColor"), N0(e, "stroke-width", "1.5"), N0(e, "stroke-linecap", "round"), N0(e, "stroke-linejoin", "round"), N0(e, "class", "feather feather-music");
    },
    m(i, l) {
      wu(i, e, l), yi(e, t), yi(e, r), yi(e, a);
    },
    p: ki,
    i: ki,
    o: ki,
    d(i) {
      i && jn(e);
    }
  };
}
class Xl extends vu {
  constructor(e) {
    super(), bu(this, e, null, ku, yu, {});
  }
}
const {
  SvelteComponent: Du,
  append_hydration: Eu,
  attr: T0,
  children: ms,
  claim_svg_element: ps,
  detach: Di,
  init: Au,
  insert_hydration: Fu,
  noop: gs,
  safe_not_equal: Su,
  svg_element: _s
} = window.__gradio__svelte__internal;
function xu(n) {
  let e, t, r;
  return {
    c() {
      e = _s("svg"), t = _s("rect"), this.h();
    },
    l(a) {
      e = ps(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = ms(e);
      t = ps(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), ms(t).forEach(Di), i.forEach(Di), this.h();
    },
    h() {
      T0(t, "x", "3"), T0(t, "y", "3"), T0(t, "width", "18"), T0(t, "height", "18"), T0(t, "rx", "2"), T0(t, "ry", "2"), T0(e, "xmlns", "http://www.w3.org/2000/svg"), T0(e, "width", "100%"), T0(e, "height", "100%"), T0(e, "viewBox", "0 0 24 24"), T0(
        e,
        "fill",
        /*fill*/
        n[0]
      ), T0(e, "stroke", "currentColor"), T0(e, "stroke-width", r = `${/*stroke_width*/
      n[1]}`), T0(e, "stroke-linecap", "round"), T0(e, "stroke-linejoin", "round"), T0(e, "class", "feather feather-square");
    },
    m(a, i) {
      Fu(a, e, i), Eu(e, t);
    },
    p(a, [i]) {
      i & /*fill*/
      1 && T0(
        e,
        "fill",
        /*fill*/
        a[0]
      ), i & /*stroke_width*/
      2 && r !== (r = `${/*stroke_width*/
      a[1]}`) && T0(e, "stroke-width", r);
    },
    i: gs,
    o: gs,
    d(a) {
      a && Di(e);
    }
  };
}
function Cu(n, e, t) {
  let { fill: r = "currentColor" } = e, { stroke_width: a = 1.5 } = e;
  return n.$$set = (i) => {
    "fill" in i && t(0, r = i.fill), "stroke_width" in i && t(1, a = i.stroke_width);
  }, [r, a];
}
class S4 extends Du {
  constructor(e) {
    super(), Au(this, e, Cu, xu, Su, { fill: 0, stroke_width: 1 });
  }
}
const {
  SvelteComponent: Tu,
  append_hydration: Ei,
  attr: W0,
  children: K1,
  claim_svg_element: J1,
  detach: Gn,
  init: Qu,
  insert_hydration: Mu,
  noop: Ai,
  safe_not_equal: Bu,
  svg_element: $1
} = window.__gradio__svelte__internal;
function zu(n) {
  let e, t, r, a;
  return {
    c() {
      e = $1("svg"), t = $1("path"), r = $1("polyline"), a = $1("line"), this.h();
    },
    l(i) {
      e = J1(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var l = K1(e);
      t = J1(l, "path", { d: !0 }), K1(t).forEach(Gn), r = J1(l, "polyline", { points: !0 }), K1(r).forEach(Gn), a = J1(l, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), K1(a).forEach(Gn), l.forEach(Gn), this.h();
    },
    h() {
      W0(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), W0(r, "points", "17 8 12 3 7 8"), W0(a, "x1", "12"), W0(a, "y1", "3"), W0(a, "x2", "12"), W0(a, "y2", "15"), W0(e, "xmlns", "http://www.w3.org/2000/svg"), W0(e, "width", "90%"), W0(e, "height", "90%"), W0(e, "viewBox", "0 0 24 24"), W0(e, "fill", "none"), W0(e, "stroke", "currentColor"), W0(e, "stroke-width", "2"), W0(e, "stroke-linecap", "round"), W0(e, "stroke-linejoin", "round"), W0(e, "class", "feather feather-upload");
    },
    m(i, l) {
      Mu(i, e, l), Ei(e, t), Ei(e, r), Ei(e, a);
    },
    p: Ai,
    i: Ai,
    o: Ai,
    d(i) {
      i && Gn(e);
    }
  };
}
class Lu extends Tu {
  constructor(e) {
    super(), Qu(this, e, null, zu, Bu, {});
  }
}
const {
  SvelteComponent: Iu,
  append_hydration: vs,
  attr: R0,
  children: Fi,
  claim_svg_element: Si,
  detach: ea,
  init: Nu,
  insert_hydration: Ru,
  noop: xi,
  safe_not_equal: qu,
  svg_element: Ci
} = window.__gradio__svelte__internal;
function Ou(n) {
  let e, t, r;
  return {
    c() {
      e = Ci("svg"), t = Ci("polygon"), r = Ci("rect"), this.h();
    },
    l(a) {
      e = Si(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = Fi(e);
      t = Si(i, "polygon", { points: !0 }), Fi(t).forEach(ea), r = Si(i, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), Fi(r).forEach(ea), i.forEach(ea), this.h();
    },
    h() {
      R0(t, "points", "23 7 16 12 23 17 23 7"), R0(r, "x", "1"), R0(r, "y", "5"), R0(r, "width", "15"), R0(r, "height", "14"), R0(r, "rx", "2"), R0(r, "ry", "2"), R0(e, "xmlns", "http://www.w3.org/2000/svg"), R0(e, "width", "100%"), R0(e, "height", "100%"), R0(e, "viewBox", "0 0 24 24"), R0(e, "fill", "none"), R0(e, "stroke", "currentColor"), R0(e, "stroke-width", "1.5"), R0(e, "stroke-linecap", "round"), R0(e, "stroke-linejoin", "round"), R0(e, "class", "feather feather-video");
    },
    m(a, i) {
      Ru(a, e, i), vs(e, t), vs(e, r);
    },
    p: xi,
    i: xi,
    o: xi,
    d(a) {
      a && ea(e);
    }
  };
}
class Kl extends Iu {
  constructor(e) {
    super(), Nu(this, e, null, Ou, qu, {});
  }
}
const {
  SvelteComponent: Pu,
  append_hydration: Wn,
  attr: Q0,
  children: Zn,
  claim_svg_element: Yn,
  claim_text: Hu,
  detach: En,
  init: Vu,
  insert_hydration: Uu,
  noop: Ti,
  safe_not_equal: ju,
  svg_element: Xn,
  text: Gu
} = window.__gradio__svelte__internal;
function Wu(n) {
  let e, t, r, a, i, l;
  return {
    c() {
      e = Xn("svg"), t = Xn("title"), r = Gu("High volume"), a = Xn("path"), i = Xn("path"), l = Xn("path"), this.h();
    },
    l(o) {
      e = Yn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        stroke: !0,
        xmlns: !0,
        color: !0
      });
      var s = Zn(e);
      t = Yn(s, "title", {});
      var u = Zn(t);
      r = Hu(u, "High volume"), u.forEach(En), a = Yn(s, "path", { d: !0, "stroke-width": !0 }), Zn(a).forEach(En), i = Yn(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Zn(i).forEach(En), l = Yn(s, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Zn(l).forEach(En), s.forEach(En), this.h();
    },
    h() {
      Q0(a, "d", "M1 13.8571V10.1429C1 9.03829 1.89543 8.14286 3 8.14286H5.9C6.09569 8.14286 6.28708 8.08544 6.45046 7.97772L12.4495 4.02228C13.1144 3.5839 14 4.06075 14 4.85714V19.1429C14 19.9392 13.1144 20.4161 12.4495 19.9777L6.45046 16.0223C6.28708 15.9146 6.09569 15.8571 5.9 15.8571H3C1.89543 15.8571 1 14.9617 1 13.8571Z"), Q0(a, "stroke-width", "1.5"), Q0(i, "d", "M17.5 7.5C17.5 7.5 19 9 19 11.5C19 14 17.5 15.5 17.5 15.5"), Q0(i, "stroke-width", "1.5"), Q0(i, "stroke-linecap", "round"), Q0(i, "stroke-linejoin", "round"), Q0(l, "d", "M20.5 4.5C20.5 4.5 23 7 23 11.5C23 16 20.5 18.5 20.5 18.5"), Q0(l, "stroke-width", "1.5"), Q0(l, "stroke-linecap", "round"), Q0(l, "stroke-linejoin", "round"), Q0(e, "width", "100%"), Q0(e, "height", "100%"), Q0(e, "viewBox", "0 0 24 24"), Q0(e, "stroke-width", "1.5"), Q0(e, "fill", "none"), Q0(e, "stroke", "currentColor"), Q0(e, "xmlns", "http://www.w3.org/2000/svg"), Q0(e, "color", "currentColor");
    },
    m(o, s) {
      Uu(o, e, s), Wn(e, t), Wn(t, r), Wn(e, a), Wn(e, i), Wn(e, l);
    },
    p: Ti,
    i: Ti,
    o: Ti,
    d(o) {
      o && En(e);
    }
  };
}
class Zu extends Pu {
  constructor(e) {
    super(), Vu(this, e, null, Wu, ju, {});
  }
}
const {
  SvelteComponent: Yu,
  append_hydration: zr,
  attr: F0,
  children: Lr,
  claim_svg_element: Ir,
  claim_text: Xu,
  detach: dr,
  init: Ku,
  insert_hydration: Ju,
  noop: Qi,
  safe_not_equal: $u,
  svg_element: Nr,
  text: e7
} = window.__gradio__svelte__internal;
function t7(n) {
  let e, t, r, a, i, l, o, s, u;
  return {
    c() {
      e = Nr("svg"), t = Nr("title"), r = e7("Muted volume"), a = Nr("g"), i = Nr("path"), l = Nr("path"), o = Nr("defs"), s = Nr("clipPath"), u = Nr("rect"), this.h();
    },
    l(c) {
      e = Ir(c, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-width": !0,
        fill: !0,
        xmlns: !0,
        stroke: !0,
        color: !0
      });
      var d = Lr(e);
      t = Ir(d, "title", {});
      var f = Lr(t);
      r = Xu(f, "Muted volume"), f.forEach(dr), a = Ir(d, "g", { "clip-path": !0 });
      var p = Lr(a);
      i = Ir(p, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Lr(i).forEach(dr), l = Ir(p, "path", { d: !0, "stroke-width": !0 }), Lr(l).forEach(dr), p.forEach(dr), o = Ir(d, "defs", {});
      var b = Lr(o);
      s = Ir(b, "clipPath", { id: !0 });
      var E = Lr(s);
      u = Ir(E, "rect", { width: !0, height: !0, fill: !0 }), Lr(u).forEach(dr), E.forEach(dr), b.forEach(dr), d.forEach(dr), this.h();
    },
    h() {
      F0(i, "d", "M18 14L20.0005 12M22 10L20.0005 12M20.0005 12L18 10M20.0005 12L22 14"), F0(i, "stroke-width", "1.5"), F0(i, "stroke-linecap", "round"), F0(i, "stroke-linejoin", "round"), F0(l, "d", "M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z"), F0(l, "stroke-width", "1.5"), F0(a, "clip-path", "url(#clip0_3173_16686)"), F0(u, "width", "24"), F0(u, "height", "24"), F0(u, "fill", "white"), F0(s, "id", "clip0_3173_16686"), F0(e, "width", "100%"), F0(e, "height", "100%"), F0(e, "viewBox", "0 0 24 24"), F0(e, "stroke-width", "1.5"), F0(e, "fill", "none"), F0(e, "xmlns", "http://www.w3.org/2000/svg"), F0(e, "stroke", "currentColor"), F0(e, "color", "currentColor");
    },
    m(c, d) {
      Ju(c, e, d), zr(e, t), zr(t, r), zr(e, a), zr(a, i), zr(a, l), zr(e, o), zr(o, s), zr(s, u);
    },
    p: Qi,
    i: Qi,
    o: Qi,
    d(c) {
      c && dr(e);
    }
  };
}
class r7 extends Yu {
  constructor(e) {
    super(), Ku(this, e, null, t7, $u, {});
  }
}
const {
  SvelteComponent: n7,
  append_hydration: bs,
  attr: Rr,
  children: Mi,
  claim_svg_element: Bi,
  detach: ta,
  init: a7,
  insert_hydration: i7,
  noop: zi,
  safe_not_equal: l7,
  svg_element: Li
} = window.__gradio__svelte__internal;
function s7(n) {
  let e, t, r;
  return {
    c() {
      e = Li("svg"), t = Li("path"), r = Li("path"), this.h();
    },
    l(a) {
      e = Bi(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = Mi(e);
      t = Bi(i, "path", { fill: !0, d: !0 }), Mi(t).forEach(ta), r = Bi(i, "path", { fill: !0, d: !0 }), Mi(r).forEach(ta), i.forEach(ta), this.h();
    },
    h() {
      Rr(t, "fill", "currentColor"), Rr(t, "d", "M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"), Rr(r, "fill", "currentColor"), Rr(r, "d", "M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"), Rr(e, "xmlns", "http://www.w3.org/2000/svg"), Rr(e, "width", "100%"), Rr(e, "height", "100%"), Rr(e, "viewBox", "0 0 24 24");
    },
    m(a, i) {
      i7(a, e, i), bs(e, t), bs(e, r);
    },
    p: zi,
    i: zi,
    o: zi,
    d(a) {
      a && ta(e);
    }
  };
}
let ws = class extends n7 {
  constructor(e) {
    super(), a7(this, e, null, s7, l7, {});
  }
};
const {
  SvelteComponent: o7,
  append_hydration: ys,
  attr: M0,
  children: Ii,
  claim_svg_element: Ni,
  detach: ra,
  init: u7,
  insert_hydration: c7,
  noop: Ri,
  safe_not_equal: h7,
  svg_element: qi
} = window.__gradio__svelte__internal;
function f7(n) {
  let e, t, r;
  return {
    c() {
      e = qi("svg"), t = qi("circle"), r = qi("animateTransform"), this.h();
    },
    l(a) {
      e = Ni(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        class: !0
      });
      var i = Ii(e);
      t = Ni(i, "circle", {
        cx: !0,
        cy: !0,
        r: !0,
        fill: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-dasharray": !0,
        "stroke-dashoffset": !0
      });
      var l = Ii(t);
      r = Ni(l, "animateTransform", {
        attributeName: !0,
        type: !0,
        from: !0,
        to: !0,
        repeatCount: !0
      }), Ii(r).forEach(ra), l.forEach(ra), i.forEach(ra), this.h();
    },
    h() {
      M0(r, "attributeName", "transform"), M0(r, "type", "rotate"), M0(r, "from", "0 25 25"), M0(r, "to", "360 25 25"), M0(r, "repeatCount", "indefinite"), M0(t, "cx", "25"), M0(t, "cy", "25"), M0(t, "r", "20"), M0(t, "fill", "none"), M0(t, "stroke-width", "3.0"), M0(t, "stroke-linecap", "round"), M0(t, "stroke-dasharray", "94.2477796076938 94.2477796076938"), M0(t, "stroke-dashoffset", "0"), M0(e, "xmlns", "http://www.w3.org/2000/svg"), M0(e, "width", "100%"), M0(e, "height", "100%"), M0(e, "viewBox", "0 0 50 50"), M0(e, "class", "svelte-pb9pol");
    },
    m(a, i) {
      c7(a, e, i), ys(e, t), ys(t, r);
    },
    p: Ri,
    i: Ri,
    o: Ri,
    d(a) {
      a && ra(e);
    }
  };
}
class Jl extends o7 {
  constructor(e) {
    super(), u7(this, e, null, f7, h7, {});
  }
}
class $l {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, r) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = r;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new $l(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class e5 {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new e5(t, $l.range(this, e));
  }
}
class me {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var r = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var o = l.lexer.input;
      a = l.start, i = l.end, a === o.length ? r += " at end of input: " : r += " at position " + (a + 1) + ": ";
      var s = o.slice(a, i).replace(/[^]/g, "$&̲"), u;
      a > 15 ? u = "…" + o.slice(a - 15, a) : u = o.slice(0, a);
      var c;
      i + 15 < o.length ? c = o.slice(i, i + 15) + "…" : c = o.slice(i), r += u + s + c;
    }
    var d = new Error(r);
    return d.name = "ParseError", d.__proto__ = me.prototype, d.position = a, a != null && i != null && (d.length = i - a), d.rawMessage = e, d;
  }
}
me.prototype.__proto__ = Error.prototype;
var d7 = function(e, t) {
  return e.indexOf(t) !== -1;
}, m7 = function(e, t) {
  return e === void 0 ? t : e;
}, p7 = /([A-Z])/g, g7 = function(e) {
  return e.replace(p7, "-$1").toLowerCase();
}, _7 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, v7 = /[&><"']/g;
function b7(n) {
  return String(n).replace(v7, (e) => _7[e]);
}
var x4 = function n(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? n(e.body[0]) : e : e.type === "font" ? n(e.body) : e;
}, w7 = function(e) {
  var t = x4(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, y7 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, k7 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, be = {
  contains: d7,
  deflt: m7,
  escape: b7,
  hyphenate: g7,
  getBaseElem: x4,
  isCharacterBox: w7,
  protocolFromUrl: k7
};
class qr {
  constructor(e, t, r) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = r;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return er[D7[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return er[E7[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return er[A7[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return er[F7[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return er[S7[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return er[x7[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var t5 = 0, Sa = 1, Mn = 2, br = 3, g1 = 4, yt = 5, zn = 6, tt = 7, er = [new qr(t5, 0, !1), new qr(Sa, 0, !0), new qr(Mn, 1, !1), new qr(br, 1, !0), new qr(g1, 2, !1), new qr(yt, 2, !0), new qr(zn, 3, !1), new qr(tt, 3, !0)], D7 = [g1, yt, g1, yt, zn, tt, zn, tt], E7 = [yt, yt, yt, yt, tt, tt, tt, tt], A7 = [Mn, br, g1, yt, zn, tt, zn, tt], F7 = [br, br, yt, yt, tt, tt, tt, tt], S7 = [Sa, Sa, br, br, yt, yt, tt, tt], x7 = [t5, Sa, Mn, br, Mn, br, Mn, br], ke = {
  DISPLAY: er[t5],
  TEXT: er[Mn],
  SCRIPT: er[g1],
  SCRIPTSCRIPT: er[zn]
}, Fl = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function C7(n) {
  for (var e = 0; e < Fl.length; e++)
    for (var t = Fl[e], r = 0; r < t.blocks.length; r++) {
      var a = t.blocks[r];
      if (n >= a[0] && n <= a[1])
        return t.name;
    }
  return null;
}
var ya = [];
Fl.forEach((n) => n.blocks.forEach((e) => ya.push(...e)));
function T7(n) {
  for (var e = 0; e < ya.length; e += 2)
    if (n >= ya[e] && n <= ya[e + 1])
      return !0;
  return !1;
}
var An = 80, Q7 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, M7 = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, B7 = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, z7 = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, L7 = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, I7 = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, N7 = function(e, t, r) {
  var a = r - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, R7 = function(e, t, r) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = Q7(t, An);
      break;
    case "sqrtSize1":
      a = M7(t, An);
      break;
    case "sqrtSize2":
      a = B7(t, An);
      break;
    case "sqrtSize3":
      a = z7(t, An);
      break;
    case "sqrtSize4":
      a = L7(t, An);
      break;
    case "sqrtTall":
      a = N7(t, An, r);
  }
  return a;
}, q7 = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, ks = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, O7 = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class C1 {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return be.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var _r = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, Ds = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function r5(n, e, t) {
  if (!_r[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var r = n.charCodeAt(0), a = _r[e][r];
  if (!a && n[0] in Ds && (r = Ds[n[0]].charCodeAt(0), a = _r[e][r]), !a && t === "text" && T7(r) && (a = _r[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var Sl = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, P7 = {
  ex: !0,
  em: !0,
  mu: !0
}, H7 = function(e) {
  return typeof e != "string" && (e = e.unit), e in Sl || e in P7 || e === "ex";
}, m0 = function(e, t) {
  var r;
  if (e.unit in Sl)
    r = Sl[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    r = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      r = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      r = a.fontMetrics().quad;
    else
      throw new me("Invalid unit: '" + e.unit + "'");
    a !== t && (r *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * r, t.maxSize);
}, te = function(e) {
  return +e.toFixed(4) + "em";
}, Zr = function(e) {
  return e.filter((t) => t).join(" ");
}, C4 = function(e, t, r) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, T4 = function(e) {
  var t = document.createElement(e);
  t.className = Zr(this.classes);
  for (var r in this.style)
    this.style.hasOwnProperty(r) && (t.style[r] = this.style[r]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, Q4 = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + be.escape(Zr(this.classes)) + '"');
  var r = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (r += be.hyphenate(a) + ":" + this.style[a] + ";");
  r && (t += ' style="' + be.escape(r) + '"');
  for (var i in this.attributes)
    this.attributes.hasOwnProperty(i) && (t += " " + i + '="' + be.escape(this.attributes[i]) + '"');
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class Za {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, C4.call(this, e, r, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return be.contains(this.classes, e);
  }
  toNode() {
    return T4.call(this, "span");
  }
  toMarkup() {
    return Q4.call(this, "span");
  }
}
class M4 {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, C4.call(this, t, a), this.children = r || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return be.contains(this.classes, e);
  }
  toNode() {
    return T4.call(this, "a");
  }
  toMarkup() {
    return Q4.call(this, "a");
  }
}
class V7 {
  constructor(e, t, r) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = r;
  }
  hasClass(e) {
    return be.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + be.escape(this.src) + '"' + (' alt="' + be.escape(this.alt) + '"'), t = "";
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t += be.hyphenate(r) + ":" + this.style[r] + ";");
    return t && (e += ' style="' + be.escape(t) + '"'), e += "'/>", e;
  }
}
var U7 = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class sr {
  constructor(e, t, r, a, i, l, o, s) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = r || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
    var u = C7(this.text.charCodeAt(0));
    u && this.classes.push(u + "_fallback"), /[îïíì]/.test(this.text) && (this.text = U7[this.text]);
  }
  hasClass(e) {
    return be.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = te(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = Zr(this.classes));
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t = t || document.createElement("span"), t.style[r] = this.style[r]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += be.escape(Zr(this.classes)), t += '"');
    var r = "";
    this.italic > 0 && (r += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (r += be.hyphenate(a) + ":" + this.style[a] + ";");
    r && (e = !0, t += ' style="' + be.escape(r) + '"');
    var i = be.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class Yr {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + be.escape(this.attributes[t]) + '"');
    e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</svg>", e;
  }
}
class cn {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", ks[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + be.escape(this.alternate) + '"/>' : '<path d="' + be.escape(ks[this.pathName]) + '"/>';
  }
}
class Es {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + be.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function As(n) {
  if (n instanceof sr)
    return n;
  throw new Error("Expected symbolNode but got " + String(n) + ".");
}
function j7(n) {
  if (n instanceof Za)
    return n;
  throw new Error("Expected span<HtmlDomNode> but got " + String(n) + ".");
}
var G7 = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, w0 = {
  math: {},
  text: {}
};
function h(n, e, t, r, a, i) {
  w0[n][a] = {
    font: e,
    group: t,
    replace: r
  }, i && r && (w0[n][r] = w0[n][a]);
}
var m = "math", Z = "text", g = "main", F = "ams", f0 = "accent-token", ie = "bin", nt = "close", Rn = "inner", ve = "mathord", E0 = "op-token", mt = "open", Ya = "punct", S = "rel", xr = "spacing", C = "textord";
h(m, g, S, "≡", "\\equiv", !0);
h(m, g, S, "≺", "\\prec", !0);
h(m, g, S, "≻", "\\succ", !0);
h(m, g, S, "∼", "\\sim", !0);
h(m, g, S, "⊥", "\\perp");
h(m, g, S, "⪯", "\\preceq", !0);
h(m, g, S, "⪰", "\\succeq", !0);
h(m, g, S, "≃", "\\simeq", !0);
h(m, g, S, "∣", "\\mid", !0);
h(m, g, S, "≪", "\\ll", !0);
h(m, g, S, "≫", "\\gg", !0);
h(m, g, S, "≍", "\\asymp", !0);
h(m, g, S, "∥", "\\parallel");
h(m, g, S, "⋈", "\\bowtie", !0);
h(m, g, S, "⌣", "\\smile", !0);
h(m, g, S, "⊑", "\\sqsubseteq", !0);
h(m, g, S, "⊒", "\\sqsupseteq", !0);
h(m, g, S, "≐", "\\doteq", !0);
h(m, g, S, "⌢", "\\frown", !0);
h(m, g, S, "∋", "\\ni", !0);
h(m, g, S, "∝", "\\propto", !0);
h(m, g, S, "⊢", "\\vdash", !0);
h(m, g, S, "⊣", "\\dashv", !0);
h(m, g, S, "∋", "\\owns");
h(m, g, Ya, ".", "\\ldotp");
h(m, g, Ya, "⋅", "\\cdotp");
h(m, g, C, "#", "\\#");
h(Z, g, C, "#", "\\#");
h(m, g, C, "&", "\\&");
h(Z, g, C, "&", "\\&");
h(m, g, C, "ℵ", "\\aleph", !0);
h(m, g, C, "∀", "\\forall", !0);
h(m, g, C, "ℏ", "\\hbar", !0);
h(m, g, C, "∃", "\\exists", !0);
h(m, g, C, "∇", "\\nabla", !0);
h(m, g, C, "♭", "\\flat", !0);
h(m, g, C, "ℓ", "\\ell", !0);
h(m, g, C, "♮", "\\natural", !0);
h(m, g, C, "♣", "\\clubsuit", !0);
h(m, g, C, "℘", "\\wp", !0);
h(m, g, C, "♯", "\\sharp", !0);
h(m, g, C, "♢", "\\diamondsuit", !0);
h(m, g, C, "ℜ", "\\Re", !0);
h(m, g, C, "♡", "\\heartsuit", !0);
h(m, g, C, "ℑ", "\\Im", !0);
h(m, g, C, "♠", "\\spadesuit", !0);
h(m, g, C, "§", "\\S", !0);
h(Z, g, C, "§", "\\S");
h(m, g, C, "¶", "\\P", !0);
h(Z, g, C, "¶", "\\P");
h(m, g, C, "†", "\\dag");
h(Z, g, C, "†", "\\dag");
h(Z, g, C, "†", "\\textdagger");
h(m, g, C, "‡", "\\ddag");
h(Z, g, C, "‡", "\\ddag");
h(Z, g, C, "‡", "\\textdaggerdbl");
h(m, g, nt, "⎱", "\\rmoustache", !0);
h(m, g, mt, "⎰", "\\lmoustache", !0);
h(m, g, nt, "⟯", "\\rgroup", !0);
h(m, g, mt, "⟮", "\\lgroup", !0);
h(m, g, ie, "∓", "\\mp", !0);
h(m, g, ie, "⊖", "\\ominus", !0);
h(m, g, ie, "⊎", "\\uplus", !0);
h(m, g, ie, "⊓", "\\sqcap", !0);
h(m, g, ie, "∗", "\\ast");
h(m, g, ie, "⊔", "\\sqcup", !0);
h(m, g, ie, "◯", "\\bigcirc", !0);
h(m, g, ie, "∙", "\\bullet", !0);
h(m, g, ie, "‡", "\\ddagger");
h(m, g, ie, "≀", "\\wr", !0);
h(m, g, ie, "⨿", "\\amalg");
h(m, g, ie, "&", "\\And");
h(m, g, S, "⟵", "\\longleftarrow", !0);
h(m, g, S, "⇐", "\\Leftarrow", !0);
h(m, g, S, "⟸", "\\Longleftarrow", !0);
h(m, g, S, "⟶", "\\longrightarrow", !0);
h(m, g, S, "⇒", "\\Rightarrow", !0);
h(m, g, S, "⟹", "\\Longrightarrow", !0);
h(m, g, S, "↔", "\\leftrightarrow", !0);
h(m, g, S, "⟷", "\\longleftrightarrow", !0);
h(m, g, S, "⇔", "\\Leftrightarrow", !0);
h(m, g, S, "⟺", "\\Longleftrightarrow", !0);
h(m, g, S, "↦", "\\mapsto", !0);
h(m, g, S, "⟼", "\\longmapsto", !0);
h(m, g, S, "↗", "\\nearrow", !0);
h(m, g, S, "↩", "\\hookleftarrow", !0);
h(m, g, S, "↪", "\\hookrightarrow", !0);
h(m, g, S, "↘", "\\searrow", !0);
h(m, g, S, "↼", "\\leftharpoonup", !0);
h(m, g, S, "⇀", "\\rightharpoonup", !0);
h(m, g, S, "↙", "\\swarrow", !0);
h(m, g, S, "↽", "\\leftharpoondown", !0);
h(m, g, S, "⇁", "\\rightharpoondown", !0);
h(m, g, S, "↖", "\\nwarrow", !0);
h(m, g, S, "⇌", "\\rightleftharpoons", !0);
h(m, F, S, "≮", "\\nless", !0);
h(m, F, S, "", "\\@nleqslant");
h(m, F, S, "", "\\@nleqq");
h(m, F, S, "⪇", "\\lneq", !0);
h(m, F, S, "≨", "\\lneqq", !0);
h(m, F, S, "", "\\@lvertneqq");
h(m, F, S, "⋦", "\\lnsim", !0);
h(m, F, S, "⪉", "\\lnapprox", !0);
h(m, F, S, "⊀", "\\nprec", !0);
h(m, F, S, "⋠", "\\npreceq", !0);
h(m, F, S, "⋨", "\\precnsim", !0);
h(m, F, S, "⪹", "\\precnapprox", !0);
h(m, F, S, "≁", "\\nsim", !0);
h(m, F, S, "", "\\@nshortmid");
h(m, F, S, "∤", "\\nmid", !0);
h(m, F, S, "⊬", "\\nvdash", !0);
h(m, F, S, "⊭", "\\nvDash", !0);
h(m, F, S, "⋪", "\\ntriangleleft");
h(m, F, S, "⋬", "\\ntrianglelefteq", !0);
h(m, F, S, "⊊", "\\subsetneq", !0);
h(m, F, S, "", "\\@varsubsetneq");
h(m, F, S, "⫋", "\\subsetneqq", !0);
h(m, F, S, "", "\\@varsubsetneqq");
h(m, F, S, "≯", "\\ngtr", !0);
h(m, F, S, "", "\\@ngeqslant");
h(m, F, S, "", "\\@ngeqq");
h(m, F, S, "⪈", "\\gneq", !0);
h(m, F, S, "≩", "\\gneqq", !0);
h(m, F, S, "", "\\@gvertneqq");
h(m, F, S, "⋧", "\\gnsim", !0);
h(m, F, S, "⪊", "\\gnapprox", !0);
h(m, F, S, "⊁", "\\nsucc", !0);
h(m, F, S, "⋡", "\\nsucceq", !0);
h(m, F, S, "⋩", "\\succnsim", !0);
h(m, F, S, "⪺", "\\succnapprox", !0);
h(m, F, S, "≆", "\\ncong", !0);
h(m, F, S, "", "\\@nshortparallel");
h(m, F, S, "∦", "\\nparallel", !0);
h(m, F, S, "⊯", "\\nVDash", !0);
h(m, F, S, "⋫", "\\ntriangleright");
h(m, F, S, "⋭", "\\ntrianglerighteq", !0);
h(m, F, S, "", "\\@nsupseteqq");
h(m, F, S, "⊋", "\\supsetneq", !0);
h(m, F, S, "", "\\@varsupsetneq");
h(m, F, S, "⫌", "\\supsetneqq", !0);
h(m, F, S, "", "\\@varsupsetneqq");
h(m, F, S, "⊮", "\\nVdash", !0);
h(m, F, S, "⪵", "\\precneqq", !0);
h(m, F, S, "⪶", "\\succneqq", !0);
h(m, F, S, "", "\\@nsubseteqq");
h(m, F, ie, "⊴", "\\unlhd");
h(m, F, ie, "⊵", "\\unrhd");
h(m, F, S, "↚", "\\nleftarrow", !0);
h(m, F, S, "↛", "\\nrightarrow", !0);
h(m, F, S, "⇍", "\\nLeftarrow", !0);
h(m, F, S, "⇏", "\\nRightarrow", !0);
h(m, F, S, "↮", "\\nleftrightarrow", !0);
h(m, F, S, "⇎", "\\nLeftrightarrow", !0);
h(m, F, S, "△", "\\vartriangle");
h(m, F, C, "ℏ", "\\hslash");
h(m, F, C, "▽", "\\triangledown");
h(m, F, C, "◊", "\\lozenge");
h(m, F, C, "Ⓢ", "\\circledS");
h(m, F, C, "®", "\\circledR");
h(Z, F, C, "®", "\\circledR");
h(m, F, C, "∡", "\\measuredangle", !0);
h(m, F, C, "∄", "\\nexists");
h(m, F, C, "℧", "\\mho");
h(m, F, C, "Ⅎ", "\\Finv", !0);
h(m, F, C, "⅁", "\\Game", !0);
h(m, F, C, "‵", "\\backprime");
h(m, F, C, "▲", "\\blacktriangle");
h(m, F, C, "▼", "\\blacktriangledown");
h(m, F, C, "■", "\\blacksquare");
h(m, F, C, "⧫", "\\blacklozenge");
h(m, F, C, "★", "\\bigstar");
h(m, F, C, "∢", "\\sphericalangle", !0);
h(m, F, C, "∁", "\\complement", !0);
h(m, F, C, "ð", "\\eth", !0);
h(Z, g, C, "ð", "ð");
h(m, F, C, "╱", "\\diagup");
h(m, F, C, "╲", "\\diagdown");
h(m, F, C, "□", "\\square");
h(m, F, C, "□", "\\Box");
h(m, F, C, "◊", "\\Diamond");
h(m, F, C, "¥", "\\yen", !0);
h(Z, F, C, "¥", "\\yen", !0);
h(m, F, C, "✓", "\\checkmark", !0);
h(Z, F, C, "✓", "\\checkmark");
h(m, F, C, "ℶ", "\\beth", !0);
h(m, F, C, "ℸ", "\\daleth", !0);
h(m, F, C, "ℷ", "\\gimel", !0);
h(m, F, C, "ϝ", "\\digamma", !0);
h(m, F, C, "ϰ", "\\varkappa");
h(m, F, mt, "┌", "\\@ulcorner", !0);
h(m, F, nt, "┐", "\\@urcorner", !0);
h(m, F, mt, "└", "\\@llcorner", !0);
h(m, F, nt, "┘", "\\@lrcorner", !0);
h(m, F, S, "≦", "\\leqq", !0);
h(m, F, S, "⩽", "\\leqslant", !0);
h(m, F, S, "⪕", "\\eqslantless", !0);
h(m, F, S, "≲", "\\lesssim", !0);
h(m, F, S, "⪅", "\\lessapprox", !0);
h(m, F, S, "≊", "\\approxeq", !0);
h(m, F, ie, "⋖", "\\lessdot");
h(m, F, S, "⋘", "\\lll", !0);
h(m, F, S, "≶", "\\lessgtr", !0);
h(m, F, S, "⋚", "\\lesseqgtr", !0);
h(m, F, S, "⪋", "\\lesseqqgtr", !0);
h(m, F, S, "≑", "\\doteqdot");
h(m, F, S, "≓", "\\risingdotseq", !0);
h(m, F, S, "≒", "\\fallingdotseq", !0);
h(m, F, S, "∽", "\\backsim", !0);
h(m, F, S, "⋍", "\\backsimeq", !0);
h(m, F, S, "⫅", "\\subseteqq", !0);
h(m, F, S, "⋐", "\\Subset", !0);
h(m, F, S, "⊏", "\\sqsubset", !0);
h(m, F, S, "≼", "\\preccurlyeq", !0);
h(m, F, S, "⋞", "\\curlyeqprec", !0);
h(m, F, S, "≾", "\\precsim", !0);
h(m, F, S, "⪷", "\\precapprox", !0);
h(m, F, S, "⊲", "\\vartriangleleft");
h(m, F, S, "⊴", "\\trianglelefteq");
h(m, F, S, "⊨", "\\vDash", !0);
h(m, F, S, "⊪", "\\Vvdash", !0);
h(m, F, S, "⌣", "\\smallsmile");
h(m, F, S, "⌢", "\\smallfrown");
h(m, F, S, "≏", "\\bumpeq", !0);
h(m, F, S, "≎", "\\Bumpeq", !0);
h(m, F, S, "≧", "\\geqq", !0);
h(m, F, S, "⩾", "\\geqslant", !0);
h(m, F, S, "⪖", "\\eqslantgtr", !0);
h(m, F, S, "≳", "\\gtrsim", !0);
h(m, F, S, "⪆", "\\gtrapprox", !0);
h(m, F, ie, "⋗", "\\gtrdot");
h(m, F, S, "⋙", "\\ggg", !0);
h(m, F, S, "≷", "\\gtrless", !0);
h(m, F, S, "⋛", "\\gtreqless", !0);
h(m, F, S, "⪌", "\\gtreqqless", !0);
h(m, F, S, "≖", "\\eqcirc", !0);
h(m, F, S, "≗", "\\circeq", !0);
h(m, F, S, "≜", "\\triangleq", !0);
h(m, F, S, "∼", "\\thicksim");
h(m, F, S, "≈", "\\thickapprox");
h(m, F, S, "⫆", "\\supseteqq", !0);
h(m, F, S, "⋑", "\\Supset", !0);
h(m, F, S, "⊐", "\\sqsupset", !0);
h(m, F, S, "≽", "\\succcurlyeq", !0);
h(m, F, S, "⋟", "\\curlyeqsucc", !0);
h(m, F, S, "≿", "\\succsim", !0);
h(m, F, S, "⪸", "\\succapprox", !0);
h(m, F, S, "⊳", "\\vartriangleright");
h(m, F, S, "⊵", "\\trianglerighteq");
h(m, F, S, "⊩", "\\Vdash", !0);
h(m, F, S, "∣", "\\shortmid");
h(m, F, S, "∥", "\\shortparallel");
h(m, F, S, "≬", "\\between", !0);
h(m, F, S, "⋔", "\\pitchfork", !0);
h(m, F, S, "∝", "\\varpropto");
h(m, F, S, "◀", "\\blacktriangleleft");
h(m, F, S, "∴", "\\therefore", !0);
h(m, F, S, "∍", "\\backepsilon");
h(m, F, S, "▶", "\\blacktriangleright");
h(m, F, S, "∵", "\\because", !0);
h(m, F, S, "⋘", "\\llless");
h(m, F, S, "⋙", "\\gggtr");
h(m, F, ie, "⊲", "\\lhd");
h(m, F, ie, "⊳", "\\rhd");
h(m, F, S, "≂", "\\eqsim", !0);
h(m, g, S, "⋈", "\\Join");
h(m, F, S, "≑", "\\Doteq", !0);
h(m, F, ie, "∔", "\\dotplus", !0);
h(m, F, ie, "∖", "\\smallsetminus");
h(m, F, ie, "⋒", "\\Cap", !0);
h(m, F, ie, "⋓", "\\Cup", !0);
h(m, F, ie, "⩞", "\\doublebarwedge", !0);
h(m, F, ie, "⊟", "\\boxminus", !0);
h(m, F, ie, "⊞", "\\boxplus", !0);
h(m, F, ie, "⋇", "\\divideontimes", !0);
h(m, F, ie, "⋉", "\\ltimes", !0);
h(m, F, ie, "⋊", "\\rtimes", !0);
h(m, F, ie, "⋋", "\\leftthreetimes", !0);
h(m, F, ie, "⋌", "\\rightthreetimes", !0);
h(m, F, ie, "⋏", "\\curlywedge", !0);
h(m, F, ie, "⋎", "\\curlyvee", !0);
h(m, F, ie, "⊝", "\\circleddash", !0);
h(m, F, ie, "⊛", "\\circledast", !0);
h(m, F, ie, "⋅", "\\centerdot");
h(m, F, ie, "⊺", "\\intercal", !0);
h(m, F, ie, "⋒", "\\doublecap");
h(m, F, ie, "⋓", "\\doublecup");
h(m, F, ie, "⊠", "\\boxtimes", !0);
h(m, F, S, "⇢", "\\dashrightarrow", !0);
h(m, F, S, "⇠", "\\dashleftarrow", !0);
h(m, F, S, "⇇", "\\leftleftarrows", !0);
h(m, F, S, "⇆", "\\leftrightarrows", !0);
h(m, F, S, "⇚", "\\Lleftarrow", !0);
h(m, F, S, "↞", "\\twoheadleftarrow", !0);
h(m, F, S, "↢", "\\leftarrowtail", !0);
h(m, F, S, "↫", "\\looparrowleft", !0);
h(m, F, S, "⇋", "\\leftrightharpoons", !0);
h(m, F, S, "↶", "\\curvearrowleft", !0);
h(m, F, S, "↺", "\\circlearrowleft", !0);
h(m, F, S, "↰", "\\Lsh", !0);
h(m, F, S, "⇈", "\\upuparrows", !0);
h(m, F, S, "↿", "\\upharpoonleft", !0);
h(m, F, S, "⇃", "\\downharpoonleft", !0);
h(m, g, S, "⊶", "\\origof", !0);
h(m, g, S, "⊷", "\\imageof", !0);
h(m, F, S, "⊸", "\\multimap", !0);
h(m, F, S, "↭", "\\leftrightsquigarrow", !0);
h(m, F, S, "⇉", "\\rightrightarrows", !0);
h(m, F, S, "⇄", "\\rightleftarrows", !0);
h(m, F, S, "↠", "\\twoheadrightarrow", !0);
h(m, F, S, "↣", "\\rightarrowtail", !0);
h(m, F, S, "↬", "\\looparrowright", !0);
h(m, F, S, "↷", "\\curvearrowright", !0);
h(m, F, S, "↻", "\\circlearrowright", !0);
h(m, F, S, "↱", "\\Rsh", !0);
h(m, F, S, "⇊", "\\downdownarrows", !0);
h(m, F, S, "↾", "\\upharpoonright", !0);
h(m, F, S, "⇂", "\\downharpoonright", !0);
h(m, F, S, "⇝", "\\rightsquigarrow", !0);
h(m, F, S, "⇝", "\\leadsto");
h(m, F, S, "⇛", "\\Rrightarrow", !0);
h(m, F, S, "↾", "\\restriction");
h(m, g, C, "‘", "`");
h(m, g, C, "$", "\\$");
h(Z, g, C, "$", "\\$");
h(Z, g, C, "$", "\\textdollar");
h(m, g, C, "%", "\\%");
h(Z, g, C, "%", "\\%");
h(m, g, C, "_", "\\_");
h(Z, g, C, "_", "\\_");
h(Z, g, C, "_", "\\textunderscore");
h(m, g, C, "∠", "\\angle", !0);
h(m, g, C, "∞", "\\infty", !0);
h(m, g, C, "′", "\\prime");
h(m, g, C, "△", "\\triangle");
h(m, g, C, "Γ", "\\Gamma", !0);
h(m, g, C, "Δ", "\\Delta", !0);
h(m, g, C, "Θ", "\\Theta", !0);
h(m, g, C, "Λ", "\\Lambda", !0);
h(m, g, C, "Ξ", "\\Xi", !0);
h(m, g, C, "Π", "\\Pi", !0);
h(m, g, C, "Σ", "\\Sigma", !0);
h(m, g, C, "Υ", "\\Upsilon", !0);
h(m, g, C, "Φ", "\\Phi", !0);
h(m, g, C, "Ψ", "\\Psi", !0);
h(m, g, C, "Ω", "\\Omega", !0);
h(m, g, C, "A", "Α");
h(m, g, C, "B", "Β");
h(m, g, C, "E", "Ε");
h(m, g, C, "Z", "Ζ");
h(m, g, C, "H", "Η");
h(m, g, C, "I", "Ι");
h(m, g, C, "K", "Κ");
h(m, g, C, "M", "Μ");
h(m, g, C, "N", "Ν");
h(m, g, C, "O", "Ο");
h(m, g, C, "P", "Ρ");
h(m, g, C, "T", "Τ");
h(m, g, C, "X", "Χ");
h(m, g, C, "¬", "\\neg", !0);
h(m, g, C, "¬", "\\lnot");
h(m, g, C, "⊤", "\\top");
h(m, g, C, "⊥", "\\bot");
h(m, g, C, "∅", "\\emptyset");
h(m, F, C, "∅", "\\varnothing");
h(m, g, ve, "α", "\\alpha", !0);
h(m, g, ve, "β", "\\beta", !0);
h(m, g, ve, "γ", "\\gamma", !0);
h(m, g, ve, "δ", "\\delta", !0);
h(m, g, ve, "ϵ", "\\epsilon", !0);
h(m, g, ve, "ζ", "\\zeta", !0);
h(m, g, ve, "η", "\\eta", !0);
h(m, g, ve, "θ", "\\theta", !0);
h(m, g, ve, "ι", "\\iota", !0);
h(m, g, ve, "κ", "\\kappa", !0);
h(m, g, ve, "λ", "\\lambda", !0);
h(m, g, ve, "μ", "\\mu", !0);
h(m, g, ve, "ν", "\\nu", !0);
h(m, g, ve, "ξ", "\\xi", !0);
h(m, g, ve, "ο", "\\omicron", !0);
h(m, g, ve, "π", "\\pi", !0);
h(m, g, ve, "ρ", "\\rho", !0);
h(m, g, ve, "σ", "\\sigma", !0);
h(m, g, ve, "τ", "\\tau", !0);
h(m, g, ve, "υ", "\\upsilon", !0);
h(m, g, ve, "ϕ", "\\phi", !0);
h(m, g, ve, "χ", "\\chi", !0);
h(m, g, ve, "ψ", "\\psi", !0);
h(m, g, ve, "ω", "\\omega", !0);
h(m, g, ve, "ε", "\\varepsilon", !0);
h(m, g, ve, "ϑ", "\\vartheta", !0);
h(m, g, ve, "ϖ", "\\varpi", !0);
h(m, g, ve, "ϱ", "\\varrho", !0);
h(m, g, ve, "ς", "\\varsigma", !0);
h(m, g, ve, "φ", "\\varphi", !0);
h(m, g, ie, "∗", "*", !0);
h(m, g, ie, "+", "+");
h(m, g, ie, "−", "-", !0);
h(m, g, ie, "⋅", "\\cdot", !0);
h(m, g, ie, "∘", "\\circ", !0);
h(m, g, ie, "÷", "\\div", !0);
h(m, g, ie, "±", "\\pm", !0);
h(m, g, ie, "×", "\\times", !0);
h(m, g, ie, "∩", "\\cap", !0);
h(m, g, ie, "∪", "\\cup", !0);
h(m, g, ie, "∖", "\\setminus", !0);
h(m, g, ie, "∧", "\\land");
h(m, g, ie, "∨", "\\lor");
h(m, g, ie, "∧", "\\wedge", !0);
h(m, g, ie, "∨", "\\vee", !0);
h(m, g, C, "√", "\\surd");
h(m, g, mt, "⟨", "\\langle", !0);
h(m, g, mt, "∣", "\\lvert");
h(m, g, mt, "∥", "\\lVert");
h(m, g, nt, "?", "?");
h(m, g, nt, "!", "!");
h(m, g, nt, "⟩", "\\rangle", !0);
h(m, g, nt, "∣", "\\rvert");
h(m, g, nt, "∥", "\\rVert");
h(m, g, S, "=", "=");
h(m, g, S, ":", ":");
h(m, g, S, "≈", "\\approx", !0);
h(m, g, S, "≅", "\\cong", !0);
h(m, g, S, "≥", "\\ge");
h(m, g, S, "≥", "\\geq", !0);
h(m, g, S, "←", "\\gets");
h(m, g, S, ">", "\\gt", !0);
h(m, g, S, "∈", "\\in", !0);
h(m, g, S, "", "\\@not");
h(m, g, S, "⊂", "\\subset", !0);
h(m, g, S, "⊃", "\\supset", !0);
h(m, g, S, "⊆", "\\subseteq", !0);
h(m, g, S, "⊇", "\\supseteq", !0);
h(m, F, S, "⊈", "\\nsubseteq", !0);
h(m, F, S, "⊉", "\\nsupseteq", !0);
h(m, g, S, "⊨", "\\models");
h(m, g, S, "←", "\\leftarrow", !0);
h(m, g, S, "≤", "\\le");
h(m, g, S, "≤", "\\leq", !0);
h(m, g, S, "<", "\\lt", !0);
h(m, g, S, "→", "\\rightarrow", !0);
h(m, g, S, "→", "\\to");
h(m, F, S, "≱", "\\ngeq", !0);
h(m, F, S, "≰", "\\nleq", !0);
h(m, g, xr, " ", "\\ ");
h(m, g, xr, " ", "\\space");
h(m, g, xr, " ", "\\nobreakspace");
h(Z, g, xr, " ", "\\ ");
h(Z, g, xr, " ", " ");
h(Z, g, xr, " ", "\\space");
h(Z, g, xr, " ", "\\nobreakspace");
h(m, g, xr, null, "\\nobreak");
h(m, g, xr, null, "\\allowbreak");
h(m, g, Ya, ",", ",");
h(m, g, Ya, ";", ";");
h(m, F, ie, "⊼", "\\barwedge", !0);
h(m, F, ie, "⊻", "\\veebar", !0);
h(m, g, ie, "⊙", "\\odot", !0);
h(m, g, ie, "⊕", "\\oplus", !0);
h(m, g, ie, "⊗", "\\otimes", !0);
h(m, g, C, "∂", "\\partial", !0);
h(m, g, ie, "⊘", "\\oslash", !0);
h(m, F, ie, "⊚", "\\circledcirc", !0);
h(m, F, ie, "⊡", "\\boxdot", !0);
h(m, g, ie, "△", "\\bigtriangleup");
h(m, g, ie, "▽", "\\bigtriangledown");
h(m, g, ie, "†", "\\dagger");
h(m, g, ie, "⋄", "\\diamond");
h(m, g, ie, "⋆", "\\star");
h(m, g, ie, "◃", "\\triangleleft");
h(m, g, ie, "▹", "\\triangleright");
h(m, g, mt, "{", "\\{");
h(Z, g, C, "{", "\\{");
h(Z, g, C, "{", "\\textbraceleft");
h(m, g, nt, "}", "\\}");
h(Z, g, C, "}", "\\}");
h(Z, g, C, "}", "\\textbraceright");
h(m, g, mt, "{", "\\lbrace");
h(m, g, nt, "}", "\\rbrace");
h(m, g, mt, "[", "\\lbrack", !0);
h(Z, g, C, "[", "\\lbrack", !0);
h(m, g, nt, "]", "\\rbrack", !0);
h(Z, g, C, "]", "\\rbrack", !0);
h(m, g, mt, "(", "\\lparen", !0);
h(m, g, nt, ")", "\\rparen", !0);
h(Z, g, C, "<", "\\textless", !0);
h(Z, g, C, ">", "\\textgreater", !0);
h(m, g, mt, "⌊", "\\lfloor", !0);
h(m, g, nt, "⌋", "\\rfloor", !0);
h(m, g, mt, "⌈", "\\lceil", !0);
h(m, g, nt, "⌉", "\\rceil", !0);
h(m, g, C, "\\", "\\backslash");
h(m, g, C, "∣", "|");
h(m, g, C, "∣", "\\vert");
h(Z, g, C, "|", "\\textbar", !0);
h(m, g, C, "∥", "\\|");
h(m, g, C, "∥", "\\Vert");
h(Z, g, C, "∥", "\\textbardbl");
h(Z, g, C, "~", "\\textasciitilde");
h(Z, g, C, "\\", "\\textbackslash");
h(Z, g, C, "^", "\\textasciicircum");
h(m, g, S, "↑", "\\uparrow", !0);
h(m, g, S, "⇑", "\\Uparrow", !0);
h(m, g, S, "↓", "\\downarrow", !0);
h(m, g, S, "⇓", "\\Downarrow", !0);
h(m, g, S, "↕", "\\updownarrow", !0);
h(m, g, S, "⇕", "\\Updownarrow", !0);
h(m, g, E0, "∐", "\\coprod");
h(m, g, E0, "⋁", "\\bigvee");
h(m, g, E0, "⋀", "\\bigwedge");
h(m, g, E0, "⨄", "\\biguplus");
h(m, g, E0, "⋂", "\\bigcap");
h(m, g, E0, "⋃", "\\bigcup");
h(m, g, E0, "∫", "\\int");
h(m, g, E0, "∫", "\\intop");
h(m, g, E0, "∬", "\\iint");
h(m, g, E0, "∭", "\\iiint");
h(m, g, E0, "∏", "\\prod");
h(m, g, E0, "∑", "\\sum");
h(m, g, E0, "⨂", "\\bigotimes");
h(m, g, E0, "⨁", "\\bigoplus");
h(m, g, E0, "⨀", "\\bigodot");
h(m, g, E0, "∮", "\\oint");
h(m, g, E0, "∯", "\\oiint");
h(m, g, E0, "∰", "\\oiiint");
h(m, g, E0, "⨆", "\\bigsqcup");
h(m, g, E0, "∫", "\\smallint");
h(Z, g, Rn, "…", "\\textellipsis");
h(m, g, Rn, "…", "\\mathellipsis");
h(Z, g, Rn, "…", "\\ldots", !0);
h(m, g, Rn, "…", "\\ldots", !0);
h(m, g, Rn, "⋯", "\\@cdots", !0);
h(m, g, Rn, "⋱", "\\ddots", !0);
h(m, g, C, "⋮", "\\varvdots");
h(m, g, f0, "ˊ", "\\acute");
h(m, g, f0, "ˋ", "\\grave");
h(m, g, f0, "¨", "\\ddot");
h(m, g, f0, "~", "\\tilde");
h(m, g, f0, "ˉ", "\\bar");
h(m, g, f0, "˘", "\\breve");
h(m, g, f0, "ˇ", "\\check");
h(m, g, f0, "^", "\\hat");
h(m, g, f0, "⃗", "\\vec");
h(m, g, f0, "˙", "\\dot");
h(m, g, f0, "˚", "\\mathring");
h(m, g, ve, "", "\\@imath");
h(m, g, ve, "", "\\@jmath");
h(m, g, C, "ı", "ı");
h(m, g, C, "ȷ", "ȷ");
h(Z, g, C, "ı", "\\i", !0);
h(Z, g, C, "ȷ", "\\j", !0);
h(Z, g, C, "ß", "\\ss", !0);
h(Z, g, C, "æ", "\\ae", !0);
h(Z, g, C, "œ", "\\oe", !0);
h(Z, g, C, "ø", "\\o", !0);
h(Z, g, C, "Æ", "\\AE", !0);
h(Z, g, C, "Œ", "\\OE", !0);
h(Z, g, C, "Ø", "\\O", !0);
h(Z, g, f0, "ˊ", "\\'");
h(Z, g, f0, "ˋ", "\\`");
h(Z, g, f0, "ˆ", "\\^");
h(Z, g, f0, "˜", "\\~");
h(Z, g, f0, "ˉ", "\\=");
h(Z, g, f0, "˘", "\\u");
h(Z, g, f0, "˙", "\\.");
h(Z, g, f0, "¸", "\\c");
h(Z, g, f0, "˚", "\\r");
h(Z, g, f0, "ˇ", "\\v");
h(Z, g, f0, "¨", '\\"');
h(Z, g, f0, "˝", "\\H");
h(Z, g, f0, "◯", "\\textcircled");
var B4 = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
h(Z, g, C, "–", "--", !0);
h(Z, g, C, "–", "\\textendash");
h(Z, g, C, "—", "---", !0);
h(Z, g, C, "—", "\\textemdash");
h(Z, g, C, "‘", "`", !0);
h(Z, g, C, "‘", "\\textquoteleft");
h(Z, g, C, "’", "'", !0);
h(Z, g, C, "’", "\\textquoteright");
h(Z, g, C, "“", "``", !0);
h(Z, g, C, "“", "\\textquotedblleft");
h(Z, g, C, "”", "''", !0);
h(Z, g, C, "”", "\\textquotedblright");
h(m, g, C, "°", "\\degree", !0);
h(Z, g, C, "°", "\\degree");
h(Z, g, C, "°", "\\textdegree", !0);
h(m, g, C, "£", "\\pounds");
h(m, g, C, "£", "\\mathsterling", !0);
h(Z, g, C, "£", "\\pounds");
h(Z, g, C, "£", "\\textsterling", !0);
h(m, F, C, "✠", "\\maltese");
h(Z, F, C, "✠", "\\maltese");
var Fs = '0123456789/@."';
for (var Oi = 0; Oi < Fs.length; Oi++) {
  var Ss = Fs.charAt(Oi);
  h(m, g, C, Ss, Ss);
}
var xs = '0123456789!@*()-=+";:?/.,';
for (var Pi = 0; Pi < xs.length; Pi++) {
  var Cs = xs.charAt(Pi);
  h(Z, g, C, Cs, Cs);
}
var xa = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Hi = 0; Hi < xa.length; Hi++) {
  var na = xa.charAt(Hi);
  h(m, g, ve, na, na), h(Z, g, C, na, na);
}
h(m, F, C, "C", "ℂ");
h(Z, F, C, "C", "ℂ");
h(m, F, C, "H", "ℍ");
h(Z, F, C, "H", "ℍ");
h(m, F, C, "N", "ℕ");
h(Z, F, C, "N", "ℕ");
h(m, F, C, "P", "ℙ");
h(Z, F, C, "P", "ℙ");
h(m, F, C, "Q", "ℚ");
h(Z, F, C, "Q", "ℚ");
h(m, F, C, "R", "ℝ");
h(Z, F, C, "R", "ℝ");
h(m, F, C, "Z", "ℤ");
h(Z, F, C, "Z", "ℤ");
h(m, g, ve, "h", "ℎ");
h(Z, g, ve, "h", "ℎ");
var Fe = "";
for (var $0 = 0; $0 < xa.length; $0++) {
  var _0 = xa.charAt($0);
  Fe = String.fromCharCode(55349, 56320 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56372 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56424 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56580 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56684 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56736 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56788 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56840 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56944 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), $0 < 26 && (Fe = String.fromCharCode(55349, 56632 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe), Fe = String.fromCharCode(55349, 56476 + $0), h(m, g, ve, _0, Fe), h(Z, g, C, _0, Fe));
}
Fe = "𝕜";
h(m, g, ve, "k", Fe);
h(Z, g, C, "k", Fe);
for (var $r = 0; $r < 10; $r++) {
  var Or = $r.toString();
  Fe = String.fromCharCode(55349, 57294 + $r), h(m, g, ve, Or, Fe), h(Z, g, C, Or, Fe), Fe = String.fromCharCode(55349, 57314 + $r), h(m, g, ve, Or, Fe), h(Z, g, C, Or, Fe), Fe = String.fromCharCode(55349, 57324 + $r), h(m, g, ve, Or, Fe), h(Z, g, C, Or, Fe), Fe = String.fromCharCode(55349, 57334 + $r), h(m, g, ve, Or, Fe), h(Z, g, C, Or, Fe);
}
var Ts = "ÐÞþ";
for (var Vi = 0; Vi < Ts.length; Vi++) {
  var aa = Ts.charAt(Vi);
  h(m, g, ve, aa, aa), h(Z, g, C, aa, aa);
}
var ia = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Qs = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], W7 = function(e, t) {
  var r = e.charCodeAt(0), a = e.charCodeAt(1), i = (r - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var o = Math.floor((i - 119808) / 26);
    return [ia[o][2], ia[o][l]];
  } else if (120782 <= i && i <= 120831) {
    var s = Math.floor((i - 120782) / 10);
    return [Qs[s][2], Qs[s][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [ia[0][2], ia[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new me("Unsupported character: " + e);
  }
}, Xa = function(e, t, r) {
  return w0[r][e] && w0[r][e].replace && (e = w0[r][e].replace), {
    value: e,
    metrics: r5(e, t, r)
  };
}, Lt = function(e, t, r, a, i) {
  var l = Xa(e, t, r), o = l.metrics;
  e = l.value;
  var s;
  if (o) {
    var u = o.italic;
    (r === "text" || a && a.font === "mathit") && (u = 0), s = new sr(e, o.height, o.depth, u, o.skew, o.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + r + "'")), s = new sr(e, 0, 0, 0, 0, 0, i);
  if (a) {
    s.maxFontSize = a.sizeMultiplier, a.style.isTight() && s.classes.push("mtight");
    var c = a.getColor();
    c && (s.style.color = c);
  }
  return s;
}, Z7 = function(e, t, r, a) {
  return a === void 0 && (a = []), r.font === "boldsymbol" && Xa(e, "Main-Bold", t).metrics ? Lt(e, "Main-Bold", t, r, a.concat(["mathbf"])) : e === "\\" || w0[t][e].font === "main" ? Lt(e, "Main-Regular", t, r, a) : Lt(e, "AMS-Regular", t, r, a.concat(["amsrm"]));
}, Y7 = function(e, t, r, a, i) {
  return i !== "textord" && Xa(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, X7 = function(e, t, r) {
  var a = e.mode, i = e.text, l = ["mord"], o = a === "math" || a === "text" && t.font, s = o ? t.font : t.fontFamily, u = "", c = "";
  if (i.charCodeAt(0) === 55349 && ([u, c] = W7(i, a)), u.length > 0)
    return Lt(i, u, a, t, l.concat(c));
  if (s) {
    var d, f;
    if (s === "boldsymbol") {
      var p = Y7(i, a, t, l, r);
      d = p.fontName, f = [p.fontClass];
    } else o ? (d = I4[s].fontName, f = [s]) : (d = la(s, t.fontWeight, t.fontShape), f = [s, t.fontWeight, t.fontShape]);
    if (Xa(i, d, a).metrics)
      return Lt(i, d, a, t, l.concat(f));
    if (B4.hasOwnProperty(i) && d.slice(0, 10) === "Typewriter") {
      for (var b = [], E = 0; E < i.length; E++)
        b.push(Lt(i[E], d, a, t, l.concat(f)));
      return L4(b);
    }
  }
  if (r === "mathord")
    return Lt(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (r === "textord") {
    var k = w0[a][i] && w0[a][i].font;
    if (k === "ams") {
      var w = la("amsrm", t.fontWeight, t.fontShape);
      return Lt(i, w, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (k === "main" || !k) {
      var _ = la("textrm", t.fontWeight, t.fontShape);
      return Lt(i, _, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var v = la(k, t.fontWeight, t.fontShape);
      return Lt(i, v, a, t, l.concat(v, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + r + " in makeOrd");
}, K7 = (n, e) => {
  if (Zr(n.classes) !== Zr(e.classes) || n.skew !== e.skew || n.maxFontSize !== e.maxFontSize)
    return !1;
  if (n.classes.length === 1) {
    var t = n.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var r in n.style)
    if (n.style.hasOwnProperty(r) && n.style[r] !== e.style[r])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && n.style[a] !== e.style[a])
      return !1;
  return !0;
}, J7 = (n) => {
  for (var e = 0; e < n.length - 1; e++) {
    var t = n[e], r = n[e + 1];
    t instanceof sr && r instanceof sr && K7(t, r) && (t.text += r.text, t.height = Math.max(t.height, r.height), t.depth = Math.max(t.depth, r.depth), t.italic = r.italic, n.splice(e + 1, 1), e--);
  }
  return n;
}, n5 = function(e) {
  for (var t = 0, r = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > r && (r = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = r, e.maxFontSize = a;
}, lt = function(e, t, r, a) {
  var i = new Za(e, t, r, a);
  return n5(i), i;
}, z4 = (n, e, t, r) => new Za(n, e, t, r), $7 = function(e, t, r) {
  var a = lt([e], [], t);
  return a.height = Math.max(r || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = te(a.height), a.maxFontSize = 1, a;
}, ec = function(e, t, r, a) {
  var i = new M4(e, t, r, a);
  return n5(i), i;
}, L4 = function(e) {
  var t = new C1(e);
  return n5(t), t;
}, tc = function(e, t) {
  return e instanceof C1 ? lt([], [e], t) : e;
}, rc = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, r = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var o = -t[l].shift - i - t[l].elem.depth, s = o - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + o, r.push({
        type: "kern",
        size: s
      }), r.push(t[l]);
    }
    return {
      children: r,
      depth: a
    };
  }
  var u;
  if (e.positionType === "top") {
    for (var c = e.positionData, d = 0; d < e.children.length; d++) {
      var f = e.children[d];
      c -= f.type === "kern" ? f.size : f.elem.height + f.elem.depth;
    }
    u = c;
  } else if (e.positionType === "bottom")
    u = -e.positionData;
  else {
    var p = e.children[0];
    if (p.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      u = -p.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      u = -p.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: u
  };
}, nc = function(e, t) {
  for (var {
    children: r,
    depth: a
  } = rc(e), i = 0, l = 0; l < r.length; l++) {
    var o = r[l];
    if (o.type === "elem") {
      var s = o.elem;
      i = Math.max(i, s.maxFontSize, s.height);
    }
  }
  i += 2;
  var u = lt(["pstrut"], []);
  u.style.height = te(i);
  for (var c = [], d = a, f = a, p = a, b = 0; b < r.length; b++) {
    var E = r[b];
    if (E.type === "kern")
      p += E.size;
    else {
      var k = E.elem, w = E.wrapperClasses || [], _ = E.wrapperStyle || {}, v = lt(w, [u, k], void 0, _);
      v.style.top = te(-i - p - k.depth), E.marginLeft && (v.style.marginLeft = E.marginLeft), E.marginRight && (v.style.marginRight = E.marginRight), c.push(v), p += k.height + k.depth;
    }
    d = Math.min(d, p), f = Math.max(f, p);
  }
  var A = lt(["vlist"], c);
  A.style.height = te(f);
  var x;
  if (d < 0) {
    var Q = lt([], []), B = lt(["vlist"], [Q]);
    B.style.height = te(-d);
    var O = lt(["vlist-s"], [new sr("​")]);
    x = [lt(["vlist-r"], [A, O]), lt(["vlist-r"], [B])];
  } else
    x = [lt(["vlist-r"], [A])];
  var M = lt(["vlist-t"], x);
  return x.length === 2 && M.classes.push("vlist-t2"), M.height = f, M.depth = -d, M;
}, ac = (n, e) => {
  var t = lt(["mspace"], [], e), r = m0(n, e);
  return t.style.marginRight = te(r), t;
}, la = function(e, t, r) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && r === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, I4 = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, N4 = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, ic = function(e, t) {
  var [r, a, i] = N4[e], l = new cn(r), o = new Yr([l], {
    width: te(a),
    height: te(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + te(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), s = z4(["overlay"], [o], t);
  return s.height = i, s.style.height = te(i), s.style.width = te(a), s;
}, L = {
  fontMap: I4,
  makeSymbol: Lt,
  mathsym: Z7,
  makeSpan: lt,
  makeSvgSpan: z4,
  makeLineSpan: $7,
  makeAnchor: ec,
  makeFragment: L4,
  wrapFragment: tc,
  makeVList: nc,
  makeOrd: X7,
  makeGlue: ac,
  staticSvg: ic,
  svgData: N4,
  tryCombineChars: J7
}, d0 = {
  number: 3,
  unit: "mu"
}, en = {
  number: 4,
  unit: "mu"
}, mr = {
  number: 5,
  unit: "mu"
}, lc = {
  mord: {
    mop: d0,
    mbin: en,
    mrel: mr,
    minner: d0
  },
  mop: {
    mord: d0,
    mop: d0,
    mrel: mr,
    minner: d0
  },
  mbin: {
    mord: en,
    mop: en,
    mopen: en,
    minner: en
  },
  mrel: {
    mord: mr,
    mop: mr,
    mopen: mr,
    minner: mr
  },
  mopen: {},
  mclose: {
    mop: d0,
    mbin: en,
    mrel: mr,
    minner: d0
  },
  mpunct: {
    mord: d0,
    mop: d0,
    mrel: mr,
    mopen: d0,
    mclose: d0,
    mpunct: d0,
    minner: d0
  },
  minner: {
    mord: d0,
    mop: d0,
    mbin: en,
    mrel: mr,
    mopen: d0,
    mpunct: d0,
    minner: d0
  }
}, sc = {
  mord: {
    mop: d0
  },
  mop: {
    mord: d0,
    mop: d0
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: d0
  },
  mpunct: {},
  minner: {
    mop: d0
  }
}, R4 = {}, Ca = {}, Ta = {};
function ne(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs,
    argTypes: r.argTypes,
    allowedInArgument: !!r.allowedInArgument,
    allowedInText: !!r.allowedInText,
    allowedInMath: r.allowedInMath === void 0 ? !0 : r.allowedInMath,
    numOptionalArgs: r.numOptionalArgs || 0,
    infix: !!r.infix,
    primitive: !!r.primitive,
    handler: a
  }, s = 0; s < t.length; ++s)
    R4[t[s]] = o;
  e && (i && (Ca[e] = i), l && (Ta[e] = l));
}
function mn(n) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: r
  } = n;
  ne({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: r
  });
}
var Qa = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, b0 = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, Ln = L.makeSpan, oc = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], uc = ["rightmost", "mrel", "mclose", "mpunct"], cc = {
  display: ke.DISPLAY,
  text: ke.TEXT,
  script: ke.SCRIPT,
  scriptscript: ke.SCRIPTSCRIPT
}, hc = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, U0 = function(e, t, r, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var o = He(e[l], t);
    if (o instanceof C1) {
      var s = o.children;
      i.push(...s);
    } else
      i.push(o);
  }
  if (L.tryCombineChars(i), !r)
    return i;
  var u = t;
  if (e.length === 1) {
    var c = e[0];
    c.type === "sizing" ? u = t.havingSize(c.size) : c.type === "styling" && (u = t.havingStyle(cc[c.style]));
  }
  var d = Ln([a[0] || "leftmost"], [], t), f = Ln([a[1] || "rightmost"], [], t), p = r === "root";
  return Ms(i, (b, E) => {
    var k = E.classes[0], w = b.classes[0];
    k === "mbin" && be.contains(uc, w) ? E.classes[0] = "mord" : w === "mbin" && be.contains(oc, k) && (b.classes[0] = "mord");
  }, {
    node: d
  }, f, p), Ms(i, (b, E) => {
    var k = xl(E), w = xl(b), _ = k && w ? b.hasClass("mtight") ? sc[k][w] : lc[k][w] : null;
    if (_)
      return L.makeGlue(_, u);
  }, {
    node: d
  }, f, p), i;
}, Ms = function n(e, t, r, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var o = e[l], s = q4(o);
    if (s) {
      n(s.children, t, r, null, i);
      continue;
    }
    var u = !o.hasClass("mspace");
    if (u) {
      var c = t(o, r.node);
      c && (r.insertAfter ? r.insertAfter(c) : (e.unshift(c), l++));
    }
    u ? r.node = o : i && o.hasClass("newline") && (r.node = Ln(["leftmost"])), r.insertAfter = /* @__PURE__ */ ((d) => (f) => {
      e.splice(d + 1, 0, f), l++;
    })(l);
  }
  a && e.pop();
}, q4 = function(e) {
  return e instanceof C1 || e instanceof M4 || e instanceof Za && e.hasClass("enclosing") ? e : null;
}, fc = function n(e, t) {
  var r = q4(e);
  if (r) {
    var a = r.children;
    if (a.length) {
      if (t === "right")
        return n(a[a.length - 1], "right");
      if (t === "left")
        return n(a[0], "left");
    }
  }
  return e;
}, xl = function(e, t) {
  return e ? (t && (e = fc(e, t)), hc[e.classes[0]] || null) : null;
}, _1 = function(e, t) {
  var r = ["nulldelimiter"].concat(e.baseSizingClasses());
  return Ln(t.concat(r));
}, He = function(e, t, r) {
  if (!e)
    return Ln();
  if (Ca[e.type]) {
    var a = Ca[e.type](e, t);
    if (r && t.size !== r.size) {
      a = Ln(t.sizingClasses(r), [a], t);
      var i = t.sizeMultiplier / r.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new me("Got group of unknown type: '" + e.type + "'");
};
function O4(n) {
  return new C1(n);
}
class Rt {
  constructor(e, t, r) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = r || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = Zr(this.classes));
    for (var r = 0; r < this.children.length; r++)
      e.appendChild(this.children[r].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += be.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + be.escape(Zr(this.classes)) + '"'), e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class l1 {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return be.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class dc {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", te(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + te(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var Y = {
  MathNode: Rt,
  TextNode: l1,
  SpaceNode: dc,
  newDocumentFragment: O4
}, Et = function(e, t, r) {
  return w0[t][e] && w0[t][e].replace && e.charCodeAt(0) !== 55349 && !(B4.hasOwnProperty(e) && r && (r.fontFamily && r.fontFamily.slice(4, 6) === "tt" || r.font && r.font.slice(4, 6) === "tt")) && (e = w0[t][e].replace), new Y.TextNode(e);
}, a5 = function(e) {
  return e.length === 1 ? e[0] : new Y.MathNode("mrow", e);
}, i5 = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var r = t.font;
  if (!r || r === "mathnormal")
    return null;
  var a = e.mode;
  if (r === "mathit")
    return "italic";
  if (r === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (r === "mathbf")
    return "bold";
  if (r === "mathbb")
    return "double-struck";
  if (r === "mathfrak")
    return "fraktur";
  if (r === "mathscr" || r === "mathcal")
    return "script";
  if (r === "mathsf")
    return "sans-serif";
  if (r === "mathtt")
    return "monospace";
  var i = e.text;
  if (be.contains(["\\imath", "\\jmath"], i))
    return null;
  w0[a][i] && w0[a][i].replace && (i = w0[a][i].replace);
  var l = L.fontMap[r].fontName;
  return r5(i, l, a) ? L.fontMap[r].variant : null;
}, pt = function(e, t, r) {
  if (e.length === 1) {
    var a = l0(e[0], t);
    return r && a instanceof Rt && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, o = 0; o < e.length; o++) {
    var s = l0(e[o], t);
    if (s instanceof Rt && l instanceof Rt) {
      if (s.type === "mtext" && l.type === "mtext" && s.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mn" && l.type === "mn") {
        l.children.push(...s.children);
        continue;
      } else if (s.type === "mi" && s.children.length === 1 && l.type === "mn") {
        var u = s.children[0];
        if (u instanceof l1 && u.text === ".") {
          l.children.push(...s.children);
          continue;
        }
      } else if (l.type === "mi" && l.children.length === 1) {
        var c = l.children[0];
        if (c instanceof l1 && c.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
          var d = s.children[0];
          d instanceof l1 && d.text.length > 0 && (d.text = d.text.slice(0, 1) + "̸" + d.text.slice(1), i.pop());
        }
      }
    }
    i.push(s), l = s;
  }
  return i;
}, Xr = function(e, t, r) {
  return a5(pt(e, t, r));
}, l0 = function(e, t) {
  if (!e)
    return new Y.MathNode("mrow");
  if (Ta[e.type]) {
    var r = Ta[e.type](e, t);
    return r;
  } else
    throw new me("Got group of unknown type: '" + e.type + "'");
}, mc = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, pc = function(e) {
  var t = new Y.MathNode("mo", [new Y.TextNode(mc[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, gc = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, _c = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, vc = function(e, t) {
  function r() {
    var o = 4e5, s = e.label.slice(1);
    if (be.contains(["widehat", "widecheck", "widetilde", "utilde"], s)) {
      var u = e, c = _c(u.base), d, f, p;
      if (c > 5)
        s === "widehat" || s === "widecheck" ? (d = 420, o = 2364, p = 0.42, f = s + "4") : (d = 312, o = 2340, p = 0.34, f = "tilde4");
      else {
        var b = [1, 1, 2, 2, 3, 3][c];
        s === "widehat" || s === "widecheck" ? (o = [0, 1062, 2364, 2364, 2364][b], d = [0, 239, 300, 360, 420][b], p = [0, 0.24, 0.3, 0.3, 0.36, 0.42][b], f = s + b) : (o = [0, 600, 1033, 2339, 2340][b], d = [0, 260, 286, 306, 312][b], p = [0, 0.26, 0.286, 0.3, 0.306, 0.34][b], f = "tilde" + b);
      }
      var E = new cn(f), k = new Yr([E], {
        width: "100%",
        height: te(p),
        viewBox: "0 0 " + o + " " + d,
        preserveAspectRatio: "none"
      });
      return {
        span: L.makeSvgSpan([], [k], t),
        minWidth: 0,
        height: p
      };
    } else {
      var w = [], _ = gc[s], [v, A, x] = _, Q = x / 1e3, B = v.length, O, M;
      if (B === 1) {
        var I = _[3];
        O = ["hide-tail"], M = [I];
      } else if (B === 2)
        O = ["halfarrow-left", "halfarrow-right"], M = ["xMinYMin", "xMaxYMin"];
      else if (B === 3)
        O = ["brace-left", "brace-center", "brace-right"], M = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + B + " children.");
      for (var V = 0; V < B; V++) {
        var re = new cn(v[V]), W = new Yr([re], {
          width: "400em",
          height: te(Q),
          viewBox: "0 0 " + o + " " + x,
          preserveAspectRatio: M[V] + " slice"
        }), ae = L.makeSvgSpan([O[V]], [W], t);
        if (B === 1)
          return {
            span: ae,
            minWidth: A,
            height: Q
          };
        ae.style.height = te(Q), w.push(ae);
      }
      return {
        span: L.makeSpan(["stretchy"], w, t),
        minWidth: A,
        height: Q
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = r();
  return a.height = l, a.style.height = te(l), i > 0 && (a.style.minWidth = te(i)), a;
}, bc = function(e, t, r, a, i) {
  var l, o = e.height + e.depth + r + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = L.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var s = i.color && i.getColor();
      s && (l.style.borderColor = s);
    }
  } else {
    var u = [];
    /^[bx]cancel$/.test(t) && u.push(new Es({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && u.push(new Es({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var c = new Yr(u, {
      width: "100%",
      height: te(o)
    });
    l = L.makeSvgSpan([], [c], i);
  }
  return l.height = o, l.style.height = te(o), l;
}, Dr = {
  encloseSpan: bc,
  mathMLnode: pc,
  svgSpan: vc
};
function ze(n, e) {
  if (!n || n.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (n ? "node of type " + n.type : String(n)));
  return n;
}
function l5(n) {
  var e = Ka(n);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (n ? "node of type " + n.type : String(n)));
  return e;
}
function Ka(n) {
  return n && (n.type === "atom" || G7.hasOwnProperty(n.type)) ? n : null;
}
var s5 = (n, e) => {
  var t, r, a;
  n && n.type === "supsub" ? (r = ze(n.base, "accent"), t = r.base, n.base = t, a = j7(He(n, e)), n.base = r) : (r = ze(n, "accent"), t = r.base);
  var i = He(t, e.havingCrampedStyle()), l = r.isShifty && be.isCharacterBox(t), o = 0;
  if (l) {
    var s = be.getBaseElem(t), u = He(s, e.havingCrampedStyle());
    o = As(u).skew;
  }
  var c = r.label === "\\c", d = c ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), f;
  if (r.isStretchy)
    f = Dr.svgSpan(r, e), f = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: f,
        wrapperClasses: ["svg-align"],
        wrapperStyle: o > 0 ? {
          width: "calc(100% - " + te(2 * o) + ")",
          marginLeft: te(2 * o)
        } : void 0
      }]
    }, e);
  else {
    var p, b;
    r.label === "\\vec" ? (p = L.staticSvg("vec", e), b = L.svgData.vec[1]) : (p = L.makeOrd({
      mode: r.mode,
      text: r.label
    }, e, "textord"), p = As(p), p.italic = 0, b = p.width, c && (d += p.depth)), f = L.makeSpan(["accent-body"], [p]);
    var E = r.label === "\\textcircled";
    E && (f.classes.push("accent-full"), d = i.height);
    var k = o;
    E || (k -= b / 2), f.style.left = te(k), r.label === "\\textcircled" && (f.style.top = ".2em"), f = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -d
      }, {
        type: "elem",
        elem: f
      }]
    }, e);
  }
  var w = L.makeSpan(["mord", "accent"], [f], e);
  return a ? (a.children[0] = w, a.height = Math.max(w.height, a.height), a.classes[0] = "mord", a) : w;
}, P4 = (n, e) => {
  var t = n.isStretchy ? Dr.mathMLnode(n.label) : new Y.MathNode("mo", [Et(n.label, n.mode)]), r = new Y.MathNode("mover", [l0(n.base, e), t]);
  return r.setAttribute("accent", "true"), r;
}, wc = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((n) => "\\" + n).join("|"));
ne({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var t = Qa(e[0]), r = !wc.test(n.funcName), a = !r || n.funcName === "\\widehat" || n.funcName === "\\widetilde" || n.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: n.parser.mode,
      label: n.funcName,
      isStretchy: r,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: s5,
  mathmlBuilder: P4
});
ne({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = e[0], r = n.parser.mode;
    return r === "math" && (n.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + n.funcName + " works only in text mode"), r = "text"), {
      type: "accent",
      mode: r,
      label: n.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: s5,
  mathmlBuilder: P4
});
ne({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: r,
      base: a
    };
  },
  htmlBuilder: (n, e) => {
    var t = He(n.base, e), r = Dr.svgSpan(n, e), a = n.label === "\\utilde" ? 0.12 : 0, i = L.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: r,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return L.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Dr.mathMLnode(n.label), r = new Y.MathNode("munder", [l0(n.base, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
var sa = (n) => {
  var e = new Y.MathNode("mpadded", n ? [n] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
ne({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n;
    return {
      type: "xArrow",
      mode: r.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(n, e) {
    var t = e.style, r = e.havingStyle(t.sup()), a = L.wrapFragment(He(n.body, r, e), e), i = n.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    n.below && (r = e.havingStyle(t.sub()), l = L.wrapFragment(He(n.below, r, e), e), l.classes.push(i + "-arrow-pad"));
    var o = Dr.svgSpan(n, e), s = -e.fontMetrics().axisHeight + 0.5 * o.height, u = -e.fontMetrics().axisHeight - 0.5 * o.height - 0.111;
    (a.depth > 0.25 || n.label === "\\xleftequilibrium") && (u -= a.depth);
    var c;
    if (l) {
      var d = -e.fontMetrics().axisHeight + l.height + 0.5 * o.height + 0.111;
      c = L.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }, {
          type: "elem",
          elem: l,
          shift: d
        }]
      }, e);
    } else
      c = L.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: s
        }]
      }, e);
    return c.children[0].children[0].children[1].classes.push("svg-align"), L.makeSpan(["mrel", "x-arrow"], [c], e);
  },
  mathmlBuilder(n, e) {
    var t = Dr.mathMLnode(n.label);
    t.setAttribute("minsize", n.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var r;
    if (n.body) {
      var a = sa(l0(n.body, e));
      if (n.below) {
        var i = sa(l0(n.below, e));
        r = new Y.MathNode("munderover", [t, i, a]);
      } else
        r = new Y.MathNode("mover", [t, a]);
    } else if (n.below) {
      var l = sa(l0(n.below, e));
      r = new Y.MathNode("munder", [t, l]);
    } else
      r = sa(), r = new Y.MathNode("mover", [t, r]);
    return r;
  }
});
var yc = L.makeSpan;
function H4(n, e) {
  var t = U0(n.body, e, !0);
  return yc([n.mclass], t, e);
}
function V4(n, e) {
  var t, r = pt(n.body, e);
  return n.mclass === "minner" ? t = new Y.MathNode("mpadded", r) : n.mclass === "mord" ? n.isCharacterBox ? (t = r[0], t.type = "mi") : t = new Y.MathNode("mi", r) : (n.isCharacterBox ? (t = r[0], t.type = "mo") : t = new Y.MathNode("mo", r), n.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : n.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : n.mclass === "mopen" || n.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : n.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
ne({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + r.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: b0(a),
      isCharacterBox: be.isCharacterBox(a)
    };
  },
  htmlBuilder: H4,
  mathmlBuilder: V4
});
var Ja = (n) => {
  var e = n.type === "ordgroup" && n.body.length ? n.body[0] : n;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
ne({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Ja(e[0]),
      body: b0(e[1]),
      isCharacterBox: be.isCharacterBox(e[1])
    };
  }
});
ne({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[1], i = e[0], l;
    r !== "\\stackrel" ? l = Ja(a) : l = "mrel";
    var o = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: r !== "\\stackrel",
      body: b0(a)
    }, s = {
      type: "supsub",
      mode: i.mode,
      base: o,
      sup: r === "\\underset" ? null : i,
      sub: r === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [s],
      isCharacterBox: be.isCharacterBox(s)
    };
  },
  htmlBuilder: H4,
  mathmlBuilder: V4
});
ne({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: Ja(e[0]),
      body: b0(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = U0(n.body, e, !0), r = L.makeSpan([n.mclass], t, e);
    return r.style.textShadow = "0.02em 0.01em 0.04px", r;
  },
  mathmlBuilder(n, e) {
    var t = pt(n.body, e), r = new Y.MathNode("mstyle", t);
    return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
  }
});
var kc = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Bs = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), zs = (n) => n.type === "textord" && n.text === "@", Dc = (n, e) => (n.type === "mathord" || n.type === "atom") && n.text === e;
function Ec(n, e, t) {
  var r = kc[n];
  switch (r) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(r, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: r,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), o = t.callFunction("\\\\cdright", [e[1]], []), s = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, o]
      };
      return t.callFunction("\\\\cdparent", [s], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var u = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [u], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function Ac(n) {
  var e = [];
  for (n.gullet.beginGroup(), n.gullet.macros.set("\\cr", "\\\\\\relax"), n.gullet.beginGroup(); ; ) {
    e.push(n.parseExpression(!1, "\\\\")), n.gullet.endGroup(), n.gullet.beginGroup();
    var t = n.fetch().text;
    if (t === "&" || t === "\\\\")
      n.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new me("Expected \\\\ or \\cr or \\end", n.nextToken);
  }
  for (var r = [], a = [r], i = 0; i < e.length; i++) {
    for (var l = e[i], o = Bs(), s = 0; s < l.length; s++)
      if (!zs(l[s]))
        o.body.push(l[s]);
      else {
        r.push(o), s += 1;
        var u = l5(l[s]).text, c = new Array(2);
        if (c[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, c[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(u) > -1)) if ("<>AV".indexOf(u) > -1)
          for (var d = 0; d < 2; d++) {
            for (var f = !0, p = s + 1; p < l.length; p++) {
              if (Dc(l[p], u)) {
                f = !1, s = p;
                break;
              }
              if (zs(l[p]))
                throw new me("Missing a " + u + " character to complete a CD arrow.", l[p]);
              c[d].body.push(l[p]);
            }
            if (f)
              throw new me("Missing a " + u + " character to complete a CD arrow.", l[s]);
          }
        else
          throw new me('Expected one of "<>AV=|." after @', l[s]);
        var b = Ec(u, c, n), E = {
          type: "styling",
          body: [b],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        r.push(E), o = Bs();
      }
    i % 2 === 0 ? r.push(o) : r.shift(), r = [], a.push(r);
  }
  n.gullet.endGroup(), n.gullet.endGroup();
  var k = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: k,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
ne({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: r.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = e.havingStyle(e.style.sup()), r = L.wrapFragment(He(n.label, t, e), e);
    return r.classes.push("cd-label-" + n.side), r.style.bottom = te(0.8 - r.depth), r.height = 0, r.depth = 0, r;
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mrow", [l0(n.label, e)]);
    return t = new Y.MathNode("mpadded", [t]), t.setAttribute("width", "0"), n.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new Y.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
ne({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = L.wrapFragment(He(n.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mrow", [l0(n.fragment, e)]);
  }
});
ne({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    for (var {
      parser: t
    } = n, r = ze(e[0], "ordgroup"), a = r.body, i = "", l = 0; l < a.length; l++) {
      var o = ze(a[l], "textord");
      i += o.text;
    }
    var s = parseInt(i), u;
    if (isNaN(s))
      throw new me("\\@char has non-numeric argument " + i);
    if (s < 0 || s >= 1114111)
      throw new me("\\@char with invalid code point " + i);
    return s <= 65535 ? u = String.fromCharCode(s) : (s -= 65536, u = String.fromCharCode((s >> 10) + 55296, (s & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: u
    };
  }
});
var U4 = (n, e) => {
  var t = U0(n.body, e.withColor(n.color), !1);
  return L.makeFragment(t);
}, j4 = (n, e) => {
  var t = pt(n.body, e.withColor(n.color)), r = new Y.MathNode("mstyle", t);
  return r.setAttribute("mathcolor", n.color), r;
};
ne({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = ze(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: r,
      body: b0(a)
    };
  },
  htmlBuilder: U4,
  mathmlBuilder: j4
});
ne({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(n, e) {
    var {
      parser: t,
      breakOnTokenText: r
    } = n, a = ze(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, r);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: U4,
  mathmlBuilder: j4
});
ne({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, i = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: r.mode,
      newLine: i,
      size: a && ze(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(n, e) {
    var t = L.makeSpan(["mspace"], [], e);
    return n.newLine && (t.classes.push("newline"), n.size && (t.style.marginTop = te(m0(n.size, e)))), t;
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mspace");
    return n.newLine && (t.setAttribute("linebreak", "newline"), n.size && t.setAttribute("height", te(m0(n.size, e)))), t;
  }
});
var Cl = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, G4 = (n) => {
  var e = n.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new me("Expected a control sequence", n);
  return e;
}, Fc = (n) => {
  var e = n.gullet.popToken();
  return e.text === "=" && (e = n.gullet.popToken(), e.text === " " && (e = n.gullet.popToken())), e;
}, W4 = (n, e, t, r) => {
  var a = n.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !n.gullet.isExpandable(t.text)
  }), n.gullet.macros.set(e, a, r);
};
ne({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    e.consumeSpaces();
    var r = e.fetch();
    if (Cl[r.text])
      return (t === "\\global" || t === "\\\\globallong") && (r.text = Cl[r.text]), ze(e.parseFunction(), "internal");
    throw new me("Invalid token after macro prefix", r);
  }
});
ne({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e.gullet.popToken(), a = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new me("Expected a control sequence", r);
    for (var i = 0, l, o = [[]]; e.gullet.future().text !== "{"; )
      if (r = e.gullet.popToken(), r.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), o[i].push("{");
          break;
        }
        if (r = e.gullet.popToken(), !/^[1-9]$/.test(r.text))
          throw new me('Invalid argument number "' + r.text + '"');
        if (parseInt(r.text) !== i + 1)
          throw new me('Argument number "' + r.text + '" out of order');
        i++, o.push([]);
      } else {
        if (r.text === "EOF")
          throw new me("Expected a macro definition");
        o[i].push(r.text);
      }
    var {
      tokens: s
    } = e.gullet.consumeArg();
    return l && s.unshift(l), (t === "\\edef" || t === "\\xdef") && (s = e.gullet.expandTokens(s), s.reverse()), e.gullet.macros.set(a, {
      tokens: s,
      numArgs: i,
      delimiters: o
    }, t === Cl[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
ne({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = G4(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = Fc(e);
    return W4(e, r, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
ne({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = G4(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return W4(e, r, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var i1 = function(e, t, r) {
  var a = w0.math[e] && w0.math[e].replace, i = r5(a || e, t, r);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, o5 = function(e, t, r, a) {
  var i = r.havingBaseStyle(t), l = L.makeSpan(a.concat(i.sizingClasses(r)), [e], r), o = i.sizeMultiplier / r.sizeMultiplier;
  return l.height *= o, l.depth *= o, l.maxFontSize = i.sizeMultiplier, l;
}, Z4 = function(e, t, r) {
  var a = t.havingBaseStyle(r), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = te(i), e.height -= i, e.depth += i;
}, Sc = function(e, t, r, a, i, l) {
  var o = L.makeSymbol(e, "Main-Regular", i, a), s = o5(o, t, a, l);
  return r && Z4(s, a, t), s;
}, xc = function(e, t, r, a) {
  return L.makeSymbol(e, "Size" + t + "-Regular", r, a);
}, Y4 = function(e, t, r, a, i, l) {
  var o = xc(e, t, i, a), s = o5(L.makeSpan(["delimsizing", "size" + t], [o], a), ke.TEXT, a, l);
  return r && Z4(s, a, ke.TEXT), s;
}, Ui = function(e, t, r) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = L.makeSpan(["delimsizinginner", a], [L.makeSpan([], [L.makeSymbol(e, t, r)])]);
  return {
    type: "elem",
    elem: i
  };
}, ji = function(e, t, r) {
  var a = _r["Size4-Regular"][e.charCodeAt(0)] ? _r["Size4-Regular"][e.charCodeAt(0)][4] : _r["Size1-Regular"][e.charCodeAt(0)][4], i = new cn("inner", q7(e, Math.round(1e3 * t))), l = new Yr([i], {
    width: te(a),
    height: te(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + te(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), o = L.makeSvgSpan([], [l], r);
  return o.height = t, o.style.height = te(t), o.style.width = te(a), {
    type: "elem",
    elem: o
  };
}, Tl = 8e-3, oa = {
  type: "kern",
  size: -1 * Tl
}, Cc = ["|", "\\lvert", "\\rvert", "\\vert"], Tc = ["\\|", "\\lVert", "\\rVert", "\\Vert"], X4 = function(e, t, r, a, i, l) {
  var o, s, u, c, d = "", f = 0;
  o = u = c = e, s = null;
  var p = "Size1-Regular";
  e === "\\uparrow" ? u = c = "⏐" : e === "\\Uparrow" ? u = c = "‖" : e === "\\downarrow" ? o = u = "⏐" : e === "\\Downarrow" ? o = u = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", u = "⏐", c = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", u = "‖", c = "\\Downarrow") : be.contains(Cc, e) ? (u = "∣", d = "vert", f = 333) : be.contains(Tc, e) ? (u = "∥", d = "doublevert", f = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", u = "⎢", c = "⎣", p = "Size4-Regular", d = "lbrack", f = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", u = "⎥", c = "⎦", p = "Size4-Regular", d = "rbrack", f = 667) : e === "\\lfloor" || e === "⌊" ? (u = o = "⎢", c = "⎣", p = "Size4-Regular", d = "lfloor", f = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", u = c = "⎢", p = "Size4-Regular", d = "lceil", f = 667) : e === "\\rfloor" || e === "⌋" ? (u = o = "⎥", c = "⎦", p = "Size4-Regular", d = "rfloor", f = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", u = c = "⎥", p = "Size4-Regular", d = "rceil", f = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", u = "⎜", c = "⎝", p = "Size4-Regular", d = "lparen", f = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", u = "⎟", c = "⎠", p = "Size4-Regular", d = "rparen", f = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", c = "⎩", u = "⎪", p = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", c = "⎭", u = "⎪", p = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", c = "⎩", u = "⎪", p = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", c = "⎭", u = "⎪", p = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", c = "⎭", u = "⎪", p = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", c = "⎩", u = "⎪", p = "Size4-Regular");
  var b = i1(o, p, i), E = b.height + b.depth, k = i1(u, p, i), w = k.height + k.depth, _ = i1(c, p, i), v = _.height + _.depth, A = 0, x = 1;
  if (s !== null) {
    var Q = i1(s, p, i);
    A = Q.height + Q.depth, x = 2;
  }
  var B = E + v + A, O = Math.max(0, Math.ceil((t - B) / (x * w))), M = B + O * x * w, I = a.fontMetrics().axisHeight;
  r && (I *= a.sizeMultiplier);
  var V = M / 2 - I, re = [];
  if (d.length > 0) {
    var W = M - E - v, ae = Math.round(M * 1e3), Ee = O7(d, Math.round(W * 1e3)), xe = new cn(d, Ee), qe = (f / 1e3).toFixed(3) + "em", ce = (ae / 1e3).toFixed(3) + "em", pe = new Yr([xe], {
      width: qe,
      height: ce,
      viewBox: "0 0 " + f + " " + ae
    }), Ce = L.makeSvgSpan([], [pe], a);
    Ce.height = ae / 1e3, Ce.style.width = qe, Ce.style.height = ce, re.push({
      type: "elem",
      elem: Ce
    });
  } else {
    if (re.push(Ui(c, p, i)), re.push(oa), s === null) {
      var $ = M - E - v + 2 * Tl;
      re.push(ji(u, $, a));
    } else {
      var Te = (M - E - v - A) / 2 + 2 * Tl;
      re.push(ji(u, Te, a)), re.push(oa), re.push(Ui(s, p, i)), re.push(oa), re.push(ji(u, Te, a));
    }
    re.push(oa), re.push(Ui(o, p, i));
  }
  var se = a.havingBaseStyle(ke.TEXT), De = L.makeVList({
    positionType: "bottom",
    positionData: V,
    children: re
  }, se);
  return o5(L.makeSpan(["delimsizing", "mult"], [De], se), ke.TEXT, a, l);
}, Gi = 80, Wi = 0.08, Zi = function(e, t, r, a, i) {
  var l = R7(e, a, r), o = new cn(e, l), s = new Yr([o], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: te(t),
    viewBox: "0 0 400000 " + r,
    preserveAspectRatio: "xMinYMin slice"
  });
  return L.makeSvgSpan(["hide-tail"], [s], i);
}, Qc = function(e, t) {
  var r = t.havingBaseSizing(), a = e6("\\surd", e * r.sizeMultiplier, $4, r), i = r.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s = 0, u = 0, c = 0, d;
  return a.type === "small" ? (c = 1e3 + 1e3 * l + Gi, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), s = (1 + l + Wi) / i, u = (1 + l) / i, o = Zi("sqrtMain", s, c, l, t), o.style.minWidth = "0.853em", d = 0.833 / i) : a.type === "large" ? (c = (1e3 + Gi) * s1[a.size], u = (s1[a.size] + l) / i, s = (s1[a.size] + l + Wi) / i, o = Zi("sqrtSize" + a.size, s, c, l, t), o.style.minWidth = "1.02em", d = 1 / i) : (s = e + l + Wi, u = e + l, c = Math.floor(1e3 * e + l) + Gi, o = Zi("sqrtTall", s, c, l, t), o.style.minWidth = "0.742em", d = 1.056), o.height = u, o.style.height = te(s), {
    span: o,
    advanceWidth: d,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, K4 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], Mc = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], J4 = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], s1 = [0, 1.2, 1.8, 2.4, 3], Bc = function(e, t, r, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), be.contains(K4, e) || be.contains(J4, e))
    return Y4(e, t, !1, r, a, i);
  if (be.contains(Mc, e))
    return X4(e, s1[t], !1, r, a, i);
  throw new me("Illegal delimiter: '" + e + "'");
}, zc = [{
  type: "small",
  style: ke.SCRIPTSCRIPT
}, {
  type: "small",
  style: ke.SCRIPT
}, {
  type: "small",
  style: ke.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], Lc = [{
  type: "small",
  style: ke.SCRIPTSCRIPT
}, {
  type: "small",
  style: ke.SCRIPT
}, {
  type: "small",
  style: ke.TEXT
}, {
  type: "stack"
}], $4 = [{
  type: "small",
  style: ke.SCRIPTSCRIPT
}, {
  type: "small",
  style: ke.SCRIPT
}, {
  type: "small",
  style: ke.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], Ic = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, e6 = function(e, t, r, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < r.length && r[l].type !== "stack"; l++) {
    var o = i1(e, Ic(r[l]), "math"), s = o.height + o.depth;
    if (r[l].type === "small") {
      var u = a.havingBaseStyle(r[l].style);
      s *= u.sizeMultiplier;
    }
    if (s > t)
      return r[l];
  }
  return r[r.length - 1];
}, t6 = function(e, t, r, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var o;
  be.contains(J4, e) ? o = zc : be.contains(K4, e) ? o = $4 : o = Lc;
  var s = e6(e, t, o, a);
  return s.type === "small" ? Sc(e, s.style, r, a, i, l) : s.type === "large" ? Y4(e, s.size, r, a, i, l) : X4(e, t, r, a, i, l);
}, Nc = function(e, t, r, a, i, l) {
  var o = a.fontMetrics().axisHeight * a.sizeMultiplier, s = 901, u = 5 / a.fontMetrics().ptPerEm, c = Math.max(t - o, r + o), d = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    c / 500 * s,
    2 * c - u
  );
  return t6(e, d, !0, a, i, l);
}, wr = {
  sqrtImage: Qc,
  sizedDelim: Bc,
  sizeToMaxHeight: s1,
  customSizedDelim: t6,
  leftRightDelim: Nc
}, Ls = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, Rc = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function $a(n, e) {
  var t = Ka(n);
  if (t && be.contains(Rc, t.text))
    return t;
  throw t ? new me("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", n) : new me("Invalid delimiter type '" + n.type + "'", n);
}
ne({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = $a(e[0], n);
    return {
      type: "delimsizing",
      mode: n.parser.mode,
      size: Ls[n.funcName].size,
      mclass: Ls[n.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => n.delim === "." ? L.makeSpan([n.mclass]) : wr.sizedDelim(n.delim, n.size, e, n.mode, [n.mclass]),
  mathmlBuilder: (n) => {
    var e = [];
    n.delim !== "." && e.push(Et(n.delim, n.mode));
    var t = new Y.MathNode("mo", e);
    n.mclass === "mopen" || n.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var r = te(wr.sizeToMaxHeight[n.size]);
    return t.setAttribute("minsize", r), t.setAttribute("maxsize", r), t;
  }
});
function Is(n) {
  if (!n.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
ne({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = n.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new me("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: n.parser.mode,
      delim: $a(e[0], n).text,
      color: t
      // undefined if not set via \color
    };
  }
});
ne({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = $a(e[0], n), r = n.parser;
    ++r.leftrightDepth;
    var a = r.parseExpression(!1);
    --r.leftrightDepth, r.expect("\\right", !1);
    var i = ze(r.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: r.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (n, e) => {
    Is(n);
    for (var t = U0(n.body, e, !0, ["mopen", "mclose"]), r = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (r = Math.max(t[l].height, r), a = Math.max(t[l].depth, a));
    r *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var o;
    if (n.left === "." ? o = _1(e, ["mopen"]) : o = wr.leftRightDelim(n.left, r, a, e, n.mode, ["mopen"]), t.unshift(o), i)
      for (var s = 1; s < t.length; s++) {
        var u = t[s], c = u.isMiddle;
        c && (t[s] = wr.leftRightDelim(c.delim, r, a, c.options, n.mode, []));
      }
    var d;
    if (n.right === ".")
      d = _1(e, ["mclose"]);
    else {
      var f = n.rightColor ? e.withColor(n.rightColor) : e;
      d = wr.leftRightDelim(n.right, r, a, f, n.mode, ["mclose"]);
    }
    return t.push(d), L.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (n, e) => {
    Is(n);
    var t = pt(n.body, e);
    if (n.left !== ".") {
      var r = new Y.MathNode("mo", [Et(n.left, n.mode)]);
      r.setAttribute("fence", "true"), t.unshift(r);
    }
    if (n.right !== ".") {
      var a = new Y.MathNode("mo", [Et(n.right, n.mode)]);
      a.setAttribute("fence", "true"), n.rightColor && a.setAttribute("mathcolor", n.rightColor), t.push(a);
    }
    return a5(t);
  }
});
ne({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = $a(e[0], n);
    if (!n.parser.leftrightDepth)
      throw new me("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: n.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    if (n.delim === ".")
      t = _1(e, []);
    else {
      t = wr.sizedDelim(n.delim, 1, e, n.mode, []);
      var r = {
        delim: n.delim,
        options: e
      };
      t.isMiddle = r;
    }
    return t;
  },
  mathmlBuilder: (n, e) => {
    var t = n.delim === "\\vert" || n.delim === "|" ? Et("|", "text") : Et(n.delim, n.mode), r = new Y.MathNode("mo", [t]);
    return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
  }
});
var u5 = (n, e) => {
  var t = L.wrapFragment(He(n.body, e), e), r = n.label.slice(1), a = e.sizeMultiplier, i, l = 0, o = be.isCharacterBox(n.body);
  if (r === "sout")
    i = L.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (r === "phase") {
    var s = m0({
      number: 0.6,
      unit: "pt"
    }, e), u = m0({
      number: 0.35,
      unit: "ex"
    }, e), c = e.havingBaseSizing();
    a = a / c.sizeMultiplier;
    var d = t.height + t.depth + s + u;
    t.style.paddingLeft = te(d / 2 + s);
    var f = Math.floor(1e3 * d * a), p = I7(f), b = new Yr([new cn("phase", p)], {
      width: "400em",
      height: te(f / 1e3),
      viewBox: "0 0 400000 " + f,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = L.makeSvgSpan(["hide-tail"], [b], e), i.style.height = te(d), l = t.depth + s + u;
  } else {
    /cancel/.test(r) ? o || t.classes.push("cancel-pad") : r === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var E = 0, k = 0, w = 0;
    /box/.test(r) ? (w = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), E = e.fontMetrics().fboxsep + (r === "colorbox" ? 0 : w), k = E) : r === "angl" ? (w = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), E = 4 * w, k = Math.max(0, 0.25 - t.depth)) : (E = o ? 0.2 : 0, k = E), i = Dr.encloseSpan(t, r, E, k, e), /fbox|boxed|fcolorbox/.test(r) ? (i.style.borderStyle = "solid", i.style.borderWidth = te(w)) : r === "angl" && w !== 0.049 && (i.style.borderTopWidth = te(w), i.style.borderRightWidth = te(w)), l = t.depth + k, n.backgroundColor && (i.style.backgroundColor = n.backgroundColor, n.borderColor && (i.style.borderColor = n.borderColor));
  }
  var _;
  if (n.backgroundColor)
    _ = L.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var v = /cancel|phase/.test(r) ? ["svg-align"] : [];
    _ = L.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: v
        }
      ]
    }, e);
  }
  return /cancel/.test(r) && (_.height = t.height, _.depth = t.depth), /cancel/.test(r) && !o ? L.makeSpan(["mord", "cancel-lap"], [_], e) : L.makeSpan(["mord"], [_], e);
}, c5 = (n, e) => {
  var t = 0, r = new Y.MathNode(n.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [l0(n.body, e)]);
  switch (n.label) {
    case "\\cancel":
      r.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      r.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      r.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      r.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      r.setAttribute("notation", "box");
      break;
    case "\\angl":
      r.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * t + "pt"), r.setAttribute("height", "+" + 2 * t + "pt"), r.setAttribute("lspace", t + "pt"), r.setAttribute("voffset", t + "pt"), n.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        r.setAttribute("style", "border: " + a + "em solid " + String(n.borderColor));
      }
      break;
    case "\\xcancel":
      r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return n.backgroundColor && r.setAttribute("mathbackground", n.backgroundColor), r;
};
ne({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = ze(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: u5,
  mathmlBuilder: c5
});
ne({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = ze(e[0], "color-token").color, l = ze(e[1], "color-token").color, o = e[2];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: o
    };
  },
  htmlBuilder: u5,
  mathmlBuilder: c5
});
ne({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
ne({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: r,
      body: a
    };
  },
  htmlBuilder: u5,
  mathmlBuilder: c5
});
ne({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var r6 = {};
function or(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, s = 0; s < t.length; ++s)
    r6[t[s]] = o;
  i && (Ca[e] = i), l && (Ta[e] = l);
}
var qc = {};
function y(n, e) {
  qc[n] = e;
}
function Ns(n) {
  var e = [];
  n.consumeSpaces();
  var t = n.fetch().text;
  for (t === "\\relax" && (n.consume(), n.consumeSpaces(), t = n.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    n.consume(), e.push(t === "\\hdashline"), n.consumeSpaces(), t = n.fetch().text;
  return e;
}
var ei = (n) => {
  var e = n.parser.settings;
  if (!e.displayMode)
    throw new me("{" + n.envName + "} can be used only in display mode.");
};
function h5(n) {
  if (n.indexOf("ed") === -1)
    return n.indexOf("*") === -1;
}
function Jr(n, e, t) {
  var {
    hskipBeforeAndAfter: r,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: o,
    autoTag: s,
    singleRow: u,
    emptySingleRow: c,
    maxNumCols: d,
    leqno: f
  } = e;
  if (n.gullet.beginGroup(), u || n.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var p = n.gullet.expandMacroAsText("\\arraystretch");
    if (p == null)
      l = 1;
    else if (l = parseFloat(p), !l || l < 0)
      throw new me("Invalid \\arraystretch: " + p);
  }
  n.gullet.beginGroup();
  var b = [], E = [b], k = [], w = [], _ = s != null ? [] : void 0;
  function v() {
    s && n.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function A() {
    _ && (n.gullet.macros.get("\\df@tag") ? (_.push(n.subparse([new e5("\\df@tag")])), n.gullet.macros.set("\\df@tag", void 0, !0)) : _.push(!!s && n.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (v(), w.push(Ns(n)); ; ) {
    var x = n.parseExpression(!1, u ? "\\end" : "\\\\");
    n.gullet.endGroup(), n.gullet.beginGroup(), x = {
      type: "ordgroup",
      mode: n.mode,
      body: x
    }, t && (x = {
      type: "styling",
      mode: n.mode,
      style: t,
      body: [x]
    }), b.push(x);
    var Q = n.fetch().text;
    if (Q === "&") {
      if (d && b.length === d) {
        if (u || o)
          throw new me("Too many tab characters: &", n.nextToken);
        n.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      n.consume();
    } else if (Q === "\\end") {
      A(), b.length === 1 && x.type === "styling" && x.body[0].body.length === 0 && (E.length > 1 || !c) && E.pop(), w.length < E.length + 1 && w.push([]);
      break;
    } else if (Q === "\\\\") {
      n.consume();
      var B = void 0;
      n.gullet.future().text !== " " && (B = n.parseSizeGroup(!0)), k.push(B ? B.value : null), A(), w.push(Ns(n)), b = [], E.push(b), v();
    } else
      throw new me("Expected & or \\\\ or \\cr or \\end", n.nextToken);
  }
  return n.gullet.endGroup(), n.gullet.endGroup(), {
    type: "array",
    mode: n.mode,
    addJot: a,
    arraystretch: l,
    body: E,
    cols: i,
    rowGaps: k,
    hskipBeforeAndAfter: r,
    hLinesBeforeRow: w,
    colSeparationType: o,
    tags: _,
    leqno: f
  };
}
function f5(n) {
  return n.slice(0, 1) === "d" ? "display" : "text";
}
var ur = function(e, t) {
  var r, a, i = e.body.length, l = e.hLinesBeforeRow, o = 0, s = new Array(i), u = [], c = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), d = 1 / t.fontMetrics().ptPerEm, f = 5 * d;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var p = t.havingStyle(ke.SCRIPT).sizeMultiplier;
    f = 0.2778 * (p / t.sizeMultiplier);
  }
  var b = e.colSeparationType === "CD" ? m0({
    number: 3,
    unit: "ex"
  }, t) : 12 * d, E = 3 * d, k = e.arraystretch * b, w = 0.7 * k, _ = 0.3 * k, v = 0;
  function A(Ve) {
    for (var Qe = 0; Qe < Ve.length; ++Qe)
      Qe > 0 && (v += 0.25), u.push({
        pos: v,
        isDashed: Ve[Qe]
      });
  }
  for (A(l[0]), r = 0; r < e.body.length; ++r) {
    var x = e.body[r], Q = w, B = _;
    o < x.length && (o = x.length);
    var O = new Array(x.length);
    for (a = 0; a < x.length; ++a) {
      var M = He(x[a], t);
      B < M.depth && (B = M.depth), Q < M.height && (Q = M.height), O[a] = M;
    }
    var I = e.rowGaps[r], V = 0;
    I && (V = m0(I, t), V > 0 && (V += _, B < V && (B = V), V = 0)), e.addJot && (B += E), O.height = Q, O.depth = B, v += Q, O.pos = v, v += B + V, s[r] = O, A(l[r + 1]);
  }
  var re = v / 2 + t.fontMetrics().axisHeight, W = e.cols || [], ae = [], Ee, xe, qe = [];
  if (e.tags && e.tags.some((Ve) => Ve))
    for (r = 0; r < i; ++r) {
      var ce = s[r], pe = ce.pos - re, Ce = e.tags[r], $ = void 0;
      Ce === !0 ? $ = L.makeSpan(["eqn-num"], [], t) : Ce === !1 ? $ = L.makeSpan([], [], t) : $ = L.makeSpan([], U0(Ce, t, !0), t), $.depth = ce.depth, $.height = ce.height, qe.push({
        type: "elem",
        elem: $,
        shift: pe
      });
    }
  for (
    a = 0, xe = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < o || xe < W.length;
    ++a, ++xe
  ) {
    for (var Te = W[xe] || {}, se = !0; Te.type === "separator"; ) {
      if (se || (Ee = L.makeSpan(["arraycolsep"], []), Ee.style.width = te(t.fontMetrics().doubleRuleSep), ae.push(Ee)), Te.separator === "|" || Te.separator === ":") {
        var De = Te.separator === "|" ? "solid" : "dashed", P = L.makeSpan(["vertical-separator"], [], t);
        P.style.height = te(v), P.style.borderRightWidth = te(c), P.style.borderRightStyle = De, P.style.margin = "0 " + te(-c / 2);
        var we = v - re;
        we && (P.style.verticalAlign = te(-we)), ae.push(P);
      } else
        throw new me("Invalid separator type: " + Te.separator);
      xe++, Te = W[xe] || {}, se = !1;
    }
    if (!(a >= o)) {
      var he = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (he = be.deflt(Te.pregap, f), he !== 0 && (Ee = L.makeSpan(["arraycolsep"], []), Ee.style.width = te(he), ae.push(Ee)));
      var Ke = [];
      for (r = 0; r < i; ++r) {
        var J = s[r], Ae = J[a];
        if (Ae) {
          var ge = J.pos - re;
          Ae.depth = J.depth, Ae.height = J.height, Ke.push({
            type: "elem",
            elem: Ae,
            shift: ge
          });
        }
      }
      Ke = L.makeVList({
        positionType: "individualShift",
        children: Ke
      }, t), Ke = L.makeSpan(["col-align-" + (Te.align || "c")], [Ke]), ae.push(Ke), (a < o - 1 || e.hskipBeforeAndAfter) && (he = be.deflt(Te.postgap, f), he !== 0 && (Ee = L.makeSpan(["arraycolsep"], []), Ee.style.width = te(he), ae.push(Ee)));
    }
  }
  if (s = L.makeSpan(["mtable"], ae), u.length > 0) {
    for (var Oe = L.makeLineSpan("hline", t, c), Le = L.makeLineSpan("hdashline", t, c), je = [{
      type: "elem",
      elem: s,
      shift: 0
    }]; u.length > 0; ) {
      var Ge = u.pop(), e0 = Ge.pos - re;
      Ge.isDashed ? je.push({
        type: "elem",
        elem: Le,
        shift: e0
      }) : je.push({
        type: "elem",
        elem: Oe,
        shift: e0
      });
    }
    s = L.makeVList({
      positionType: "individualShift",
      children: je
    }, t);
  }
  if (qe.length === 0)
    return L.makeSpan(["mord"], [s], t);
  var X = L.makeVList({
    positionType: "individualShift",
    children: qe
  }, t);
  return X = L.makeSpan(["tag"], [X], t), L.makeFragment([s, X]);
}, Oc = {
  c: "center ",
  l: "left ",
  r: "right "
}, cr = function(e, t) {
  for (var r = [], a = new Y.MathNode("mtd", [], ["mtr-glue"]), i = new Y.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var o = e.body[l], s = [], u = 0; u < o.length; u++)
      s.push(new Y.MathNode("mtd", [l0(o[u], t)]));
    e.tags && e.tags[l] && (s.unshift(a), s.push(a), e.leqno ? s.unshift(i) : s.push(i)), r.push(new Y.MathNode("mtr", s));
  }
  var c = new Y.MathNode("mtable", r), d = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  c.setAttribute("rowspacing", te(d));
  var f = "", p = "";
  if (e.cols && e.cols.length > 0) {
    var b = e.cols, E = "", k = !1, w = 0, _ = b.length;
    b[0].type === "separator" && (f += "top ", w = 1), b[b.length - 1].type === "separator" && (f += "bottom ", _ -= 1);
    for (var v = w; v < _; v++)
      b[v].type === "align" ? (p += Oc[b[v].align], k && (E += "none "), k = !0) : b[v].type === "separator" && k && (E += b[v].separator === "|" ? "solid " : "dashed ", k = !1);
    c.setAttribute("columnalign", p.trim()), /[sd]/.test(E) && c.setAttribute("columnlines", E.trim());
  }
  if (e.colSeparationType === "align") {
    for (var A = e.cols || [], x = "", Q = 1; Q < A.length; Q++)
      x += Q % 2 ? "0em " : "1em ";
    c.setAttribute("columnspacing", x.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? c.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? c.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? c.setAttribute("columnspacing", "0.5em") : c.setAttribute("columnspacing", "1em");
  var B = "", O = e.hLinesBeforeRow;
  f += O[0].length > 0 ? "left " : "", f += O[O.length - 1].length > 0 ? "right " : "";
  for (var M = 1; M < O.length - 1; M++)
    B += O[M].length === 0 ? "none " : O[M][0] ? "dashed " : "solid ";
  return /[sd]/.test(B) && c.setAttribute("rowlines", B.trim()), f !== "" && (c = new Y.MathNode("menclose", [c]), c.setAttribute("notation", f.trim())), e.arraystretch && e.arraystretch < 1 && (c = new Y.MathNode("mstyle", [c]), c.setAttribute("scriptlevel", "1")), c;
}, n6 = function(e, t) {
  e.envName.indexOf("ed") === -1 && ei(e);
  var r = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = Jr(e.parser, {
    cols: r,
    addJot: !0,
    autoTag: i ? void 0 : h5(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), o, s = 0, u = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var c = "", d = 0; d < t[0].body.length; d++) {
      var f = ze(t[0].body[d], "textord");
      c += f.text;
    }
    o = Number(c), s = o * 2;
  }
  var p = !s;
  l.body.forEach(function(w) {
    for (var _ = 1; _ < w.length; _ += 2) {
      var v = ze(w[_], "styling"), A = ze(v.body[0], "ordgroup");
      A.body.unshift(u);
    }
    if (p)
      s < w.length && (s = w.length);
    else {
      var x = w.length / 2;
      if (o < x)
        throw new me("Too many math in a row: " + ("expected " + o + ", but got " + x), w[0]);
    }
  });
  for (var b = 0; b < s; ++b) {
    var E = "r", k = 0;
    b % 2 === 1 ? E = "l" : b > 0 && p && (k = 1), r[b] = {
      type: "align",
      align: E,
      pregap: k,
      postgap: 0
    };
  }
  return l.colSeparationType = p ? "align" : "alignat", l;
};
or({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = Ka(e[0]), r = t ? [e[0]] : ze(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = l5(l), s = o.text;
      if ("lcr".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      if (s === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (s === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new me("Unknown column alignment: " + s, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return Jr(n.parser, i, f5(n.envName));
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[n.envName.replace("*", "")], t = "c", r = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (n.envName.charAt(n.envName.length - 1) === "*") {
      var a = n.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new me("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), r.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = Jr(n.parser, r, f5(n.envName)), l = Math.max(0, ...i.body.map((o) => o.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: n.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 0.5
    }, t = Jr(n.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = Ka(e[0]), r = t ? [e[0]] : ze(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = l5(l), s = o.text;
      if ("lc".indexOf(s) !== -1)
        return {
          type: "align",
          align: s
        };
      throw new me("Unknown column alignment: " + s, l);
    });
    if (a.length > 1)
      throw new me("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = Jr(n.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new me("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = Jr(n.parser, e, f5(n.envName));
    return {
      type: "leftright",
      mode: n.mode,
      body: [t],
      left: n.envName.indexOf("r") > -1 ? "." : "\\{",
      right: n.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: n6,
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    be.contains(["gather", "gather*"], n.envName) && ei(n);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: h5(n.envName),
      emptySingleRow: !0,
      leqno: n.parser.settings.leqno
    };
    return Jr(n.parser, e, "display");
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: n6,
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    ei(n);
    var e = {
      autoTag: h5(n.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: n.parser.settings.leqno
    };
    return Jr(n.parser, e, "display");
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
or({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(n) {
    return ei(n), Ac(n.parser);
  },
  htmlBuilder: ur,
  mathmlBuilder: cr
});
y("\\nonumber", "\\gdef\\@eqnsw{0}");
y("\\notag", "\\nonumber");
ne({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(n, e) {
    throw new me(n.funcName + " valid only within array environment");
  }
});
var Rs = r6;
ne({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    if (a.type !== "ordgroup")
      throw new me("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += ze(a.body[l], "textord").text;
    if (r === "\\begin") {
      if (!Rs.hasOwnProperty(i))
        throw new me("No such environment: " + i, a);
      var o = Rs[i], {
        args: s,
        optArgs: u
      } = t.parseArguments("\\begin{" + i + "}", o), c = {
        mode: t.mode,
        envName: i,
        parser: t
      }, d = o.handler(c, s, u);
      t.expect("\\end", !1);
      var f = t.nextToken, p = ze(t.parseFunction(), "environment");
      if (p.name !== i)
        throw new me("Mismatch: \\begin{" + i + "} matched by \\end{" + p.name + "}", f);
      return d;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var a6 = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return He(n.body, r);
}, i6 = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return l0(n.body, r);
}, qs = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
ne({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = Qa(e[0]), i = r;
    return i in qs && (i = qs[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: a6,
  mathmlBuilder: i6
});
ne({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0], a = be.isCharacterBox(r);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Ja(r),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: r
      }],
      isCharacterBox: a
    };
  }
});
ne({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      breakOnTokenText: a
    } = n, {
      mode: i
    } = t, l = t.parseExpression(!0, a), o = "math" + r.slice(1);
    return {
      type: "font",
      mode: i,
      font: o,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: a6,
  mathmlBuilder: i6
});
var l6 = (n, e) => {
  var t = e;
  return n === "display" ? t = t.id >= ke.SCRIPT.id ? t.text() : ke.DISPLAY : n === "text" && t.size === ke.DISPLAY.size ? t = ke.TEXT : n === "script" ? t = ke.SCRIPT : n === "scriptscript" && (t = ke.SCRIPTSCRIPT), t;
}, d5 = (n, e) => {
  var t = l6(n.size, e.style), r = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(r);
  var l = He(n.numer, i, e);
  if (n.continued) {
    var o = 8.5 / e.fontMetrics().ptPerEm, s = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < o ? o : l.height, l.depth = l.depth < s ? s : l.depth;
  }
  i = e.havingStyle(a);
  var u = He(n.denom, i, e), c, d, f;
  n.hasBarLine ? (n.barSize ? (d = m0(n.barSize, e), c = L.makeLineSpan("frac-line", e, d)) : c = L.makeLineSpan("frac-line", e), d = c.height, f = c.height) : (c = null, d = 0, f = e.fontMetrics().defaultRuleThickness);
  var p, b, E;
  t.size === ke.DISPLAY.size || n.size === "display" ? (p = e.fontMetrics().num1, d > 0 ? b = 3 * f : b = 7 * f, E = e.fontMetrics().denom1) : (d > 0 ? (p = e.fontMetrics().num2, b = f) : (p = e.fontMetrics().num3, b = 3 * f), E = e.fontMetrics().denom2);
  var k;
  if (c) {
    var _ = e.fontMetrics().axisHeight;
    p - l.depth - (_ + 0.5 * d) < b && (p += b - (p - l.depth - (_ + 0.5 * d))), _ - 0.5 * d - (u.height - E) < b && (E += b - (_ - 0.5 * d - (u.height - E)));
    var v = -(_ - 0.5 * d);
    k = L.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: E
      }, {
        type: "elem",
        elem: c,
        shift: v
      }, {
        type: "elem",
        elem: l,
        shift: -p
      }]
    }, e);
  } else {
    var w = p - l.depth - (u.height - E);
    w < b && (p += 0.5 * (b - w), E += 0.5 * (b - w)), k = L.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: u,
        shift: E
      }, {
        type: "elem",
        elem: l,
        shift: -p
      }]
    }, e);
  }
  i = e.havingStyle(t), k.height *= i.sizeMultiplier / e.sizeMultiplier, k.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var A;
  t.size === ke.DISPLAY.size ? A = e.fontMetrics().delim1 : t.size === ke.SCRIPTSCRIPT.size ? A = e.havingStyle(ke.SCRIPT).fontMetrics().delim2 : A = e.fontMetrics().delim2;
  var x, Q;
  return n.leftDelim == null ? x = _1(e, ["mopen"]) : x = wr.customSizedDelim(n.leftDelim, A, !0, e.havingStyle(t), n.mode, ["mopen"]), n.continued ? Q = L.makeSpan([]) : n.rightDelim == null ? Q = _1(e, ["mclose"]) : Q = wr.customSizedDelim(n.rightDelim, A, !0, e.havingStyle(t), n.mode, ["mclose"]), L.makeSpan(["mord"].concat(i.sizingClasses(e)), [x, L.makeSpan(["mfrac"], [k]), Q], e);
}, m5 = (n, e) => {
  var t = new Y.MathNode("mfrac", [l0(n.numer, e), l0(n.denom, e)]);
  if (!n.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (n.barSize) {
    var r = m0(n.barSize, e);
    t.setAttribute("linethickness", te(r));
  }
  var a = l6(n.size, e.style);
  if (a.size !== e.style.size) {
    t = new Y.MathNode("mstyle", [t]);
    var i = a.size === ke.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (n.leftDelim != null || n.rightDelim != null) {
    var l = [];
    if (n.leftDelim != null) {
      var o = new Y.MathNode("mo", [new Y.TextNode(n.leftDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    if (l.push(t), n.rightDelim != null) {
      var s = new Y.MathNode("mo", [new Y.TextNode(n.rightDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    return a5(l);
  }
  return t;
};
ne({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1], l, o = null, s = null, u = "auto";
    switch (r) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, o = "(", s = ")";
        break;
      case "\\\\bracefrac":
        l = !1, o = "\\{", s = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, o = "[", s = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (r) {
      case "\\dfrac":
      case "\\dbinom":
        u = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        u = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: o,
      rightDelim: s,
      size: u,
      barSize: null
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
ne({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
ne({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t,
      token: r
    } = n, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: r
    };
  }
});
var Os = ["display", "text", "script", "scriptscript"], Ps = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
ne({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[4], a = e[5], i = Qa(e[0]), l = i.type === "atom" && i.family === "open" ? Ps(i.text) : null, o = Qa(e[1]), s = o.type === "atom" && o.family === "close" ? Ps(o.text) : null, u = ze(e[2], "size"), c, d = null;
    u.isBlank ? c = !0 : (d = u.value, c = d.number > 0);
    var f = "auto", p = e[3];
    if (p.type === "ordgroup") {
      if (p.body.length > 0) {
        var b = ze(p.body[0], "textord");
        f = Os[Number(b.text)];
      }
    } else
      p = ze(p, "textord"), f = Os[Number(p.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: r,
      denom: a,
      continued: !1,
      hasBarLine: c,
      barSize: d,
      leftDelim: l,
      rightDelim: s,
      size: f
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
ne({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: ze(e[0], "size").value,
      token: a
    };
  }
});
ne({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = y7(ze(e[1], "infix").size), l = e[2], o = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: o,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: d5,
  mathmlBuilder: m5
});
var s6 = (n, e) => {
  var t = e.style, r, a;
  n.type === "supsub" ? (r = n.sup ? He(n.sup, e.havingStyle(t.sup()), e) : He(n.sub, e.havingStyle(t.sub()), e), a = ze(n.base, "horizBrace")) : a = ze(n, "horizBrace");
  var i = He(a.base, e.havingBaseStyle(ke.DISPLAY)), l = Dr.svgSpan(a, e), o;
  if (a.isOver ? (o = L.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), o.children[0].children[0].children[1].classes.push("svg-align")) : (o = L.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), o.children[0].children[0].children[0].classes.push("svg-align")), r) {
    var s = L.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
    a.isOver ? o = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: r
      }]
    }, e) : o = L.makeVList({
      positionType: "bottom",
      positionData: s.depth + 0.2 + r.height + r.depth,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: s
      }]
    }, e);
  }
  return L.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
}, Pc = (n, e) => {
  var t = Dr.mathMLnode(n.label);
  return new Y.MathNode(n.isOver ? "mover" : "munder", [l0(n.base, e), t]);
};
ne({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: r,
      isOver: /^\\over/.test(r),
      base: e[0]
    };
  },
  htmlBuilder: s6,
  mathmlBuilder: Pc
});
ne({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[1], a = ze(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: b0(r)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e, !1);
    return L.makeAnchor(n.href, [], t, e);
  },
  mathmlBuilder: (n, e) => {
    var t = Xr(n.body, e);
    return t instanceof Rt || (t = new Rt("mrow", [t])), t.setAttribute("href", n.href), t;
  }
});
ne({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = ze(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: r
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < r.length; i++) {
      var l = r[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var o = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: r,
      body: b0(o)
    };
  }
});
ne({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "hbox",
      mode: t.mode,
      body: b0(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = U0(n.body, e, !1);
    return L.makeFragment(t);
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mrow", pt(n.body, e));
  }
});
ne({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n, i = ze(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var o, s = {};
    switch (r) {
      case "\\htmlClass":
        s.class = i, o = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        s.id = i, o = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        s.style = i, o = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var u = i.split(","), c = 0; c < u.length; c++) {
          var d = u[c].split("=");
          if (d.length !== 2)
            throw new me("Error parsing key-value for \\htmlData");
          s["data-" + d[0].trim()] = d[1].trim();
        }
        o = {
          command: "\\htmlData",
          attributes: s
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(o) ? {
      type: "html",
      mode: t.mode,
      attributes: s,
      body: b0(l)
    } : t.formatUnsupportedCmd(r);
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e, !1), r = ["enclosing"];
    n.attributes.class && r.push(...n.attributes.class.trim().split(/\s+/));
    var a = L.makeSpan(r, t, e);
    for (var i in n.attributes)
      i !== "class" && n.attributes.hasOwnProperty(i) && a.setAttribute(i, n.attributes[i]);
    return a;
  },
  mathmlBuilder: (n, e) => Xr(n.body, e)
});
ne({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: b0(e[0]),
      mathml: b0(e[1])
    };
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.html, e, !1);
    return L.makeFragment(t);
  },
  mathmlBuilder: (n, e) => Xr(n.mathml, e)
});
var Yi = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new me("Invalid size: '" + e + "' in \\includegraphics");
  var r = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!H7(r))
    throw new me("Invalid unit: '" + r.unit + "' in \\includegraphics.");
  return r;
};
ne({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, o = "";
    if (t[0])
      for (var s = ze(t[0], "raw").string, u = s.split(","), c = 0; c < u.length; c++) {
        var d = u[c].split("=");
        if (d.length === 2) {
          var f = d[1].trim();
          switch (d[0].trim()) {
            case "alt":
              o = f;
              break;
            case "width":
              a = Yi(f);
              break;
            case "height":
              i = Yi(f);
              break;
            case "totalheight":
              l = Yi(f);
              break;
            default:
              throw new me("Invalid key: '" + d[0] + "' in \\includegraphics.");
          }
        }
      }
    var p = ze(e[0], "url").url;
    return o === "" && (o = p, o = o.replace(/^.*[\\/]/, ""), o = o.substring(0, o.lastIndexOf("."))), r.settings.isTrusted({
      command: "\\includegraphics",
      url: p
    }) ? {
      type: "includegraphics",
      mode: r.mode,
      alt: o,
      width: a,
      height: i,
      totalheight: l,
      src: p
    } : r.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (n, e) => {
    var t = m0(n.height, e), r = 0;
    n.totalheight.number > 0 && (r = m0(n.totalheight, e) - t);
    var a = 0;
    n.width.number > 0 && (a = m0(n.width, e));
    var i = {
      height: te(t + r)
    };
    a > 0 && (i.width = te(a)), r > 0 && (i.verticalAlign = te(-r));
    var l = new V7(n.src, n.alt, i);
    return l.height = t, l.depth = r, l;
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mglyph", []);
    t.setAttribute("alt", n.alt);
    var r = m0(n.height, e), a = 0;
    if (n.totalheight.number > 0 && (a = m0(n.totalheight, e) - r, t.setAttribute("valign", te(-a))), t.setAttribute("height", te(r + a)), n.width.number > 0) {
      var i = m0(n.width, e);
      t.setAttribute("width", te(i));
    }
    return t.setAttribute("src", n.src), t;
  }
});
ne({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = ze(e[0], "size");
    if (t.settings.strict) {
      var i = r[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(n, e) {
    return L.makeGlue(n.dimension, e);
  },
  mathmlBuilder(n, e) {
    var t = m0(n.dimension, e);
    return new Y.SpaceNode(t);
  }
});
ne({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: r.slice(5),
      body: a
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    n.alignment === "clap" ? (t = L.makeSpan([], [He(n.body, e)]), t = L.makeSpan(["inner"], [t], e)) : t = L.makeSpan(["inner"], [He(n.body, e)]);
    var r = L.makeSpan(["fix"], []), a = L.makeSpan([n.alignment], [t, r], e), i = L.makeSpan(["strut"]);
    return i.style.height = te(a.height + a.depth), a.depth && (i.style.verticalAlign = te(-a.depth)), a.children.unshift(i), a = L.makeSpan(["thinbox"], [a], e), L.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mpadded", [l0(n.body, e)]);
    if (n.alignment !== "rlap") {
      var r = n.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", r + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
ne({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    var {
      funcName: t,
      parser: r
    } = n, a = r.mode;
    r.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = r.parseExpression(!1, i);
    return r.expect(i), r.switchMode(a), {
      type: "styling",
      mode: r.mode,
      style: "text",
      body: l
    };
  }
});
ne({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    throw new me("Mismatched " + n.funcName);
  }
});
var Hs = (n, e) => {
  switch (e.style.size) {
    case ke.DISPLAY.size:
      return n.display;
    case ke.TEXT.size:
      return n.text;
    case ke.SCRIPT.size:
      return n.script;
    case ke.SCRIPTSCRIPT.size:
      return n.scriptscript;
    default:
      return n.text;
  }
};
ne({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: b0(e[0]),
      text: b0(e[1]),
      script: b0(e[2]),
      scriptscript: b0(e[3])
    };
  },
  htmlBuilder: (n, e) => {
    var t = Hs(n, e), r = U0(t, e, !1);
    return L.makeFragment(r);
  },
  mathmlBuilder: (n, e) => {
    var t = Hs(n, e);
    return Xr(t, e);
  }
});
var o6 = (n, e, t, r, a, i, l) => {
  n = L.makeSpan([], [n]);
  var o = t && be.isCharacterBox(t), s, u;
  if (e) {
    var c = He(e, r.havingStyle(a.sup()), r);
    u = {
      elem: c,
      kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - c.depth)
    };
  }
  if (t) {
    var d = He(t, r.havingStyle(a.sub()), r);
    s = {
      elem: d,
      kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - d.height)
    };
  }
  var f;
  if (u && s) {
    var p = r.fontMetrics().bigOpSpacing5 + s.elem.height + s.elem.depth + s.kern + n.depth + l;
    f = L.makeVList({
      positionType: "bottom",
      positionData: p,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: te(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: te(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else if (s) {
    var b = n.height - l;
    f = L.makeVList({
      positionType: "top",
      positionData: b,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: s.elem,
        marginLeft: te(-i)
      }, {
        type: "kern",
        size: s.kern
      }, {
        type: "elem",
        elem: n
      }]
    }, r);
  } else if (u) {
    var E = n.depth + l;
    f = L.makeVList({
      positionType: "bottom",
      positionData: E,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: u.kern
      }, {
        type: "elem",
        elem: u.elem,
        marginLeft: te(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else
    return n;
  var k = [f];
  if (s && i !== 0 && !o) {
    var w = L.makeSpan(["mspace"], [], r);
    w.style.marginRight = te(i), k.unshift(w);
  }
  return L.makeSpan(["mop", "op-limits"], k, r);
}, u6 = ["\\smallint"], qn = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = ze(n.base, "op"), a = !0) : i = ze(n, "op");
  var l = e.style, o = !1;
  l.size === ke.DISPLAY.size && i.symbol && !be.contains(u6, i.name) && (o = !0);
  var s;
  if (i.symbol) {
    var u = o ? "Size2-Regular" : "Size1-Regular", c = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (c = i.name.slice(1), i.name = c === "oiint" ? "\\iint" : "\\iiint"), s = L.makeSymbol(i.name, u, "math", e, ["mop", "op-symbol", o ? "large-op" : "small-op"]), c.length > 0) {
      var d = s.italic, f = L.staticSvg(c + "Size" + (o ? "2" : "1"), e);
      s = L.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: s,
          shift: 0
        }, {
          type: "elem",
          elem: f,
          shift: o ? 0.08 : 0
        }]
      }, e), i.name = "\\" + c, s.classes.unshift("mop"), s.italic = d;
    }
  } else if (i.body) {
    var p = U0(i.body, e, !0);
    p.length === 1 && p[0] instanceof sr ? (s = p[0], s.classes[0] = "mop") : s = L.makeSpan(["mop"], p, e);
  } else {
    for (var b = [], E = 1; E < i.name.length; E++)
      b.push(L.mathsym(i.name[E], i.mode, e));
    s = L.makeSpan(["mop"], b, e);
  }
  var k = 0, w = 0;
  return (s instanceof sr || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (k = (s.height - s.depth) / 2 - e.fontMetrics().axisHeight, w = s.italic), a ? o6(s, t, r, e, l, w, k) : (k && (s.style.position = "relative", s.style.top = te(k)), s);
}, T1 = (n, e) => {
  var t;
  if (n.symbol)
    t = new Rt("mo", [Et(n.name, n.mode)]), be.contains(u6, n.name) && t.setAttribute("largeop", "false");
  else if (n.body)
    t = new Rt("mo", pt(n.body, e));
  else {
    t = new Rt("mi", [new l1(n.name.slice(1))]);
    var r = new Rt("mo", [Et("⁡", "text")]);
    n.parentIsSupSub ? t = new Rt("mrow", [t, r]) : t = O4([t, r]);
  }
  return t;
}, Hc = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
ne({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = r;
    return a.length === 1 && (a = Hc[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: T1
});
ne({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: b0(r)
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: T1
});
var Vc = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
ne({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: T1
});
ne({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: T1
});
ne({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = t;
    return r.length === 1 && (r = Vc[r]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: r
    };
  },
  htmlBuilder: qn,
  mathmlBuilder: T1
});
var c6 = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = ze(n.base, "operatorname"), a = !0) : i = ze(n, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var o = i.body.map((d) => {
      var f = d.text;
      return typeof f == "string" ? {
        type: "textord",
        mode: d.mode,
        text: f
      } : d;
    }), s = U0(o, e.withFont("mathrm"), !0), u = 0; u < s.length; u++) {
      var c = s[u];
      c instanceof sr && (c.text = c.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = L.makeSpan(["mop"], s, e);
  } else
    l = L.makeSpan(["mop"], [], e);
  return a ? o6(l, t, r, e, e.style, 0, 0) : l;
}, Uc = (n, e) => {
  for (var t = pt(n.body, e.withFont("mathrm")), r = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof Y.SpaceNode)) if (i instanceof Y.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof Y.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
          break;
        }
        default:
          r = !1;
      }
    else
      r = !1;
  }
  if (r) {
    var o = t.map((c) => c.toText()).join("");
    t = [new Y.TextNode(o)];
  }
  var s = new Y.MathNode("mi", t);
  s.setAttribute("mathvariant", "normal");
  var u = new Y.MathNode("mo", [Et("⁡", "text")]);
  return n.parentIsSupSub ? new Y.MathNode("mrow", [s, u]) : Y.newDocumentFragment([s, u]);
};
ne({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: b0(a),
      alwaysHandleSupSub: r === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: c6,
  mathmlBuilder: Uc
});
y("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
mn({
  type: "ordgroup",
  htmlBuilder(n, e) {
    return n.semisimple ? L.makeFragment(U0(n.body, e, !1)) : L.makeSpan(["mord"], U0(n.body, e, !0), e);
  },
  mathmlBuilder(n, e) {
    return Xr(n.body, e, !0);
  }
});
ne({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder(n, e) {
    var t = He(n.body, e.havingCrampedStyle()), r = L.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return L.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [new Y.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new Y.MathNode("mover", [l0(n.body, e), t]);
    return r.setAttribute("accent", "true"), r;
  }
});
ne({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: b0(r)
    };
  },
  htmlBuilder: (n, e) => {
    var t = U0(n.body, e.withPhantom(), !1);
    return L.makeFragment(t);
  },
  mathmlBuilder: (n, e) => {
    var t = pt(n.body, e);
    return new Y.MathNode("mphantom", t);
  }
});
ne({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = L.makeSpan([], [He(n.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0, t.children[r].depth = 0;
    return t = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), L.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (n, e) => {
    var t = pt(b0(n.body), e), r = new Y.MathNode("mphantom", t), a = new Y.MathNode("mpadded", [r]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
ne({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = L.makeSpan(["inner"], [He(n.body, e.withPhantom())]), r = L.makeSpan(["fix"], []);
    return L.makeSpan(["mord", "rlap"], [t, r], e);
  },
  mathmlBuilder: (n, e) => {
    var t = pt(b0(n.body), e), r = new Y.MathNode("mphantom", t), a = new Y.MathNode("mpadded", [r]);
    return a.setAttribute("width", "0px"), a;
  }
});
ne({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = ze(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: r,
      body: a
    };
  },
  htmlBuilder(n, e) {
    var t = He(n.body, e), r = m0(n.dy, e);
    return L.makeVList({
      positionType: "shift",
      positionData: -r,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mpadded", [l0(n.body, e)]), r = n.dy.number + n.dy.unit;
    return t.setAttribute("voffset", r), t;
  }
});
ne({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e
    } = n;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
ne({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    argTypes: ["size", "size", "size"]
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = ze(e[0], "size"), l = ze(e[1], "size");
    return {
      type: "rule",
      mode: r.mode,
      shift: a && ze(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(n, e) {
    var t = L.makeSpan(["mord", "rule"], [], e), r = m0(n.width, e), a = m0(n.height, e), i = n.shift ? m0(n.shift, e) : 0;
    return t.style.borderRightWidth = te(r), t.style.borderTopWidth = te(a), t.style.bottom = te(i), t.width = r, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(n, e) {
    var t = m0(n.width, e), r = m0(n.height, e), a = n.shift ? m0(n.shift, e) : 0, i = e.color && e.getColor() || "black", l = new Y.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", te(t)), l.setAttribute("height", te(r));
    var o = new Y.MathNode("mpadded", [l]);
    return a >= 0 ? o.setAttribute("height", te(a)) : (o.setAttribute("height", te(a)), o.setAttribute("depth", te(-a))), o.setAttribute("voffset", te(a)), o;
  }
});
function h6(n, e, t) {
  for (var r = U0(n, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < r.length; i++) {
    var l = r[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(r[i].classes, e.sizingClasses(t)) : r[i].classes[l + 1] === "reset-size" + e.size && (r[i].classes[l + 1] = "reset-size" + t.size), r[i].height *= a, r[i].depth *= a;
  }
  return L.makeFragment(r);
}
var Vs = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], jc = (n, e) => {
  var t = e.havingSize(n.size);
  return h6(n.body, t, e);
};
ne({
  type: "sizing",
  names: Vs,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: Vs.indexOf(r) + 1,
      body: i
    };
  },
  htmlBuilder: jc,
  mathmlBuilder: (n, e) => {
    var t = e.havingSize(n.size), r = pt(n.body, t), a = new Y.MathNode("mstyle", r);
    return a.setAttribute("mathsize", te(t.sizeMultiplier)), a;
  }
});
ne({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = !1, i = !1, l = t[0] && ze(t[0], "ordgroup");
    if (l)
      for (var o = "", s = 0; s < l.body.length; ++s) {
        var u = l.body[s];
        if (o = u.text, o === "t")
          a = !0;
        else if (o === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var c = e[0];
    return {
      type: "smash",
      mode: r.mode,
      body: c,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (n, e) => {
    var t = L.makeSpan([], [He(n.body, e)]);
    if (!n.smashHeight && !n.smashDepth)
      return t;
    if (n.smashHeight && (t.height = 0, t.children))
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0;
    if (n.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return L.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new Y.MathNode("mpadded", [l0(n.body, e)]);
    return n.smashHeight && t.setAttribute("height", "0px"), n.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
ne({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: r.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(n, e) {
    var t = He(n.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = L.wrapFragment(t, e);
    var r = e.fontMetrics(), a = r.defaultRuleThickness, i = a;
    e.style.id < ke.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, o = t.height + t.depth + l + a, {
      span: s,
      ruleWidth: u,
      advanceWidth: c
    } = wr.sqrtImage(o, e), d = s.height - u;
    d > t.height + t.depth + l && (l = (l + d - t.height - t.depth) / 2);
    var f = s.height - t.height - l - u;
    t.style.paddingLeft = te(c);
    var p = L.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + f)
      }, {
        type: "elem",
        elem: s
      }, {
        type: "kern",
        size: u
      }]
    }, e);
    if (n.index) {
      var b = e.havingStyle(ke.SCRIPTSCRIPT), E = He(n.index, b, e), k = 0.6 * (p.height - p.depth), w = L.makeVList({
        positionType: "shift",
        positionData: -k,
        children: [{
          type: "elem",
          elem: E
        }]
      }, e), _ = L.makeSpan(["root"], [w]);
      return L.makeSpan(["mord", "sqrt"], [_, p], e);
    } else
      return L.makeSpan(["mord", "sqrt"], [p], e);
  },
  mathmlBuilder(n, e) {
    var {
      body: t,
      index: r
    } = n;
    return r ? new Y.MathNode("mroot", [l0(t, e), l0(r, e)]) : new Y.MathNode("msqrt", [l0(t, e)]);
  }
});
var Us = {
  display: ke.DISPLAY,
  text: ke.TEXT,
  script: ke.SCRIPT,
  scriptscript: ke.SCRIPTSCRIPT
};
ne({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!0, t), l = r.slice(1, r.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(n, e) {
    var t = Us[n.style], r = e.havingStyle(t).withFont("");
    return h6(n.body, r, e);
  },
  mathmlBuilder(n, e) {
    var t = Us[n.style], r = e.havingStyle(t), a = pt(n.body, r), i = new Y.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, o = l[n.style];
    return i.setAttribute("scriptlevel", o[0]), i.setAttribute("displaystyle", o[1]), i;
  }
});
var Gc = function(e, t) {
  var r = e.base;
  if (r)
    if (r.type === "op") {
      var a = r.limits && (t.style.size === ke.DISPLAY.size || r.alwaysHandleSupSub);
      return a ? qn : null;
    } else if (r.type === "operatorname") {
      var i = r.alwaysHandleSupSub && (t.style.size === ke.DISPLAY.size || r.limits);
      return i ? c6 : null;
    } else {
      if (r.type === "accent")
        return be.isCharacterBox(r.base) ? s5 : null;
      if (r.type === "horizBrace") {
        var l = !e.sub;
        return l === r.isOver ? s6 : null;
      } else
        return null;
    }
  else return null;
};
mn({
  type: "supsub",
  htmlBuilder(n, e) {
    var t = Gc(n, e);
    if (t)
      return t(n, e);
    var {
      base: r,
      sup: a,
      sub: i
    } = n, l = He(r, e), o, s, u = e.fontMetrics(), c = 0, d = 0, f = r && be.isCharacterBox(r);
    if (a) {
      var p = e.havingStyle(e.style.sup());
      o = He(a, p, e), f || (c = l.height - p.fontMetrics().supDrop * p.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var b = e.havingStyle(e.style.sub());
      s = He(i, b, e), f || (d = l.depth + b.fontMetrics().subDrop * b.sizeMultiplier / e.sizeMultiplier);
    }
    var E;
    e.style === ke.DISPLAY ? E = u.sup1 : e.style.cramped ? E = u.sup3 : E = u.sup2;
    var k = e.sizeMultiplier, w = te(0.5 / u.ptPerEm / k), _ = null;
    if (s) {
      var v = n.base && n.base.type === "op" && n.base.name && (n.base.name === "\\oiint" || n.base.name === "\\oiiint");
      (l instanceof sr || v) && (_ = te(-l.italic));
    }
    var A;
    if (o && s) {
      c = Math.max(c, E, o.depth + 0.25 * u.xHeight), d = Math.max(d, u.sub2);
      var x = u.defaultRuleThickness, Q = 4 * x;
      if (c - o.depth - (s.height - d) < Q) {
        d = Q - (c - o.depth) + s.height;
        var B = 0.8 * u.xHeight - (c - o.depth);
        B > 0 && (c += B, d -= B);
      }
      var O = [{
        type: "elem",
        elem: s,
        shift: d,
        marginRight: w,
        marginLeft: _
      }, {
        type: "elem",
        elem: o,
        shift: -c,
        marginRight: w
      }];
      A = L.makeVList({
        positionType: "individualShift",
        children: O
      }, e);
    } else if (s) {
      d = Math.max(d, u.sub1, s.height - 0.8 * u.xHeight);
      var M = [{
        type: "elem",
        elem: s,
        marginLeft: _,
        marginRight: w
      }];
      A = L.makeVList({
        positionType: "shift",
        positionData: d,
        children: M
      }, e);
    } else if (o)
      c = Math.max(c, E, o.depth + 0.25 * u.xHeight), A = L.makeVList({
        positionType: "shift",
        positionData: -c,
        children: [{
          type: "elem",
          elem: o,
          marginRight: w
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var I = xl(l, "right") || "mord";
    return L.makeSpan([I], [l, L.makeSpan(["msupsub"], [A])], e);
  },
  mathmlBuilder(n, e) {
    var t = !1, r, a;
    n.base && n.base.type === "horizBrace" && (a = !!n.sup, a === n.base.isOver && (t = !0, r = n.base.isOver)), n.base && (n.base.type === "op" || n.base.type === "operatorname") && (n.base.parentIsSupSub = !0);
    var i = [l0(n.base, e)];
    n.sub && i.push(l0(n.sub, e)), n.sup && i.push(l0(n.sup, e));
    var l;
    if (t)
      l = r ? "mover" : "munder";
    else if (n.sub)
      if (n.sup) {
        var u = n.base;
        u && u.type === "op" && u.limits && e.style === ke.DISPLAY || u && u.type === "operatorname" && u.alwaysHandleSupSub && (e.style === ke.DISPLAY || u.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var s = n.base;
        s && s.type === "op" && s.limits && (e.style === ke.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === ke.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var o = n.base;
      o && o.type === "op" && o.limits && (e.style === ke.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === ke.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new Y.MathNode(l, i);
  }
});
mn({
  type: "atom",
  htmlBuilder(n, e) {
    return L.mathsym(n.text, n.mode, e, ["m" + n.family]);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [Et(n.text, n.mode)]);
    if (n.family === "bin") {
      var r = i5(n, e);
      r === "bold-italic" && t.setAttribute("mathvariant", r);
    } else n.family === "punct" ? t.setAttribute("separator", "true") : (n.family === "open" || n.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var f6 = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
mn({
  type: "mathord",
  htmlBuilder(n, e) {
    return L.makeOrd(n, e, "mathord");
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mi", [Et(n.text, n.mode, e)]), r = i5(n, e) || "italic";
    return r !== f6[t.type] && t.setAttribute("mathvariant", r), t;
  }
});
mn({
  type: "textord",
  htmlBuilder(n, e) {
    return L.makeOrd(n, e, "textord");
  },
  mathmlBuilder(n, e) {
    var t = Et(n.text, n.mode, e), r = i5(n, e) || "normal", a;
    return n.mode === "text" ? a = new Y.MathNode("mtext", [t]) : /[0-9]/.test(n.text) ? a = new Y.MathNode("mn", [t]) : n.text === "\\prime" ? a = new Y.MathNode("mo", [t]) : a = new Y.MathNode("mi", [t]), r !== f6[a.type] && a.setAttribute("mathvariant", r), a;
  }
});
var Xi = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, Ki = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
mn({
  type: "spacing",
  htmlBuilder(n, e) {
    if (Ki.hasOwnProperty(n.text)) {
      var t = Ki[n.text].className || "";
      if (n.mode === "text") {
        var r = L.makeOrd(n, e, "textord");
        return r.classes.push(t), r;
      } else
        return L.makeSpan(["mspace", t], [L.mathsym(n.text, n.mode, e)], e);
    } else {
      if (Xi.hasOwnProperty(n.text))
        return L.makeSpan(["mspace", Xi[n.text]], [], e);
      throw new me('Unknown type of space "' + n.text + '"');
    }
  },
  mathmlBuilder(n, e) {
    var t;
    if (Ki.hasOwnProperty(n.text))
      t = new Y.MathNode("mtext", [new Y.TextNode(" ")]);
    else {
      if (Xi.hasOwnProperty(n.text))
        return new Y.MathNode("mspace");
      throw new me('Unknown type of space "' + n.text + '"');
    }
    return t;
  }
});
var js = () => {
  var n = new Y.MathNode("mtd", []);
  return n.setAttribute("width", "50%"), n;
};
mn({
  type: "tag",
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mtable", [new Y.MathNode("mtr", [js(), new Y.MathNode("mtd", [Xr(n.body, e)]), js(), new Y.MathNode("mtd", [Xr(n.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var Gs = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Ws = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, Wc = {
  "\\textit": "textit",
  "\\textup": "textup"
}, Zs = (n, e) => {
  var t = n.font;
  if (t) {
    if (Gs[t])
      return e.withTextFontFamily(Gs[t]);
    if (Ws[t])
      return e.withTextFontWeight(Ws[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(Wc[t]);
};
ne({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: b0(a),
      font: r
    };
  },
  htmlBuilder(n, e) {
    var t = Zs(n, e), r = U0(n.body, t, !0);
    return L.makeSpan(["mord", "text"], r, t);
  },
  mathmlBuilder(n, e) {
    var t = Zs(n, e);
    return Xr(n.body, t);
  }
});
ne({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = He(n.body, e), r = L.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = L.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return L.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new Y.MathNode("mo", [new Y.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new Y.MathNode("munder", [l0(n.body, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
ne({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = He(n.body, e), r = e.fontMetrics().axisHeight, a = 0.5 * (t.height - r - (t.depth + r));
    return L.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    return new Y.MathNode("mpadded", [l0(n.body, e)], ["vcenter"]);
  }
});
ne({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    throw new me("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(n, e) {
    for (var t = Ys(n), r = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), r.push(L.makeSymbol(l, "Typewriter-Regular", n.mode, a, ["mord", "texttt"]));
    }
    return L.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), L.tryCombineChars(r), a);
  },
  mathmlBuilder(n, e) {
    var t = new Y.TextNode(Ys(n)), r = new Y.MathNode("mtext", [t]);
    return r.setAttribute("mathvariant", "monospace"), r;
  }
});
var Ys = (n) => n.body.replace(/ /g, n.star ? "␣" : " "), Zc = R4;
y("\\noexpand", function(n) {
  var e = n.popToken();
  return n.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
y("\\expandafter", function(n) {
  var e = n.popToken();
  return n.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
y("\\@firstoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
y("\\@secondoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
y("\\@ifnextchar", function(n) {
  var e = n.consumeArgs(3);
  n.consumeSpaces();
  var t = n.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
y("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
y("\\TextOrMath", function(n) {
  var e = n.consumeArgs(2);
  return n.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var Xs = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
y("\\char", function(n) {
  var e = n.popToken(), t, r = "";
  if (e.text === "'")
    t = 8, e = n.popToken();
  else if (e.text === '"')
    t = 16, e = n.popToken();
  else if (e.text === "`")
    if (e = n.popToken(), e.text[0] === "\\")
      r = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new me("\\char` missing argument");
      r = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (r = Xs[e.text], r == null || r >= t)
      throw new me("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = Xs[n.future().text]) != null && a < t; )
      r *= t, r += a, n.popToken();
  }
  return "\\@char{" + r + "}";
});
var p5 = (n, e, t) => {
  var r = n.consumeArg().tokens;
  if (r.length !== 1)
    throw new me("\\newcommand's first argument must be a macro name");
  var a = r[0].text, i = n.isDefined(a);
  if (i && !e)
    throw new me("\\newcommand{" + a + "} attempting to redefine " + (a + "; use \\renewcommand"));
  if (!i && !t)
    throw new me("\\renewcommand{" + a + "} when command " + a + " does not yet exist; use \\newcommand");
  var l = 0;
  if (r = n.consumeArg().tokens, r.length === 1 && r[0].text === "[") {
    for (var o = "", s = n.expandNextToken(); s.text !== "]" && s.text !== "EOF"; )
      o += s.text, s = n.expandNextToken();
    if (!o.match(/^\s*[0-9]+\s*$/))
      throw new me("Invalid number of arguments: " + o);
    l = parseInt(o), r = n.consumeArg().tokens;
  }
  return n.macros.set(a, {
    tokens: r,
    numArgs: l
  }), "";
};
y("\\newcommand", (n) => p5(n, !1, !0));
y("\\renewcommand", (n) => p5(n, !0, !1));
y("\\providecommand", (n) => p5(n, !0, !0));
y("\\message", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
y("\\errmessage", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
y("\\show", (n) => {
  var e = n.popToken(), t = e.text;
  return console.log(e, n.macros.get(t), Zc[t], w0.math[t], w0.text[t]), "";
});
y("\\bgroup", "{");
y("\\egroup", "}");
y("~", "\\nobreakspace");
y("\\lq", "`");
y("\\rq", "'");
y("\\aa", "\\r a");
y("\\AA", "\\r A");
y("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
y("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
y("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
y("ℬ", "\\mathscr{B}");
y("ℰ", "\\mathscr{E}");
y("ℱ", "\\mathscr{F}");
y("ℋ", "\\mathscr{H}");
y("ℐ", "\\mathscr{I}");
y("ℒ", "\\mathscr{L}");
y("ℳ", "\\mathscr{M}");
y("ℛ", "\\mathscr{R}");
y("ℭ", "\\mathfrak{C}");
y("ℌ", "\\mathfrak{H}");
y("ℨ", "\\mathfrak{Z}");
y("\\Bbbk", "\\Bbb{k}");
y("·", "\\cdotp");
y("\\llap", "\\mathllap{\\textrm{#1}}");
y("\\rlap", "\\mathrlap{\\textrm{#1}}");
y("\\clap", "\\mathclap{\\textrm{#1}}");
y("\\mathstrut", "\\vphantom{(}");
y("\\underbar", "\\underline{\\text{#1}}");
y("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
y("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
y("\\ne", "\\neq");
y("≠", "\\neq");
y("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
y("∉", "\\notin");
y("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
y("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
y("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
y("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
y("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
y("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
y("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
y("⟂", "\\perp");
y("‼", "\\mathclose{!\\mkern-0.8mu!}");
y("∌", "\\notni");
y("⌜", "\\ulcorner");
y("⌝", "\\urcorner");
y("⌞", "\\llcorner");
y("⌟", "\\lrcorner");
y("©", "\\copyright");
y("®", "\\textregistered");
y("️", "\\textregistered");
y("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
y("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
y("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
y("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
y("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}");
y("⋮", "\\vdots");
y("\\varGamma", "\\mathit{\\Gamma}");
y("\\varDelta", "\\mathit{\\Delta}");
y("\\varTheta", "\\mathit{\\Theta}");
y("\\varLambda", "\\mathit{\\Lambda}");
y("\\varXi", "\\mathit{\\Xi}");
y("\\varPi", "\\mathit{\\Pi}");
y("\\varSigma", "\\mathit{\\Sigma}");
y("\\varUpsilon", "\\mathit{\\Upsilon}");
y("\\varPhi", "\\mathit{\\Phi}");
y("\\varPsi", "\\mathit{\\Psi}");
y("\\varOmega", "\\mathit{\\Omega}");
y("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
y("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
y("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
y("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
y("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
y("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
var Ks = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
y("\\dots", function(n) {
  var e = "\\dotso", t = n.expandAfterFuture().text;
  return t in Ks ? e = Ks[t] : (t.slice(0, 4) === "\\not" || t in w0.math && be.contains(["bin", "rel"], w0.math[t].group)) && (e = "\\dotsb"), e;
});
var g5 = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
y("\\dotso", function(n) {
  var e = n.future().text;
  return e in g5 ? "\\ldots\\," : "\\ldots";
});
y("\\dotsc", function(n) {
  var e = n.future().text;
  return e in g5 && e !== "," ? "\\ldots\\," : "\\ldots";
});
y("\\cdots", function(n) {
  var e = n.future().text;
  return e in g5 ? "\\@cdots\\," : "\\@cdots";
});
y("\\dotsb", "\\cdots");
y("\\dotsm", "\\cdots");
y("\\dotsi", "\\!\\cdots");
y("\\dotsx", "\\ldots\\,");
y("\\DOTSI", "\\relax");
y("\\DOTSB", "\\relax");
y("\\DOTSX", "\\relax");
y("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
y("\\,", "\\tmspace+{3mu}{.1667em}");
y("\\thinspace", "\\,");
y("\\>", "\\mskip{4mu}");
y("\\:", "\\tmspace+{4mu}{.2222em}");
y("\\medspace", "\\:");
y("\\;", "\\tmspace+{5mu}{.2777em}");
y("\\thickspace", "\\;");
y("\\!", "\\tmspace-{3mu}{.1667em}");
y("\\negthinspace", "\\!");
y("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
y("\\negthickspace", "\\tmspace-{5mu}{.277em}");
y("\\enspace", "\\kern.5em ");
y("\\enskip", "\\hskip.5em\\relax");
y("\\quad", "\\hskip1em\\relax");
y("\\qquad", "\\hskip2em\\relax");
y("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
y("\\tag@paren", "\\tag@literal{({#1})}");
y("\\tag@literal", (n) => {
  if (n.macros.get("\\df@tag"))
    throw new me("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
y("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
y("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
y("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
y("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
y("\\newline", "\\\\\\relax");
y("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var d6 = te(_r["Main-Regular"][84][1] - 0.7 * _r["Main-Regular"][65][1]);
y("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + d6 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
y("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + d6 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
y("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
y("\\@hspace", "\\hskip #1\\relax");
y("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
y("\\ordinarycolon", ":");
y("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
y("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
y("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
y("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
y("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
y("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
y("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
y("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
y("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
y("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
y("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
y("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
y("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
y("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
y("∷", "\\dblcolon");
y("∹", "\\eqcolon");
y("≔", "\\coloneqq");
y("≕", "\\eqqcolon");
y("⩴", "\\Coloneqq");
y("\\ratio", "\\vcentcolon");
y("\\coloncolon", "\\dblcolon");
y("\\colonequals", "\\coloneqq");
y("\\coloncolonequals", "\\Coloneqq");
y("\\equalscolon", "\\eqqcolon");
y("\\equalscoloncolon", "\\Eqqcolon");
y("\\colonminus", "\\coloneq");
y("\\coloncolonminus", "\\Coloneq");
y("\\minuscolon", "\\eqcolon");
y("\\minuscoloncolon", "\\Eqcolon");
y("\\coloncolonapprox", "\\Colonapprox");
y("\\coloncolonsim", "\\Colonsim");
y("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
y("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
y("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
y("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
y("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
y("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
y("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
y("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
y("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
y("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
y("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
y("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
y("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
y("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
y("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
y("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
y("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
y("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
y("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
y("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
y("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
y("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
y("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
y("\\imath", "\\html@mathml{\\@imath}{ı}");
y("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
y("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
y("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
y("⟦", "\\llbracket");
y("⟧", "\\rrbracket");
y("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
y("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
y("⦃", "\\lBrace");
y("⦄", "\\rBrace");
y("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
y("⦵", "\\minuso");
y("\\darr", "\\downarrow");
y("\\dArr", "\\Downarrow");
y("\\Darr", "\\Downarrow");
y("\\lang", "\\langle");
y("\\rang", "\\rangle");
y("\\uarr", "\\uparrow");
y("\\uArr", "\\Uparrow");
y("\\Uarr", "\\Uparrow");
y("\\N", "\\mathbb{N}");
y("\\R", "\\mathbb{R}");
y("\\Z", "\\mathbb{Z}");
y("\\alef", "\\aleph");
y("\\alefsym", "\\aleph");
y("\\Alpha", "\\mathrm{A}");
y("\\Beta", "\\mathrm{B}");
y("\\bull", "\\bullet");
y("\\Chi", "\\mathrm{X}");
y("\\clubs", "\\clubsuit");
y("\\cnums", "\\mathbb{C}");
y("\\Complex", "\\mathbb{C}");
y("\\Dagger", "\\ddagger");
y("\\diamonds", "\\diamondsuit");
y("\\empty", "\\emptyset");
y("\\Epsilon", "\\mathrm{E}");
y("\\Eta", "\\mathrm{H}");
y("\\exist", "\\exists");
y("\\harr", "\\leftrightarrow");
y("\\hArr", "\\Leftrightarrow");
y("\\Harr", "\\Leftrightarrow");
y("\\hearts", "\\heartsuit");
y("\\image", "\\Im");
y("\\infin", "\\infty");
y("\\Iota", "\\mathrm{I}");
y("\\isin", "\\in");
y("\\Kappa", "\\mathrm{K}");
y("\\larr", "\\leftarrow");
y("\\lArr", "\\Leftarrow");
y("\\Larr", "\\Leftarrow");
y("\\lrarr", "\\leftrightarrow");
y("\\lrArr", "\\Leftrightarrow");
y("\\Lrarr", "\\Leftrightarrow");
y("\\Mu", "\\mathrm{M}");
y("\\natnums", "\\mathbb{N}");
y("\\Nu", "\\mathrm{N}");
y("\\Omicron", "\\mathrm{O}");
y("\\plusmn", "\\pm");
y("\\rarr", "\\rightarrow");
y("\\rArr", "\\Rightarrow");
y("\\Rarr", "\\Rightarrow");
y("\\real", "\\Re");
y("\\reals", "\\mathbb{R}");
y("\\Reals", "\\mathbb{R}");
y("\\Rho", "\\mathrm{P}");
y("\\sdot", "\\cdot");
y("\\sect", "\\S");
y("\\spades", "\\spadesuit");
y("\\sub", "\\subset");
y("\\sube", "\\subseteq");
y("\\supe", "\\supseteq");
y("\\Tau", "\\mathrm{T}");
y("\\thetasym", "\\vartheta");
y("\\weierp", "\\wp");
y("\\Zeta", "\\mathrm{Z}");
y("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
y("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
y("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
y("\\bra", "\\mathinner{\\langle{#1}|}");
y("\\ket", "\\mathinner{|{#1}\\rangle}");
y("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
y("\\Bra", "\\left\\langle#1\\right|");
y("\\Ket", "\\left|#1\\right\\rangle");
var m6 = (n) => (e) => {
  var t = e.consumeArg().tokens, r = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), o = e.macros.get("\\|");
  e.macros.beginGroup();
  var s = (d) => (f) => {
    n && (f.macros.set("|", l), a.length && f.macros.set("\\|", o));
    var p = d;
    if (!d && a.length) {
      var b = f.future();
      b.text === "|" && (f.popToken(), p = !0);
    }
    return {
      tokens: p ? a : r,
      numArgs: 0
    };
  };
  e.macros.set("|", s(!1)), a.length && e.macros.set("\\|", s(!0));
  var u = e.consumeArg().tokens, c = e.expandTokens([
    ...i,
    ...u,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: c.reverse(),
    numArgs: 0
  };
};
y("\\bra@ket", m6(!1));
y("\\bra@set", m6(!0));
y("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
y("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
y("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
y("\\angln", "{\\angl n}");
y("\\blue", "\\textcolor{##6495ed}{#1}");
y("\\orange", "\\textcolor{##ffa500}{#1}");
y("\\pink", "\\textcolor{##ff00af}{#1}");
y("\\red", "\\textcolor{##df0030}{#1}");
y("\\green", "\\textcolor{##28ae7b}{#1}");
y("\\gray", "\\textcolor{gray}{#1}");
y("\\purple", "\\textcolor{##9d38bd}{#1}");
y("\\blueA", "\\textcolor{##ccfaff}{#1}");
y("\\blueB", "\\textcolor{##80f6ff}{#1}");
y("\\blueC", "\\textcolor{##63d9ea}{#1}");
y("\\blueD", "\\textcolor{##11accd}{#1}");
y("\\blueE", "\\textcolor{##0c7f99}{#1}");
y("\\tealA", "\\textcolor{##94fff5}{#1}");
y("\\tealB", "\\textcolor{##26edd5}{#1}");
y("\\tealC", "\\textcolor{##01d1c1}{#1}");
y("\\tealD", "\\textcolor{##01a995}{#1}");
y("\\tealE", "\\textcolor{##208170}{#1}");
y("\\greenA", "\\textcolor{##b6ffb0}{#1}");
y("\\greenB", "\\textcolor{##8af281}{#1}");
y("\\greenC", "\\textcolor{##74cf70}{#1}");
y("\\greenD", "\\textcolor{##1fab54}{#1}");
y("\\greenE", "\\textcolor{##0d923f}{#1}");
y("\\goldA", "\\textcolor{##ffd0a9}{#1}");
y("\\goldB", "\\textcolor{##ffbb71}{#1}");
y("\\goldC", "\\textcolor{##ff9c39}{#1}");
y("\\goldD", "\\textcolor{##e07d10}{#1}");
y("\\goldE", "\\textcolor{##a75a05}{#1}");
y("\\redA", "\\textcolor{##fca9a9}{#1}");
y("\\redB", "\\textcolor{##ff8482}{#1}");
y("\\redC", "\\textcolor{##f9685d}{#1}");
y("\\redD", "\\textcolor{##e84d39}{#1}");
y("\\redE", "\\textcolor{##bc2612}{#1}");
y("\\maroonA", "\\textcolor{##ffbde0}{#1}");
y("\\maroonB", "\\textcolor{##ff92c6}{#1}");
y("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
y("\\maroonD", "\\textcolor{##ca337c}{#1}");
y("\\maroonE", "\\textcolor{##9e034e}{#1}");
y("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
y("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
y("\\purpleC", "\\textcolor{##aa87ff}{#1}");
y("\\purpleD", "\\textcolor{##7854ab}{#1}");
y("\\purpleE", "\\textcolor{##543b78}{#1}");
y("\\mintA", "\\textcolor{##f5f9e8}{#1}");
y("\\mintB", "\\textcolor{##edf2df}{#1}");
y("\\mintC", "\\textcolor{##e0e5cc}{#1}");
y("\\grayA", "\\textcolor{##f6f7f7}{#1}");
y("\\grayB", "\\textcolor{##f0f1f2}{#1}");
y("\\grayC", "\\textcolor{##e3e5e6}{#1}");
y("\\grayD", "\\textcolor{##d6d8da}{#1}");
y("\\grayE", "\\textcolor{##babec2}{#1}");
y("\\grayF", "\\textcolor{##888d93}{#1}");
y("\\grayG", "\\textcolor{##626569}{#1}");
y("\\grayH", "\\textcolor{##3b3e40}{#1}");
y("\\grayI", "\\textcolor{##21242c}{#1}");
y("\\kaBlue", "\\textcolor{##314453}{#1}");
y("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function _5() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let pn = _5();
function p6(n) {
  pn = n;
}
const g6 = /[&<>"']/, Yc = new RegExp(g6.source, "g"), _6 = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Xc = new RegExp(_6.source, "g"), Kc = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Js = (n) => Kc[n];
function ct(n, e) {
  if (e) {
    if (g6.test(n))
      return n.replace(Yc, Js);
  } else if (_6.test(n))
    return n.replace(Xc, Js);
  return n;
}
const Jc = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function $c(n) {
  return n.replace(Jc, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const e9 = /(^|[^\[])\^/g;
function n0(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(e9, "$1"), t = t.replace(a, l), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function $s(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const o1 = { exec: () => null };
function eo(n, e) {
  const t = n.replace(/\|/g, (i, l, o) => {
    let s = !1, u = l;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), r = t.split(/ \|/);
  let a = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; a < r.length; a++)
    r[a] = r[a].trim().replace(/\\\|/g, "|");
  return r;
}
function ua(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let a = 0;
  for (; a < r; ) {
    const i = n.charAt(r - a - 1);
    if (i === e && !t)
      a++;
    else if (i !== e && t)
      a++;
    else
      break;
  }
  return n.slice(0, r - a);
}
function t9(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function to(n, e, t, r) {
  const a = e.href, i = e.title ? ct(e.title) : null, l = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: r.inlineTokens(l)
    };
    return r.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: ct(l)
  };
}
function r9(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= r.length ? a.slice(r.length) : a;
  }).join(`
`);
}
class Ma {
  // set by the lexer
  constructor(e) {
    c0(this, "options");
    c0(this, "rules");
    // set by the lexer
    c0(this, "lexer");
    this.options = e || pn;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : ua(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], a = r9(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const a = ua(r, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (r = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = ua(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(r);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const a = r.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = a ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = a ? r : "[*+-]");
      const l = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (w) => " ".repeat(3 * w.length)), f = e.split(`
`, 1)[0], p = 0;
        this.options.pedantic ? (p = 2, s = d.trimStart()) : (p = t[2].search(/[^ ]/), p = p > 4 ? 1 : p, s = d.slice(p), p += t[1].length);
        let b = !1;
        if (!d && /^ *$/.test(f) && (o += f + `
`, e = e.substring(f.length + 1), c = !0), !c) {
          const w = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), _ = new RegExp(`^ {0,${Math.min(3, p - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), v = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:\`\`\`|~~~)`), A = new RegExp(`^ {0,${Math.min(3, p - 1)}}#`);
          for (; e; ) {
            const x = e.split(`
`, 1)[0];
            if (f = x, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), v.test(f) || A.test(f) || w.test(f) || _.test(e))
              break;
            if (f.search(/[^ ]/) >= p || !f.trim())
              s += `
` + f.slice(p);
            else {
              if (b || d.search(/[^ ]/) >= 4 || v.test(d) || A.test(d) || _.test(d))
                break;
              s += `
` + f;
            }
            !b && !f.trim() && (b = !0), o += x + `
`, e = e.substring(x.length + 1), d = f.slice(p);
          }
        }
        i.loose || (u ? i.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let E = null, k;
        this.options.gfm && (E = /^\[[ xX]\] /.exec(s), E && (k = E[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: o,
          task: !!E,
          checked: k,
          loose: !1,
          text: s,
          tokens: []
        }), i.raw += o;
      }
      i.items[i.items.length - 1].raw = o.trimEnd(), i.items[i.items.length - 1].text = s.trimEnd(), i.raw = i.raw.trimEnd();
      for (let c = 0; c < i.items.length; c++)
        if (this.lexer.state.top = !1, i.items[c].tokens = this.lexer.blockTokens(i.items[c].text, []), !i.loose) {
          const d = i.items[c].tokens.filter((p) => p.type === "space"), f = d.length > 0 && d.some((p) => /\n.*\n/.test(p.raw));
          i.loose = f;
        }
      if (i.loose)
        for (let c = 0; c < i.items.length; c++)
          i.items[c].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = eo(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === a.length) {
      for (const o of a)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of r)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of i)
        l.rows.push(eo(o, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: ct(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const l = ua(r.slice(0, -1), "\\");
        if ((r.length - l.length) % 2 === 0)
          return;
      } else {
        const l = t9(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(r) ? a = a.slice(1) : a = a.slice(1, -1)), to(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const a = (r[2] || r[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = r[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return to(r, i, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const l = [...a[0]].length - 1;
      let o, s, u = l, c = 0;
      const d = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = d.exec(t)) != null; ) {
        if (o = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !o)
          continue;
        if (s = [...o].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const f = [...a[0]][0].length, p = e.slice(0, l + a.index + f + s);
        if (Math.min(l, s) % 2) {
          const E = p.slice(1, -1);
          return {
            type: "em",
            raw: p,
            text: E,
            tokens: this.lexer.inlineTokens(E)
          };
        }
        const b = p.slice(2, -2);
        return {
          type: "strong",
          raw: p,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(r), i = /^ /.test(r) && / $/.test(r);
      return a && i && (r = r.substring(1, r.length - 1)), r = ct(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, a;
      return t[2] === "@" ? (r = ct(t[1]), a = "mailto:" + r) : (r = ct(t[1]), a = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = ct(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (l !== t[0]);
        a = ct(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = ct(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const n9 = /^(?: *(?:\n|$))+/, a9 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, i9 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Q1 = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, l9 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, v6 = /(?:[*+-]|\d{1,9}[.)])/, b6 = n0(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, v6).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), v5 = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, s9 = /^[^\n]+/, b5 = /(?!\s*\])(?:\\.|[^\[\]\\])+/, o9 = n0(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", b5).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), u9 = n0(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, v6).getRegex(), ti = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", w5 = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, c9 = n0("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", w5).replace("tag", ti).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), w6 = n0(v5).replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ti).getRegex(), h9 = n0(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", w6).getRegex(), y5 = {
  blockquote: h9,
  code: a9,
  def: o9,
  fences: i9,
  heading: l9,
  hr: Q1,
  html: c9,
  lheading: b6,
  list: u9,
  newline: n9,
  paragraph: w6,
  table: o1,
  text: s9
}, ro = n0("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ti).getRegex(), f9 = {
  ...y5,
  table: ro,
  paragraph: n0(v5).replace("hr", Q1).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ro).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ti).getRegex()
}, d9 = {
  ...y5,
  html: n0(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", w5).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: o1,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: n0(v5).replace("hr", Q1).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", b6).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, y6 = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, m9 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, k6 = /^( {2,}|\\)\n(?!\s*$)/, p9 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, M1 = "\\p{P}\\p{S}", g9 = n0(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, M1).getRegex(), _9 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, v9 = n0(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, M1).getRegex(), b9 = n0("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, M1).getRegex(), w9 = n0("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, M1).getRegex(), y9 = n0(/\\([punct])/, "gu").replace(/punct/g, M1).getRegex(), k9 = n0(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), D9 = n0(w5).replace("(?:-->|$)", "-->").getRegex(), E9 = n0("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", D9).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Ba = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, A9 = n0(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Ba).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), D6 = n0(/^!?\[(label)\]\[(ref)\]/).replace("label", Ba).replace("ref", b5).getRegex(), E6 = n0(/^!?\[(ref)\](?:\[\])?/).replace("ref", b5).getRegex(), F9 = n0("reflink|nolink(?!\\()", "g").replace("reflink", D6).replace("nolink", E6).getRegex(), k5 = {
  _backpedal: o1,
  // only used for GFM url
  anyPunctuation: y9,
  autolink: k9,
  blockSkip: _9,
  br: k6,
  code: m9,
  del: o1,
  emStrongLDelim: v9,
  emStrongRDelimAst: b9,
  emStrongRDelimUnd: w9,
  escape: y6,
  link: A9,
  nolink: E6,
  punctuation: g9,
  reflink: D6,
  reflinkSearch: F9,
  tag: E9,
  text: p9,
  url: o1
}, S9 = {
  ...k5,
  link: n0(/^!?\[(label)\]\((.*?)\)/).replace("label", Ba).getRegex(),
  reflink: n0(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Ba).getRegex()
}, Ql = {
  ...k5,
  escape: n0(y6).replace("])", "~|])").getRegex(),
  url: n0(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, x9 = {
  ...Ql,
  br: n0(k6).replace("{2,}", "*").getRegex(),
  text: n0(Ql.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, ca = {
  normal: y5,
  gfm: f9,
  pedantic: d9
}, Kn = {
  normal: k5,
  gfm: Ql,
  breaks: x9,
  pedantic: S9
};
class tr {
  constructor(e) {
    c0(this, "tokens");
    c0(this, "options");
    c0(this, "state");
    c0(this, "tokenizer");
    c0(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || pn, this.options.tokenizer = this.options.tokenizer || new Ma(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: ca.normal,
      inline: Kn.normal
    };
    this.options.pedantic ? (t.block = ca.pedantic, t.inline = Kn.pedantic) : this.options.gfm && (t.block = ca.gfm, this.options.breaks ? t.inline = Kn.breaks : t.inline = Kn.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: ca,
      inline: Kn
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new tr(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new tr(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let r, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (r = o.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (i = e.substring(0, o + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r), l = i.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, a, i, l = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (r = c.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const d = e.slice(1);
          let f;
          this.options.extensions.startInline.forEach((p) => {
            f = p.call({ lexer: this }, d), typeof f == "number" && f >= 0 && (c = Math.min(c, f));
          }), c < 1 / 0 && c >= 0 && (i = e.substring(0, c + 1));
        }
        if (r = this.tokenizer.inlineText(i)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (u = r.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class za {
  constructor(e) {
    c0(this, "options");
    this.options = e || pn;
  }
  code(e, t, r) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + ct(a) + '">' + (r ? e : ct(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : ct(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const a = t ? "ol" : "ul", i = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const a = $s(e);
    if (a === null)
      return r;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + r + "</a>", i;
  }
  image(e, t, r) {
    const a = $s(e);
    if (a === null)
      return r;
    e = a;
    let i = `<img src="${e}" alt="${r}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class D5 {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class rr {
  constructor(e) {
    c0(this, "options");
    c0(this, "renderer");
    c0(this, "textRenderer");
    this.options = e || pn, this.options.renderer = this.options.renderer || new za(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new D5();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new rr(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new rr(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          r += o || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          r += this.renderer.heading(this.parseInline(l.tokens), l.depth, $c(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          r += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let o = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const d = l.rows[c];
            s = "";
            for (let f = 0; f < d.length; f++)
              s += this.renderer.tablecell(this.parseInline(d[f].tokens), { header: !1, align: l.align[f] });
            u += this.renderer.tablerow(s);
          }
          r += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const l = i, o = this.parse(l.tokens);
          r += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = i, o = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let d = 0; d < l.items.length; d++) {
            const f = l.items[d], p = f.checked, b = f.task;
            let E = "";
            if (f.task) {
              const k = this.renderer.checkbox(!!p);
              u ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = k + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = k + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: k + " "
              }) : E += k + " ";
            }
            E += this.parse(f.tokens, u), c += this.renderer.listitem(E, b, !!p);
          }
          r += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const l = i;
          r += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          r += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          r += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          r += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          r += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          r += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          r += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          r += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          r += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          r += t.codespan(l.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const l = i;
          r += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
}
class u1 {
  constructor(e) {
    c0(this, "options");
    this.options = e || pn;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
c0(u1, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var dn, Ml, A6;
class C9 {
  constructor(...e) {
    ts(this, dn);
    c0(this, "defaults", _5());
    c0(this, "options", this.setOptions);
    c0(this, "parse", H1(this, dn, Ml).call(this, tr.lex, rr.parse));
    c0(this, "parseInline", H1(this, dn, Ml).call(this, tr.lexInline, rr.parseInline));
    c0(this, "Parser", rr);
    c0(this, "Renderer", za);
    c0(this, "TextRenderer", D5);
    c0(this, "Lexer", tr);
    c0(this, "Tokenizer", Ma);
    c0(this, "Hooks", u1);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let r = [];
    for (const l of e)
      switch (r = r.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const s of o.header)
            r = r.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const u of s)
              r = r.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            r = r.concat(this.walkTokens(u, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const a = { ...r };
      if (a.async = this.defaults.async || a.async || !1, r.extensions && (r.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...o) {
            let s = i.renderer.apply(this, o);
            return s === !1 && (s = l.apply(this, o)), s;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), r.renderer) {
        const i = this.defaults.renderer || new za(this.defaults);
        for (const l in r.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = r.renderer[o], u = i[o];
          i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d || "";
          };
        }
        a.renderer = i;
      }
      if (r.tokenizer) {
        const i = this.defaults.tokenizer || new Ma(this.defaults);
        for (const l in r.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, s = r.tokenizer[o], u = i[o];
          i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d;
          };
        }
        a.tokenizer = i;
      }
      if (r.hooks) {
        const i = this.defaults.hooks || new u1();
        for (const l in r.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = r.hooks[o], u = i[o];
          u1.passThroughHooks.has(l) ? i[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(i, c)).then((f) => u.call(i, f));
            const d = s.call(i, c);
            return u.call(i, d);
          } : i[o] = (...c) => {
            let d = s.apply(i, c);
            return d === !1 && (d = u.apply(i, c)), d;
          };
        }
        a.hooks = i;
      }
      if (r.walkTokens) {
        const i = this.defaults.walkTokens, l = r.walkTokens;
        a.walkTokens = function(o) {
          let s = [];
          return s.push(l.call(this, o)), i && (s = s.concat(i.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return tr.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return rr.parse(e, t ?? this.defaults);
  }
}
dn = new WeakSet(), Ml = function(e, t) {
  return (r, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = H1(this, dn, A6).call(this, !!l.silent, !!l.async);
    if (typeof r > "u" || r === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(r) : r).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(o);
    try {
      l.hooks && (r = l.hooks.preprocess(r));
      let s = e(r, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, A6 = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + ct(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const hn = new C9();
function r0(n, e) {
  return hn.parse(n, e);
}
r0.options = r0.setOptions = function(n) {
  return hn.setOptions(n), r0.defaults = hn.defaults, p6(r0.defaults), r0;
};
r0.getDefaults = _5;
r0.defaults = pn;
r0.use = function(...n) {
  return hn.use(...n), r0.defaults = hn.defaults, p6(r0.defaults), r0;
};
r0.walkTokens = function(n, e) {
  return hn.walkTokens(n, e);
};
r0.parseInline = hn.parseInline;
r0.Parser = rr;
r0.parser = rr.parse;
r0.Renderer = za;
r0.TextRenderer = D5;
r0.Lexer = tr;
r0.lexer = tr.lex;
r0.Tokenizer = Ma;
r0.Hooks = u1;
r0.parse = r0;
r0.options;
r0.setOptions;
r0.use;
r0.walkTokens;
r0.parseInline;
rr.parse;
tr.lex;
const T9 = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Q9 = Object.hasOwnProperty;
class F6 {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let a = M9(e, t === !0);
    const i = a;
    for (; Q9.call(r.occurrences, a); )
      r.occurrences[i]++, a = i + "-" + r.occurrences[i];
    return r.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function M9(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(T9, "").replace(/ /g, "-"));
}
new F6();
var no = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, B9 = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function _(v) {
          return v instanceof s ? new s(v.type, _(v.content), v.alias) : Array.isArray(v) ? v.map(_) : v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(_) {
          return Object.prototype.toString.call(_).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(_) {
          return _.__id || Object.defineProperty(_, "__id", { value: ++i }), _.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function _(v, A) {
          A = A || {};
          var x, Q;
          switch (o.util.type(v)) {
            case "Object":
              if (Q = o.util.objId(v), A[Q])
                return A[Q];
              x = /** @type {Record<string, any>} */
              {}, A[Q] = x;
              for (var B in v)
                v.hasOwnProperty(B) && (x[B] = _(v[B], A));
              return (
                /** @type {any} */
                x
              );
            case "Array":
              return Q = o.util.objId(v), A[Q] ? A[Q] : (x = [], A[Q] = x, /** @type {Array} */
              /** @type {any} */
              v.forEach(function(O, M) {
                x[M] = _(O, A);
              }), /** @type {any} */
              x);
            default:
              return v;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(_) {
          for (; _; ) {
            var v = a.exec(_.className);
            if (v)
              return v[1].toLowerCase();
            _ = _.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(_, v) {
          _.className = _.className.replace(RegExp(a, "gi"), ""), _.classList.add("language-" + v);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (x) {
            var _ = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(x.stack) || [])[1];
            if (_) {
              var v = document.getElementsByTagName("script");
              for (var A in v)
                if (v[A].src == _)
                  return v[A];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(_, v, A) {
          for (var x = "no-" + v; _; ) {
            var Q = _.classList;
            if (Q.contains(v))
              return !0;
            if (Q.contains(x))
              return !1;
            _ = _.parentElement;
          }
          return !!A;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(_, v) {
          var A = o.util.clone(o.languages[_]);
          for (var x in v)
            A[x] = v[x];
          return A;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(_, v, A, x) {
          x = x || /** @type {any} */
          o.languages;
          var Q = x[_], B = {};
          for (var O in Q)
            if (Q.hasOwnProperty(O)) {
              if (O == v)
                for (var M in A)
                  A.hasOwnProperty(M) && (B[M] = A[M]);
              A.hasOwnProperty(O) || (B[O] = Q[O]);
            }
          var I = x[_];
          return x[_] = B, o.languages.DFS(o.languages, function(V, re) {
            re === I && V != _ && (this[V] = B);
          }), B;
        },
        // Traverse a language definition with Depth First Search
        DFS: function _(v, A, x, Q) {
          Q = Q || {};
          var B = o.util.objId;
          for (var O in v)
            if (v.hasOwnProperty(O)) {
              A.call(v, O, v[O], x || O);
              var M = v[O], I = o.util.type(M);
              I === "Object" && !Q[B(M)] ? (Q[B(M)] = !0, _(M, A, null, Q)) : I === "Array" && !Q[B(M)] && (Q[B(M)] = !0, _(M, A, O, Q));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(_, v) {
        o.highlightAllUnder(document, _, v);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(_, v, A) {
        var x = {
          callback: A,
          container: _,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", x), x.elements = Array.prototype.slice.apply(x.container.querySelectorAll(x.selector)), o.hooks.run("before-all-elements-highlight", x);
        for (var Q = 0, B; B = x.elements[Q++]; )
          o.highlightElement(B, v === !0, x.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(_, v, A) {
        var x = o.util.getLanguage(_), Q = o.languages[x];
        o.util.setLanguage(_, x);
        var B = _.parentElement;
        B && B.nodeName.toLowerCase() === "pre" && o.util.setLanguage(B, x);
        var O = _.textContent, M = {
          element: _,
          language: x,
          grammar: Q,
          code: O
        };
        function I(re) {
          M.highlightedCode = re, o.hooks.run("before-insert", M), M.element.innerHTML = M.highlightedCode, o.hooks.run("after-highlight", M), o.hooks.run("complete", M), A && A.call(M.element);
        }
        if (o.hooks.run("before-sanity-check", M), B = M.element.parentElement, B && B.nodeName.toLowerCase() === "pre" && !B.hasAttribute("tabindex") && B.setAttribute("tabindex", "0"), !M.code) {
          o.hooks.run("complete", M), A && A.call(M.element);
          return;
        }
        if (o.hooks.run("before-highlight", M), !M.grammar) {
          I(o.util.encode(M.code));
          return;
        }
        if (v && r.Worker) {
          var V = new Worker(o.filename);
          V.onmessage = function(re) {
            I(re.data);
          }, V.postMessage(JSON.stringify({
            language: M.language,
            code: M.code,
            immediateClose: !0
          }));
        } else
          I(o.highlight(M.code, M.grammar, M.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(_, v, A) {
        var x = {
          code: _,
          grammar: v,
          language: A
        };
        if (o.hooks.run("before-tokenize", x), !x.grammar)
          throw new Error('The language "' + x.language + '" has no grammar.');
        return x.tokens = o.tokenize(x.code, x.grammar), o.hooks.run("after-tokenize", x), s.stringify(o.util.encode(x.tokens), x.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(_, v) {
        var A = v.rest;
        if (A) {
          for (var x in A)
            v[x] = A[x];
          delete v.rest;
        }
        var Q = new d();
        return f(Q, Q.head, _), c(_, Q, v, Q.head, 0), b(Q);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(_, v) {
          var A = o.hooks.all;
          A[_] = A[_] || [], A[_].push(v);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(_, v) {
          var A = o.hooks.all[_];
          if (!(!A || !A.length))
            for (var x = 0, Q; Q = A[x++]; )
              Q(v);
        }
      },
      Token: s
    };
    r.Prism = o;
    function s(_, v, A, x) {
      this.type = _, this.content = v, this.alias = A, this.length = (x || "").length | 0;
    }
    s.stringify = function _(v, A) {
      if (typeof v == "string")
        return v;
      if (Array.isArray(v)) {
        var x = "";
        return v.forEach(function(I) {
          x += _(I, A);
        }), x;
      }
      var Q = {
        type: v.type,
        content: _(v.content, A),
        tag: "span",
        classes: ["token", v.type],
        attributes: {},
        language: A
      }, B = v.alias;
      B && (Array.isArray(B) ? Array.prototype.push.apply(Q.classes, B) : Q.classes.push(B)), o.hooks.run("wrap", Q);
      var O = "";
      for (var M in Q.attributes)
        O += " " + M + '="' + (Q.attributes[M] || "").replace(/"/g, "&quot;") + '"';
      return "<" + Q.tag + ' class="' + Q.classes.join(" ") + '"' + O + ">" + Q.content + "</" + Q.tag + ">";
    };
    function u(_, v, A, x) {
      _.lastIndex = v;
      var Q = _.exec(A);
      if (Q && x && Q[1]) {
        var B = Q[1].length;
        Q.index += B, Q[0] = Q[0].slice(B);
      }
      return Q;
    }
    function c(_, v, A, x, Q, B) {
      for (var O in A)
        if (!(!A.hasOwnProperty(O) || !A[O])) {
          var M = A[O];
          M = Array.isArray(M) ? M : [M];
          for (var I = 0; I < M.length; ++I) {
            if (B && B.cause == O + "," + I)
              return;
            var V = M[I], re = V.inside, W = !!V.lookbehind, ae = !!V.greedy, Ee = V.alias;
            if (ae && !V.pattern.global) {
              var xe = V.pattern.toString().match(/[imsuy]*$/)[0];
              V.pattern = RegExp(V.pattern.source, xe + "g");
            }
            for (var qe = V.pattern || V, ce = x.next, pe = Q; ce !== v.tail && !(B && pe >= B.reach); pe += ce.value.length, ce = ce.next) {
              var Ce = ce.value;
              if (v.length > _.length)
                return;
              if (!(Ce instanceof s)) {
                var $ = 1, Te;
                if (ae) {
                  if (Te = u(qe, pe, _, W), !Te || Te.index >= _.length)
                    break;
                  var we = Te.index, se = Te.index + Te[0].length, De = pe;
                  for (De += ce.value.length; we >= De; )
                    ce = ce.next, De += ce.value.length;
                  if (De -= ce.value.length, pe = De, ce.value instanceof s)
                    continue;
                  for (var P = ce; P !== v.tail && (De < se || typeof P.value == "string"); P = P.next)
                    $++, De += P.value.length;
                  $--, Ce = _.slice(pe, De), Te.index -= pe;
                } else if (Te = u(qe, 0, Ce, W), !Te)
                  continue;
                var we = Te.index, he = Te[0], Ke = Ce.slice(0, we), J = Ce.slice(we + he.length), Ae = pe + Ce.length;
                B && Ae > B.reach && (B.reach = Ae);
                var ge = ce.prev;
                Ke && (ge = f(v, ge, Ke), pe += Ke.length), p(v, ge, $);
                var Oe = new s(O, re ? o.tokenize(he, re) : he, Ee, he);
                if (ce = f(v, ge, Oe), J && f(v, ce, J), $ > 1) {
                  var Le = {
                    cause: O + "," + I,
                    reach: Ae
                  };
                  c(_, v, A, ce.prev, pe, Le), B && Le.reach > B.reach && (B.reach = Le.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var _ = { value: null, prev: null, next: null }, v = { value: null, prev: _, next: null };
      _.next = v, this.head = _, this.tail = v, this.length = 0;
    }
    function f(_, v, A) {
      var x = v.next, Q = { value: A, prev: v, next: x };
      return v.next = Q, x.prev = Q, _.length++, Q;
    }
    function p(_, v, A) {
      for (var x = v.next, Q = 0; Q < A && x !== _.tail; Q++)
        x = x.next;
      v.next = x, x.prev = v, _.length -= Q;
    }
    function b(_) {
      for (var v = [], A = _.head.next; A !== _.tail; )
        v.push(A.value), A = A.next;
      return v;
    }
    if (!r.document)
      return r.addEventListener && (o.disableWorkerMessageHandler || r.addEventListener("message", function(_) {
        var v = JSON.parse(_.data), A = v.language, x = v.code, Q = v.immediateClose;
        r.postMessage(o.highlight(x, o.languages[A], A)), Q && r.close();
      }, !1)), o;
    var E = o.util.currentScript();
    E && (o.filename = E.src, E.hasAttribute("data-manual") && (o.manual = !0));
    function k() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var w = document.readyState;
      w === "loading" || w === "interactive" && E && E.defer ? document.addEventListener("DOMContentLoaded", k) : window.requestAnimationFrame ? window.requestAnimationFrame(k) : window.setTimeout(k, 16);
    }
    return o;
  }(e);
  n.exports && (n.exports = t), typeof no < "u" && (no.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var i = r.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", a = function(E, k) {
      return "✖ Error " + E + " while fetching file: " + k;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", d = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function f(E, k, w) {
      var _ = new XMLHttpRequest();
      _.open("GET", E, !0), _.onreadystatechange = function() {
        _.readyState == 4 && (_.status < 400 && _.responseText ? k(_.responseText) : _.status >= 400 ? w(a(_.status, _.statusText)) : w(i));
      }, _.send(null);
    }
    function p(E) {
      var k = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(E || "");
      if (k) {
        var w = Number(k[1]), _ = k[2], v = k[3];
        return _ ? v ? [w, Number(v)] : [w, void 0] : [w, w];
      }
    }
    t.hooks.add("before-highlightall", function(E) {
      E.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(E) {
      var k = (
        /** @type {HTMLPreElement} */
        E.element
      );
      if (k.matches(d)) {
        E.code = "", k.setAttribute(o, s);
        var w = k.appendChild(document.createElement("CODE"));
        w.textContent = r;
        var _ = k.getAttribute("data-src"), v = E.language;
        if (v === "none") {
          var A = (/\.(\w+)$/.exec(_) || [, "none"])[1];
          v = l[A] || A;
        }
        t.util.setLanguage(w, v), t.util.setLanguage(k, v);
        var x = t.plugins.autoloader;
        x && x.loadLanguages(v), f(
          _,
          function(Q) {
            k.setAttribute(o, u);
            var B = p(k.getAttribute("data-range"));
            if (B) {
              var O = Q.split(/\r\n?|\n/g), M = B[0], I = B[1] == null ? O.length : B[1];
              M < 0 && (M += O.length), M = Math.max(0, Math.min(M - 1, O.length)), I < 0 && (I += O.length), I = Math.max(0, Math.min(I, O.length)), Q = O.slice(M, I).join(`
`), k.hasAttribute("data-start") || k.setAttribute("data-start", String(M + 1));
            }
            w.textContent = Q, t.highlightElement(w);
          },
          function(Q) {
            k.setAttribute(o, c), w.textContent = Q;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(k) {
        for (var w = (k || document).querySelectorAll(d), _ = 0, v; v = w[_++]; )
          t.highlightElement(v);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(B9);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = r.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = n.languages.bash[a[l]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new F6();
const z9 = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const a = n[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, L9 = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], I9 = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], N9 = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], R9 = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], q9 = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], O9 = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
[
  ...L9,
  ...I9.map((n) => `svg:${n}`),
  ...N9.map((n) => `math:${n}`)
], z9([
  Object.fromEntries(R9.map((n) => [n, ["*"]])),
  Object.fromEntries(q9.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(O9.map((n) => [n, ["math:*"]]))
]);
function Tn(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function ka() {
}
const P9 = (n) => n;
function H9(n, e) {
  return n != n ? e == e : n !== e || n && typeof n == "object" || typeof n == "function";
}
const S6 = typeof window < "u";
let ao = S6 ? () => window.performance.now() : () => Date.now(), x6 = S6 ? (n) => requestAnimationFrame(n) : ka;
const Bn = /* @__PURE__ */ new Set();
function C6(n) {
  Bn.forEach((e) => {
    e.c(n) || (Bn.delete(e), e.f());
  }), Bn.size !== 0 && x6(C6);
}
function V9(n) {
  let e;
  return Bn.size === 0 && x6(C6), {
    promise: new Promise((t) => {
      Bn.add(e = { c: n, f: t });
    }),
    abort() {
      Bn.delete(e);
    }
  };
}
function E5(n, { delay: e = 0, duration: t = 400, easing: r = P9 } = {}) {
  const a = +getComputedStyle(n).opacity;
  return {
    delay: e,
    duration: t,
    easing: r,
    css: (i) => `opacity: ${i * a}`
  };
}
const Fn = [];
function U9(n, e = ka) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function a(o) {
    if (H9(n, o) && (n = o, t)) {
      const s = !Fn.length;
      for (const u of r)
        u[1](), Fn.push(u, n);
      if (s) {
        for (let u = 0; u < Fn.length; u += 2)
          Fn[u][0](Fn[u + 1]);
        Fn.length = 0;
      }
    }
  }
  function i(o) {
    a(o(n));
  }
  function l(o, s = ka) {
    const u = [o, s];
    return r.add(u), r.size === 1 && (t = e(a, i) || ka), o(n), () => {
      r.delete(u), r.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function io(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function Bl(n, e, t, r) {
  if (typeof t == "number" || io(t)) {
    const a = r - t, i = (t - e) / (n.dt || 1 / 60), l = n.opts.stiffness * a, o = n.opts.damping * i, s = (l - o) * n.inv_mass, u = (i + s) * n.dt;
    return Math.abs(u) < n.opts.precision && Math.abs(a) < n.opts.precision ? r : (n.settled = !1, io(t) ? new Date(t.getTime() + u) : t + u);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => Bl(n, e[i], t[i], r[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = Bl(n, e[i], t[i], r[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function lo(n, e = {}) {
  const t = U9(n), { stiffness: r = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, o, s, u = n, c = n, d = 1, f = 0, p = !1;
  function b(k, w = {}) {
    c = k;
    const _ = s = {};
    return n == null || w.hard || E.stiffness >= 1 && E.damping >= 1 ? (p = !0, l = ao(), u = k, t.set(n = c), Promise.resolve()) : (w.soft && (f = 1 / ((w.soft === !0 ? 0.5 : +w.soft) * 60), d = 0), o || (l = ao(), p = !1, o = V9((v) => {
      if (p)
        return p = !1, o = null, !1;
      d = Math.min(d + f, 1);
      const A = {
        inv_mass: d,
        opts: E,
        settled: !0,
        dt: (v - l) * 60 / 1e3
      }, x = Bl(A, u, n, c);
      return l = v, u = n, t.set(n = x), A.settled && (o = null), !A.settled;
    })), new Promise((v) => {
      o.promise.then(() => {
        _ === s && v();
      });
    }));
  }
  const E = {
    set: b,
    update: (k, w) => b(k(c, n), w),
    subscribe: t.subscribe,
    stiffness: r,
    damping: a,
    precision: i
  };
  return E;
}
const {
  SvelteComponent: j9,
  append_hydration: Tt,
  attr: Pe,
  children: _t,
  claim_element: G9,
  claim_svg_element: Qt,
  component_subscribe: so,
  detach: ut,
  element: W9,
  init: Z9,
  insert_hydration: Y9,
  noop: oo,
  safe_not_equal: X9,
  set_style: ha,
  svg_element: Mt,
  toggle_class: uo
} = window.__gradio__svelte__internal, { onMount: K9 } = window.__gradio__svelte__internal;
function J9(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f;
  return {
    c() {
      e = W9("div"), t = Mt("svg"), r = Mt("g"), a = Mt("path"), i = Mt("path"), l = Mt("path"), o = Mt("path"), s = Mt("g"), u = Mt("path"), c = Mt("path"), d = Mt("path"), f = Mt("path"), this.h();
    },
    l(p) {
      e = G9(p, "DIV", { class: !0 });
      var b = _t(e);
      t = Qt(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var E = _t(t);
      r = Qt(E, "g", { style: !0 });
      var k = _t(r);
      a = Qt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(a).forEach(ut), i = Qt(k, "path", { d: !0, fill: !0, class: !0 }), _t(i).forEach(ut), l = Qt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(l).forEach(ut), o = Qt(k, "path", { d: !0, fill: !0, class: !0 }), _t(o).forEach(ut), k.forEach(ut), s = Qt(E, "g", { style: !0 });
      var w = _t(s);
      u = Qt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(u).forEach(ut), c = Qt(w, "path", { d: !0, fill: !0, class: !0 }), _t(c).forEach(ut), d = Qt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(d).forEach(ut), f = Qt(w, "path", { d: !0, fill: !0, class: !0 }), _t(f).forEach(ut), w.forEach(ut), E.forEach(ut), b.forEach(ut), this.h();
    },
    h() {
      Pe(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Pe(a, "fill", "#FF7C00"), Pe(a, "fill-opacity", "0.4"), Pe(a, "class", "svelte-43sxxs"), Pe(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Pe(i, "fill", "#FF7C00"), Pe(i, "class", "svelte-43sxxs"), Pe(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Pe(l, "fill", "#FF7C00"), Pe(l, "fill-opacity", "0.4"), Pe(l, "class", "svelte-43sxxs"), Pe(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Pe(o, "fill", "#FF7C00"), Pe(o, "class", "svelte-43sxxs"), ha(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), Pe(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Pe(u, "fill", "#FF7C00"), Pe(u, "fill-opacity", "0.4"), Pe(u, "class", "svelte-43sxxs"), Pe(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Pe(c, "fill", "#FF7C00"), Pe(c, "class", "svelte-43sxxs"), Pe(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Pe(d, "fill", "#FF7C00"), Pe(d, "fill-opacity", "0.4"), Pe(d, "class", "svelte-43sxxs"), Pe(f, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Pe(f, "fill", "#FF7C00"), Pe(f, "class", "svelte-43sxxs"), ha(s, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), Pe(t, "viewBox", "-1200 -1200 3000 3000"), Pe(t, "fill", "none"), Pe(t, "xmlns", "http://www.w3.org/2000/svg"), Pe(t, "class", "svelte-43sxxs"), Pe(e, "class", "svelte-43sxxs"), uo(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(p, b) {
      Y9(p, e, b), Tt(e, t), Tt(t, r), Tt(r, a), Tt(r, i), Tt(r, l), Tt(r, o), Tt(t, s), Tt(s, u), Tt(s, c), Tt(s, d), Tt(s, f);
    },
    p(p, [b]) {
      b & /*$top*/
      2 && ha(r, "transform", "translate(" + /*$top*/
      p[1][0] + "px, " + /*$top*/
      p[1][1] + "px)"), b & /*$bottom*/
      4 && ha(s, "transform", "translate(" + /*$bottom*/
      p[2][0] + "px, " + /*$bottom*/
      p[2][1] + "px)"), b & /*margin*/
      1 && uo(
        e,
        "margin",
        /*margin*/
        p[0]
      );
    },
    i: oo,
    o: oo,
    d(p) {
      p && ut(e);
    }
  };
}
function $9(n, e, t) {
  let r, a;
  var i = this && this.__awaiter || function(p, b, E, k) {
    function w(_) {
      return _ instanceof E ? _ : new E(function(v) {
        v(_);
      });
    }
    return new (E || (E = Promise))(function(_, v) {
      function A(B) {
        try {
          Q(k.next(B));
        } catch (O) {
          v(O);
        }
      }
      function x(B) {
        try {
          Q(k.throw(B));
        } catch (O) {
          v(O);
        }
      }
      function Q(B) {
        B.done ? _(B.value) : w(B.value).then(A, x);
      }
      Q((k = k.apply(p, b || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const o = lo([0, 0]);
  so(n, o, (p) => t(1, r = p));
  const s = lo([0, 0]);
  so(n, s, (p) => t(2, a = p));
  let u;
  function c() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function d() {
    return i(this, void 0, void 0, function* () {
      yield c(), u || d();
    });
  }
  function f() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), d();
    });
  }
  return K9(() => (f(), () => u = !0)), n.$$set = (p) => {
    "margin" in p && t(0, l = p.margin);
  }, [l, r, a, o, s];
}
class e8 extends j9 {
  constructor(e) {
    super(), Z9(this, e, $9, J9, X9, { margin: 0 });
  }
}
const {
  SvelteComponent: t8,
  append_hydration: rn,
  attr: Ot,
  binding_callbacks: co,
  check_outros: zl,
  children: nr,
  claim_component: T6,
  claim_element: ar,
  claim_space: kt,
  claim_text: p0,
  create_component: Q6,
  create_slot: M6,
  destroy_component: B6,
  destroy_each: z6,
  detach: de,
  element: ir,
  empty: At,
  ensure_array_like: La,
  get_all_dirty_from_scope: L6,
  get_slot_changes: I6,
  group_outros: Ll,
  init: r8,
  insert_hydration: Se,
  mount_component: N6,
  noop: Il,
  safe_not_equal: n8,
  set_data: Ft,
  set_style: Gr,
  space: Dt,
  text: g0,
  toggle_class: vt,
  transition_in: qt,
  transition_out: lr,
  update_slot_base: R6
} = window.__gradio__svelte__internal, { tick: a8 } = window.__gradio__svelte__internal, { onDestroy: i8 } = window.__gradio__svelte__internal, { createEventDispatcher: l8 } = window.__gradio__svelte__internal, s8 = (n) => ({}), ho = (n) => ({}), o8 = (n) => ({}), fo = (n) => ({});
function mo(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r[43] = t, r;
}
function po(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r;
}
function u8(n) {
  let e, t, r, a, i = (
    /*i18n*/
    n[1]("common.error") + ""
  ), l, o, s;
  t = new Qh({
    props: {
      Icon: $3,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const u = (
    /*#slots*/
    n[30].error
  ), c = M6(
    u,
    n,
    /*$$scope*/
    n[29],
    ho
  );
  return {
    c() {
      e = ir("div"), Q6(t.$$.fragment), r = Dt(), a = ir("span"), l = g0(i), o = Dt(), c && c.c(), this.h();
    },
    l(d) {
      e = ar(d, "DIV", { class: !0 });
      var f = nr(e);
      T6(t.$$.fragment, f), f.forEach(de), r = kt(d), a = ar(d, "SPAN", { class: !0 });
      var p = nr(a);
      l = p0(p, i), p.forEach(de), o = kt(d), c && c.l(d), this.h();
    },
    h() {
      Ot(e, "class", "clear-status svelte-17v219f"), Ot(a, "class", "error svelte-17v219f");
    },
    m(d, f) {
      Se(d, e, f), N6(t, e, null), Se(d, r, f), Se(d, a, f), rn(a, l), Se(d, o, f), c && c.m(d, f), s = !0;
    },
    p(d, f) {
      const p = {};
      f[0] & /*i18n*/
      2 && (p.label = /*i18n*/
      d[1]("common.clear")), t.$set(p), (!s || f[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      d[1]("common.error") + "") && Ft(l, i), c && c.p && (!s || f[0] & /*$$scope*/
      536870912) && R6(
        c,
        u,
        d,
        /*$$scope*/
        d[29],
        s ? I6(
          u,
          /*$$scope*/
          d[29],
          f,
          s8
        ) : L6(
          /*$$scope*/
          d[29]
        ),
        ho
      );
    },
    i(d) {
      s || (qt(t.$$.fragment, d), qt(c, d), s = !0);
    },
    o(d) {
      lr(t.$$.fragment, d), lr(c, d), s = !1;
    },
    d(d) {
      d && (de(e), de(r), de(a), de(o)), B6(t), c && c.d(d);
    }
  };
}
function c8(n) {
  let e, t, r, a, i, l, o, s, u, c = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && go(n)
  );
  function d(v, A) {
    if (
      /*progress*/
      v[7]
    ) return d8;
    if (
      /*queue_position*/
      v[2] !== null && /*queue_size*/
      v[3] !== void 0 && /*queue_position*/
      v[2] >= 0
    ) return f8;
    if (
      /*queue_position*/
      v[2] === 0
    ) return h8;
  }
  let f = d(n), p = f && f(n), b = (
    /*timer*/
    n[5] && bo(n)
  );
  const E = [_8, g8], k = [];
  function w(v, A) {
    return (
      /*last_progress_level*/
      v[15] != null ? 0 : (
        /*show_progress*/
        v[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = w(n)) && (l = k[i] = E[i](n));
  let _ = !/*timer*/
  n[5] && Fo(n);
  return {
    c() {
      c && c.c(), e = Dt(), t = ir("div"), p && p.c(), r = Dt(), b && b.c(), a = Dt(), l && l.c(), o = Dt(), _ && _.c(), s = At(), this.h();
    },
    l(v) {
      c && c.l(v), e = kt(v), t = ar(v, "DIV", { class: !0 });
      var A = nr(t);
      p && p.l(A), r = kt(A), b && b.l(A), A.forEach(de), a = kt(v), l && l.l(v), o = kt(v), _ && _.l(v), s = At(), this.h();
    },
    h() {
      Ot(t, "class", "progress-text svelte-17v219f"), vt(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), vt(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(v, A) {
      c && c.m(v, A), Se(v, e, A), Se(v, t, A), p && p.m(t, null), rn(t, r), b && b.m(t, null), Se(v, a, A), ~i && k[i].m(v, A), Se(v, o, A), _ && _.m(v, A), Se(v, s, A), u = !0;
    },
    p(v, A) {
      /*variant*/
      v[8] === "default" && /*show_eta_bar*/
      v[18] && /*show_progress*/
      v[6] === "full" ? c ? c.p(v, A) : (c = go(v), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), f === (f = d(v)) && p ? p.p(v, A) : (p && p.d(1), p = f && f(v), p && (p.c(), p.m(t, r))), /*timer*/
      v[5] ? b ? b.p(v, A) : (b = bo(v), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || A[0] & /*variant*/
      256) && vt(
        t,
        "meta-text-center",
        /*variant*/
        v[8] === "center"
      ), (!u || A[0] & /*variant*/
      256) && vt(
        t,
        "meta-text",
        /*variant*/
        v[8] === "default"
      );
      let x = i;
      i = w(v), i === x ? ~i && k[i].p(v, A) : (l && (Ll(), lr(k[x], 1, 1, () => {
        k[x] = null;
      }), zl()), ~i ? (l = k[i], l ? l.p(v, A) : (l = k[i] = E[i](v), l.c()), qt(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      v[5] ? _ && (Ll(), lr(_, 1, 1, () => {
        _ = null;
      }), zl()) : _ ? (_.p(v, A), A[0] & /*timer*/
      32 && qt(_, 1)) : (_ = Fo(v), _.c(), qt(_, 1), _.m(s.parentNode, s));
    },
    i(v) {
      u || (qt(l), qt(_), u = !0);
    },
    o(v) {
      lr(l), lr(_), u = !1;
    },
    d(v) {
      v && (de(e), de(t), de(a), de(o), de(s)), c && c.d(v), p && p.d(), b && b.d(), ~i && k[i].d(v), _ && _.d(v);
    }
  };
}
function go(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = ir("div"), this.h();
    },
    l(r) {
      e = ar(r, "DIV", { class: !0 }), nr(e).forEach(de), this.h();
    },
    h() {
      Ot(e, "class", "eta-bar svelte-17v219f"), Gr(e, "transform", t);
    },
    m(r, a) {
      Se(r, e, a);
    },
    p(r, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && Gr(e, "transform", t);
    },
    d(r) {
      r && de(e);
    }
  };
}
function h8(n) {
  let e;
  return {
    c() {
      e = g0("processing |");
    },
    l(t) {
      e = p0(t, "processing |");
    },
    m(t, r) {
      Se(t, e, r);
    },
    p: Il,
    d(t) {
      t && de(e);
    }
  };
}
function f8(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, a, i, l;
  return {
    c() {
      e = g0("queue: "), r = g0(t), a = g0("/"), i = g0(
        /*queue_size*/
        n[3]
      ), l = g0(" |");
    },
    l(o) {
      e = p0(o, "queue: "), r = p0(o, t), a = p0(o, "/"), i = p0(
        o,
        /*queue_size*/
        n[3]
      ), l = p0(o, " |");
    },
    m(o, s) {
      Se(o, e, s), Se(o, r, s), Se(o, a, s), Se(o, i, s), Se(o, l, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && Ft(r, t), s[0] & /*queue_size*/
      8 && Ft(
        i,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (de(e), de(r), de(a), de(i), de(l));
    }
  };
}
function d8(n) {
  let e, t = La(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = vo(po(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = At();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = At();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      Se(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = La(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = po(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = vo(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && de(e), z6(r, a);
    }
  };
}
function _o(n) {
  let e, t = (
    /*p*/
    n[41].unit + ""
  ), r, a, i = " ", l;
  function o(c, d) {
    return (
      /*p*/
      c[41].length != null ? p8 : m8
    );
  }
  let s = o(n), u = s(n);
  return {
    c() {
      u.c(), e = Dt(), r = g0(t), a = g0(" | "), l = g0(i);
    },
    l(c) {
      u.l(c), e = kt(c), r = p0(c, t), a = p0(c, " | "), l = p0(c, i);
    },
    m(c, d) {
      u.m(c, d), Se(c, e, d), Se(c, r, d), Se(c, a, d), Se(c, l, d);
    },
    p(c, d) {
      s === (s = o(c)) && u ? u.p(c, d) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[41].unit + "") && Ft(r, t);
    },
    d(c) {
      c && (de(e), de(r), de(a), de(l)), u.d(c);
    }
  };
}
function m8(n) {
  let e = Tn(
    /*p*/
    n[41].index || 0
  ) + "", t;
  return {
    c() {
      t = g0(e);
    },
    l(r) {
      t = p0(r, e);
    },
    m(r, a) {
      Se(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = Tn(
        /*p*/
        r[41].index || 0
      ) + "") && Ft(t, e);
    },
    d(r) {
      r && de(t);
    }
  };
}
function p8(n) {
  let e = Tn(
    /*p*/
    n[41].index || 0
  ) + "", t, r, a = Tn(
    /*p*/
    n[41].length
  ) + "", i;
  return {
    c() {
      t = g0(e), r = g0("/"), i = g0(a);
    },
    l(l) {
      t = p0(l, e), r = p0(l, "/"), i = p0(l, a);
    },
    m(l, o) {
      Se(l, t, o), Se(l, r, o), Se(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      128 && e !== (e = Tn(
        /*p*/
        l[41].index || 0
      ) + "") && Ft(t, e), o[0] & /*progress*/
      128 && a !== (a = Tn(
        /*p*/
        l[41].length
      ) + "") && Ft(i, a);
    },
    d(l) {
      l && (de(t), de(r), de(i));
    }
  };
}
function vo(n) {
  let e, t = (
    /*p*/
    n[41].index != null && _o(n)
  );
  return {
    c() {
      t && t.c(), e = At();
    },
    l(r) {
      t && t.l(r), e = At();
    },
    m(r, a) {
      t && t.m(r, a), Se(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].index != null ? t ? t.p(r, a) : (t = _o(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && de(e), t && t.d(r);
    }
  };
}
function bo(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, a;
  return {
    c() {
      e = g0(
        /*formatted_timer*/
        n[20]
      ), r = g0(t), a = g0("s");
    },
    l(i) {
      e = p0(
        i,
        /*formatted_timer*/
        n[20]
      ), r = p0(i, t), a = p0(i, "s");
    },
    m(i, l) {
      Se(i, e, l), Se(i, r, l), Se(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && Ft(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && Ft(r, t);
    },
    d(i) {
      i && (de(e), de(r), de(a));
    }
  };
}
function g8(n) {
  let e, t;
  return e = new e8({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      Q6(e.$$.fragment);
    },
    l(r) {
      T6(e.$$.fragment, r);
    },
    m(r, a) {
      N6(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      r[8] === "default"), e.$set(i);
    },
    i(r) {
      t || (qt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      lr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      B6(e, r);
    }
  };
}
function _8(n) {
  let e, t, r, a, i, l = `${/*last_progress_level*/
  n[15] * 100}%`, o = (
    /*progress*/
    n[7] != null && wo(n)
  );
  return {
    c() {
      e = ir("div"), t = ir("div"), o && o.c(), r = Dt(), a = ir("div"), i = ir("div"), this.h();
    },
    l(s) {
      e = ar(s, "DIV", { class: !0 });
      var u = nr(e);
      t = ar(u, "DIV", { class: !0 });
      var c = nr(t);
      o && o.l(c), c.forEach(de), r = kt(u), a = ar(u, "DIV", { class: !0 });
      var d = nr(a);
      i = ar(d, "DIV", { class: !0 }), nr(i).forEach(de), d.forEach(de), u.forEach(de), this.h();
    },
    h() {
      Ot(t, "class", "progress-level-inner svelte-17v219f"), Ot(i, "class", "progress-bar svelte-17v219f"), Gr(i, "width", l), Ot(a, "class", "progress-bar-wrap svelte-17v219f"), Ot(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      Se(s, e, u), rn(e, t), o && o.m(t, null), rn(e, r), rn(e, a), rn(a, i), n[31](i);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = wo(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Gr(i, "width", l);
    },
    i: Il,
    o: Il,
    d(s) {
      s && de(e), o && o.d(), n[31](null);
    }
  };
}
function wo(n) {
  let e, t = La(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = Ao(mo(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = At();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = At();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      Se(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = La(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = mo(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = Ao(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && de(e), z6(r, a);
    }
  };
}
function yo(n) {
  let e, t, r, a, i = (
    /*i*/
    n[43] !== 0 && v8()
  ), l = (
    /*p*/
    n[41].desc != null && ko(n)
  ), o = (
    /*p*/
    n[41].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null && Do()
  ), s = (
    /*progress_level*/
    n[14] != null && Eo(n)
  );
  return {
    c() {
      i && i.c(), e = Dt(), l && l.c(), t = Dt(), o && o.c(), r = Dt(), s && s.c(), a = At();
    },
    l(u) {
      i && i.l(u), e = kt(u), l && l.l(u), t = kt(u), o && o.l(u), r = kt(u), s && s.l(u), a = At();
    },
    m(u, c) {
      i && i.m(u, c), Se(u, e, c), l && l.m(u, c), Se(u, t, c), o && o.m(u, c), Se(u, r, c), s && s.m(u, c), Se(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[41].desc != null ? l ? l.p(u, c) : (l = ko(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[41].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[43]
      ] != null ? o || (o = Do(), o.c(), o.m(r.parentNode, r)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Eo(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (de(e), de(t), de(r), de(a)), i && i.d(u), l && l.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function v8(n) {
  let e;
  return {
    c() {
      e = g0(" /");
    },
    l(t) {
      e = p0(t, " /");
    },
    m(t, r) {
      Se(t, e, r);
    },
    d(t) {
      t && de(e);
    }
  };
}
function ko(n) {
  let e = (
    /*p*/
    n[41].desc + ""
  ), t;
  return {
    c() {
      t = g0(e);
    },
    l(r) {
      t = p0(r, e);
    },
    m(r, a) {
      Se(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[41].desc + "") && Ft(t, e);
    },
    d(r) {
      r && de(t);
    }
  };
}
function Do(n) {
  let e;
  return {
    c() {
      e = g0("-");
    },
    l(t) {
      e = p0(t, "-");
    },
    m(t, r) {
      Se(t, e, r);
    },
    d(t) {
      t && de(e);
    }
  };
}
function Eo(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[43]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = g0(e), r = g0("%");
    },
    l(a) {
      t = p0(a, e), r = p0(a, "%");
    },
    m(a, i) {
      Se(a, t, i), Se(a, r, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[43]
      ] || 0)).toFixed(1) + "") && Ft(t, e);
    },
    d(a) {
      a && (de(t), de(r));
    }
  };
}
function Ao(n) {
  let e, t = (
    /*p*/
    (n[41].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null) && yo(n)
  );
  return {
    c() {
      t && t.c(), e = At();
    },
    l(r) {
      t && t.l(r), e = At();
    },
    m(r, a) {
      t && t.m(r, a), Se(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[43]
      ] != null ? t ? t.p(r, a) : (t = yo(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && de(e), t && t.d(r);
    }
  };
}
function Fo(n) {
  let e, t, r, a;
  const i = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), l = M6(
    i,
    n,
    /*$$scope*/
    n[29],
    fo
  );
  return {
    c() {
      e = ir("p"), t = g0(
        /*loading_text*/
        n[9]
      ), r = Dt(), l && l.c(), this.h();
    },
    l(o) {
      e = ar(o, "P", { class: !0 });
      var s = nr(e);
      t = p0(
        s,
        /*loading_text*/
        n[9]
      ), s.forEach(de), r = kt(o), l && l.l(o), this.h();
    },
    h() {
      Ot(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      Se(o, e, s), rn(e, t), Se(o, r, s), l && l.m(o, s), a = !0;
    },
    p(o, s) {
      (!a || s[0] & /*loading_text*/
      512) && Ft(
        t,
        /*loading_text*/
        o[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && R6(
        l,
        i,
        o,
        /*$$scope*/
        o[29],
        a ? I6(
          i,
          /*$$scope*/
          o[29],
          s,
          o8
        ) : L6(
          /*$$scope*/
          o[29]
        ),
        fo
      );
    },
    i(o) {
      a || (qt(l, o), a = !0);
    },
    o(o) {
      lr(l, o), a = !1;
    },
    d(o) {
      o && (de(e), de(r)), l && l.d(o);
    }
  };
}
function b8(n) {
  let e, t, r, a, i;
  const l = [c8, u8], o = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(n)) && (r = o[t] = l[t](n)), {
    c() {
      e = ir("div"), r && r.c(), this.h();
    },
    l(u) {
      e = ar(u, "DIV", { class: !0 });
      var c = nr(e);
      r && r.l(c), c.forEach(de), this.h();
    },
    h() {
      Ot(e, "class", a = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), vt(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), vt(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), vt(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), vt(
        e,
        "border",
        /*border*/
        n[12]
      ), Gr(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), Gr(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      Se(u, e, c), ~t && o[t].m(e, null), n[33](e), i = !0;
    },
    p(u, c) {
      let d = t;
      t = s(u), t === d ? ~t && o[t].p(u, c) : (r && (Ll(), lr(o[d], 1, 1, () => {
        o[d] = null;
      }), zl()), ~t ? (r = o[t], r ? r.p(u, c) : (r = o[t] = l[t](u), r.c()), qt(r, 1), r.m(e, null)) : r = null), (!i || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ot(e, "class", a), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && vt(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!i || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && vt(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!i || c[0] & /*variant, show_progress, status, show_progress*/
      336) && vt(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!i || c[0] & /*variant, show_progress, border*/
      4416) && vt(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Gr(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Gr(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      i || (qt(r), i = !0);
    },
    o(u) {
      lr(r), i = !1;
    },
    d(u) {
      u && de(e), ~t && o[t].d(), n[33](null);
    }
  };
}
var w8 = function(n, e, t, r) {
  function a(i) {
    return i instanceof t ? i : new t(function(l) {
      l(i);
    });
  }
  return new (t || (t = Promise))(function(i, l) {
    function o(c) {
      try {
        u(r.next(c));
      } catch (d) {
        l(d);
      }
    }
    function s(c) {
      try {
        u(r.throw(c));
      } catch (d) {
        l(d);
      }
    }
    function u(c) {
      c.done ? i(c.value) : a(c.value).then(o, s);
    }
    u((r = r.apply(n, e || [])).next());
  });
};
let fa = [], Ji = !1;
const y8 = typeof window < "u", q6 = y8 ? window.requestAnimationFrame : (n) => {
};
function k8(n) {
  return w8(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (fa.push(e), !Ji) Ji = !0;
      else return;
      yield a8(), q6(() => {
        let r = [0, 0];
        for (let a = 0; a < fa.length; a++) {
          const l = fa[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= r[0]) && (r[0] = l.top + window.scrollY, r[1] = a);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), Ji = !1, fa = [];
      });
    }
  });
}
function D8(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e;
  this && this.__awaiter;
  const l = l8();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: d } = e, { scroll_to_output: f = !1 } = e, { timer: p = !0 } = e, { show_progress: b = "full" } = e, { message: E = null } = e, { progress: k = null } = e, { variant: w = "default" } = e, { loading_text: _ = "Loading..." } = e, { absolute: v = !0 } = e, { translucent: A = !1 } = e, { border: x = !1 } = e, { autoscroll: Q } = e, B, O = !1, M = 0, I = 0, V = null, re = null, W = 0, ae = null, Ee, xe = null, qe = !0;
  const ce = () => {
    t(0, s = t(27, V = t(19, $ = null))), t(25, M = performance.now()), t(26, I = 0), O = !0, pe();
  };
  function pe() {
    q6(() => {
      t(26, I = (performance.now() - M) / 1e3), O && pe();
    });
  }
  function Ce() {
    t(26, I = 0), t(0, s = t(27, V = t(19, $ = null))), O && (O = !1);
  }
  i8(() => {
    O && Ce();
  });
  let $ = null;
  function Te(P) {
    co[P ? "unshift" : "push"](() => {
      xe = P, t(16, xe), t(7, k), t(14, ae), t(15, Ee);
    });
  }
  const se = () => {
    l("clear_status");
  };
  function De(P) {
    co[P ? "unshift" : "push"](() => {
      B = P, t(13, B);
    });
  }
  return n.$$set = (P) => {
    "i18n" in P && t(1, o = P.i18n), "eta" in P && t(0, s = P.eta), "queue_position" in P && t(2, u = P.queue_position), "queue_size" in P && t(3, c = P.queue_size), "status" in P && t(4, d = P.status), "scroll_to_output" in P && t(22, f = P.scroll_to_output), "timer" in P && t(5, p = P.timer), "show_progress" in P && t(6, b = P.show_progress), "message" in P && t(23, E = P.message), "progress" in P && t(7, k = P.progress), "variant" in P && t(8, w = P.variant), "loading_text" in P && t(9, _ = P.loading_text), "absolute" in P && t(10, v = P.absolute), "translucent" in P && t(11, A = P.translucent), "border" in P && t(12, x = P.border), "autoscroll" in P && t(24, Q = P.autoscroll), "$$scope" in P && t(29, i = P.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = V), s != null && V !== s && (t(28, re = (performance.now() - M) / 1e3 + s), t(19, $ = re.toFixed(1)), t(27, V = s))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, W = re === null || re <= 0 || !I ? null : Math.min(I / re, 1)), n.$$.dirty[0] & /*progress*/
    128 && k != null && t(18, qe = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (k != null ? t(14, ae = k.map((P) => {
      if (P.index != null && P.length != null)
        return P.index / P.length;
      if (P.progress != null)
        return P.progress;
    })) : t(14, ae = null), ae ? (t(15, Ee = ae[ae.length - 1]), xe && (Ee === 0 ? t(16, xe.style.transition = "0", xe) : t(16, xe.style.transition = "150ms", xe))) : t(15, Ee = void 0)), n.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? ce() : Ce()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && B && f && (d === "pending" || d === "complete") && k8(B, Q), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = I.toFixed(1));
  }, [
    s,
    o,
    u,
    c,
    d,
    p,
    b,
    k,
    w,
    _,
    v,
    A,
    x,
    B,
    ae,
    Ee,
    xe,
    W,
    qe,
    $,
    r,
    l,
    f,
    E,
    Q,
    M,
    I,
    V,
    re,
    i,
    a,
    Te,
    se,
    De
  ];
}
class E8 extends t8 {
  constructor(e) {
    super(), r8(
      this,
      e,
      D8,
      b8,
      n8,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.1.7 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.7/LICENSE */
const {
  entries: O6,
  setPrototypeOf: So,
  isFrozen: A8,
  getPrototypeOf: F8,
  getOwnPropertyDescriptor: S8
} = Object;
let {
  freeze: rt,
  seal: St,
  create: P6
} = Object, {
  apply: Nl,
  construct: Rl
} = typeof Reflect < "u" && Reflect;
rt || (rt = function(e) {
  return e;
});
St || (St = function(e) {
  return e;
});
Nl || (Nl = function(e, t, r) {
  return e.apply(t, r);
});
Rl || (Rl = function(e, t) {
  return new e(...t);
});
const da = dt(Array.prototype.forEach), xo = dt(Array.prototype.pop), Jn = dt(Array.prototype.push), Da = dt(String.prototype.toLowerCase), $i = dt(String.prototype.toString), Co = dt(String.prototype.match), $n = dt(String.prototype.replace), x8 = dt(String.prototype.indexOf), C8 = dt(String.prototype.trim), Bt = dt(Object.prototype.hasOwnProperty), et = dt(RegExp.prototype.test), e1 = T8(TypeError);
function dt(n) {
  return function(e) {
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      r[a - 1] = arguments[a];
    return Nl(n, e, r);
  };
}
function T8(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return Rl(n, t);
  };
}
function Ne(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Da;
  So && So(n, null);
  let r = e.length;
  for (; r--; ) {
    let a = e[r];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (A8(e) || (e[r] = i), a = i);
    }
    n[a] = !0;
  }
  return n;
}
function Q8(n) {
  for (let e = 0; e < n.length; e++)
    Bt(n, e) || (n[e] = null);
  return n;
}
function tn(n) {
  const e = P6(null);
  for (const [t, r] of O6(n))
    Bt(n, t) && (Array.isArray(r) ? e[t] = Q8(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = tn(r) : e[t] = r);
  return e;
}
function t1(n, e) {
  for (; n !== null; ) {
    const r = S8(n, e);
    if (r) {
      if (r.get)
        return dt(r.get);
      if (typeof r.value == "function")
        return dt(r.value);
    }
    n = F8(n);
  }
  function t() {
    return null;
  }
  return t;
}
const To = rt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), el = rt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), tl = rt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), M8 = rt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), rl = rt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), B8 = rt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Qo = rt(["#text"]), Mo = rt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), nl = rt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Bo = rt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), ma = rt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), z8 = St(/\{\{[\w\W]*|[\w\W]*\}\}/gm), L8 = St(/<%[\w\W]*|[\w\W]*%>/gm), I8 = St(/\${[\w\W]*}/gm), N8 = St(/^data-[\-\w.\u00B7-\uFFFF]/), R8 = St(/^aria-[\-\w]+$/), H6 = St(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), q8 = St(/^(?:\w+script|data):/i), O8 = St(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), V6 = St(/^html$/i), P8 = St(/^[a-z][.\w]*(-[.\w]+)+$/i);
var zo = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: z8,
  ERB_EXPR: L8,
  TMPLIT_EXPR: I8,
  DATA_ATTR: N8,
  ARIA_ATTR: R8,
  IS_ALLOWED_URI: H6,
  IS_SCRIPT_OR_DATA: q8,
  ATTR_WHITESPACE: O8,
  DOCTYPE_NAME: V6,
  CUSTOM_ELEMENT: P8
});
const r1 = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, H8 = function() {
  return typeof window > "u" ? null : window;
}, V8 = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (r = t.getAttribute(a));
  const i = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
};
function U6() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : H8();
  const e = (fe) => U6(fe);
  if (e.version = "3.1.7", e.removed = [], !n || !n.document || n.document.nodeType !== r1.document)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, a = r.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: o,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: d,
    DOMParser: f,
    trustedTypes: p
  } = n, b = s.prototype, E = t1(b, "cloneNode"), k = t1(b, "remove"), w = t1(b, "nextSibling"), _ = t1(b, "childNodes"), v = t1(b, "parentNode");
  if (typeof l == "function") {
    const fe = t.createElement("template");
    fe.content && fe.content.ownerDocument && (t = fe.content.ownerDocument);
  }
  let A, x = "";
  const {
    implementation: Q,
    createNodeIterator: B,
    createDocumentFragment: O,
    getElementsByTagName: M
  } = t, {
    importNode: I
  } = r;
  let V = {};
  e.isSupported = typeof O6 == "function" && typeof v == "function" && Q && Q.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: re,
    ERB_EXPR: W,
    TMPLIT_EXPR: ae,
    DATA_ATTR: Ee,
    ARIA_ATTR: xe,
    IS_SCRIPT_OR_DATA: qe,
    ATTR_WHITESPACE: ce,
    CUSTOM_ELEMENT: pe
  } = zo;
  let {
    IS_ALLOWED_URI: Ce
  } = zo, $ = null;
  const Te = Ne({}, [...To, ...el, ...tl, ...rl, ...Qo]);
  let se = null;
  const De = Ne({}, [...Mo, ...nl, ...Bo, ...ma]);
  let P = Object.seal(P6(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), we = null, he = null, Ke = !0, J = !0, Ae = !1, ge = !0, Oe = !1, Le = !0, je = !1, Ge = !1, e0 = !1, X = !1, Ve = !1, Qe = !1, s0 = !0, Re = !1;
  const B0 = "user-content-";
  let Ie = !0, H = !1, q = {}, oe = null;
  const _e = Ne({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Ue = null;
  const a0 = Ne({}, ["audio", "video", "img", "source", "image", "track"]);
  let t0 = null;
  const y0 = Ne({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), G = "http://www.w3.org/1998/Math/MathML", ot = "http://www.w3.org/2000/svg", j0 = "http://www.w3.org/1999/xhtml";
  let z0 = j0, Zt = !1, bn = null;
  const wn = Ne({}, [G, ot, j0], $i);
  let Br = null;
  const hr = ["application/xhtml+xml", "text/html"], _3 = "text/html";
  let C0 = null, yn = null;
  const v3 = t.createElement("form"), q5 = function(T) {
    return T instanceof RegExp || T instanceof Function;
  }, hi = function() {
    let T = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(yn && yn === T)) {
      if ((!T || typeof T != "object") && (T = {}), T = tn(T), Br = // eslint-disable-next-line unicorn/prefer-includes
      hr.indexOf(T.PARSER_MEDIA_TYPE) === -1 ? _3 : T.PARSER_MEDIA_TYPE, C0 = Br === "application/xhtml+xml" ? $i : Da, $ = Bt(T, "ALLOWED_TAGS") ? Ne({}, T.ALLOWED_TAGS, C0) : Te, se = Bt(T, "ALLOWED_ATTR") ? Ne({}, T.ALLOWED_ATTR, C0) : De, bn = Bt(T, "ALLOWED_NAMESPACES") ? Ne({}, T.ALLOWED_NAMESPACES, $i) : wn, t0 = Bt(T, "ADD_URI_SAFE_ATTR") ? Ne(
        tn(y0),
        // eslint-disable-line indent
        T.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        C0
        // eslint-disable-line indent
      ) : y0, Ue = Bt(T, "ADD_DATA_URI_TAGS") ? Ne(
        tn(a0),
        // eslint-disable-line indent
        T.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        C0
        // eslint-disable-line indent
      ) : a0, oe = Bt(T, "FORBID_CONTENTS") ? Ne({}, T.FORBID_CONTENTS, C0) : _e, we = Bt(T, "FORBID_TAGS") ? Ne({}, T.FORBID_TAGS, C0) : {}, he = Bt(T, "FORBID_ATTR") ? Ne({}, T.FORBID_ATTR, C0) : {}, q = Bt(T, "USE_PROFILES") ? T.USE_PROFILES : !1, Ke = T.ALLOW_ARIA_ATTR !== !1, J = T.ALLOW_DATA_ATTR !== !1, Ae = T.ALLOW_UNKNOWN_PROTOCOLS || !1, ge = T.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Oe = T.SAFE_FOR_TEMPLATES || !1, Le = T.SAFE_FOR_XML !== !1, je = T.WHOLE_DOCUMENT || !1, X = T.RETURN_DOM || !1, Ve = T.RETURN_DOM_FRAGMENT || !1, Qe = T.RETURN_TRUSTED_TYPE || !1, e0 = T.FORCE_BODY || !1, s0 = T.SANITIZE_DOM !== !1, Re = T.SANITIZE_NAMED_PROPS || !1, Ie = T.KEEP_CONTENT !== !1, H = T.IN_PLACE || !1, Ce = T.ALLOWED_URI_REGEXP || H6, z0 = T.NAMESPACE || j0, P = T.CUSTOM_ELEMENT_HANDLING || {}, T.CUSTOM_ELEMENT_HANDLING && q5(T.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (P.tagNameCheck = T.CUSTOM_ELEMENT_HANDLING.tagNameCheck), T.CUSTOM_ELEMENT_HANDLING && q5(T.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (P.attributeNameCheck = T.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), T.CUSTOM_ELEMENT_HANDLING && typeof T.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (P.allowCustomizedBuiltInElements = T.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Oe && (J = !1), Ve && (X = !0), q && ($ = Ne({}, Qo), se = [], q.html === !0 && (Ne($, To), Ne(se, Mo)), q.svg === !0 && (Ne($, el), Ne(se, nl), Ne(se, ma)), q.svgFilters === !0 && (Ne($, tl), Ne(se, nl), Ne(se, ma)), q.mathMl === !0 && (Ne($, rl), Ne(se, Bo), Ne(se, ma))), T.ADD_TAGS && ($ === Te && ($ = tn($)), Ne($, T.ADD_TAGS, C0)), T.ADD_ATTR && (se === De && (se = tn(se)), Ne(se, T.ADD_ATTR, C0)), T.ADD_URI_SAFE_ATTR && Ne(t0, T.ADD_URI_SAFE_ATTR, C0), T.FORBID_CONTENTS && (oe === _e && (oe = tn(oe)), Ne(oe, T.FORBID_CONTENTS, C0)), Ie && ($["#text"] = !0), je && Ne($, ["html", "head", "body"]), $.table && (Ne($, ["tbody"]), delete we.tbody), T.TRUSTED_TYPES_POLICY) {
        if (typeof T.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw e1('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof T.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw e1('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        A = T.TRUSTED_TYPES_POLICY, x = A.createHTML("");
      } else
        A === void 0 && (A = V8(p, a)), A !== null && typeof x == "string" && (x = A.createHTML(""));
      rt && rt(T), yn = T;
    }
  }, O5 = Ne({}, ["mi", "mo", "mn", "ms", "mtext"]), P5 = Ne({}, ["annotation-xml"]), b3 = Ne({}, ["title", "style", "font", "a", "script"]), H5 = Ne({}, [...el, ...tl, ...M8]), V5 = Ne({}, [...rl, ...B8]), w3 = function(T) {
    let K = v(T);
    (!K || !K.tagName) && (K = {
      namespaceURI: z0,
      tagName: "template"
    });
    const ue = Da(T.tagName), o0 = Da(K.tagName);
    return bn[T.namespaceURI] ? T.namespaceURI === ot ? K.namespaceURI === j0 ? ue === "svg" : K.namespaceURI === G ? ue === "svg" && (o0 === "annotation-xml" || O5[o0]) : !!H5[ue] : T.namespaceURI === G ? K.namespaceURI === j0 ? ue === "math" : K.namespaceURI === ot ? ue === "math" && P5[o0] : !!V5[ue] : T.namespaceURI === j0 ? K.namespaceURI === ot && !P5[o0] || K.namespaceURI === G && !O5[o0] ? !1 : !V5[ue] && (b3[ue] || !H5[ue]) : !!(Br === "application/xhtml+xml" && bn[T.namespaceURI]) : !1;
  }, Yt = function(T) {
    Jn(e.removed, {
      element: T
    });
    try {
      v(T).removeChild(T);
    } catch {
      k(T);
    }
  }, P1 = function(T, K) {
    try {
      Jn(e.removed, {
        attribute: K.getAttributeNode(T),
        from: K
      });
    } catch {
      Jn(e.removed, {
        attribute: null,
        from: K
      });
    }
    if (K.removeAttribute(T), T === "is" && !se[T])
      if (X || Ve)
        try {
          Yt(K);
        } catch {
        }
      else
        try {
          K.setAttribute(T, "");
        } catch {
        }
  }, U5 = function(T) {
    let K = null, ue = null;
    if (e0)
      T = "<remove></remove>" + T;
    else {
      const L0 = Co(T, /^[\r\n\t ]+/);
      ue = L0 && L0[0];
    }
    Br === "application/xhtml+xml" && z0 === j0 && (T = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + T + "</body></html>");
    const o0 = A ? A.createHTML(T) : T;
    if (z0 === j0)
      try {
        K = new f().parseFromString(o0, Br);
      } catch {
      }
    if (!K || !K.documentElement) {
      K = Q.createDocument(z0, "template", null);
      try {
        K.documentElement.innerHTML = Zt ? x : o0;
      } catch {
      }
    }
    const G0 = K.body || K.documentElement;
    return T && ue && G0.insertBefore(t.createTextNode(ue), G0.childNodes[0] || null), z0 === j0 ? M.call(K, je ? "html" : "body")[0] : je ? K.documentElement : G0;
  }, j5 = function(T) {
    return B.call(
      T.ownerDocument || T,
      T,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, G5 = function(T) {
    return T instanceof d && (typeof T.nodeName != "string" || typeof T.textContent != "string" || typeof T.removeChild != "function" || !(T.attributes instanceof c) || typeof T.removeAttribute != "function" || typeof T.setAttribute != "function" || typeof T.namespaceURI != "string" || typeof T.insertBefore != "function" || typeof T.hasChildNodes != "function");
  }, W5 = function(T) {
    return typeof o == "function" && T instanceof o;
  }, fr = function(T, K, ue) {
    V[T] && da(V[T], (o0) => {
      o0.call(e, K, ue, yn);
    });
  }, Z5 = function(T) {
    let K = null;
    if (fr("beforeSanitizeElements", T, null), G5(T))
      return Yt(T), !0;
    const ue = C0(T.nodeName);
    if (fr("uponSanitizeElement", T, {
      tagName: ue,
      allowedTags: $
    }), T.hasChildNodes() && !W5(T.firstElementChild) && et(/<[/\w]/g, T.innerHTML) && et(/<[/\w]/g, T.textContent) || T.nodeType === r1.progressingInstruction || Le && T.nodeType === r1.comment && et(/<[/\w]/g, T.data))
      return Yt(T), !0;
    if (!$[ue] || we[ue]) {
      if (!we[ue] && X5(ue) && (P.tagNameCheck instanceof RegExp && et(P.tagNameCheck, ue) || P.tagNameCheck instanceof Function && P.tagNameCheck(ue)))
        return !1;
      if (Ie && !oe[ue]) {
        const o0 = v(T) || T.parentNode, G0 = _(T) || T.childNodes;
        if (G0 && o0) {
          const L0 = G0.length;
          for (let at = L0 - 1; at >= 0; --at) {
            const Xt = E(G0[at], !0);
            Xt.__removalCount = (T.__removalCount || 0) + 1, o0.insertBefore(Xt, w(T));
          }
        }
      }
      return Yt(T), !0;
    }
    return T instanceof s && !w3(T) || (ue === "noscript" || ue === "noembed" || ue === "noframes") && et(/<\/no(script|embed|frames)/i, T.innerHTML) ? (Yt(T), !0) : (Oe && T.nodeType === r1.text && (K = T.textContent, da([re, W, ae], (o0) => {
      K = $n(K, o0, " ");
    }), T.textContent !== K && (Jn(e.removed, {
      element: T.cloneNode()
    }), T.textContent = K)), fr("afterSanitizeElements", T, null), !1);
  }, Y5 = function(T, K, ue) {
    if (s0 && (K === "id" || K === "name") && (ue in t || ue in v3))
      return !1;
    if (!(J && !he[K] && et(Ee, K))) {
      if (!(Ke && et(xe, K))) {
        if (!se[K] || he[K]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(X5(T) && (P.tagNameCheck instanceof RegExp && et(P.tagNameCheck, T) || P.tagNameCheck instanceof Function && P.tagNameCheck(T)) && (P.attributeNameCheck instanceof RegExp && et(P.attributeNameCheck, K) || P.attributeNameCheck instanceof Function && P.attributeNameCheck(K)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            K === "is" && P.allowCustomizedBuiltInElements && (P.tagNameCheck instanceof RegExp && et(P.tagNameCheck, ue) || P.tagNameCheck instanceof Function && P.tagNameCheck(ue)))
          ) return !1;
        } else if (!t0[K]) {
          if (!et(Ce, $n(ue, ce, ""))) {
            if (!((K === "src" || K === "xlink:href" || K === "href") && T !== "script" && x8(ue, "data:") === 0 && Ue[T])) {
              if (!(Ae && !et(qe, $n(ue, ce, "")))) {
                if (ue)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, X5 = function(T) {
    return T !== "annotation-xml" && Co(T, pe);
  }, K5 = function(T) {
    fr("beforeSanitizeAttributes", T, null);
    const {
      attributes: K
    } = T;
    if (!K)
      return;
    const ue = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: se
    };
    let o0 = K.length;
    for (; o0--; ) {
      const G0 = K[o0], {
        name: L0,
        namespaceURI: at,
        value: Xt
      } = G0, On = C0(L0);
      let J0 = L0 === "value" ? Xt : C8(Xt);
      if (ue.attrName = On, ue.attrValue = J0, ue.keepAttr = !0, ue.forceKeepAttr = void 0, fr("uponSanitizeAttribute", T, ue), J0 = ue.attrValue, ue.forceKeepAttr || (P1(L0, T), !ue.keepAttr))
        continue;
      if (!ge && et(/\/>/i, J0)) {
        P1(L0, T);
        continue;
      }
      Oe && da([re, W, ae], ($5) => {
        J0 = $n(J0, $5, " ");
      });
      const J5 = C0(T.nodeName);
      if (Y5(J5, On, J0)) {
        if (Re && (On === "id" || On === "name") && (P1(L0, T), J0 = B0 + J0), Le && et(/((--!?|])>)|<\/(style|title)/i, J0)) {
          P1(L0, T);
          continue;
        }
        if (A && typeof p == "object" && typeof p.getAttributeType == "function" && !at)
          switch (p.getAttributeType(J5, On)) {
            case "TrustedHTML": {
              J0 = A.createHTML(J0);
              break;
            }
            case "TrustedScriptURL": {
              J0 = A.createScriptURL(J0);
              break;
            }
          }
        try {
          at ? T.setAttributeNS(at, L0, J0) : T.setAttribute(L0, J0), G5(T) ? Yt(T) : xo(e.removed);
        } catch {
        }
      }
    }
    fr("afterSanitizeAttributes", T, null);
  }, y3 = function fe(T) {
    let K = null;
    const ue = j5(T);
    for (fr("beforeSanitizeShadowDOM", T, null); K = ue.nextNode(); )
      fr("uponSanitizeShadowNode", K, null), !Z5(K) && (K.content instanceof i && fe(K.content), K5(K));
    fr("afterSanitizeShadowDOM", T, null);
  };
  return e.sanitize = function(fe) {
    let T = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, K = null, ue = null, o0 = null, G0 = null;
    if (Zt = !fe, Zt && (fe = "<!-->"), typeof fe != "string" && !W5(fe))
      if (typeof fe.toString == "function") {
        if (fe = fe.toString(), typeof fe != "string")
          throw e1("dirty is not a string, aborting");
      } else
        throw e1("toString is not a function");
    if (!e.isSupported)
      return fe;
    if (Ge || hi(T), e.removed = [], typeof fe == "string" && (H = !1), H) {
      if (fe.nodeName) {
        const Xt = C0(fe.nodeName);
        if (!$[Xt] || we[Xt])
          throw e1("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (fe instanceof o)
      K = U5("<!---->"), ue = K.ownerDocument.importNode(fe, !0), ue.nodeType === r1.element && ue.nodeName === "BODY" || ue.nodeName === "HTML" ? K = ue : K.appendChild(ue);
    else {
      if (!X && !Oe && !je && // eslint-disable-next-line unicorn/prefer-includes
      fe.indexOf("<") === -1)
        return A && Qe ? A.createHTML(fe) : fe;
      if (K = U5(fe), !K)
        return X ? null : Qe ? x : "";
    }
    K && e0 && Yt(K.firstChild);
    const L0 = j5(H ? fe : K);
    for (; o0 = L0.nextNode(); )
      Z5(o0) || (o0.content instanceof i && y3(o0.content), K5(o0));
    if (H)
      return fe;
    if (X) {
      if (Ve)
        for (G0 = O.call(K.ownerDocument); K.firstChild; )
          G0.appendChild(K.firstChild);
      else
        G0 = K;
      return (se.shadowroot || se.shadowrootmode) && (G0 = I.call(r, G0, !0)), G0;
    }
    let at = je ? K.outerHTML : K.innerHTML;
    return je && $["!doctype"] && K.ownerDocument && K.ownerDocument.doctype && K.ownerDocument.doctype.name && et(V6, K.ownerDocument.doctype.name) && (at = "<!DOCTYPE " + K.ownerDocument.doctype.name + `>
` + at), Oe && da([re, W, ae], (Xt) => {
      at = $n(at, Xt, " ");
    }), A && Qe ? A.createHTML(at) : at;
  }, e.setConfig = function() {
    let fe = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    hi(fe), Ge = !0;
  }, e.clearConfig = function() {
    yn = null, Ge = !1;
  }, e.isValidAttribute = function(fe, T, K) {
    yn || hi({});
    const ue = C0(fe), o0 = C0(T);
    return Y5(ue, o0, K);
  }, e.addHook = function(fe, T) {
    typeof T == "function" && (V[fe] = V[fe] || [], Jn(V[fe], T));
  }, e.removeHook = function(fe) {
    if (V[fe])
      return xo(V[fe]);
  }, e.removeHooks = function(fe) {
    V[fe] && (V[fe] = []);
  }, e.removeAllHooks = function() {
    V = {};
  }, e;
}
U6();
const {
  SvelteComponent: U8,
  attr: j8,
  children: G8,
  claim_element: W8,
  detach: ql,
  element: Z8,
  empty: Lo,
  init: Y8,
  insert_hydration: j6,
  noop: Io,
  safe_not_equal: X8,
  set_style: No
} = window.__gradio__svelte__internal;
function Ro(n) {
  let e, t = `${/*time_limit*/
  n[0]}s`;
  return {
    c() {
      e = Z8("div"), this.h();
    },
    l(r) {
      e = W8(r, "DIV", { class: !0 }), G8(e).forEach(ql), this.h();
    },
    h() {
      j8(e, "class", "streaming-bar svelte-ga0jj6"), No(e, "animation-duration", t);
    },
    m(r, a) {
      j6(r, e, a);
    },
    p(r, a) {
      a & /*time_limit*/
      1 && t !== (t = `${/*time_limit*/
      r[0]}s`) && No(e, "animation-duration", t);
    },
    d(r) {
      r && ql(e);
    }
  };
}
function K8(n) {
  let e, t = (
    /*time_limit*/
    n[0] && Ro(n)
  );
  return {
    c() {
      t && t.c(), e = Lo();
    },
    l(r) {
      t && t.l(r), e = Lo();
    },
    m(r, a) {
      t && t.m(r, a), j6(r, e, a);
    },
    p(r, [a]) {
      /*time_limit*/
      r[0] ? t ? t.p(r, a) : (t = Ro(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: Io,
    o: Io,
    d(r) {
      r && ql(e), t && t.d(r);
    }
  };
}
function J8(n, e, t) {
  let { time_limit: r } = e;
  return n.$$set = (a) => {
    "time_limit" in a && t(0, r = a.time_limit);
  }, [r];
}
class G6 extends U8 {
  constructor(e) {
    super(), Y8(this, e, J8, K8, X8, { time_limit: 0 });
  }
}
const {
  SvelteComponent: $8,
  append_hydration: al,
  attr: pa,
  children: qo,
  claim_component: eh,
  claim_element: Oo,
  claim_space: th,
  claim_text: rh,
  create_component: nh,
  destroy_component: ah,
  detach: il,
  element: Po,
  init: ih,
  insert_hydration: lh,
  mount_component: sh,
  safe_not_equal: oh,
  set_data: uh,
  space: ch,
  text: hh,
  toggle_class: Pr,
  transition_in: fh,
  transition_out: dh
} = window.__gradio__svelte__internal;
function mh(n) {
  let e, t, r, a, i, l;
  return r = new /*Icon*/
  n[1]({}), {
    c() {
      e = Po("label"), t = Po("span"), nh(r.$$.fragment), a = ch(), i = hh(
        /*label*/
        n[0]
      ), this.h();
    },
    l(o) {
      e = Oo(o, "LABEL", {
        for: !0,
        "data-testid": !0,
        class: !0
      });
      var s = qo(e);
      t = Oo(s, "SPAN", { class: !0 });
      var u = qo(t);
      eh(r.$$.fragment, u), u.forEach(il), a = th(s), i = rh(
        s,
        /*label*/
        n[0]
      ), s.forEach(il), this.h();
    },
    h() {
      pa(t, "class", "svelte-168uj4v"), pa(e, "for", ""), pa(e, "data-testid", "block-label"), pa(e, "class", "svelte-168uj4v"), Pr(e, "hide", !/*show_label*/
      n[2]), Pr(e, "sr-only", !/*show_label*/
      n[2]), Pr(
        e,
        "float",
        /*float*/
        n[4]
      ), Pr(
        e,
        "hide-label",
        /*disable*/
        n[3]
      );
    },
    m(o, s) {
      lh(o, e, s), al(e, t), sh(r, t, null), al(e, a), al(e, i), l = !0;
    },
    p(o, [s]) {
      (!l || s & /*label*/
      1) && uh(
        i,
        /*label*/
        o[0]
      ), (!l || s & /*show_label*/
      4) && Pr(e, "hide", !/*show_label*/
      o[2]), (!l || s & /*show_label*/
      4) && Pr(e, "sr-only", !/*show_label*/
      o[2]), (!l || s & /*float*/
      16) && Pr(
        e,
        "float",
        /*float*/
        o[4]
      ), (!l || s & /*disable*/
      8) && Pr(
        e,
        "hide-label",
        /*disable*/
        o[3]
      );
    },
    i(o) {
      l || (fh(r.$$.fragment, o), l = !0);
    },
    o(o) {
      dh(r.$$.fragment, o), l = !1;
    },
    d(o) {
      o && il(e), ah(r);
    }
  };
}
function ph(n, e, t) {
  let { label: r = null } = e, { Icon: a } = e, { show_label: i = !0 } = e, { disable: l = !1 } = e, { float: o = !0 } = e;
  return n.$$set = (s) => {
    "label" in s && t(0, r = s.label), "Icon" in s && t(1, a = s.Icon), "show_label" in s && t(2, i = s.show_label), "disable" in s && t(3, l = s.disable), "float" in s && t(4, o = s.float);
  }, [r, a, i, l, o];
}
class ri extends $8 {
  constructor(e) {
    super(), ih(this, e, ph, mh, oh, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: gh,
  append_hydration: Ol,
  attr: pr,
  bubble: _h,
  check_outros: vh,
  children: Pl,
  claim_component: bh,
  claim_element: Hl,
  claim_space: wh,
  claim_text: yh,
  construct_svelte_component: Ho,
  create_component: Vo,
  destroy_component: Uo,
  detach: c1,
  element: Vl,
  group_outros: kh,
  init: Dh,
  insert_hydration: W6,
  listen: Eh,
  mount_component: jo,
  safe_not_equal: Ah,
  set_data: Fh,
  set_style: ga,
  space: Sh,
  text: xh,
  toggle_class: it,
  transition_in: Go,
  transition_out: Wo
} = window.__gradio__svelte__internal;
function Zo(n) {
  let e, t;
  return {
    c() {
      e = Vl("span"), t = xh(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = Hl(r, "SPAN", { class: !0 });
      var a = Pl(e);
      t = yh(
        a,
        /*label*/
        n[1]
      ), a.forEach(c1), this.h();
    },
    h() {
      pr(e, "class", "svelte-vk34kx");
    },
    m(r, a) {
      W6(r, e, a), Ol(e, t);
    },
    p(r, a) {
      a & /*label*/
      2 && Fh(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && c1(e);
    }
  };
}
function Ch(n) {
  let e, t, r, a, i, l, o, s = (
    /*show_label*/
    n[2] && Zo(n)
  );
  var u = (
    /*Icon*/
    n[0]
  );
  function c(d, f) {
    return {};
  }
  return u && (a = Ho(u, c())), {
    c() {
      e = Vl("button"), s && s.c(), t = Sh(), r = Vl("div"), a && Vo(a.$$.fragment), this.h();
    },
    l(d) {
      e = Hl(d, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var f = Pl(e);
      s && s.l(f), t = wh(f), r = Hl(f, "DIV", { class: !0 });
      var p = Pl(r);
      a && bh(a.$$.fragment, p), p.forEach(c1), f.forEach(c1), this.h();
    },
    h() {
      pr(r, "class", "svelte-vk34kx"), it(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), it(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), it(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], pr(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), pr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), pr(
        e,
        "title",
        /*label*/
        n[1]
      ), pr(e, "class", "svelte-vk34kx"), it(
        e,
        "pending",
        /*pending*/
        n[3]
      ), it(
        e,
        "padded",
        /*padded*/
        n[5]
      ), it(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), it(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), ga(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), ga(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(d, f) {
      W6(d, e, f), s && s.m(e, null), Ol(e, t), Ol(e, r), a && jo(a, r, null), i = !0, l || (o = Eh(
        e,
        "click",
        /*click_handler*/
        n[13]
      ), l = !0);
    },
    p(d, [f]) {
      if (/*show_label*/
      d[2] ? s ? s.p(d, f) : (s = Zo(d), s.c(), s.m(e, t)) : s && (s.d(1), s = null), f & /*Icon*/
      1 && u !== (u = /*Icon*/
      d[0])) {
        if (a) {
          kh();
          const p = a;
          Wo(p.$$.fragment, 1, 0, () => {
            Uo(p, 1);
          }), vh();
        }
        u ? (a = Ho(u, c()), Vo(a.$$.fragment), Go(a.$$.fragment, 1), jo(a, r, null)) : a = null;
      }
      (!i || f & /*size*/
      16) && it(
        r,
        "small",
        /*size*/
        d[4] === "small"
      ), (!i || f & /*size*/
      16) && it(
        r,
        "large",
        /*size*/
        d[4] === "large"
      ), (!i || f & /*size*/
      16) && it(
        r,
        "medium",
        /*size*/
        d[4] === "medium"
      ), (!i || f & /*disabled*/
      128) && (e.disabled = /*disabled*/
      d[7]), (!i || f & /*label*/
      2) && pr(
        e,
        "aria-label",
        /*label*/
        d[1]
      ), (!i || f & /*hasPopup*/
      256) && pr(
        e,
        "aria-haspopup",
        /*hasPopup*/
        d[8]
      ), (!i || f & /*label*/
      2) && pr(
        e,
        "title",
        /*label*/
        d[1]
      ), (!i || f & /*pending*/
      8) && it(
        e,
        "pending",
        /*pending*/
        d[3]
      ), (!i || f & /*padded*/
      32) && it(
        e,
        "padded",
        /*padded*/
        d[5]
      ), (!i || f & /*highlight*/
      64) && it(
        e,
        "highlight",
        /*highlight*/
        d[6]
      ), (!i || f & /*transparent*/
      512) && it(
        e,
        "transparent",
        /*transparent*/
        d[9]
      ), f & /*disabled, _color*/
      2176 && ga(e, "color", !/*disabled*/
      d[7] && /*_color*/
      d[11] ? (
        /*_color*/
        d[11]
      ) : "var(--block-label-text-color)"), f & /*disabled, background*/
      1152 && ga(e, "--bg-color", /*disabled*/
      d[7] ? "auto" : (
        /*background*/
        d[10]
      ));
    },
    i(d) {
      i || (a && Go(a.$$.fragment, d), i = !0);
    },
    o(d) {
      a && Wo(a.$$.fragment, d), i = !1;
    },
    d(d) {
      d && c1(e), s && s.d(), a && Uo(a), l = !1, o();
    }
  };
}
function Th(n, e, t) {
  let r, { Icon: a } = e, { label: i = "" } = e, { show_label: l = !1 } = e, { pending: o = !1 } = e, { size: s = "small" } = e, { padded: u = !0 } = e, { highlight: c = !1 } = e, { disabled: d = !1 } = e, { hasPopup: f = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: E = "var(--block-background-fill)" } = e;
  function k(w) {
    _h.call(this, n, w);
  }
  return n.$$set = (w) => {
    "Icon" in w && t(0, a = w.Icon), "label" in w && t(1, i = w.label), "show_label" in w && t(2, l = w.show_label), "pending" in w && t(3, o = w.pending), "size" in w && t(4, s = w.size), "padded" in w && t(5, u = w.padded), "highlight" in w && t(6, c = w.highlight), "disabled" in w && t(7, d = w.disabled), "hasPopup" in w && t(8, f = w.hasPopup), "color" in w && t(12, p = w.color), "transparent" in w && t(9, b = w.transparent), "background" in w && t(10, E = w.background);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = c ? "var(--color-accent)" : p);
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    c,
    d,
    f,
    b,
    E,
    r,
    p,
    k
  ];
}
class Qh extends gh {
  constructor(e) {
    super(), Dh(this, e, Th, Ch, Ah, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Mh,
  append_hydration: Bh,
  attr: ll,
  binding_callbacks: zh,
  children: Yo,
  claim_element: Xo,
  create_slot: Lh,
  detach: sl,
  element: Ko,
  get_all_dirty_from_scope: Ih,
  get_slot_changes: Nh,
  init: Rh,
  insert_hydration: qh,
  safe_not_equal: Oh,
  toggle_class: Hr,
  transition_in: Ph,
  transition_out: Hh,
  update_slot_base: Vh
} = window.__gradio__svelte__internal;
function Uh(n) {
  let e, t, r;
  const a = (
    /*#slots*/
    n[5].default
  ), i = Lh(
    a,
    n,
    /*$$scope*/
    n[4],
    null
  );
  return {
    c() {
      e = Ko("div"), t = Ko("div"), i && i.c(), this.h();
    },
    l(l) {
      e = Xo(l, "DIV", { class: !0, "aria-label": !0 });
      var o = Yo(e);
      t = Xo(o, "DIV", { class: !0 });
      var s = Yo(t);
      i && i.l(s), s.forEach(sl), o.forEach(sl), this.h();
    },
    h() {
      ll(t, "class", "icon svelte-3w3rth"), ll(e, "class", "empty svelte-3w3rth"), ll(e, "aria-label", "Empty value"), Hr(
        e,
        "small",
        /*size*/
        n[0] === "small"
      ), Hr(
        e,
        "large",
        /*size*/
        n[0] === "large"
      ), Hr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        n[1]
      ), Hr(
        e,
        "small_parent",
        /*parent_height*/
        n[3]
      );
    },
    m(l, o) {
      qh(l, e, o), Bh(e, t), i && i.m(t, null), n[6](e), r = !0;
    },
    p(l, [o]) {
      i && i.p && (!r || o & /*$$scope*/
      16) && Vh(
        i,
        a,
        l,
        /*$$scope*/
        l[4],
        r ? Nh(
          a,
          /*$$scope*/
          l[4],
          o,
          null
        ) : Ih(
          /*$$scope*/
          l[4]
        ),
        null
      ), (!r || o & /*size*/
      1) && Hr(
        e,
        "small",
        /*size*/
        l[0] === "small"
      ), (!r || o & /*size*/
      1) && Hr(
        e,
        "large",
        /*size*/
        l[0] === "large"
      ), (!r || o & /*unpadded_box*/
      2) && Hr(
        e,
        "unpadded_box",
        /*unpadded_box*/
        l[1]
      ), (!r || o & /*parent_height*/
      8) && Hr(
        e,
        "small_parent",
        /*parent_height*/
        l[3]
      );
    },
    i(l) {
      r || (Ph(i, l), r = !0);
    },
    o(l) {
      Hh(i, l), r = !1;
    },
    d(l) {
      l && sl(e), i && i.d(l), n[6](null);
    }
  };
}
function jh(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e, { size: l = "small" } = e, { unpadded_box: o = !1 } = e, s;
  function u(d) {
    var f;
    if (!d) return !1;
    const { height: p } = d.getBoundingClientRect(), { height: b } = ((f = d.parentElement) === null || f === void 0 ? void 0 : f.getBoundingClientRect()) || { height: p };
    return p > b + 2;
  }
  function c(d) {
    zh[d ? "unshift" : "push"](() => {
      s = d, t(2, s);
    });
  }
  return n.$$set = (d) => {
    "size" in d && t(0, l = d.size), "unpadded_box" in d && t(1, o = d.unpadded_box), "$$scope" in d && t(4, i = d.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*el*/
    4 && t(3, r = u(s));
  }, [l, o, s, r, i, a, c];
}
class Z6 extends Mh {
  constructor(e) {
    super(), Rh(this, e, jh, Uh, Oh, { size: 0, unpadded_box: 1 });
  }
}
const Gh = /^(#\s*)(.+)$/m;
function Wh(n) {
  const e = n.trim(), t = e.match(Gh);
  if (!t)
    return [!1, e || !1];
  const [r, , a] = t, i = a.trim();
  if (e === r)
    return [i, !1];
  const l = t.index !== void 0 ? t.index + r.length : 0, s = e.substring(l).trim() || !1;
  return [i, s];
}
const {
  SvelteComponent: Zh,
  append_hydration: ln,
  attr: v1,
  check_outros: Yh,
  children: b1,
  claim_component: Y6,
  claim_element: w1,
  claim_space: ni,
  claim_text: nn,
  create_component: X6,
  destroy_component: K6,
  detach: Z0,
  element: y1,
  empty: Ia,
  group_outros: Xh,
  init: Kh,
  insert_hydration: Vt,
  mount_component: J6,
  safe_not_equal: Jh,
  set_data: k1,
  space: ai,
  text: an,
  toggle_class: Jo,
  transition_in: Na,
  transition_out: Ra
} = window.__gradio__svelte__internal;
function $h(n) {
  let e, t;
  return e = new Lu({}), {
    c() {
      X6(e.$$.fragment);
    },
    l(r) {
      Y6(e.$$.fragment, r);
    },
    m(r, a) {
      J6(e, r, a), t = !0;
    },
    i(r) {
      t || (Na(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Ra(e.$$.fragment, r), t = !1;
    },
    d(r) {
      K6(e, r);
    }
  };
}
function ef(n) {
  let e, t;
  return e = new fu({}), {
    c() {
      X6(e.$$.fragment);
    },
    l(r) {
      Y6(e.$$.fragment, r);
    },
    m(r, a) {
      J6(e, r, a), t = !0;
    },
    i(r) {
      t || (Na(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Ra(e.$$.fragment, r), t = !1;
    },
    d(r) {
      K6(e, r);
    }
  };
}
function tf(n) {
  let e = (
    /*i18n*/
    n[1](
      /*defs*/
      n[7][
        /*type*/
        n[0]
      ] || /*defs*/
      n[7].file
    ) + ""
  ), t, r, a, i = (
    /*mode*/
    n[3] !== "short" && $o(n)
  );
  return {
    c() {
      t = an(e), r = ai(), i && i.c(), a = Ia();
    },
    l(l) {
      t = nn(l, e), r = ni(l), i && i.l(l), a = Ia();
    },
    m(l, o) {
      Vt(l, t, o), Vt(l, r, o), i && i.m(l, o), Vt(l, a, o);
    },
    p(l, o) {
      o & /*i18n, type*/
      3 && e !== (e = /*i18n*/
      l[1](
        /*defs*/
        l[7][
          /*type*/
          l[0]
        ] || /*defs*/
        l[7].file
      ) + "") && k1(t, e), /*mode*/
      l[3] !== "short" ? i ? i.p(l, o) : (i = $o(l), i.c(), i.m(a.parentNode, a)) : i && (i.d(1), i = null);
    },
    d(l) {
      l && (Z0(t), Z0(r), Z0(a)), i && i.d(l);
    }
  };
}
function rf(n) {
  let e, t, r = (
    /*heading*/
    n[6] && e2(n)
  ), a = (
    /*paragraph*/
    n[5] && t2(n)
  );
  return {
    c() {
      r && r.c(), e = ai(), a && a.c(), t = Ia();
    },
    l(i) {
      r && r.l(i), e = ni(i), a && a.l(i), t = Ia();
    },
    m(i, l) {
      r && r.m(i, l), Vt(i, e, l), a && a.m(i, l), Vt(i, t, l);
    },
    p(i, l) {
      /*heading*/
      i[6] ? r ? r.p(i, l) : (r = e2(i), r.c(), r.m(e.parentNode, e)) : r && (r.d(1), r = null), /*paragraph*/
      i[5] ? a ? a.p(i, l) : (a = t2(i), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    d(i) {
      i && (Z0(e), Z0(t)), r && r.d(i), a && a.d(i);
    }
  };
}
function $o(n) {
  let e, t, r = (
    /*i18n*/
    n[1]("common.or") + ""
  ), a, i, l, o = (
    /*message*/
    (n[2] || /*i18n*/
    n[1]("upload_text.click_to_upload")) + ""
  ), s;
  return {
    c() {
      e = y1("span"), t = an("- "), a = an(r), i = an(" -"), l = ai(), s = an(o), this.h();
    },
    l(u) {
      e = w1(u, "SPAN", { class: !0 });
      var c = b1(e);
      t = nn(c, "- "), a = nn(c, r), i = nn(c, " -"), c.forEach(Z0), l = ni(u), s = nn(u, o), this.h();
    },
    h() {
      v1(e, "class", "or svelte-1xg7h5n");
    },
    m(u, c) {
      Vt(u, e, c), ln(e, t), ln(e, a), ln(e, i), Vt(u, l, c), Vt(u, s, c);
    },
    p(u, c) {
      c & /*i18n*/
      2 && r !== (r = /*i18n*/
      u[1]("common.or") + "") && k1(a, r), c & /*message, i18n*/
      6 && o !== (o = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && k1(s, o);
    },
    d(u) {
      u && (Z0(e), Z0(l), Z0(s));
    }
  };
}
function e2(n) {
  let e, t;
  return {
    c() {
      e = y1("h2"), t = an(
        /*heading*/
        n[6]
      ), this.h();
    },
    l(r) {
      e = w1(r, "H2", { class: !0 });
      var a = b1(e);
      t = nn(
        a,
        /*heading*/
        n[6]
      ), a.forEach(Z0), this.h();
    },
    h() {
      v1(e, "class", "svelte-1xg7h5n");
    },
    m(r, a) {
      Vt(r, e, a), ln(e, t);
    },
    p(r, a) {
      a & /*heading*/
      64 && k1(
        t,
        /*heading*/
        r[6]
      );
    },
    d(r) {
      r && Z0(e);
    }
  };
}
function t2(n) {
  let e, t;
  return {
    c() {
      e = y1("p"), t = an(
        /*paragraph*/
        n[5]
      ), this.h();
    },
    l(r) {
      e = w1(r, "P", { class: !0 });
      var a = b1(e);
      t = nn(
        a,
        /*paragraph*/
        n[5]
      ), a.forEach(Z0), this.h();
    },
    h() {
      v1(e, "class", "svelte-1xg7h5n");
    },
    m(r, a) {
      Vt(r, e, a), ln(e, t);
    },
    p(r, a) {
      a & /*paragraph*/
      32 && k1(
        t,
        /*paragraph*/
        r[5]
      );
    },
    d(r) {
      r && Z0(e);
    }
  };
}
function nf(n) {
  let e, t, r, a, i, l;
  const o = [ef, $h], s = [];
  function u(p, b) {
    return (
      /*type*/
      p[0] === "clipboard" ? 0 : 1
    );
  }
  r = u(n), a = s[r] = o[r](n);
  function c(p, b) {
    return (
      /*heading*/
      p[6] || /*paragraph*/
      p[5] ? rf : tf
    );
  }
  let d = c(n), f = d(n);
  return {
    c() {
      e = y1("div"), t = y1("span"), a.c(), i = ai(), f.c(), this.h();
    },
    l(p) {
      e = w1(p, "DIV", { class: !0 });
      var b = b1(e);
      t = w1(b, "SPAN", { class: !0 });
      var E = b1(t);
      a.l(E), E.forEach(Z0), i = ni(b), f.l(b), b.forEach(Z0), this.h();
    },
    h() {
      v1(t, "class", "icon-wrap svelte-1xg7h5n"), Jo(
        t,
        "hovered",
        /*hovered*/
        n[4]
      ), v1(e, "class", "wrap svelte-1xg7h5n");
    },
    m(p, b) {
      Vt(p, e, b), ln(e, t), s[r].m(t, null), ln(e, i), f.m(e, null), l = !0;
    },
    p(p, [b]) {
      let E = r;
      r = u(p), r !== E && (Xh(), Ra(s[E], 1, 1, () => {
        s[E] = null;
      }), Yh(), a = s[r], a || (a = s[r] = o[r](p), a.c()), Na(a, 1), a.m(t, null)), (!l || b & /*hovered*/
      16) && Jo(
        t,
        "hovered",
        /*hovered*/
        p[4]
      ), d === (d = c(p)) && f ? f.p(p, b) : (f.d(1), f = d(p), f && (f.c(), f.m(e, null)));
    },
    i(p) {
      l || (Na(a), l = !0);
    },
    o(p) {
      Ra(a), l = !1;
    },
    d(p) {
      p && Z0(e), s[r].d(), f.d();
    }
  };
}
function af(n, e, t) {
  let r, a, { type: i = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: s = "full" } = e, { hovered: u = !1 } = e, { placeholder: c = void 0 } = e;
  const d = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return n.$$set = (f) => {
    "type" in f && t(0, i = f.type), "i18n" in f && t(1, l = f.i18n), "message" in f && t(2, o = f.message), "mode" in f && t(3, s = f.mode), "hovered" in f && t(4, u = f.hovered), "placeholder" in f && t(8, c = f.placeholder);
  }, n.$$.update = () => {
    n.$$.dirty & /*placeholder*/
    256 && t(6, [r, a] = c ? Wh(c) : [!1, !1], r, (t(5, a), t(8, c)));
  }, [i, l, o, s, u, a, r, d, c];
}
class lf extends Zh {
  constructor(e) {
    super(), Kh(this, e, af, nf, Jh, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4,
      placeholder: 8
    });
  }
}
const {
  SvelteComponent: sf,
  append_hydration: _a,
  attr: ol,
  check_outros: of,
  children: ul,
  claim_component: uf,
  claim_element: cl,
  claim_space: cf,
  claim_text: hf,
  construct_svelte_component: r2,
  create_component: n2,
  destroy_component: a2,
  detach: va,
  element: hl,
  group_outros: ff,
  init: df,
  insert_hydration: mf,
  listen: pf,
  mount_component: i2,
  safe_not_equal: gf,
  set_data: _f,
  set_style: vf,
  space: bf,
  text: wf,
  transition_in: l2,
  transition_out: s2
} = window.__gradio__svelte__internal, { createEventDispatcher: yf } = window.__gradio__svelte__internal;
function kf(n) {
  let e, t, r, a, i, l, o, s, u;
  var c = (
    /*icon*/
    n[0]
  );
  function d(f, p) {
    return {};
  }
  return c && (a = r2(c, d())), {
    c() {
      e = hl("button"), t = hl("div"), r = hl("span"), a && n2(a.$$.fragment), i = bf(), l = wf(
        /*text*/
        n[1]
      ), this.h();
    },
    l(f) {
      e = cl(f, "BUTTON", { class: !0 });
      var p = ul(e);
      t = cl(p, "DIV", { class: !0 });
      var b = ul(t);
      r = cl(b, "SPAN", { class: !0 });
      var E = ul(r);
      a && uf(a.$$.fragment, E), E.forEach(va), i = cf(b), l = hf(
        b,
        /*text*/
        n[1]
      ), b.forEach(va), p.forEach(va), this.h();
    },
    h() {
      ol(r, "class", "icon-wrap svelte-fjcd9c"), ol(t, "class", "wrap svelte-fjcd9c"), ol(e, "class", "svelte-fjcd9c"), vf(e, "height", "100%");
    },
    m(f, p) {
      mf(f, e, p), _a(e, t), _a(t, r), a && i2(a, r, null), _a(t, i), _a(t, l), o = !0, s || (u = pf(
        e,
        "click",
        /*click_handler*/
        n[3]
      ), s = !0);
    },
    p(f, [p]) {
      if (p & /*icon*/
      1 && c !== (c = /*icon*/
      f[0])) {
        if (a) {
          ff();
          const b = a;
          s2(b.$$.fragment, 1, 0, () => {
            a2(b, 1);
          }), of();
        }
        c ? (a = r2(c, d()), n2(a.$$.fragment), l2(a.$$.fragment, 1), i2(a, r, null)) : a = null;
      }
      (!o || p & /*text*/
      2) && _f(
        l,
        /*text*/
        f[1]
      );
    },
    i(f) {
      o || (a && l2(a.$$.fragment, f), o = !0);
    },
    o(f) {
      a && s2(a.$$.fragment, f), o = !1;
    },
    d(f) {
      f && va(e), a && a2(a), s = !1, u();
    }
  };
}
function Df(n, e, t) {
  let r, { icon: a = ws } = e;
  const i = yf(), l = () => i("click");
  return n.$$set = (o) => {
    "icon" in o && t(0, a = o.icon);
  }, n.$$.update = () => {
    n.$$.dirty & /*icon*/
    1 && t(1, r = a === ws ? "Click to Access Webcam" : "Click to Access Microphone");
  }, [a, r, i, l];
}
class A5 extends sf {
  constructor(e) {
    super(), df(this, e, Df, kf, gf, { icon: 0 });
  }
}
function F5() {
  return navigator.mediaDevices.enumerateDevices();
}
function Ef(n, e) {
  e.srcObject = n, e.muted = !0, e.play();
}
async function qa(n, e, t, r) {
  const a = r || {
    width: { ideal: 500 },
    height: { ideal: 500 }
  }, i = {
    video: t ? { deviceId: { exact: t }, ...a } : a,
    audio: n
  };
  return navigator.mediaDevices.getUserMedia(i).then((l) => (Ef(l, e), l));
}
function D1(n, e = "videoinput") {
  return n.filter(
    (r) => r.kind === e
  );
}
function Af(n, e) {
  return n.addEventListener(
    "icegatheringstatechange",
    () => {
      console.debug(n.iceGatheringState);
    },
    !1
  ), n.addEventListener(
    "iceconnectionstatechange",
    () => {
      console.debug(n.iceConnectionState);
    },
    !1
  ), n.addEventListener(
    "signalingstatechange",
    () => {
      console.debug(n.signalingState);
    },
    !1
  ), n.addEventListener("track", (t) => {
    console.debug("track event listener"), e && e.srcObject !== t.streams[0] && (console.debug("streams", t.streams), e.srcObject = t.streams[0], console.debug("node.srcOject", e.srcObject), t.track.kind === "audio" && (e.volume = 1, e.muted = !1, e.autoplay = !0, e.play().catch((r) => console.debug("Autoplay failed:", r))));
  }), n;
}
async function B1(n, e, t, r, a, i = "video", l = () => {
}, o = {}) {
  e = Af(e, t);
  const s = e.createDataChannel("text");
  return s.onopen = () => {
    console.debug("Data channel is open"), s.send("handshake");
  }, s.onmessage = (u) => {
    console.debug("Received message:", u.data);
    let c;
    try {
      c = JSON.parse(u.data);
    } catch {
      console.debug("Error parsing JSON");
    }
    console.log("event_json", c), (u.data === "change" || u.data === "tick" || u.data === "stopword" || (c == null ? void 0 : c.type) === "warning" || (c == null ? void 0 : c.type) === "error") && (console.debug(`${u.data} event received`), l(c ?? u.data));
  }, n ? n.getTracks().forEach(async (u) => {
    console.debug("Track stream callback", u);
    const c = e.addTrack(u, n), f = { ...c.getParameters(), ...o };
    await c.setParameters(f), console.debug("sender params", c.getParameters());
  }) : (console.debug("Creating transceiver!"), e.addTransceiver(i, { direction: "recvonly" })), await Sf(e, r, a), e;
}
function Ff(n, e) {
  return new Promise((t, r) => {
    n(e).then((a) => {
      console.debug("data", a), (a == null ? void 0 : a.status) === "failed" && (console.debug("rejecting"), r("error")), t(a);
    });
  });
}
async function Sf(n, e, t) {
  return n.createOffer().then((r) => n.setLocalDescription(r)).then(() => new Promise((r) => {
    if (console.debug("ice gathering state", n.iceGatheringState), n.iceGatheringState === "complete")
      r();
    else {
      const a = () => {
        n.iceGatheringState === "complete" && (console.debug("ice complete"), n.removeEventListener("icegatheringstatechange", a), r());
      };
      n.addEventListener("icegatheringstatechange", a);
    }
  })).then(() => {
    var r = n.localDescription;
    return Ff(e, {
      sdp: r.sdp,
      type: r.type,
      webrtc_id: t
    });
  }).then((r) => r).then((r) => n.setRemoteDescription(r));
}
function Kr(n) {
  console.debug("Stopping peer connection"), n.getTransceivers && n.getTransceivers().forEach((e) => {
    e.stop && e.stop();
  }), n.getSenders() && n.getSenders().forEach((e) => {
    console.log("sender", e), e.track && e.track.stop && e.track.stop();
  }), setTimeout(() => {
    n.close();
  }, 500);
}
const {
  SvelteComponent: xf,
  append_hydration: fl,
  attr: Wr,
  check_outros: $6,
  children: Ea,
  claim_component: Cf,
  claim_element: h1,
  claim_space: Tf,
  construct_svelte_component: o2,
  create_component: u2,
  destroy_component: c2,
  destroy_each: Qf,
  detach: vr,
  element: f1,
  empty: Oa,
  ensure_array_like: h2,
  group_outros: e3,
  init: Mf,
  insert_hydration: z1,
  mount_component: f2,
  noop: d2,
  safe_not_equal: Bf,
  set_style: It,
  space: zf,
  src_url_equal: m2,
  transition_in: Pa,
  transition_out: Ha
} = window.__gradio__svelte__internal, { onDestroy: Lf } = window.__gradio__svelte__internal;
function p2(n, e, t) {
  const r = n.slice();
  return r[14] = e[t], r[16] = t, r;
}
function g2(n) {
  let e, t = h2(Array(3)), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = _2(p2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = Oa();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = Oa();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      z1(a, e, i);
    },
    p(a, i) {
      if (i & /*pulse_color, maxPulseScale, pulseIntensity*/
      44) {
        t = h2(Array(3));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = p2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = _2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && vr(e), Qf(r, a);
    }
  };
}
function _2(n) {
  let e;
  return {
    c() {
      e = f1("div"), this.h();
    },
    l(t) {
      e = h1(t, "DIV", { class: !0 }), Ea(e).forEach(vr), this.h();
    },
    h() {
      Wr(e, "class", "pulse-ring svelte-t6tj07"), It(
        e,
        "background",
        /*pulse_color*/
        n[2]
      ), It(e, "animation-delay", `${/*i*/
      n[16] * 0.4}s`), It(
        e,
        "--max-scale",
        /*maxPulseScale*/
        n[5]
      ), It(e, "opacity", 0.5 * /*pulseIntensity*/
      n[3]);
    },
    m(t, r) {
      z1(t, e, r);
    },
    p(t, r) {
      r & /*pulse_color*/
      4 && It(
        e,
        "background",
        /*pulse_color*/
        t[2]
      ), r & /*maxPulseScale*/
      32 && It(
        e,
        "--max-scale",
        /*maxPulseScale*/
        t[5]
      ), r & /*pulseIntensity*/
      8 && It(e, "opacity", 0.5 * /*pulseIntensity*/
      t[3]);
    },
    d(t) {
      t && vr(e);
    }
  };
}
function If(n) {
  let e, t, r;
  var a = (
    /*icon*/
    n[0]
  );
  function i(l, o) {
    return {};
  }
  return a && (e = o2(a, i())), {
    c() {
      e && u2(e.$$.fragment), t = Oa();
    },
    l(l) {
      e && Cf(e.$$.fragment, l), t = Oa();
    },
    m(l, o) {
      e && f2(e, l, o), z1(l, t, o), r = !0;
    },
    p(l, o) {
      if (o & /*icon*/
      1 && a !== (a = /*icon*/
      l[0])) {
        if (e) {
          e3();
          const s = e;
          Ha(s.$$.fragment, 1, 0, () => {
            c2(s, 1);
          }), $6();
        }
        a ? (e = o2(a, i()), u2(e.$$.fragment), Pa(e.$$.fragment, 1), f2(e, t.parentNode, t)) : e = null;
      }
    },
    i(l) {
      r || (e && Pa(e.$$.fragment, l), r = !0);
    },
    o(l) {
      e && Ha(e.$$.fragment, l), r = !1;
    },
    d(l) {
      l && vr(t), e && c2(e, l);
    }
  };
}
function Nf(n) {
  let e, t;
  return {
    c() {
      e = f1("img"), this.h();
    },
    l(r) {
      e = h1(r, "IMG", { src: !0, alt: !0, class: !0 }), this.h();
    },
    h() {
      m2(e.src, t = /*icon*/
      n[0]) || Wr(e, "src", t), Wr(e, "alt", "Audio visualization icon"), Wr(e, "class", "icon-image svelte-t6tj07");
    },
    m(r, a) {
      z1(r, e, a);
    },
    p(r, a) {
      a & /*icon*/
      1 && !m2(e.src, t = /*icon*/
      r[0]) && Wr(e, "src", t);
    },
    i: d2,
    o: d2,
    d(r) {
      r && vr(e);
    }
  };
}
function Rf(n) {
  let e, t, r, a, i, l, o, s = (
    /*pulseIntensity*/
    n[3] > 0 && g2(n)
  );
  const u = [Nf, If], c = [];
  function d(f, p) {
    return typeof /*icon*/
    f[0] == "string" ? 0 : 1;
  }
  return i = d(n), l = c[i] = u[i](n), {
    c() {
      e = f1("div"), t = f1("div"), s && s.c(), r = zf(), a = f1("div"), l.c(), this.h();
    },
    l(f) {
      e = h1(f, "DIV", { class: !0 });
      var p = Ea(e);
      t = h1(p, "DIV", { class: !0 });
      var b = Ea(t);
      s && s.l(b), r = Tf(b), a = h1(b, "DIV", { class: !0 });
      var E = Ea(a);
      l.l(E), E.forEach(vr), b.forEach(vr), p.forEach(vr), this.h();
    },
    h() {
      Wr(a, "class", "gradio-webrtc-pulsing-icon svelte-t6tj07"), It(a, "transform", `scale(${/*pulseScale*/
      n[4]})`), It(
        a,
        "background",
        /*icon_button_color*/
        n[1]
      ), Wr(t, "class", "gradio-webrtc-pulsing-icon-container svelte-t6tj07"), Wr(e, "class", "gradio-webrtc-icon-wrapper svelte-t6tj07");
    },
    m(f, p) {
      z1(f, e, p), fl(e, t), s && s.m(t, null), fl(t, r), fl(t, a), c[i].m(a, null), o = !0;
    },
    p(f, [p]) {
      /*pulseIntensity*/
      f[3] > 0 ? s ? s.p(f, p) : (s = g2(f), s.c(), s.m(t, r)) : s && (s.d(1), s = null);
      let b = i;
      i = d(f), i === b ? c[i].p(f, p) : (e3(), Ha(c[b], 1, 1, () => {
        c[b] = null;
      }), $6(), l = c[i], l ? l.p(f, p) : (l = c[i] = u[i](f), l.c()), Pa(l, 1), l.m(a, null)), p & /*pulseScale*/
      16 && It(a, "transform", `scale(${/*pulseScale*/
      f[4]})`), p & /*icon_button_color*/
      2 && It(
        a,
        "background",
        /*icon_button_color*/
        f[1]
      );
    },
    i(f) {
      o || (Pa(l), o = !0);
    },
    o(f) {
      Ha(l), o = !1;
    },
    d(f) {
      f && vr(e), s && s.d(), c[i].d();
    }
  };
}
function qf(n, e, t) {
  let r, { stream_state: a = "closed" } = e, { audio_source_callback: i } = e, { icon: l = void 0 } = e, { icon_button_color: o = "var(--color-accent)" } = e, { pulse_color: s = "var(--color-accent)" } = e, u, c, d, f, p = 1, b = 0;
  Lf(() => {
    f && cancelAnimationFrame(f), u && u.close();
  });
  function E() {
    u = new (window.AudioContext || window.webkitAudioContext)(), c = u.createAnalyser(), u.createMediaStreamSource(i()).connect(c), c.fftSize = 64, c.smoothingTimeConstant = 0.8, d = new Uint8Array(c.frequencyBinCount), k();
  }
  function k() {
    c.getByteFrequencyData(d);
    const _ = Array.from(d).reduce((v, A) => v + A, 0) / d.length / 255;
    t(4, p = 1 + _ * 0.15), t(3, b = _), f = requestAnimationFrame(k);
  }
  return n.$$set = (w) => {
    "stream_state" in w && t(6, a = w.stream_state), "audio_source_callback" in w && t(7, i = w.audio_source_callback), "icon" in w && t(0, l = w.icon), "icon_button_color" in w && t(1, o = w.icon_button_color), "pulse_color" in w && t(2, s = w.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*stream_state*/
    64 && a === "open" && E(), n.$$.dirty & /*pulseIntensity*/
    8 && t(5, r = 1 + b * 10);
  }, [
    l,
    o,
    s,
    b,
    p,
    r,
    a,
    i
  ];
}
class t3 extends xf {
  constructor(e) {
    super(), Mf(this, e, qf, Rf, Bf, {
      stream_state: 6,
      audio_source_callback: 7,
      icon: 0,
      icon_button_color: 1,
      pulse_color: 2
    });
  }
}
const {
  SvelteComponent: Of,
  action_destroyer: Pf,
  add_render_callback: Hf,
  append_hydration: Me,
  attr: ee,
  binding_callbacks: dl,
  check_outros: sn,
  children: Be,
  claim_component: Ut,
  claim_element: Je,
  claim_space: H0,
  claim_svg_element: bt,
  claim_text: gn,
  create_component: jt,
  create_in_transition: Vf,
  destroy_component: Gt,
  destroy_each: r3,
  detach: le,
  element: $e,
  empty: In,
  ensure_array_like: Va,
  group_outros: on,
  init: Uf,
  insert_hydration: h0,
  listen: yr,
  mount_component: Wt,
  noop: n3,
  run_all: S5,
  safe_not_equal: jf,
  set_data: _n,
  set_input_value: Nn,
  set_style: Gf,
  space: V0,
  stop_propagation: a3,
  svg_element: wt,
  text: vn,
  toggle_class: D0,
  transition_in: Ye,
  transition_out: u0
} = window.__gradio__svelte__internal, { createEventDispatcher: Wf, onMount: Zf } = window.__gradio__svelte__internal;
function v2(n, e, t) {
  const r = n.slice();
  return r[53] = e[t], r;
}
function b2(n, e, t) {
  const r = n.slice();
  return r[53] = e[t], r;
}
function w2(n) {
  let e, t, r;
  return t = new t3({
    props: {
      stream_state: (
        /*stream_state*/
        n[15]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        n[29]
      ),
      icon: (
        /*icon*/
        n[0] || Al
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[1]
      ),
      pulse_color: (
        /*pulse_color*/
        n[2]
      )
    }
  }), {
    c() {
      e = $e("div"), jt(t.$$.fragment), this.h();
    },
    l(a) {
      e = Je(a, "DIV", { class: !0 });
      var i = Be(e);
      Ut(t.$$.fragment, i), i.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "audio-indicator svelte-96ajhq");
    },
    m(a, i) {
      h0(a, e, i), Wt(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      32768 && (l.stream_state = /*stream_state*/
      a[15]), i[0] & /*icon*/
      1 && (l.icon = /*icon*/
      a[0] || Al), i[0] & /*icon_button_color*/
      2 && (l.icon_button_color = /*icon_button_color*/
      a[1]), i[0] & /*pulse_color*/
      4 && (l.pulse_color = /*pulse_color*/
      a[2]), t.$set(l);
    },
    i(a) {
      r || (Ye(t.$$.fragment, a), r = !0);
    },
    o(a) {
      u0(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && le(e), Gt(t);
    }
  };
}
function Yf(n) {
  let e;
  return {
    c() {
      e = $e("video"), this.h();
    },
    l(t) {
      e = Je(t, "VIDEO", { class: !0 }), Be(e).forEach(le), this.h();
    },
    h() {
      e.autoplay = !0, e.muted = /*volumeMuted*/
      n[16], e.playsInline = !0, ee(e, "class", "svelte-96ajhq"), D0(e, "hide", !/*webcam_accessed*/
      n[19]), D0(
        e,
        "flip",
        /*stream_state*/
        n[15] != "open" || /*stream_state*/
        n[15] === "open" && /*include_audio*/
        n[4]
      );
    },
    m(t, r) {
      h0(t, e, r), n[42](e);
    },
    p(t, r) {
      r[0] & /*volumeMuted*/
      65536 && (e.muted = /*volumeMuted*/
      t[16]), r[0] & /*webcam_accessed*/
      524288 && D0(e, "hide", !/*webcam_accessed*/
      t[19]), r[0] & /*stream_state, include_audio*/
      32784 && D0(
        e,
        "flip",
        /*stream_state*/
        t[15] != "open" || /*stream_state*/
        t[15] === "open" && /*include_audio*/
        t[4]
      );
    },
    d(t) {
      t && le(e), n[42](null);
    }
  };
}
function Xf(n) {
  let e, t, r, a;
  return {
    c() {
      e = $e("div"), t = $e("video"), r = V0(), a = $e("video"), this.h();
    },
    l(i) {
      e = Je(i, "DIV", { class: !0 });
      var l = Be(e);
      t = Je(l, "VIDEO", { class: !0 }), Be(t).forEach(le), r = H0(l), a = Je(l, "VIDEO", { class: !0 }), Be(a).forEach(le), l.forEach(le), this.h();
    },
    h() {
      t.autoplay = !0, t.playsInline = !0, t.muted = !0, ee(t, "class", "svelte-96ajhq"), D0(
        t,
        "local-video",
        /*stream_state*/
        n[15] === "open"
      ), D0(
        t,
        "remote-video",
        /*stream_state*/
        n[15] !== "open"
      ), D0(t, "hide", !/*webcam_accessed*/
      n[19] || /*cameraOff*/
      n[18]), ee(a, "class", "remote-video svelte-96ajhq"), a.autoplay = !0, a.muted = /*volumeMuted*/
      n[16], a.playsInline = !0, D0(a, "hide", !/*webcam_received*/
      n[20] || /*stream_state*/
      n[15] != "open"), D0(
        a,
        "flip",
        /*stream_state*/
        n[15] != "open" || /*stream_state*/
        n[15] === "open" && /*include_audio*/
        n[4]
      ), ee(e, "class", "video-wrap svelte-96ajhq"), D0(
        e,
        "picinpic",
        /*show_local_video*/
        n[5] === "picture-in-picture"
      ), D0(
        e,
        "left-right",
        /*show_local_video*/
        n[5] === "left-right"
      ), D0(e, "hide", !/*webcam_accessed*/
      n[19]);
    },
    m(i, l) {
      h0(i, e, l), Me(e, t), n[40](t), Me(e, r), Me(e, a), n[41](a);
    },
    p(i, l) {
      l[0] & /*stream_state*/
      32768 && D0(
        t,
        "local-video",
        /*stream_state*/
        i[15] === "open"
      ), l[0] & /*stream_state*/
      32768 && D0(
        t,
        "remote-video",
        /*stream_state*/
        i[15] !== "open"
      ), l[0] & /*webcam_accessed, cameraOff*/
      786432 && D0(t, "hide", !/*webcam_accessed*/
      i[19] || /*cameraOff*/
      i[18]), l[0] & /*volumeMuted*/
      65536 && (a.muted = /*volumeMuted*/
      i[16]), l[0] & /*webcam_received, stream_state*/
      1081344 && D0(a, "hide", !/*webcam_received*/
      i[20] || /*stream_state*/
      i[15] != "open"), l[0] & /*stream_state, include_audio*/
      32784 && D0(
        a,
        "flip",
        /*stream_state*/
        i[15] != "open" || /*stream_state*/
        i[15] === "open" && /*include_audio*/
        i[4]
      ), l[0] & /*show_local_video*/
      32 && D0(
        e,
        "picinpic",
        /*show_local_video*/
        i[5] === "picture-in-picture"
      ), l[0] & /*show_local_video*/
      32 && D0(
        e,
        "left-right",
        /*show_local_video*/
        i[5] === "left-right"
      ), l[0] & /*webcam_accessed*/
      524288 && D0(e, "hide", !/*webcam_accessed*/
      i[19]);
    },
    d(i) {
      i && le(e), n[40](null), n[41](null);
    }
  };
}
function Kf(n) {
  let e, t, r, a, i, l, o, s, u, c, d;
  const f = [td, ed, $f], p = [];
  function b(_, v) {
    return (
      /*stream_state*/
      _[15] === "waiting" ? 0 : (
        /*stream_state*/
        _[15] === "open" ? 1 : 2
      )
    );
  }
  r = b(n), a = p[r] = f[r](n);
  let E = rd(n), k = (
    /*include_audio*/
    n[4] === !0 && /*stream_state*/
    n[15] === "open" && y2(n)
  ), w = (
    /*options_open*/
    n[21] && /*selected_device*/
    n[12] && k2(n)
  );
  return {
    c() {
      e = $e("div"), t = $e("button"), a.c(), i = V0(), E && E.c(), l = V0(), k && k.c(), o = V0(), w && w.c(), s = In(), this.h();
    },
    l(_) {
      e = Je(_, "DIV", { class: !0 });
      var v = Be(e);
      t = Je(v, "BUTTON", { "aria-label": !0, class: !0 });
      var A = Be(t);
      a.l(A), A.forEach(le), i = H0(v), E && E.l(v), l = H0(v), k && k.l(v), v.forEach(le), o = H0(_), w && w.l(_), s = In(), this.h();
    },
    h() {
      ee(t, "aria-label", "start stream"), ee(t, "class", "svelte-96ajhq"), ee(e, "class", "button-wrap svelte-96ajhq");
    },
    m(_, v) {
      h0(_, e, v), Me(e, t), p[r].m(t, null), Me(e, i), E && E.m(e, null), Me(e, l), k && k.m(e, null), h0(_, o, v), w && w.m(_, v), h0(_, s, v), u = !0, c || (d = yr(
        t,
        "click",
        /*start_webrtc*/
        n[27]
      ), c = !0);
    },
    p(_, v) {
      let A = r;
      r = b(_), r === A ? p[r].p(_, v) : (on(), u0(p[A], 1, 1, () => {
        p[A] = null;
      }), sn(), a = p[r], a ? a.p(_, v) : (a = p[r] = f[r](_), a.c()), Ye(a, 1), a.m(t, null)), E.p(_, v), /*include_audio*/
      _[4] === !0 && /*stream_state*/
      _[15] === "open" ? k ? (k.p(_, v), v[0] & /*include_audio, stream_state*/
      32784 && Ye(k, 1)) : (k = y2(_), k.c(), Ye(k, 1), k.m(e, null)) : k && (on(), u0(k, 1, 1, () => {
        k = null;
      }), sn()), /*options_open*/
      _[21] && /*selected_device*/
      _[12] ? w ? (w.p(_, v), v[0] & /*options_open, selected_device*/
      2101248 && Ye(w, 1)) : (w = k2(_), w.c(), Ye(w, 1), w.m(s.parentNode, s)) : w && (on(), u0(w, 1, 1, () => {
        w = null;
      }), sn());
    },
    i(_) {
      u || (Ye(a), Ye(E), Ye(k), Ye(w), u = !0);
    },
    o(_) {
      u0(a), u0(E), u0(k), u0(w), u = !1;
    },
    d(_) {
      _ && (le(e), le(o), le(s)), p[r].d(), E && E.d(), k && k.d(), w && w.d(_), c = !1, d();
    }
  };
}
function Jf(n) {
  let e, t, r, a;
  return t = new A5({}), t.$on(
    "click",
    /*click_handler*/
    n[43]
  ), {
    c() {
      e = $e("div"), jt(t.$$.fragment), this.h();
    },
    l(i) {
      e = Je(i, "DIV", { title: !0, style: !0 });
      var l = Be(e);
      Ut(t.$$.fragment, l), l.forEach(le), this.h();
    },
    h() {
      ee(e, "title", "grant webcam access"), Gf(e, "height", "100%");
    },
    m(i, l) {
      h0(i, e, l), Wt(t, e, null), a = !0;
    },
    p: n3,
    i(i) {
      a || (Ye(t.$$.fragment, i), i && (r || Hf(() => {
        r = Vf(e, E5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      u0(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && le(e), Gt(t);
    }
  };
}
function $f(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].start || /*i18n*/
    n[6]("audio.record")) + ""
  ), l, o;
  return r = new F4({}), {
    c() {
      e = $e("div"), t = $e("div"), jt(r.$$.fragment), a = V0(), l = vn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Ut(r.$$.fragment, c), c.forEach(le), a = H0(u), l = gn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "start recording"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      h0(s, e, u), Me(e, t), Wt(r, t, null), Me(e, a), Me(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].start || /*i18n*/
      s[6]("audio.record")) + "") && _n(l, i);
    },
    i(s) {
      o || (Ye(r.$$.fragment, s), o = !0);
    },
    o(s) {
      u0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Gt(r);
    }
  };
}
function ed(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].stop || /*i18n*/
    n[6]("audio.stop")) + ""
  ), l, o;
  return r = new S4({}), {
    c() {
      e = $e("div"), t = $e("div"), jt(r.$$.fragment), a = V0(), l = vn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Ut(r.$$.fragment, c), c.forEach(le), a = H0(u), l = gn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "stop recording"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      h0(s, e, u), Me(e, t), Wt(r, t, null), Me(e, a), Me(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].stop || /*i18n*/
      s[6]("audio.stop")) + "") && _n(l, i);
    },
    i(s) {
      o || (Ye(r.$$.fragment, s), o = !0);
    },
    o(s) {
      u0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Gt(r);
    }
  };
}
function td(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[3].waiting || /*i18n*/
    n[6]("audio.waiting")) + ""
  ), l, o;
  return r = new Jl({}), {
    c() {
      e = $e("div"), t = $e("div"), jt(r.$$.fragment), a = V0(), l = vn(i), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Be(e);
      t = Je(u, "DIV", { class: !0, title: !0 });
      var c = Be(t);
      Ut(r.$$.fragment, c), c.forEach(le), a = H0(u), l = gn(u, i), u.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon color-primary svelte-96ajhq"), ee(t, "title", "spinner"), ee(e, "class", "icon-with-text svelte-96ajhq");
    },
    m(s, u) {
      h0(s, e, u), Me(e, t), Wt(r, t, null), Me(e, a), Me(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      72) && i !== (i = /*button_labels*/
      (s[3].waiting || /*i18n*/
      s[6]("audio.waiting")) + "") && _n(l, i);
    },
    i(s) {
      o || (Ye(r.$$.fragment, s), o = !0);
    },
    o(s) {
      u0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && le(e), Gt(r);
    }
  };
}
function rd(n) {
  let e, t, r, a, i;
  return t = new x1({}), {
    c() {
      e = $e("button"), jt(t.$$.fragment), this.h();
    },
    l(l) {
      e = Je(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = Be(e);
      Ut(t.$$.fragment, o), o.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "icon svelte-96ajhq"), ee(e, "aria-label", "select input source");
    },
    m(l, o) {
      h0(l, e, o), Wt(t, e, null), r = !0, a || (i = yr(
        e,
        "click",
        /*click_handler_1*/
        n[44]
      ), a = !0);
    },
    p: n3,
    i(l) {
      r || (Ye(t.$$.fragment, l), r = !0);
    },
    o(l) {
      u0(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && le(e), Gt(t), a = !1, i();
    }
  };
}
function y2(n) {
  let e, t, r, a, i, l, o, s, u, c, d;
  function f(x, Q) {
    return (
      /*cameraOff*/
      x[18] ? nd : ad
    );
  }
  let p = f(n), b = p(n);
  function E(x, Q) {
    return (
      /*micMuted*/
      x[17] ? id : ld
    );
  }
  let k = E(n), w = k(n);
  const _ = [od, sd], v = [];
  function A(x, Q) {
    return (
      /*volumeMuted*/
      x[16] ? 0 : 1
    );
  }
  return o = A(n), s = v[o] = _[o](n), {
    c() {
      e = $e("div"), t = $e("button"), b.c(), r = V0(), a = $e("button"), w.c(), i = V0(), l = $e("button"), s.c(), this.h();
    },
    l(x) {
      e = Je(x, "DIV", { class: !0 });
      var Q = Be(e);
      t = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var B = Be(t);
      b.l(B), B.forEach(le), r = H0(Q), a = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var O = Be(a);
      w.l(O), O.forEach(le), i = H0(Q), l = Je(Q, "BUTTON", { class: !0, "aria-label": !0 });
      var M = Be(l);
      s.l(M), M.forEach(le), Q.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "icon svelte-96ajhq"), ee(t, "aria-label", "select input source"), ee(a, "class", "icon svelte-96ajhq"), ee(a, "aria-label", "select input source"), ee(l, "class", "icon svelte-96ajhq"), ee(l, "aria-label", "select input source"), ee(e, "class", "action-wrap svelte-96ajhq");
    },
    m(x, Q) {
      h0(x, e, Q), Me(e, t), b.m(t, null), Me(e, r), Me(e, a), w.m(a, null), Me(e, i), Me(e, l), v[o].m(l, null), u = !0, c || (d = [
        yr(
          t,
          "click",
          /*handle_camera_off*/
          n[24]
        ),
        yr(
          a,
          "click",
          /*handle_mic_mute*/
          n[23]
        ),
        yr(
          l,
          "click",
          /*handle_volume_mute*/
          n[22]
        )
      ], c = !0);
    },
    p(x, Q) {
      p !== (p = f(x)) && (b.d(1), b = p(x), b && (b.c(), b.m(t, null))), k !== (k = E(x)) && (w.d(1), w = k(x), w && (w.c(), w.m(a, null)));
      let B = o;
      o = A(x), o !== B && (on(), u0(v[B], 1, 1, () => {
        v[B] = null;
      }), sn(), s = v[o], s || (s = v[o] = _[o](x), s.c()), Ye(s, 1), s.m(l, null));
    },
    i(x) {
      u || (Ye(s), u = !0);
    },
    o(x) {
      u0(s), u = !1;
    },
    d(x) {
      x && le(e), b.d(), w.d(), v[o].d(), c = !1, S5(d);
    }
  };
}
function nd(n) {
  let e, t, r;
  return {
    c() {
      e = wt("svg"), t = wt("line"), r = wt("path"), this.h();
    },
    l(a) {
      e = bt(a, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var i = Be(e);
      t = bt(i, "line", {
        fill: !0,
        id: !0,
        stroke: !0,
        "stroke-width": !0,
        x1: !0,
        x2: !0,
        y1: !0,
        y2: !0
      }), Be(t).forEach(le), r = bt(i, "path", { d: !0 }), Be(r).forEach(le), i.forEach(le), this.h();
    },
    h() {
      ee(t, "fill", "none"), ee(t, "id", "svg_5"), ee(t, "stroke", "#000000"), ee(t, "stroke-width", "80"), ee(t, "x1", "860"), ee(t, "x2", "100"), ee(t, "y1", "100"), ee(t, "y2", "860"), ee(r, "d", "M864 248H728l-32.4-90.8a32.07 32.07 0 00-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8 22.9-64.2h250.5l22.9 64.2 17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160 160-71.6 160-160-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96 96 43 96 96-43 96-96 96z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "camera"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(a, i) {
      h0(a, e, i), Me(e, t), Me(e, r);
    },
    d(a) {
      a && le(e);
    }
  };
}
function ad(n) {
  let e, t;
  return {
    c() {
      e = wt("svg"), t = wt("path"), this.h();
    },
    l(r) {
      e = bt(r, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var a = Be(e);
      t = bt(a, "path", { d: !0 }), Be(t).forEach(le), a.forEach(le), this.h();
    },
    h() {
      ee(t, "d", "M864 248H728l-32.4-90.8a32.07 32.07 0 00-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8 22.9-64.2h250.5l22.9 64.2 17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160 160-71.6 160-160-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96 96 43 96 96-43 96-96 96z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "camera"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(r, a) {
      h0(r, e, a), Me(e, t);
    },
    d(r) {
      r && le(e);
    }
  };
}
function id(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = wt("svg"), t = wt("defs"), r = wt("style"), a = wt("path"), i = wt("path"), this.h();
    },
    l(l) {
      e = bt(l, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var o = Be(e);
      t = bt(o, "defs", {});
      var s = Be(t);
      r = bt(s, "style", {});
      var u = Be(r);
      u.forEach(le), s.forEach(le), a = bt(o, "path", { d: !0 }), Be(a).forEach(le), i = bt(o, "path", { d: !0 }), Be(i).forEach(le), o.forEach(le), this.h();
    },
    h() {
      ee(a, "d", "M682 455V311l-76 76v68c-.1 50.7-42 92.1-94 92a95.8 95.8 0 01-52-15l-54 55c29.1 22.4 65.9 36 106 36 93.8 0 170-75.1 170-168z"), ee(i, "d", "M833 446h-60c-4.4 0-8 3.6-8 8 0 140.3-113.7 254-254 254-63 0-120.7-23-165-61l-54 54a334.01 334.01 0 00179 81v102H326c-13.9 0-24.9 14.3-25 32v36c.1 4.4 2.9 8 6 8h408c3.2 0 6-3.6 6-8v-36c0-17.7-11-32-25-32H547V782c165.3-17.9 294-157.9 294-328 0-4.4-3.6-8-8-8zm13.1-377.7l-43.5-41.9a8 8 0 00-11.2.1l-129 129C634.3 101.2 577 64 511 64c-93.9 0-170 75.3-170 168v224c0 6.7.4 13.3 1.2 19.8l-68 68A252.33 252.33 0 01258 454c-.2-4.4-3.8-8-8-8h-60c-4.4 0-8 3.6-8 8 0 53 12.5 103 34.6 147.4l-137 137a8.03 8.03 0 000 11.3l42.7 42.7c3.1 3.1 8.2 3.1 11.3 0L846.2 79.8l.1-.1c3.1-3.2 3-8.3-.2-11.4zM417 401V232c0-50.6 41.9-92 94-92 46 0 84.1 32.3 92.3 74.7L417 401z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "audio-muted"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(l, o) {
      h0(l, e, o), Me(e, t), Me(t, r), Me(e, a), Me(e, i);
    },
    d(l) {
      l && le(e);
    }
  };
}
function ld(n) {
  let e, t;
  return {
    c() {
      e = wt("svg"), t = wt("path"), this.h();
    },
    l(r) {
      e = bt(r, "svg", {
        viewBox: !0,
        focusable: !0,
        "data-icon": !0,
        width: !0,
        height: !0,
        fill: !0,
        "aria-hidden": !0
      });
      var a = Be(e);
      t = bt(a, "path", { d: !0 }), Be(t).forEach(le), a.forEach(le), this.h();
    },
    h() {
      ee(t, "d", "M842 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 140.3-113.7 254-254 254S258 594.3 258 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 168.7 126.6 307.9 290 327.6V884H326.7c-13.7 0-24.7 14.3-24.7 32v36c0 4.4 2.8 8 6.2 8h407.6c3.4 0 6.2-3.6 6.2-8v-36c0-17.7-11-32-24.7-32H548V782.1c165.3-18 294-158 294-328.1zM512 624c93.9 0 170-75.2 170-168V232c0-92.8-76.1-168-170-168s-170 75.2-170 168v224c0 92.8 76.1 168 170 168zm-94-392c0-50.6 41.9-92 94-92s94 41.4 94 92v224c0 50.6-41.9 92-94 92s-94-41.4-94-92V232z"), ee(e, "viewBox", "64 64 896 896"), ee(e, "focusable", "false"), ee(e, "data-icon", "audio"), ee(e, "width", "1em"), ee(e, "height", "1em"), ee(e, "fill", "currentColor"), ee(e, "aria-hidden", "true");
    },
    m(r, a) {
      h0(r, e, a), Me(e, t);
    },
    d(r) {
      r && le(e);
    }
  };
}
function sd(n) {
  let e, t;
  return e = new Zu({}), {
    c() {
      jt(e.$$.fragment);
    },
    l(r) {
      Ut(e.$$.fragment, r);
    },
    m(r, a) {
      Wt(e, r, a), t = !0;
    },
    i(r) {
      t || (Ye(e.$$.fragment, r), t = !0);
    },
    o(r) {
      u0(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Gt(e, r);
    }
  };
}
function od(n) {
  let e, t;
  return e = new r7({}), {
    c() {
      jt(e.$$.fragment);
    },
    l(r) {
      Ut(e.$$.fragment, r);
    },
    m(r, a) {
      Wt(e, r, a), t = !0;
    },
    i(r) {
      t || (Ye(e.$$.fragment, r), t = !0);
    },
    o(r) {
      u0(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Gt(e, r);
    }
  };
}
function k2(n) {
  let e, t, r, a, i, l, o, s, u;
  a = new x1({});
  function c(b, E) {
    return (
      /*available_video_devices*/
      b[10].length === 0 ? cd : ud
    );
  }
  let d = c(n), f = d(n), p = (
    /*include_audio*/
    n[4] === !0 && E2(n)
  );
  return {
    c() {
      e = $e("div"), t = $e("select"), r = $e("button"), jt(a.$$.fragment), i = V0(), f.c(), l = V0(), p && p.c(), this.h();
    },
    l(b) {
      e = Je(b, "DIV", { class: !0 });
      var E = Be(e);
      t = Je(E, "SELECT", { class: !0, "aria-label": !0 });
      var k = Be(t);
      r = Je(k, "BUTTON", { class: !0 });
      var w = Be(r);
      Ut(a.$$.fragment, w), i = H0(w), w.forEach(le), f.l(k), k.forEach(le), l = H0(E), p && p.l(E), E.forEach(le), this.h();
    },
    h() {
      ee(r, "class", "inset-icon svelte-96ajhq"), ee(t, "class", "select-wrap svelte-96ajhq"), ee(t, "aria-label", "select source"), ee(e, "class", "select-container svelte-96ajhq");
    },
    m(b, E) {
      h0(b, e, E), Me(e, t), Me(t, r), Wt(a, r, null), Me(r, i), f.m(t, null), Me(e, l), p && p.m(e, null), o = !0, s || (u = [
        yr(r, "click", a3(
          /*click_handler_2*/
          n[45]
        )),
        yr(
          t,
          "change",
          /*handle_device_change*/
          n[25]
        ),
        Pf(x5.call(
          null,
          e,
          /*handle_click_outside*/
          n[28]
        ))
      ], s = !0);
    },
    p(b, E) {
      d === (d = c(b)) && f ? f.p(b, E) : (f.d(1), f = d(b), f && (f.c(), f.m(t, null))), /*include_audio*/
      b[4] === !0 ? p ? (p.p(b, E), E[0] & /*include_audio*/
      16 && Ye(p, 1)) : (p = E2(b), p.c(), Ye(p, 1), p.m(e, null)) : p && (on(), u0(p, 1, 1, () => {
        p = null;
      }), sn());
    },
    i(b) {
      o || (Ye(a.$$.fragment, b), Ye(p), o = !0);
    },
    o(b) {
      u0(a.$$.fragment, b), u0(p), o = !1;
    },
    d(b) {
      b && le(e), Gt(a), f.d(), p && p.d(), s = !1, S5(u);
    }
  };
}
function ud(n) {
  let e, t = Va(
    /*available_video_devices*/
    n[10]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = D2(b2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = In();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = In();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      h0(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_video_devices, selected_device*/
      5120) {
        t = Va(
          /*available_video_devices*/
          a[10]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = b2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = D2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && le(e), r3(r, a);
    }
  };
}
function cd(n) {
  let e, t = (
    /*i18n*/
    n[6]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = $e("option"), r = vn(t), this.h();
    },
    l(a) {
      e = Je(a, "OPTION", { class: !0 });
      var i = Be(e);
      r = gn(i, t), i.forEach(le), this.h();
    },
    h() {
      e.__value = "", Nn(e, e.__value), ee(e, "class", "svelte-96ajhq");
    },
    m(a, i) {
      h0(a, e, i), Me(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      64 && t !== (t = /*i18n*/
      a[6]("common.no_devices") + "") && _n(r, t);
    },
    d(a) {
      a && le(e);
    }
  };
}
function D2(n) {
  let e, t = (
    /*device*/
    n[53].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = $e("option"), r = vn(t), a = V0(), this.h();
    },
    l(o) {
      e = Je(o, "OPTION", { class: !0 });
      var s = Be(e);
      r = gn(s, t), a = H0(s), s.forEach(le), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[53].deviceId, Nn(e, e.__value), e.selected = l = /*selected_device*/
      n[12].deviceId === /*device*/
      n[53].deviceId, ee(e, "class", "svelte-96ajhq");
    },
    m(o, s) {
      h0(o, e, s), Me(e, r), Me(e, a);
    },
    p(o, s) {
      s[0] & /*available_video_devices*/
      1024 && t !== (t = /*device*/
      o[53].label + "") && _n(r, t), s[0] & /*available_video_devices*/
      1024 && i !== (i = /*device*/
      o[53].deviceId) && (e.__value = i, Nn(e, e.__value)), s[0] & /*selected_device, available_video_devices*/
      5120 && l !== (l = /*selected_device*/
      o[12].deviceId === /*device*/
      o[53].deviceId) && (e.selected = l);
    },
    d(o) {
      o && le(e);
    }
  };
}
function E2(n) {
  let e, t, r, a, i, l, o;
  r = new x1({});
  function s(d, f) {
    return (
      /*available_audio_devices*/
      d[11].length === 0 ? fd : hd
    );
  }
  let u = s(n), c = u(n);
  return {
    c() {
      e = $e("select"), t = $e("button"), jt(r.$$.fragment), a = V0(), c.c(), this.h();
    },
    l(d) {
      e = Je(d, "SELECT", { class: !0, "aria-label": !0 });
      var f = Be(e);
      t = Je(f, "BUTTON", { class: !0 });
      var p = Be(t);
      Ut(r.$$.fragment, p), a = H0(p), p.forEach(le), c.l(f), f.forEach(le), this.h();
    },
    h() {
      ee(t, "class", "inset-icon svelte-96ajhq"), ee(e, "class", "select-wrap svelte-96ajhq"), ee(e, "aria-label", "select source");
    },
    m(d, f) {
      h0(d, e, f), Me(e, t), Wt(r, t, null), Me(t, a), c.m(e, null), i = !0, l || (o = [
        yr(t, "click", a3(
          /*click_handler_3*/
          n[46]
        )),
        yr(
          e,
          "change",
          /*handle_device_change*/
          n[25]
        )
      ], l = !0);
    },
    p(d, f) {
      u === (u = s(d)) && c ? c.p(d, f) : (c.d(1), c = u(d), c && (c.c(), c.m(e, null)));
    },
    i(d) {
      i || (Ye(r.$$.fragment, d), i = !0);
    },
    o(d) {
      u0(r.$$.fragment, d), i = !1;
    },
    d(d) {
      d && le(e), Gt(r), c.d(), l = !1, S5(o);
    }
  };
}
function hd(n) {
  let e, t = Va(
    /*available_audio_devices*/
    n[11]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = A2(v2(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = In();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = In();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      h0(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_audio_devices, selected_audio_device*/
      10240) {
        t = Va(
          /*available_audio_devices*/
          a[11]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = v2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = A2(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && le(e), r3(r, a);
    }
  };
}
function fd(n) {
  let e, t = (
    /*i18n*/
    n[6]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = $e("option"), r = vn(t), this.h();
    },
    l(a) {
      e = Je(a, "OPTION", { class: !0 });
      var i = Be(e);
      r = gn(i, t), i.forEach(le), this.h();
    },
    h() {
      e.__value = "", Nn(e, e.__value), ee(e, "class", "svelte-96ajhq");
    },
    m(a, i) {
      h0(a, e, i), Me(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      64 && t !== (t = /*i18n*/
      a[6]("common.no_devices") + "") && _n(r, t);
    },
    d(a) {
      a && le(e);
    }
  };
}
function A2(n) {
  let e, t = (
    /*device*/
    n[53].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = $e("option"), r = vn(t), a = V0(), this.h();
    },
    l(o) {
      e = Je(o, "OPTION", { class: !0 });
      var s = Be(e);
      r = gn(s, t), a = H0(s), s.forEach(le), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[53].deviceId, Nn(e, e.__value), e.selected = l = /*selected_audio_device*/
      n[13].deviceId === /*device*/
      n[53].deviceId, ee(e, "class", "svelte-96ajhq");
    },
    m(o, s) {
      h0(o, e, s), Me(e, r), Me(e, a);
    },
    p(o, s) {
      s[0] & /*available_audio_devices*/
      2048 && t !== (t = /*device*/
      o[53].label + "") && _n(r, t), s[0] & /*available_audio_devices*/
      2048 && i !== (i = /*device*/
      o[53].deviceId) && (e.__value = i, Nn(e, e.__value)), s[0] & /*selected_audio_device, available_audio_devices*/
      10240 && l !== (l = /*selected_audio_device*/
      o[13].deviceId === /*device*/
      o[53].deviceId) && (e.selected = l);
    },
    d(o) {
      o && le(e);
    }
  };
}
function dd(n) {
  let e, t, r, a, i, l, o, s;
  t = new G6({
    props: { time_limit: (
      /*_time_limit*/
      n[14]
    ) }
  });
  let u = (
    /*stream_state*/
    n[15] === "open" && /*include_audio*/
    n[4] && w2(n)
  );
  function c(k, w) {
    return (
      /*show_local_video*/
      k[5] ? Xf : Yf
    );
  }
  let d = c(n), f = d(n);
  const p = [Jf, Kf], b = [];
  function E(k, w) {
    return (
      /*webcam_accessed*/
      k[19] ? 1 : 0
    );
  }
  return l = E(n), o = b[l] = p[l](n), {
    c() {
      e = $e("div"), jt(t.$$.fragment), r = V0(), u && u.c(), a = V0(), f.c(), i = V0(), o.c(), this.h();
    },
    l(k) {
      e = Je(k, "DIV", { class: !0 });
      var w = Be(e);
      Ut(t.$$.fragment, w), r = H0(w), u && u.l(w), a = H0(w), f.l(w), i = H0(w), o.l(w), w.forEach(le), this.h();
    },
    h() {
      ee(e, "class", "wrap svelte-96ajhq");
    },
    m(k, w) {
      h0(k, e, w), Wt(t, e, null), Me(e, r), u && u.m(e, null), Me(e, a), f.m(e, null), Me(e, i), b[l].m(e, null), s = !0;
    },
    p(k, w) {
      const _ = {};
      w[0] & /*_time_limit*/
      16384 && (_.time_limit = /*_time_limit*/
      k[14]), t.$set(_), /*stream_state*/
      k[15] === "open" && /*include_audio*/
      k[4] ? u ? (u.p(k, w), w[0] & /*stream_state, include_audio*/
      32784 && Ye(u, 1)) : (u = w2(k), u.c(), Ye(u, 1), u.m(e, a)) : u && (on(), u0(u, 1, 1, () => {
        u = null;
      }), sn()), d === (d = c(k)) && f ? f.p(k, w) : (f.d(1), f = d(k), f && (f.c(), f.m(e, i)));
      let v = l;
      l = E(k), l === v ? b[l].p(k, w) : (on(), u0(b[v], 1, 1, () => {
        b[v] = null;
      }), sn(), o = b[l], o ? o.p(k, w) : (o = b[l] = p[l](k), o.c()), Ye(o, 1), o.m(e, null));
    },
    i(k) {
      s || (Ye(t.$$.fragment, k), Ye(u), Ye(o), s = !0);
    },
    o(k) {
      u0(t.$$.fragment, k), u0(u), u0(o), s = !1;
    },
    d(k) {
      k && le(e), Gt(t), u && u.d(), f.d(), b[l].d();
    }
  };
}
function x5(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function md(n, e, t) {
  var r = this && this.__awaiter || function(X, Ve, Qe, s0) {
    function Re(B0) {
      return B0 instanceof Qe ? B0 : new Qe(function(Ie) {
        Ie(B0);
      });
    }
    return new (Qe || (Qe = Promise))(function(B0, Ie) {
      function H(_e) {
        try {
          oe(s0.next(_e));
        } catch (Ue) {
          Ie(Ue);
        }
      }
      function q(_e) {
        try {
          oe(s0.throw(_e));
        } catch (Ue) {
          Ie(Ue);
        }
      }
      function oe(_e) {
        _e.done ? B0(_e.value) : Re(_e.value).then(H, q);
      }
      oe((s0 = s0.apply(X, Ve || [])).next());
    });
  };
  let a, i, l = [], o = [], s = null, u = null, c = null, { time_limit: d = null } = e, f = "closed", { on_change_cb: p } = e, { mode: b } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: E = {} } = e, { icon: k = void 0 } = e, { icon_button_color: w = "var(--color-accent)" } = e, { pulse_color: _ = "var(--color-accent)" } = e, { button_labels: v } = e;
  const A = (X) => {
    X === "closed" ? (t(14, c = null), t(15, f = "closed")) : X === "waiting" ? t(15, f = "waiting") : t(15, f = "open");
  };
  let { track_constraints: x = null } = e, { rtc_configuration: Q } = e, { stream_every: B = 1 } = e, { server: O } = e, { include_audio: M } = e, { show_local_video: I } = e, { i18n: V } = e, re = !1, W = !1, ae = !1;
  const Ee = () => {
    t(16, re = !re);
  }, xe = () => {
    t(17, W = !W), $.getTracks().forEach((X) => {
      X.kind.includes("audio") && (X.enabled = !W);
    });
  }, qe = () => {
    t(18, ae = !ae), $.getTracks().forEach((X) => {
      X.kind.includes("video") && (X.enabled = !ae);
    });
  }, ce = Wf();
  Zf(() => document.createElement("canvas"));
  const pe = (X) => r(void 0, void 0, void 0, function* () {
    const Qe = X.target.value;
    let s0, Re;
    M && o.find((Ie) => Ie.deviceId === Qe) ? Re = Qe : s0 = Qe, yield qa(
      Re ? { deviceId: { exact: Re } } : M,
      I ? a : i,
      s0,
      x
    ).then((Ie) => r(void 0, void 0, void 0, function* () {
      $ = Ie, t(12, s = l.find((H) => H.deviceId === s0) || null), t(13, u = M && o.find((H) => H.deviceId === Re) || null), t(21, he = !1);
    }));
  });
  function Ce() {
    return r(this, void 0, void 0, function* () {
      try {
        const X = I ? a : i;
        t(17, W = !1), t(18, ae = !1), t(16, re = !1), qa(M, X, null, x).then((Ve) => r(this, void 0, void 0, function* () {
          t(19, Te = !0);
          let Qe = yield F5();
          return $ = Ve, Qe;
        })).then((Ve) => {
          t(10, l = D1(Ve, "videoinput")), t(11, o = D1(Ve, "audioinput")), $.getTracks().map((s0) => {
            var Re;
            return (Re = s0.getSettings()) === null || Re === void 0 ? void 0 : Re.deviceId;
          }).forEach((s0) => {
            const Re = Ve.find((B0) => B0.deviceId === s0);
            Re && (Re != null && Re.kind.includes("video")) ? t(12, s = Re) : Re && (Re != null && Re.kind.includes("audio")) && t(13, u = Re);
          }), !s && t(12, s = l[0]);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && ce("error", V("image.no_webcam_support"));
      } catch (X) {
        if (X instanceof DOMException && X.name == "NotAllowedError")
          ce("error", V("image.allow_webcam_access"));
        else
          throw X;
      }
    });
  }
  let $, Te = !1, se = !1, De, { webrtc_id: P } = e;
  function we() {
    return r(this, void 0, void 0, function* () {
      f === "closed" ? (De = new RTCPeerConnection(Q), De.addEventListener("connectionstatechange", (X) => r(this, void 0, void 0, function* () {
        switch (De.connectionState) {
          case "connected":
            t(15, f = "open"), t(14, c = d);
            break;
          case "disconnected":
            t(15, f = "closed"), t(14, c = null), Kr(De), yield Ce();
            break;
        }
      })), t(15, f = "waiting"), t(30, P = Math.random().toString(36).substring(2)), B1($, De, b === "send" ? null : i, O.offer, P, "video", p, E).then((X) => {
        De = X, t(20, se = !0);
      }).catch(() => {
        console.info("catching"), t(15, f = "closed"), t(20, se = !1), ce("error", "Too many concurrent users. Come back later!");
      })) : (Kr(De), t(15, f = "closed"), t(20, se = !1), t(14, c = null), yield Ce());
    });
  }
  let he = !1;
  function Ke(X) {
    X.preventDefault(), X.stopPropagation(), t(21, he = !1);
  }
  const J = () => i.srcObject;
  function Ae(X) {
    dl[X ? "unshift" : "push"](() => {
      a = X, t(8, a);
    });
  }
  function ge(X) {
    dl[X ? "unshift" : "push"](() => {
      i = X, t(9, i);
    });
  }
  function Oe(X) {
    dl[X ? "unshift" : "push"](() => {
      i = X, t(9, i);
    });
  }
  const Le = async () => Ce(), je = () => t(21, he = !0), Ge = () => t(21, he = !1), e0 = () => t(21, he = !1);
  return n.$$set = (X) => {
    "time_limit" in X && t(31, d = X.time_limit), "on_change_cb" in X && t(32, p = X.on_change_cb), "mode" in X && t(33, b = X.mode), "rtp_params" in X && t(34, E = X.rtp_params), "icon" in X && t(0, k = X.icon), "icon_button_color" in X && t(1, w = X.icon_button_color), "pulse_color" in X && t(2, _ = X.pulse_color), "button_labels" in X && t(3, v = X.button_labels), "track_constraints" in X && t(36, x = X.track_constraints), "rtc_configuration" in X && t(37, Q = X.rtc_configuration), "stream_every" in X && t(38, B = X.stream_every), "server" in X && t(39, O = X.server), "include_audio" in X && t(4, M = X.include_audio), "show_local_video" in X && t(5, I = X.show_local_video), "i18n" in X && t(6, V = X.i18n), "webrtc_id" in X && t(30, P = X.webrtc_id);
  }, [
    k,
    w,
    _,
    v,
    M,
    I,
    V,
    x5,
    a,
    i,
    l,
    o,
    s,
    u,
    c,
    f,
    re,
    W,
    ae,
    Te,
    se,
    he,
    Ee,
    xe,
    qe,
    pe,
    Ce,
    we,
    Ke,
    J,
    P,
    d,
    p,
    b,
    E,
    A,
    x,
    Q,
    B,
    O,
    Ae,
    ge,
    Oe,
    Le,
    je,
    Ge,
    e0
  ];
}
class pd extends Of {
  constructor(e) {
    super(), Uf(
      this,
      e,
      md,
      dd,
      jf,
      {
        time_limit: 31,
        on_change_cb: 32,
        mode: 33,
        rtp_params: 34,
        icon: 0,
        icon_button_color: 1,
        pulse_color: 2,
        button_labels: 3,
        modify_stream: 35,
        track_constraints: 36,
        rtc_configuration: 37,
        stream_every: 38,
        server: 39,
        include_audio: 4,
        show_local_video: 5,
        i18n: 6,
        webrtc_id: 30,
        click_outside: 7
      },
      null,
      [-1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[35];
  }
  get click_outside() {
    return x5;
  }
}
const {
  SvelteComponent: gd,
  add_flush_callback: _d,
  attr: F2,
  bind: vd,
  binding_callbacks: bd,
  bubble: ba,
  children: wd,
  claim_component: S2,
  claim_element: yd,
  claim_space: kd,
  create_component: x2,
  destroy_component: C2,
  detach: ml,
  element: Dd,
  init: Ed,
  insert_hydration: T2,
  mount_component: Q2,
  safe_not_equal: Ad,
  space: Fd,
  transition_in: M2,
  transition_out: B2
} = window.__gradio__svelte__internal, { createEventDispatcher: Sd } = window.__gradio__svelte__internal;
function xd(n) {
  let e, t, r, a, i, l;
  e = new ri({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: Kl,
      label: (
        /*label*/
        n[1] || "Video"
      )
    }
  });
  function o(u) {
    n[20](u);
  }
  let s = {
    rtc_configuration: (
      /*rtc_configuration*/
      n[9]
    ),
    include_audio: (
      /*include_audio*/
      n[3]
    ),
    show_local_video: (
      /*show_local_video*/
      n[4]
    ),
    time_limit: (
      /*time_limit*/
      n[6]
    ),
    track_constraints: (
      /*track_constraints*/
      n[10]
    ),
    mode: (
      /*mode*/
      n[11]
    ),
    rtp_params: (
      /*rtp_params*/
      n[13]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[12]
    ),
    icon: (
      /*icon*/
      n[14]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[15]
    ),
    pulse_color: (
      /*pulse_color*/
      n[16]
    ),
    button_labels: (
      /*button_labels*/
      n[7]
    ),
    i18n: (
      /*i18n*/
      n[5]
    ),
    stream_every: 0.5,
    server: (
      /*server*/
      n[8]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (s.webrtc_id = /*value*/
    n[0]), a = new pd({ props: s }), bd.push(() => vd(a, "webrtc_id", o)), a.$on(
      "error",
      /*error_handler*/
      n[21]
    ), a.$on(
      "start_recording",
      /*start_recording_handler*/
      n[22]
    ), a.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[23]
    ), a.$on(
      "tick",
      /*tick_handler*/
      n[24]
    ), {
      c() {
        x2(e.$$.fragment), t = Fd(), r = Dd("div"), x2(a.$$.fragment), this.h();
      },
      l(u) {
        S2(e.$$.fragment, u), t = kd(u), r = yd(u, "DIV", { "data-testid": !0, class: !0 });
        var c = wd(r);
        S2(a.$$.fragment, c), c.forEach(ml), this.h();
      },
      h() {
        F2(r, "data-testid", "video"), F2(r, "class", "video-container svelte-iln0va");
      },
      m(u, c) {
        Q2(e, u, c), T2(u, t, c), T2(u, r, c), Q2(a, r, null), l = !0;
      },
      p(u, [c]) {
        const d = {};
        c & /*show_label*/
        4 && (d.show_label = /*show_label*/
        u[2]), c & /*label*/
        2 && (d.label = /*label*/
        u[1] || "Video"), e.$set(d);
        const f = {};
        c & /*rtc_configuration*/
        512 && (f.rtc_configuration = /*rtc_configuration*/
        u[9]), c & /*include_audio*/
        8 && (f.include_audio = /*include_audio*/
        u[3]), c & /*show_local_video*/
        16 && (f.show_local_video = /*show_local_video*/
        u[4]), c & /*time_limit*/
        64 && (f.time_limit = /*time_limit*/
        u[6]), c & /*track_constraints*/
        1024 && (f.track_constraints = /*track_constraints*/
        u[10]), c & /*mode*/
        2048 && (f.mode = /*mode*/
        u[11]), c & /*rtp_params*/
        8192 && (f.rtp_params = /*rtp_params*/
        u[13]), c & /*on_change_cb*/
        4096 && (f.on_change_cb = /*on_change_cb*/
        u[12]), c & /*icon*/
        16384 && (f.icon = /*icon*/
        u[14]), c & /*icon_button_color*/
        32768 && (f.icon_button_color = /*icon_button_color*/
        u[15]), c & /*pulse_color*/
        65536 && (f.pulse_color = /*pulse_color*/
        u[16]), c & /*button_labels*/
        128 && (f.button_labels = /*button_labels*/
        u[7]), c & /*i18n*/
        32 && (f.i18n = /*i18n*/
        u[5]), c & /*server*/
        256 && (f.server = /*server*/
        u[8]), !i && c & /*value*/
        1 && (i = !0, f.webrtc_id = /*value*/
        u[0], _d(() => i = !1)), a.$set(f);
      },
      i(u) {
        l || (M2(e.$$.fragment, u), M2(a.$$.fragment, u), l = !0);
      },
      o(u) {
        B2(e.$$.fragment, u), B2(a.$$.fragment, u), l = !1;
      },
      d(u) {
        u && (ml(t), ml(r)), C2(e, u), C2(a);
      }
    }
  );
}
let Cd = !1;
function Td(n, e, t) {
  let { value: r = null } = e, { label: a = void 0 } = e, { show_label: i = !0 } = e, { include_audio: l } = e, { show_local_video: o } = e, { i18n: s } = e, { active_source: u = "webcam" } = e, { handle_reset_value: c = () => {
  } } = e, { stream_handler: d } = e, { time_limit: f = null } = e, { button_labels: p } = e, { server: b } = e, { rtc_configuration: E } = e, { track_constraints: k = {} } = e, { mode: w } = e, { on_change_cb: _ } = e, { rtp_params: v = {} } = e, { icon: A = void 0 } = e, { icon_button_color: x = "var(--color-accent)" } = e, { pulse_color: Q = "var(--color-accent)" } = e;
  const B = Sd();
  function O(W) {
    r = W, t(0, r);
  }
  function M(W) {
    ba.call(this, n, W);
  }
  function I(W) {
    ba.call(this, n, W);
  }
  function V(W) {
    ba.call(this, n, W);
  }
  function re(W) {
    ba.call(this, n, W);
  }
  return n.$$set = (W) => {
    "value" in W && t(0, r = W.value), "label" in W && t(1, a = W.label), "show_label" in W && t(2, i = W.show_label), "include_audio" in W && t(3, l = W.include_audio), "show_local_video" in W && t(4, o = W.show_local_video), "i18n" in W && t(5, s = W.i18n), "active_source" in W && t(17, u = W.active_source), "handle_reset_value" in W && t(18, c = W.handle_reset_value), "stream_handler" in W && t(19, d = W.stream_handler), "time_limit" in W && t(6, f = W.time_limit), "button_labels" in W && t(7, p = W.button_labels), "server" in W && t(8, b = W.server), "rtc_configuration" in W && t(9, E = W.rtc_configuration), "track_constraints" in W && t(10, k = W.track_constraints), "mode" in W && t(11, w = W.mode), "on_change_cb" in W && t(12, _ = W.on_change_cb), "rtp_params" in W && t(13, v = W.rtp_params), "icon" in W && t(14, A = W.icon), "icon_button_color" in W && t(15, x = W.icon_button_color), "pulse_color" in W && t(16, Q = W.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && console.log("value", r);
  }, B("drag", Cd), [
    r,
    a,
    i,
    l,
    o,
    s,
    f,
    p,
    b,
    E,
    k,
    w,
    _,
    v,
    A,
    x,
    Q,
    u,
    c,
    d,
    O,
    M,
    I,
    V,
    re
  ];
}
class Qd extends gd {
  constructor(e) {
    super(), Ed(this, e, Td, xd, Ad, {
      value: 0,
      label: 1,
      show_label: 2,
      include_audio: 3,
      show_local_video: 4,
      i18n: 5,
      active_source: 17,
      handle_reset_value: 18,
      stream_handler: 19,
      time_limit: 6,
      button_labels: 7,
      server: 8,
      rtc_configuration: 9,
      track_constraints: 10,
      mode: 11,
      on_change_cb: 12,
      rtp_params: 13,
      icon: 14,
      icon_button_color: 15,
      pulse_color: 16
    });
  }
}
var z2;
(function(n) {
  n.LOAD = "LOAD", n.EXEC = "EXEC", n.WRITE_FILE = "WRITE_FILE", n.READ_FILE = "READ_FILE", n.DELETE_FILE = "DELETE_FILE", n.RENAME = "RENAME", n.CREATE_DIR = "CREATE_DIR", n.LIST_DIR = "LIST_DIR", n.DELETE_DIR = "DELETE_DIR", n.ERROR = "ERROR", n.DOWNLOAD = "DOWNLOAD", n.PROGRESS = "PROGRESS", n.LOG = "LOG", n.MOUNT = "MOUNT", n.UNMOUNT = "UNMOUNT";
})(z2 || (z2 = {}));
const jp = (n) => {
  let e = ["B", "KB", "MB", "GB", "PB"], t = 0;
  for (; n > 1024; )
    n /= 1024, t++;
  let r = e[t];
  return n.toFixed(1) + " " + r;
}, Gp = () => !0;
function Wp(n, { autoplay: e }) {
  async function t() {
    e && await n.play();
  }
  return n.addEventListener("loadeddata", t), {
    destroy() {
      n.removeEventListener("loadeddata", t);
    }
  };
}
const {
  SvelteComponent: Md,
  append_hydration: Bd,
  attr: pl,
  binding_callbacks: zd,
  children: L2,
  claim_element: I2,
  claim_text: Zp,
  detach: d1,
  element: N2,
  empty: Ua,
  init: Ld,
  insert_hydration: C5,
  is_function: R2,
  listen: gl,
  noop: q2,
  run_all: Id,
  safe_not_equal: Nd,
  set_data: Yp,
  src_url_equal: O2,
  text: Xp,
  toggle_class: Sn
} = window.__gradio__svelte__internal;
function P2(n) {
  let e;
  function t(i, l) {
    return Rd;
  }
  let a = t()(n);
  return {
    c() {
      a.c(), e = Ua();
    },
    l(i) {
      a.l(i), e = Ua();
    },
    m(i, l) {
      a.m(i, l), C5(i, e, l);
    },
    p(i, l) {
      a.p(i, l);
    },
    d(i) {
      i && d1(e), a.d(i);
    }
  };
}
function Rd(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = N2("div"), t = N2("video"), this.h();
    },
    l(l) {
      e = I2(l, "DIV", { class: !0 });
      var o = L2(e);
      t = I2(o, "VIDEO", { src: !0 }), L2(t).forEach(d1), o.forEach(d1), this.h();
    },
    h() {
      var l;
      O2(t.src, r = /*value*/
      (l = n[2]) == null ? void 0 : l.video.url) || pl(t, "src", r), pl(e, "class", "container svelte-13u05e4"), Sn(
        e,
        "table",
        /*type*/
        n[0] === "table"
      ), Sn(
        e,
        "gallery",
        /*type*/
        n[0] === "gallery"
      ), Sn(
        e,
        "selected",
        /*selected*/
        n[1]
      );
    },
    m(l, o) {
      C5(l, e, o), Bd(e, t), n[6](t), a || (i = [
        gl(
          t,
          "loadeddata",
          /*init*/
          n[4]
        ),
        gl(t, "mouseover", function() {
          R2(
            /*video*/
            n[3].play.bind(
              /*video*/
              n[3]
            )
          ) && n[3].play.bind(
            /*video*/
            n[3]
          ).apply(this, arguments);
        }),
        gl(t, "mouseout", function() {
          R2(
            /*video*/
            n[3].pause.bind(
              /*video*/
              n[3]
            )
          ) && n[3].pause.bind(
            /*video*/
            n[3]
          ).apply(this, arguments);
        })
      ], a = !0);
    },
    p(l, o) {
      var s;
      n = l, o & /*value*/
      4 && !O2(t.src, r = /*value*/
      (s = n[2]) == null ? void 0 : s.video.url) && pl(t, "src", r), o & /*type*/
      1 && Sn(
        e,
        "table",
        /*type*/
        n[0] === "table"
      ), o & /*type*/
      1 && Sn(
        e,
        "gallery",
        /*type*/
        n[0] === "gallery"
      ), o & /*selected*/
      2 && Sn(
        e,
        "selected",
        /*selected*/
        n[1]
      );
    },
    d(l) {
      l && d1(e), n[6](null), a = !1, Id(i);
    }
  };
}
function qd(n) {
  let e, t = (
    /*value*/
    n[2] && P2(n)
  );
  return {
    c() {
      t && t.c(), e = Ua();
    },
    l(r) {
      t && t.l(r), e = Ua();
    },
    m(r, a) {
      t && t.m(r, a), C5(r, e, a);
    },
    p(r, [a]) {
      /*value*/
      r[2] ? t ? t.p(r, a) : (t = P2(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    i: q2,
    o: q2,
    d(r) {
      r && d1(e), t && t.d(r);
    }
  };
}
function Od(n, e, t) {
  var r = this && this.__awaiter || function(d, f, p, b) {
    function E(k) {
      return k instanceof p ? k : new p(function(w) {
        w(k);
      });
    }
    return new (p || (p = Promise))(function(k, w) {
      function _(x) {
        try {
          A(b.next(x));
        } catch (Q) {
          w(Q);
        }
      }
      function v(x) {
        try {
          A(b.throw(x));
        } catch (Q) {
          w(Q);
        }
      }
      function A(x) {
        x.done ? k(x.value) : E(x.value).then(_, v);
      }
      A((b = b.apply(d, f || [])).next());
    });
  };
  let { type: a } = e, { selected: i = !1 } = e, { value: l } = e, { loop: o } = e, s;
  function u() {
    return r(this, void 0, void 0, function* () {
      t(3, s.muted = !0, s), t(3, s.playsInline = !0, s), t(3, s.controls = !1, s), s.setAttribute("muted", ""), yield s.play(), s.pause();
    });
  }
  function c(d) {
    zd[d ? "unshift" : "push"](() => {
      s = d, t(3, s);
    });
  }
  return n.$$set = (d) => {
    "type" in d && t(0, a = d.type), "selected" in d && t(1, i = d.selected), "value" in d && t(2, l = d.value), "loop" in d && t(5, o = d.loop);
  }, [a, i, l, s, u, o, c];
}
class Kp extends Md {
  constructor(e) {
    super(), Ld(this, e, Od, qd, Nd, { type: 0, selected: 1, value: 2, loop: 5 });
  }
}
const {
  SvelteComponent: Pd,
  append_hydration: H2,
  assign: V2,
  attr: xn,
  binding_callbacks: Hd,
  bubble: Vd,
  check_outros: Ud,
  children: U2,
  claim_component: T5,
  claim_element: _l,
  claim_space: j2,
  create_component: Q5,
  destroy_component: M5,
  detach: n1,
  element: vl,
  exclude_internal_props: G2,
  group_outros: jd,
  init: Gd,
  insert_hydration: bl,
  listen: Jt,
  mount_component: B5,
  run_all: Wd,
  safe_not_equal: Zd,
  space: W2,
  toggle_class: Z2,
  transition_in: Qn,
  transition_out: m1
} = window.__gradio__svelte__internal, { createEventDispatcher: Yd, onMount: Xd } = window.__gradio__svelte__internal;
function Y2(n) {
  let e, t;
  return e = new Z6({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [Kd] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Q5(e.$$.fragment);
    },
    l(r) {
      T5(e.$$.fragment, r);
    },
    m(r, a) {
      B5(e, r, a), t = !0;
    },
    i(r) {
      t || (Qn(e.$$.fragment, r), t = !0);
    },
    o(r) {
      m1(e.$$.fragment, r), t = !1;
    },
    d(r) {
      M5(e, r);
    }
  };
}
function Kd(n) {
  let e, t;
  return e = new Kl({}), {
    c() {
      Q5(e.$$.fragment);
    },
    l(r) {
      T5(e.$$.fragment, r);
    },
    m(r, a) {
      B5(e, r, a), t = !0;
    },
    i(r) {
      t || (Qn(e.$$.fragment, r), t = !0);
    },
    o(r) {
      m1(e.$$.fragment, r), t = !1;
    },
    d(r) {
      M5(e, r);
    }
  };
}
function Jd(n) {
  let e, t, r, a, i, l, o, s, u, c;
  e = new ri({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: Kl,
      label: (
        /*label*/
        n[1] || "Video"
      )
    }
  });
  let d = (
    /*value*/
    n[0] === "__webrtc_value__" && Y2(n)
  );
  return {
    c() {
      Q5(e.$$.fragment), t = W2(), d && d.c(), r = W2(), a = vl("div"), i = vl("video"), l = vl("track"), this.h();
    },
    l(f) {
      T5(e.$$.fragment, f), t = j2(f), d && d.l(f), r = j2(f), a = _l(f, "DIV", { class: !0 });
      var p = U2(a);
      i = _l(p, "VIDEO", {
        "data-testid": !0,
        crossorigin: !0,
        class: !0
      });
      var b = U2(i);
      l = _l(b, "TRACK", { kind: !0 }), b.forEach(n1), p.forEach(n1), this.h();
    },
    h() {
      xn(l, "kind", "captions"), i.autoplay = !0, xn(i, "data-testid", o = /*$$props*/
      n[5]["data-testid"]), xn(i, "crossorigin", "anonymous"), xn(i, "class", "svelte-1xabgau"), Z2(
        i,
        "hidden",
        /*value*/
        n[0] === "__webrtc_value__"
      ), xn(a, "class", "wrap svelte-1xabgau");
    },
    m(f, p) {
      B5(e, f, p), bl(f, t, p), d && d.m(f, p), bl(f, r, p), bl(f, a, p), H2(a, i), H2(i, l), n[12](i), s = !0, u || (c = [
        Jt(
          i,
          "loadeddata",
          /*dispatch*/
          n[4].bind(null, "loadeddata")
        ),
        Jt(
          i,
          "click",
          /*dispatch*/
          n[4].bind(null, "click")
        ),
        Jt(
          i,
          "play",
          /*dispatch*/
          n[4].bind(null, "play")
        ),
        Jt(
          i,
          "pause",
          /*dispatch*/
          n[4].bind(null, "pause")
        ),
        Jt(
          i,
          "ended",
          /*dispatch*/
          n[4].bind(null, "ended")
        ),
        Jt(
          i,
          "mouseover",
          /*dispatch*/
          n[4].bind(null, "mouseover")
        ),
        Jt(
          i,
          "mouseout",
          /*dispatch*/
          n[4].bind(null, "mouseout")
        ),
        Jt(
          i,
          "focus",
          /*dispatch*/
          n[4].bind(null, "focus")
        ),
        Jt(
          i,
          "blur",
          /*dispatch*/
          n[4].bind(null, "blur")
        ),
        Jt(
          i,
          "load",
          /*load_handler*/
          n[11]
        )
      ], u = !0);
    },
    p(f, [p]) {
      const b = {};
      p & /*show_label*/
      4 && (b.show_label = /*show_label*/
      f[2]), p & /*label*/
      2 && (b.label = /*label*/
      f[1] || "Video"), e.$set(b), /*value*/
      f[0] === "__webrtc_value__" ? d ? p & /*value*/
      1 && Qn(d, 1) : (d = Y2(f), d.c(), Qn(d, 1), d.m(r.parentNode, r)) : d && (jd(), m1(d, 1, 1, () => {
        d = null;
      }), Ud()), (!s || p & /*$$props*/
      32 && o !== (o = /*$$props*/
      f[5]["data-testid"])) && xn(i, "data-testid", o), (!s || p & /*value*/
      1) && Z2(
        i,
        "hidden",
        /*value*/
        f[0] === "__webrtc_value__"
      );
    },
    i(f) {
      s || (Qn(e.$$.fragment, f), Qn(d), s = !0);
    },
    o(f) {
      m1(e.$$.fragment, f), m1(d), s = !1;
    },
    d(f) {
      f && (n1(t), n1(r), n1(a)), M5(e, f), d && d.d(f), n[12](null), u = !1, Wd(c);
    }
  };
}
function $d(n, e, t) {
  var r = this && this.__awaiter || function(w, _, v, A) {
    function x(Q) {
      return Q instanceof v ? Q : new v(function(B) {
        B(Q);
      });
    }
    return new (v || (v = Promise))(function(Q, B) {
      function O(V) {
        try {
          I(A.next(V));
        } catch (re) {
          B(re);
        }
      }
      function M(V) {
        try {
          I(A.throw(V));
        } catch (re) {
          B(re);
        }
      }
      function I(V) {
        V.done ? Q(V.value) : x(V.value).then(O, M);
      }
      I((A = A.apply(w, _ || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { on_change_cb: s } = e, { server: u } = e, c, d = Math.random().toString(36).substring(2), f;
  const p = Yd();
  let b = "closed";
  Xd(() => {
    window.setInterval(
      () => {
        b == "open" && p("tick");
      },
      1e3
    );
  });
  function E(w) {
    Vd.call(this, n, w);
  }
  function k(w) {
    Hd[w ? "unshift" : "push"](() => {
      c = w, t(3, c);
    });
  }
  return n.$$set = (w) => {
    t(5, e = V2(V2({}, e), G2(w))), "value" in w && t(0, a = w.value), "label" in w && t(1, i = w.label), "show_label" in w && t(2, l = w.show_label), "rtc_configuration" in w && t(6, o = w.rtc_configuration), "on_change_cb" in w && t(7, s = w.on_change_cb), "server" in w && t(8, u = w.server);
  }, n.$$.update = () => {
    n.$$.dirty & /*value, _webrtc_id, rtc_configuration, pc, video_element, server, on_change_cb*/
    1993 && a === "start_webrtc_stream" && (t(9, d = Math.random().toString(36).substring(2)), t(0, a = d), t(10, f = new RTCPeerConnection(o)), f.addEventListener("connectionstatechange", (w) => r(void 0, void 0, void 0, function* () {
      switch (f.connectionState) {
        case "connected":
          console.log("connected"), b = "open";
          break;
        case "disconnected":
          console.log("closed"), Kr(f);
          break;
      }
    })), B1(null, f, c, u.offer, d, "video", s).then((w) => {
      t(10, f = w);
    }).catch(() => {
      console.log("catching"), p("error", "Too many concurrent users. Come back later!");
    }));
  }, e = G2(e), [
    a,
    i,
    l,
    c,
    p,
    e,
    o,
    s,
    u,
    d,
    f,
    E,
    k
  ];
}
class em extends Pd {
  constructor(e) {
    super(), Gd(this, e, $d, Jd, Zd, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 6,
      on_change_cb: 7,
      server: 8
    });
  }
}
const {
  SvelteComponent: tm,
  append_hydration: rm,
  attr: E1,
  check_outros: nm,
  children: A1,
  claim_component: am,
  claim_element: F1,
  create_component: im,
  destroy_component: lm,
  destroy_each: sm,
  detach: kr,
  element: S1,
  ensure_array_like: X2,
  group_outros: om,
  init: um,
  insert_hydration: ii,
  mount_component: cm,
  noop: Ul,
  safe_not_equal: hm,
  set_style: p1,
  transition_in: jl,
  transition_out: Gl
} = window.__gradio__svelte__internal, { onDestroy: fm } = window.__gradio__svelte__internal;
function K2(n, e, t) {
  const r = n.slice();
  return r[14] = e[t], r;
}
function dm(n) {
  let e, t = X2(Array(
    /*numBars*/
    n[0]
  )), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = J2(K2(n, t, a));
  return {
    c() {
      e = S1("div");
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      this.h();
    },
    l(a) {
      e = F1(a, "DIV", { class: !0 });
      var i = A1(e);
      for (let l = 0; l < r.length; l += 1)
        r[l].l(i);
      i.forEach(kr), this.h();
    },
    h() {
      E1(e, "class", "gradio-webrtc-boxContainer svelte-18c3b6q"), p1(
        e,
        "width",
        /*containerWidth*/
        n[6]
      );
    },
    m(a, i) {
      ii(a, e, i);
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(e, null);
    },
    p(a, i) {
      if (i & /*numBars*/
      1) {
        t = X2(Array(
          /*numBars*/
          a[0]
        ));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = K2(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = J2(), r[l].c(), r[l].m(e, null));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
      i & /*containerWidth*/
      64 && p1(
        e,
        "width",
        /*containerWidth*/
        a[6]
      );
    },
    i: Ul,
    o: Ul,
    d(a) {
      a && kr(e), sm(r, a);
    }
  };
}
function mm(n) {
  let e, t, r, a;
  return r = new t3({
    props: {
      stream_state: (
        /*stream_state*/
        n[1]
      ),
      pulse_color: (
        /*pulse_color*/
        n[5]
      ),
      icon: (
        /*icon*/
        n[3]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[4]
      ),
      audio_source_callback: (
        /*audio_source_callback*/
        n[2]
      )
    }
  }), {
    c() {
      e = S1("div"), t = S1("div"), im(r.$$.fragment), this.h();
    },
    l(i) {
      e = F1(i, "DIV", { class: !0 });
      var l = A1(e);
      t = F1(l, "DIV", { class: !0 });
      var o = A1(t);
      am(r.$$.fragment, o), o.forEach(kr), l.forEach(kr), this.h();
    },
    h() {
      E1(t, "class", "gradio-webrtc-icon svelte-18c3b6q"), p1(t, "transform", `scale(${gm})`), p1(
        t,
        "background",
        /*icon_button_color*/
        n[4]
      ), E1(e, "class", "gradio-webrtc-icon-container svelte-18c3b6q");
    },
    m(i, l) {
      ii(i, e, l), rm(e, t), cm(r, t, null), a = !0;
    },
    p(i, l) {
      const o = {};
      l & /*stream_state*/
      2 && (o.stream_state = /*stream_state*/
      i[1]), l & /*pulse_color*/
      32 && (o.pulse_color = /*pulse_color*/
      i[5]), l & /*icon*/
      8 && (o.icon = /*icon*/
      i[3]), l & /*icon_button_color*/
      16 && (o.icon_button_color = /*icon_button_color*/
      i[4]), l & /*audio_source_callback*/
      4 && (o.audio_source_callback = /*audio_source_callback*/
      i[2]), r.$set(o), l & /*icon_button_color*/
      16 && p1(
        t,
        "background",
        /*icon_button_color*/
        i[4]
      );
    },
    i(i) {
      a || (jl(r.$$.fragment, i), a = !0);
    },
    o(i) {
      Gl(r.$$.fragment, i), a = !1;
    },
    d(i) {
      i && kr(e), lm(r);
    }
  };
}
function J2(n) {
  let e;
  return {
    c() {
      e = S1("div"), this.h();
    },
    l(t) {
      e = F1(t, "DIV", { class: !0 }), A1(e).forEach(kr), this.h();
    },
    h() {
      E1(e, "class", "gradio-webrtc-box svelte-18c3b6q");
    },
    m(t, r) {
      ii(t, e, r);
    },
    p: Ul,
    d(t) {
      t && kr(e);
    }
  };
}
function pm(n) {
  let e, t, r, a;
  const i = [mm, dm], l = [];
  function o(s, u) {
    return (
      /*icon*/
      s[3] ? 0 : 1
    );
  }
  return t = o(n), r = l[t] = i[t](n), {
    c() {
      e = S1("div"), r.c(), this.h();
    },
    l(s) {
      e = F1(s, "DIV", { class: !0 });
      var u = A1(e);
      r.l(u), u.forEach(kr), this.h();
    },
    h() {
      E1(e, "class", "gradio-webrtc-waveContainer svelte-18c3b6q");
    },
    m(s, u) {
      ii(s, e, u), l[t].m(e, null), a = !0;
    },
    p(s, [u]) {
      let c = t;
      t = o(s), t === c ? l[t].p(s, u) : (om(), Gl(l[c], 1, 1, () => {
        l[c] = null;
      }), nm(), r = l[t], r ? r.p(s, u) : (r = l[t] = i[t](s), r.c()), jl(r, 1), r.m(e, null));
    },
    i(s) {
      a || (jl(r), a = !0);
    },
    o(s) {
      Gl(r), a = !1;
    },
    d(s) {
      s && kr(e), l[t].d();
    }
  };
}
let gm = 1;
function _m(n) {
  const e = [0, 2, 4, 6, 8, 10, 12, 14, 15, 13, 11, 9, 7, 5, 3, 1];
  if (n < 0 || n >= e.length)
    throw new Error("Index must be between 0 and 15");
  return e[n];
}
function vm(n, e, t) {
  let r, { numBars: a = 16 } = e, { stream_state: i = "closed" } = e, { audio_source_callback: l } = e, { icon: o = void 0 } = e, { icon_button_color: s = "var(--color-accent)" } = e, { pulse_color: u = "var(--color-accent)" } = e, { wave_color: c = "var(--color-accent)" } = e, d, f, p, b;
  fm(() => {
    b && cancelAnimationFrame(b), d && d.close();
  });
  function E() {
    d = new (window.AudioContext || window.webkitAudioContext)(), f = d.createAnalyser(), d.createMediaStreamSource(l()).connect(f), f.fftSize = 64, f.smoothingTimeConstant = 0.8, p = new Uint8Array(f.frequencyBinCount), k();
  }
  function k() {
    f.getByteFrequencyData(p);
    const w = document.querySelectorAll(".gradio-webrtc-waveContainer .gradio-webrtc-box");
    for (let _ = 0; _ < w.length; _++) {
      const v = p[_m(_)] / 255;
      w[_].style.transform = `scaleY(${Math.max(0.1, v)})`, w[_].style.background = c, w[_].style.opacity = 0.5;
    }
    b = requestAnimationFrame(k);
  }
  return n.$$set = (w) => {
    "numBars" in w && t(0, a = w.numBars), "stream_state" in w && t(1, i = w.stream_state), "audio_source_callback" in w && t(2, l = w.audio_source_callback), "icon" in w && t(3, o = w.icon), "icon_button_color" in w && t(4, s = w.icon_button_color), "pulse_color" in w && t(5, u = w.pulse_color), "wave_color" in w && t(7, c = w.wave_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*icon, numBars*/
    9 && t(6, r = o ? "128px" : `calc((var(--boxSize) + var(--gutter)) * ${a})`), n.$$.dirty & /*stream_state*/
    2 && i === "open" && E();
  }, [
    a,
    i,
    l,
    o,
    s,
    u,
    r,
    c
  ];
}
class z5 extends tm {
  constructor(e) {
    super(), um(this, e, vm, pm, hm, {
      numBars: 0,
      stream_state: 1,
      audio_source_callback: 2,
      icon: 3,
      icon_button_color: 4,
      pulse_color: 5,
      wave_color: 7
    });
  }
}
const {
  SvelteComponent: bm,
  attr: i3,
  binding_callbacks: wm,
  bubble: ym,
  check_outros: $2,
  children: l3,
  claim_component: li,
  claim_element: s3,
  claim_space: wl,
  create_component: si,
  destroy_component: oi,
  detach: Ur,
  element: o3,
  empty: e4,
  group_outros: t4,
  init: km,
  insert_hydration: Cn,
  listen: yl,
  mount_component: ui,
  run_all: Dm,
  safe_not_equal: Em,
  space: kl,
  toggle_class: Am,
  transition_in: $t,
  transition_out: jr
} = window.__gradio__svelte__internal, { createEventDispatcher: Fm } = window.__gradio__svelte__internal, { onMount: Sm } = window.__gradio__svelte__internal;
function r4(n) {
  let e, t, r;
  return t = new z5({
    props: {
      audio_source_callback: (
        /*func*/
        n[17]
      ),
      stream_state: (
        /*stream_state*/
        n[7]
      ),
      icon: (
        /*icon*/
        n[4]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[5]
      ),
      pulse_color: (
        /*pulse_color*/
        n[6]
      )
    }
  }), {
    c() {
      e = o3("div"), si(t.$$.fragment), this.h();
    },
    l(a) {
      e = s3(a, "DIV", { class: !0 });
      var i = l3(e);
      li(t.$$.fragment, i), i.forEach(Ur), this.h();
    },
    h() {
      i3(e, "class", "audio-container svelte-v2iok3");
    },
    m(a, i) {
      Cn(a, e, i), ui(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i & /*audio_player*/
      256 && (l.audio_source_callback = /*func*/
      a[17]), i & /*stream_state*/
      128 && (l.stream_state = /*stream_state*/
      a[7]), i & /*icon*/
      16 && (l.icon = /*icon*/
      a[4]), i & /*icon_button_color*/
      32 && (l.icon_button_color = /*icon_button_color*/
      a[5]), i & /*pulse_color*/
      64 && (l.pulse_color = /*pulse_color*/
      a[6]), t.$set(l);
    },
    i(a) {
      r || ($t(t.$$.fragment, a), r = !0);
    },
    o(a) {
      jr(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && Ur(e), oi(t);
    }
  };
}
function n4(n) {
  let e, t;
  return e = new Z6({
    props: {
      size: "small",
      $$slots: { default: [xm] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      si(e.$$.fragment);
    },
    l(r) {
      li(e.$$.fragment, r);
    },
    m(r, a) {
      ui(e, r, a), t = !0;
    },
    i(r) {
      t || ($t(e.$$.fragment, r), t = !0);
    },
    o(r) {
      jr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      oi(e, r);
    }
  };
}
function xm(n) {
  let e, t;
  return e = new Xl({}), {
    c() {
      si(e.$$.fragment);
    },
    l(r) {
      li(e.$$.fragment, r);
    },
    m(r, a) {
      ui(e, r, a), t = !0;
    },
    i(r) {
      t || ($t(e.$$.fragment, r), t = !0);
    },
    o(r) {
      jr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      oi(e, r);
    }
  };
}
function Cm(n) {
  let e, t, r, a, i, l, o, s, u;
  e = new ri({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: Xl,
      float: !1,
      label: (
        /*label*/
        n[1] || /*i18n*/
        n[3]("audio.audio")
      )
    }
  });
  let c = (
    /*value*/
    n[0] !== "__webrtc_value__" && r4(n)
  ), d = (
    /*value*/
    n[0] === "__webrtc_value__" && n4(n)
  );
  return {
    c() {
      si(e.$$.fragment), t = kl(), r = o3("audio"), a = kl(), c && c.c(), i = kl(), d && d.c(), l = e4(), this.h();
    },
    l(f) {
      li(e.$$.fragment, f), t = wl(f), r = s3(f, "AUDIO", { class: !0 }), l3(r).forEach(Ur), a = wl(f), c && c.l(f), i = wl(f), d && d.l(f), l = e4(), this.h();
    },
    h() {
      i3(r, "class", "standard-player svelte-v2iok3"), Am(r, "hidden", !0);
    },
    m(f, p) {
      ui(e, f, p), Cn(f, t, p), Cn(f, r, p), n[14](r), Cn(f, a, p), c && c.m(f, p), Cn(f, i, p), d && d.m(f, p), Cn(f, l, p), o = !0, s || (u = [
        yl(
          r,
          "load",
          /*load_handler*/
          n[13]
        ),
        yl(
          r,
          "ended",
          /*ended_handler*/
          n[15]
        ),
        yl(
          r,
          "play",
          /*play_handler*/
          n[16]
        )
      ], s = !0);
    },
    p(f, [p]) {
      const b = {};
      p & /*show_label*/
      4 && (b.show_label = /*show_label*/
      f[2]), p & /*label, i18n*/
      10 && (b.label = /*label*/
      f[1] || /*i18n*/
      f[3]("audio.audio")), e.$set(b), /*value*/
      f[0] !== "__webrtc_value__" ? c ? (c.p(f, p), p & /*value*/
      1 && $t(c, 1)) : (c = r4(f), c.c(), $t(c, 1), c.m(i.parentNode, i)) : c && (t4(), jr(c, 1, 1, () => {
        c = null;
      }), $2()), /*value*/
      f[0] === "__webrtc_value__" ? d ? p & /*value*/
      1 && $t(d, 1) : (d = n4(f), d.c(), $t(d, 1), d.m(l.parentNode, l)) : d && (t4(), jr(d, 1, 1, () => {
        d = null;
      }), $2());
    },
    i(f) {
      o || ($t(e.$$.fragment, f), $t(c), $t(d), o = !0);
    },
    o(f) {
      jr(e.$$.fragment, f), jr(c), jr(d), o = !1;
    },
    d(f) {
      f && (Ur(t), Ur(r), Ur(a), Ur(i), Ur(l)), oi(e, f), n[14](null), c && c.d(f), d && d.d(f), s = !1, Dm(u);
    }
  };
}
function Tm(n, e, t) {
  var r = this && this.__awaiter || function(M, I, V, re) {
    function W(ae) {
      return ae instanceof V ? ae : new V(function(Ee) {
        Ee(ae);
      });
    }
    return new (V || (V = Promise))(function(ae, Ee) {
      function xe(pe) {
        try {
          ce(re.next(pe));
        } catch (Ce) {
          Ee(Ce);
        }
      }
      function qe(pe) {
        try {
          ce(re.throw(pe));
        } catch (Ce) {
          Ee(Ce);
        }
      }
      function ce(pe) {
        pe.done ? ae(pe.value) : W(pe.value).then(xe, qe);
      }
      ce((re = re.apply(M, I || [])).next());
    });
  };
  let { value: a = null } = e, { label: i = void 0 } = e, { show_label: l = !0 } = e, { rtc_configuration: o = null } = e, { i18n: s } = e, { on_change_cb: u } = e, { icon: c = void 0 } = e, { icon_button_color: d = "var(--color-accent)" } = e, { pulse_color: f = "var(--color-accent)" } = e, { server: p } = e, b = "closed", E, k, w = Math.random().toString(36).substring(2);
  const _ = Fm();
  Sm(() => {
    window.setInterval(
      () => {
        b == "open" && _("tick");
      },
      1e3
    );
  });
  function v(M) {
    return r(this, void 0, void 0, function* () {
      return M === "start_webrtc_stream" && (t(7, b = "waiting"), w = Math.random().toString(36).substring(2), M = w, console.log("set value to ", M), k = new RTCPeerConnection(o), k.addEventListener("connectionstatechange", (V) => r(this, void 0, void 0, function* () {
        switch (k.connectionState) {
          case "connected":
            console.info("connected"), t(7, b = "open");
            break;
          case "disconnected":
            console.info("closed"), Kr(k);
            break;
        }
      })), B1(null, k, E, p.offer, w, "audio", u).then((V) => {
        k = V;
      }).catch(() => {
        console.info("catching"), _("error", "Too many concurrent users. Come back later!");
      })), M;
    });
  }
  function A(M) {
    ym.call(this, n, M);
  }
  function x(M) {
    wm[M ? "unshift" : "push"](() => {
      E = M, t(8, E);
    });
  }
  const Q = () => _("stop"), B = () => _("play"), O = () => E.srcObject;
  return n.$$set = (M) => {
    "value" in M && t(0, a = M.value), "label" in M && t(1, i = M.label), "show_label" in M && t(2, l = M.show_label), "rtc_configuration" in M && t(10, o = M.rtc_configuration), "i18n" in M && t(3, s = M.i18n), "on_change_cb" in M && t(11, u = M.on_change_cb), "icon" in M && t(4, c = M.icon), "icon_button_color" in M && t(5, d = M.icon_button_color), "pulse_color" in M && t(6, f = M.pulse_color), "server" in M && t(12, p = M.server);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && v(a).then((M) => {
      t(0, a = M);
    });
  }, [
    a,
    i,
    l,
    s,
    c,
    d,
    f,
    b,
    E,
    _,
    o,
    u,
    p,
    A,
    x,
    Q,
    B,
    O
  ];
}
class Qm extends bm {
  constructor(e) {
    super(), km(this, e, Tm, Cm, Em, {
      value: 0,
      label: 1,
      show_label: 2,
      rtc_configuration: 10,
      i18n: 3,
      on_change_cb: 11,
      icon: 4,
      icon_button_color: 5,
      pulse_color: 6,
      server: 12
    });
  }
}
const {
  SvelteComponent: Mm,
  action_destroyer: Bm,
  add_render_callback: zm,
  append_hydration: x0,
  attr: v0,
  binding_callbacks: Lm,
  bubble: Im,
  check_outros: Aa,
  children: Y0,
  claim_component: Er,
  claim_element: X0,
  claim_space: Pt,
  claim_text: L1,
  create_component: Ar,
  create_in_transition: Nm,
  destroy_component: Fr,
  destroy_each: Rm,
  detach: Xe,
  element: K0,
  empty: a4,
  ensure_array_like: i4,
  group_outros: Fa,
  init: qm,
  insert_hydration: st,
  listen: un,
  mount_component: Sr,
  noop: u3,
  run_all: c3,
  safe_not_equal: Om,
  set_data: I1,
  set_input_value: Wl,
  set_style: Pm,
  space: Ht,
  stop_propagation: Hm,
  text: N1,
  toggle_class: ja,
  transition_in: S0,
  transition_out: P0
} = window.__gradio__svelte__internal, { createEventDispatcher: Vm } = window.__gradio__svelte__internal, { onMount: Um } = window.__gradio__svelte__internal;
function l4(n, e, t) {
  const r = n.slice();
  return r[42] = e[t], r;
}
function jm(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p;
  e = new z5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        n[16]
      ),
      stream_state: (
        /*stream_state*/
        n[11]
      ),
      icon: (
        /*icon*/
        n[4]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[5]
      ),
      pulse_color: (
        /*pulse_color*/
        n[6]
      )
    }
  }), r = new G6({
    props: { time_limit: (
      /*_time_limit*/
      n[10]
    ) }
  });
  const b = [Ym, Zm, Wm], E = [];
  function k(v, A) {
    return (
      /*stream_state*/
      v[11] === "waiting" ? 0 : (
        /*stream_state*/
        v[11] === "open" ? 1 : 2
      )
    );
  }
  o = k(n), s = E[o] = b[o](n);
  let w = (
    /*stream_state*/
    n[11] === "closed" && s4(n)
  ), _ = (
    /*options_open*/
    n[9] && /*selected_device*/
    n[14] && o4(n)
  );
  return {
    c() {
      Ar(e.$$.fragment), t = Ht(), Ar(r.$$.fragment), a = Ht(), i = K0("div"), l = K0("button"), s.c(), u = Ht(), w && w.c(), c = Ht(), _ && _.c(), this.h();
    },
    l(v) {
      Er(e.$$.fragment, v), t = Pt(v), Er(r.$$.fragment, v), a = Pt(v), i = X0(v, "DIV", { class: !0 });
      var A = Y0(i);
      l = X0(A, "BUTTON", { "aria-label": !0, class: !0 });
      var x = Y0(l);
      s.l(x), x.forEach(Xe), u = Pt(A), w && w.l(A), c = Pt(A), _ && _.l(A), A.forEach(Xe), this.h();
    },
    h() {
      v0(l, "aria-label", "start stream"), v0(l, "class", "svelte-c1guob"), v0(i, "class", "button-wrap svelte-c1guob"), ja(
        i,
        "pulse",
        /*stopword_recognized*/
        n[8]
      );
    },
    m(v, A) {
      Sr(e, v, A), st(v, t, A), Sr(r, v, A), st(v, a, A), st(v, i, A), x0(i, l), E[o].m(l, null), x0(i, u), w && w.m(i, null), x0(i, c), _ && _.m(i, null), d = !0, f || (p = un(
        l,
        "click",
        /*start_stream*/
        n[19]
      ), f = !0);
    },
    p(v, A) {
      const x = {};
      A[0] & /*stream_state*/
      2048 && (x.stream_state = /*stream_state*/
      v[11]), A[0] & /*icon*/
      16 && (x.icon = /*icon*/
      v[4]), A[0] & /*icon_button_color*/
      32 && (x.icon_button_color = /*icon_button_color*/
      v[5]), A[0] & /*pulse_color*/
      64 && (x.pulse_color = /*pulse_color*/
      v[6]), e.$set(x);
      const Q = {};
      A[0] & /*_time_limit*/
      1024 && (Q.time_limit = /*_time_limit*/
      v[10]), r.$set(Q);
      let B = o;
      o = k(v), o === B ? E[o].p(v, A) : (Fa(), P0(E[B], 1, 1, () => {
        E[B] = null;
      }), Aa(), s = E[o], s ? s.p(v, A) : (s = E[o] = b[o](v), s.c()), S0(s, 1), s.m(l, null)), /*stream_state*/
      v[11] === "closed" ? w ? (w.p(v, A), A[0] & /*stream_state*/
      2048 && S0(w, 1)) : (w = s4(v), w.c(), S0(w, 1), w.m(i, c)) : w && (Fa(), P0(w, 1, 1, () => {
        w = null;
      }), Aa()), /*options_open*/
      v[9] && /*selected_device*/
      v[14] ? _ ? (_.p(v, A), A[0] & /*options_open, selected_device*/
      16896 && S0(_, 1)) : (_ = o4(v), _.c(), S0(_, 1), _.m(i, null)) : _ && (Fa(), P0(_, 1, 1, () => {
        _ = null;
      }), Aa()), (!d || A[0] & /*stopword_recognized*/
      256) && ja(
        i,
        "pulse",
        /*stopword_recognized*/
        v[8]
      );
    },
    i(v) {
      d || (S0(e.$$.fragment, v), S0(r.$$.fragment, v), S0(s), S0(w), S0(_), d = !0);
    },
    o(v) {
      P0(e.$$.fragment, v), P0(r.$$.fragment, v), P0(s), P0(w), P0(_), d = !1;
    },
    d(v) {
      v && (Xe(t), Xe(a), Xe(i)), Fr(e, v), Fr(r, v), E[o].d(), w && w.d(), _ && _.d(), f = !1, p();
    }
  };
}
function Gm(n) {
  let e, t, r, a;
  return t = new A5({ props: { icon: Al } }), t.$on(
    "click",
    /*click_handler*/
    n[34]
  ), {
    c() {
      e = K0("div"), Ar(t.$$.fragment), this.h();
    },
    l(i) {
      e = X0(i, "DIV", { title: !0, style: !0 });
      var l = Y0(e);
      Er(t.$$.fragment, l), l.forEach(Xe), this.h();
    },
    h() {
      v0(e, "title", "grant webcam access"), Pm(e, "height", "100%");
    },
    m(i, l) {
      st(i, e, l), Sr(t, e, null), a = !0;
    },
    p: u3,
    i(i) {
      a || (S0(t.$$.fragment, i), i && (r || zm(() => {
        r = Nm(e, E5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      P0(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Xe(e), Fr(t);
    }
  };
}
function Wm(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].start || /*i18n*/
    n[3]("audio.record")) + ""
  ), l, o;
  return r = new F4({}), {
    c() {
      e = K0("div"), t = K0("div"), Ar(r.$$.fragment), a = Ht(), l = N1(i), this.h();
    },
    l(s) {
      e = X0(s, "DIV", { class: !0 });
      var u = Y0(e);
      t = X0(u, "DIV", { class: !0, title: !0 });
      var c = Y0(t);
      Er(r.$$.fragment, c), c.forEach(Xe), a = Pt(u), l = L1(u, i), u.forEach(Xe), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "start recording"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      st(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].start || /*i18n*/
      s[3]("audio.record")) + "") && I1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Xe(e), Fr(r);
    }
  };
}
function Zm(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].stop || /*i18n*/
    n[3]("audio.stop")) + ""
  ), l, o;
  return r = new S4({}), {
    c() {
      e = K0("div"), t = K0("div"), Ar(r.$$.fragment), a = Ht(), l = N1(i), this.h();
    },
    l(s) {
      e = X0(s, "DIV", { class: !0 });
      var u = Y0(e);
      t = X0(u, "DIV", { class: !0, title: !0 });
      var c = Y0(t);
      Er(r.$$.fragment, c), c.forEach(Xe), a = Pt(u), l = L1(u, i), u.forEach(Xe), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "stop recording"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      st(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].stop || /*i18n*/
      s[3]("audio.stop")) + "") && I1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Xe(e), Fr(r);
    }
  };
}
function Ym(n) {
  let e, t, r, a, i = (
    /*button_labels*/
    (n[7].waiting || /*i18n*/
    n[3]("audio.waiting")) + ""
  ), l, o;
  return r = new Jl({}), {
    c() {
      e = K0("div"), t = K0("div"), Ar(r.$$.fragment), a = Ht(), l = N1(i), this.h();
    },
    l(s) {
      e = X0(s, "DIV", { class: !0 });
      var u = Y0(e);
      t = X0(u, "DIV", { class: !0, title: !0 });
      var c = Y0(t);
      Er(r.$$.fragment, c), c.forEach(Xe), a = Pt(u), l = L1(u, i), u.forEach(Xe), this.h();
    },
    h() {
      v0(t, "class", "icon color-primary svelte-c1guob"), v0(t, "title", "spinner"), v0(e, "class", "icon-with-text svelte-c1guob");
    },
    m(s, u) {
      st(s, e, u), x0(e, t), Sr(r, t, null), x0(e, a), x0(e, l), o = !0;
    },
    p(s, u) {
      (!o || u[0] & /*button_labels, i18n*/
      136) && i !== (i = /*button_labels*/
      (s[7].waiting || /*i18n*/
      s[3]("audio.waiting")) + "") && I1(l, i);
    },
    i(s) {
      o || (S0(r.$$.fragment, s), o = !0);
    },
    o(s) {
      P0(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Xe(e), Fr(r);
    }
  };
}
function s4(n) {
  let e, t, r, a, i;
  return t = new x1({}), {
    c() {
      e = K0("button"), Ar(t.$$.fragment), this.h();
    },
    l(l) {
      e = X0(l, "BUTTON", { class: !0, "aria-label": !0 });
      var o = Y0(e);
      Er(t.$$.fragment, o), o.forEach(Xe), this.h();
    },
    h() {
      v0(e, "class", "icon svelte-c1guob"), v0(e, "aria-label", "select input source");
    },
    m(l, o) {
      st(l, e, o), Sr(t, e, null), r = !0, a || (i = un(
        e,
        "click",
        /*click_handler_1*/
        n[35]
      ), a = !0);
    },
    p: u3,
    i(l) {
      r || (S0(t.$$.fragment, l), r = !0);
    },
    o(l) {
      P0(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && Xe(e), Fr(t), a = !1, i();
    }
  };
}
function o4(n) {
  let e, t, r, a, i, l, o;
  r = new x1({});
  function s(d, f) {
    return (
      /*available_audio_devices*/
      d[13].length === 0 ? Km : Xm
    );
  }
  let u = s(n), c = u(n);
  return {
    c() {
      e = K0("select"), t = K0("button"), Ar(r.$$.fragment), a = Ht(), c.c(), this.h();
    },
    l(d) {
      e = X0(d, "SELECT", { class: !0, "aria-label": !0 });
      var f = Y0(e);
      t = X0(f, "BUTTON", { class: !0 });
      var p = Y0(t);
      Er(r.$$.fragment, p), a = Pt(p), p.forEach(Xe), c.l(f), f.forEach(Xe), this.h();
    },
    h() {
      v0(t, "class", "inset-icon svelte-c1guob"), v0(e, "class", "select-wrap svelte-c1guob"), v0(e, "aria-label", "select source");
    },
    m(d, f) {
      st(d, e, f), x0(e, t), Sr(r, t, null), x0(t, a), c.m(e, null), i = !0, l || (o = [
        un(t, "click", Hm(
          /*click_handler_2*/
          n[36]
        )),
        Bm($m.call(
          null,
          e,
          /*handle_click_outside*/
          n[20]
        )),
        un(
          e,
          "change",
          /*handle_device_change*/
          n[21]
        )
      ], l = !0);
    },
    p(d, f) {
      u === (u = s(d)) && c ? c.p(d, f) : (c.d(1), c = u(d), c && (c.c(), c.m(e, null)));
    },
    i(d) {
      i || (S0(r.$$.fragment, d), i = !0);
    },
    o(d) {
      P0(r.$$.fragment, d), i = !1;
    },
    d(d) {
      d && Xe(e), Fr(r), c.d(), l = !1, c3(o);
    }
  };
}
function Xm(n) {
  let e, t = i4(
    /*available_audio_devices*/
    n[13]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = u4(l4(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = a4();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = a4();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      st(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*available_audio_devices, selected_device*/
      24576) {
        t = i4(
          /*available_audio_devices*/
          a[13]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = l4(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = u4(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && Xe(e), Rm(r, a);
    }
  };
}
function Km(n) {
  let e, t = (
    /*i18n*/
    n[3]("common.no_devices") + ""
  ), r;
  return {
    c() {
      e = K0("option"), r = N1(t), this.h();
    },
    l(a) {
      e = X0(a, "OPTION", { class: !0 });
      var i = Y0(e);
      r = L1(i, t), i.forEach(Xe), this.h();
    },
    h() {
      e.__value = "", Wl(e, e.__value), v0(e, "class", "svelte-c1guob");
    },
    m(a, i) {
      st(a, e, i), x0(e, r);
    },
    p(a, i) {
      i[0] & /*i18n*/
      8 && t !== (t = /*i18n*/
      a[3]("common.no_devices") + "") && I1(r, t);
    },
    d(a) {
      a && Xe(e);
    }
  };
}
function u4(n) {
  let e, t = (
    /*device*/
    n[42].label + ""
  ), r, a, i, l;
  return {
    c() {
      e = K0("option"), r = N1(t), a = Ht(), this.h();
    },
    l(o) {
      e = X0(o, "OPTION", { class: !0 });
      var s = Y0(e);
      r = L1(s, t), a = Pt(s), s.forEach(Xe), this.h();
    },
    h() {
      e.__value = i = /*device*/
      n[42].deviceId, Wl(e, e.__value), e.selected = l = /*selected_device*/
      n[14].deviceId === /*device*/
      n[42].deviceId, v0(e, "class", "svelte-c1guob");
    },
    m(o, s) {
      st(o, e, s), x0(e, r), x0(e, a);
    },
    p(o, s) {
      s[0] & /*available_audio_devices*/
      8192 && t !== (t = /*device*/
      o[42].label + "") && I1(r, t), s[0] & /*available_audio_devices*/
      8192 && i !== (i = /*device*/
      o[42].deviceId) && (e.__value = i, Wl(e, e.__value)), s[0] & /*selected_device, available_audio_devices*/
      24576 && l !== (l = /*selected_device*/
      o[14].deviceId === /*device*/
      o[42].deviceId) && (e.selected = l);
    },
    d(o) {
      o && Xe(e);
    }
  };
}
function Jm(n) {
  let e, t, r, a, i, l, o, s, u, c;
  e = new ri({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: Xl,
      float: !1,
      label: (
        /*label*/
        n[1] || /*i18n*/
        n[3]("audio.audio")
      )
    }
  });
  const d = [Gm, jm], f = [];
  function p(b, E) {
    return (
      /*mic_accessed*/
      b[15] ? 1 : 0
    );
  }
  return l = p(n), o = f[l] = d[l](n), {
    c() {
      Ar(e.$$.fragment), t = Ht(), r = K0("div"), a = K0("audio"), i = Ht(), o.c(), this.h();
    },
    l(b) {
      Er(e.$$.fragment, b), t = Pt(b), r = X0(b, "DIV", { class: !0 });
      var E = Y0(r);
      a = X0(E, "AUDIO", { class: !0 }), Y0(a).forEach(Xe), i = Pt(E), o.l(E), E.forEach(Xe), this.h();
    },
    h() {
      v0(a, "class", "standard-player svelte-c1guob"), ja(
        a,
        "hidden",
        /*value*/
        n[0] === "__webrtc_value__"
      ), v0(r, "class", "audio-container svelte-c1guob");
    },
    m(b, E) {
      Sr(e, b, E), st(b, t, E), st(b, r, E), x0(r, a), n[31](a), x0(r, i), f[l].m(r, null), s = !0, u || (c = [
        un(
          a,
          "load",
          /*load_handler*/
          n[30]
        ),
        un(
          a,
          "ended",
          /*ended_handler*/
          n[32]
        ),
        un(
          a,
          "play",
          /*play_handler*/
          n[33]
        )
      ], u = !0);
    },
    p(b, E) {
      const k = {};
      E[0] & /*show_label*/
      4 && (k.show_label = /*show_label*/
      b[2]), E[0] & /*label, i18n*/
      10 && (k.label = /*label*/
      b[1] || /*i18n*/
      b[3]("audio.audio")), e.$set(k), (!s || E[0] & /*value*/
      1) && ja(
        a,
        "hidden",
        /*value*/
        b[0] === "__webrtc_value__"
      );
      let w = l;
      l = p(b), l === w ? f[l].p(b, E) : (Fa(), P0(f[w], 1, 1, () => {
        f[w] = null;
      }), Aa(), o = f[l], o ? o.p(b, E) : (o = f[l] = d[l](b), o.c()), S0(o, 1), o.m(r, null));
    },
    i(b) {
      s || (S0(e.$$.fragment, b), S0(o), s = !0);
    },
    o(b) {
      P0(e.$$.fragment, b), P0(o), s = !1;
    },
    d(b) {
      b && (Xe(t), Xe(r)), Fr(e, b), n[31](null), f[l].d(), u = !1, c3(c);
    }
  };
}
function $m(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function ep(n, e, t) {
  var r = this && this.__awaiter || function(J, Ae, ge, Oe) {
    function Le(je) {
      return je instanceof ge ? je : new ge(function(Ge) {
        Ge(je);
      });
    }
    return new (ge || (ge = Promise))(function(je, Ge) {
      function e0(Qe) {
        try {
          Ve(Oe.next(Qe));
        } catch (s0) {
          Ge(s0);
        }
      }
      function X(Qe) {
        try {
          Ve(Oe.throw(Qe));
        } catch (s0) {
          Ge(s0);
        }
      }
      function Ve(Qe) {
        Qe.done ? je(Qe.value) : Le(Qe.value).then(e0, X);
      }
      Ve((Oe = Oe.apply(J, Ae || [])).next());
    });
  };
  let { mode: a } = e, { value: i = null } = e, { label: l = void 0 } = e, { show_label: o = !0 } = e, { rtc_configuration: s = null } = e, { i18n: u } = e, { time_limit: c = null } = e, { track_constraints: d = {} } = e, { rtp_params: f = {} } = e, { on_change_cb: p } = e, { icon: b = void 0 } = e, { icon_button_color: E = "var(--color-accent)" } = e, { pulse_color: k = "var(--color-accent)" } = e, { button_labels: w } = e, _ = !1, v;
  Um(() => {
    i === "__webrtc_value__" && t(29, v = new Audio("https://huggingface.co/datasets/freddyaboulton/bucket/resolve/main/pop-sounds.mp3"));
  });
  let A = (J) => {
    console.log("msg", J), J === "stopword" ? (console.log("stopword recognized"), t(8, _ = !0), setTimeout(
      () => {
        t(8, _ = !1);
      },
      3e3
    )) : (console.log("calling on_change_cb with msg", J), p(J));
  }, x = !1, Q = null, { server: B } = e, O = "closed", M, I, V = null, re, W, ae = null, Ee = !1;
  const xe = () => (console.log("stream in callback", re), a === "send" ? re : M.srcObject), qe = Vm();
  function ce() {
    return r(this, void 0, void 0, function* () {
      try {
        const Ae = ae ? Object.assign(
          {
            deviceId: { exact: ae.deviceId }
          },
          d
        ) : d;
        re = yield navigator.mediaDevices.getUserMedia({ audio: Ae });
      } catch (Ae) {
        if (!navigator.mediaDevices) {
          qe("error", u("audio.no_device_support"));
          return;
        }
        if (Ae instanceof DOMException && Ae.name == "NotAllowedError") {
          qe("error", u("audio.allow_recording_access"));
          return;
        }
        throw Ae;
      }
      t(13, W = D1(yield F5(), "audioinput")), t(15, Ee = !0);
      const J = re.getTracks().map((Ae) => {
        var ge;
        return (ge = Ae.getSettings()) === null || ge === void 0 ? void 0 : ge.deviceId;
      })[0];
      t(14, ae = J && W.find((Ae) => Ae.deviceId === J) || W[0]);
    });
  }
  function pe() {
    return r(this, void 0, void 0, function* () {
      if (O === "open") {
        Kr(I), t(11, O = "closed"), t(10, Q = null), yield ce();
        return;
      }
      V = Math.random().toString(36).substring(2), t(0, i = V), I = new RTCPeerConnection(s), I.addEventListener("connectionstatechange", (J) => r(this, void 0, void 0, function* () {
        switch (I.connectionState) {
          case "connected":
            console.info("connected"), t(11, O = "open"), t(10, Q = c);
            break;
          case "disconnected":
            console.info("closed"), t(11, O = "closed"), t(10, Q = null), Kr(I);
            break;
        }
      })), t(11, O = "waiting"), re = null;
      try {
        yield ce();
      } catch (J) {
        if (!navigator.mediaDevices) {
          qe("error", u("audio.no_device_support"));
          return;
        }
        if (J instanceof DOMException && J.name == "NotAllowedError") {
          qe("error", u("audio.allow_recording_access"));
          return;
        }
        throw J;
      }
      re != null && B1(re, I, a === "send" ? null : M, B.offer, V, "audio", A, f).then((J) => {
        I = J;
      }).catch(() => {
        console.info("catching"), qe("error", "Too many concurrent users. Come back later!");
      });
    });
  }
  function Ce(J) {
    J.preventDefault(), J.stopPropagation(), t(9, x = !1);
  }
  const $ = (J) => r(void 0, void 0, void 0, function* () {
    const ge = J.target.value;
    re = yield navigator.mediaDevices.getUserMedia({
      audio: Object.assign({ deviceId: { exact: ge } }, d)
    }), t(14, ae = W.find((Oe) => Oe.deviceId === ge) || null), t(9, x = !1);
  });
  function Te(J) {
    Im.call(this, n, J);
  }
  function se(J) {
    Lm[J ? "unshift" : "push"](() => {
      M = J, t(12, M);
    });
  }
  const De = () => qe("stop"), P = () => qe("play"), we = async () => ce(), he = () => t(9, x = !0), Ke = () => t(9, x = !1);
  return n.$$set = (J) => {
    "mode" in J && t(22, a = J.mode), "value" in J && t(0, i = J.value), "label" in J && t(1, l = J.label), "show_label" in J && t(2, o = J.show_label), "rtc_configuration" in J && t(23, s = J.rtc_configuration), "i18n" in J && t(3, u = J.i18n), "time_limit" in J && t(24, c = J.time_limit), "track_constraints" in J && t(25, d = J.track_constraints), "rtp_params" in J && t(26, f = J.rtp_params), "on_change_cb" in J && t(27, p = J.on_change_cb), "icon" in J && t(4, b = J.icon), "icon_button_color" in J && t(5, E = J.icon_button_color), "pulse_color" in J && t(6, k = J.pulse_color), "button_labels" in J && t(7, w = J.button_labels), "server" in J && t(28, B = J.server);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*stopword_recognized, notification_sound*/
    536871168 && _ && v.play();
  }, [
    i,
    l,
    o,
    u,
    b,
    E,
    k,
    w,
    _,
    x,
    Q,
    O,
    M,
    W,
    ae,
    Ee,
    xe,
    qe,
    ce,
    pe,
    Ce,
    $,
    a,
    s,
    c,
    d,
    f,
    p,
    B,
    v,
    Te,
    se,
    De,
    P,
    we,
    he,
    Ke
  ];
}
class tp extends Mm {
  constructor(e) {
    super(), qm(
      this,
      e,
      ep,
      Jm,
      Om,
      {
        mode: 22,
        value: 0,
        label: 1,
        show_label: 2,
        rtc_configuration: 23,
        i18n: 3,
        time_limit: 24,
        track_constraints: 25,
        rtp_params: 26,
        on_change_cb: 27,
        icon: 4,
        icon_button_color: 5,
        pulse_color: 6,
        button_labels: 7,
        server: 28
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: rp,
  action_destroyer: c4,
  add_render_callback: np,
  append_hydration: N,
  attr: D,
  binding_callbacks: a1,
  check_outros: Dl,
  children: R,
  claim_component: L5,
  claim_element: We,
  claim_space: q0,
  claim_svg_element: U,
  claim_text: h3,
  create_component: I5,
  create_in_transition: ap,
  destroy_component: N5,
  destroy_each: h4,
  detach: z,
  element: Ze,
  ensure_array_like: wa,
  get_svelte_dataset: ci,
  group_outros: El,
  init: ip,
  insert_hydration: A0,
  is_function: f4,
  listen: Nt,
  mount_component: R5,
  noop: fn,
  run_all: lp,
  safe_not_equal: sp,
  set_data: f3,
  set_style: ye,
  space: O0,
  stop_propagation: d3,
  svg_element: j,
  text: m3,
  toggle_class: Vr,
  transition_in: zt,
  transition_out: gr
} = window.__gradio__svelte__internal, { createEventDispatcher: op, onMount: up } = window.__gradio__svelte__internal;
function d4(n, e, t) {
  const r = n.slice();
  return r[62] = e[t], r[64] = t, r;
}
function m4(n, e, t) {
  const r = n.slice();
  return r[62] = e[t], r[64] = t, r;
}
function p4(n) {
  let e, t, r, a;
  return t = new A5({}), t.$on(
    "click",
    /*click_handler*/
    n[44]
  ), {
    c() {
      e = Ze("div"), I5(t.$$.fragment), this.h();
    },
    l(i) {
      e = We(i, "DIV", { style: !0 });
      var l = R(e);
      L5(t.$$.fragment, l), l.forEach(z), this.h();
    },
    h() {
      ye(e, "height", "100%");
    },
    m(i, l) {
      A0(i, e, l), R5(t, e, null), a = !0;
    },
    p: fn,
    i(i) {
      a || (zt(t.$$.fragment, i), i && (r || np(() => {
        r = ap(e, E5, { delay: 100, duration: 200 }), r.start();
      })), a = !0);
    },
    o(i) {
      gr(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && z(e), N5(t);
    }
  };
}
function cp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("clipPath"), l = j("rect"), o = j("g"), s = j("g"), u = j("g"), c = j("rect"), d = j("g"), f = j("path"), p = j("g"), b = j("path"), E = j("g"), k = j("path"), this.h();
    },
    l(w) {
      e = U(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = R(e);
      t = U(_, "defs", {});
      var v = R(t);
      r = U(v, "clipPath", { id: !0 });
      var A = R(r);
      a = U(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), A.forEach(z), i = U(v, "clipPath", { id: !0 });
      var x = R(i);
      l = U(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(l).forEach(z), x.forEach(z), v.forEach(z), o = U(_, "g", { "clip-path": !0 });
      var Q = R(o);
      s = U(Q, "g", { "clip-path": !0 });
      var B = R(s);
      u = U(B, "g", {});
      var O = R(u);
      c = U(O, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(c).forEach(z), O.forEach(z), d = U(B, "g", {});
      var M = R(d);
      f = U(M, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(f).forEach(z), M.forEach(z), p = U(B, "g", {});
      var I = R(p);
      b = U(I, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(b).forEach(z), I.forEach(z), E = U(B, "g", {});
      var V = R(E);
      k = U(V, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(k).forEach(z), V.forEach(z), B.forEach(z), Q.forEach(z), _.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_279"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_279/13_007"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), ye(c, "mix-blend-mode", "passthrough"), D(f, "d", "M0.83317090625,15.8333259765625L0.83317090625,4.1666259765625Q0.83317090625,4.0845497765625,0.84918290625,4.0040509765625Q0.86519490625,3.9235519765625,0.89660490625,3.8477229765625Q0.92801390625,3.7718949765625,0.97361290625,3.7036509765625Q1.01921190625,3.6354069765625,1.07724790625,3.5773699765625Q1.13528490625,3.5193339765625,1.2035289062499999,3.4737349765625Q1.27177290625,3.4281359765625,1.34760090625,3.3967269765625Q1.42342990625,3.3653169765625,1.50392890625,3.3493049765625003Q1.58442770625,3.3332929765625,1.66650390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,15.8333259765625Q15.83320390625,15.9153259765625,15.81720390625,15.9958259765625Q15.80110390625,16.0763259765625,15.76970390625,16.152225976562498Q15.73830390625,16.2280259765625,15.69270390625,16.2962259765625Q15.64710390625,16.3645259765625,15.58910390625,16.4225259765625Q15.53100390625,16.4806259765625,15.46280390625,16.5262259765625Q15.39460390625,16.5718259765625,15.31870390625,16.6032259765625Q15.24290390625,16.6346259765625,15.16240390625,16.6506259765625Q15.08190390625,16.6666259765625,14.99980390625,16.6666259765625L1.66650390625,16.6666259765625Q1.58442770625,16.6666259765625,1.50392890625,16.6506259765625Q1.42342990625,16.6346259765625,1.34760090625,16.6032259765625Q1.27177290625,16.5718259765625,1.2035289062499999,16.5262259765625Q1.13528490625,16.4806259765625,1.07724790625,16.4225259765625Q1.01921190625,16.3645259765625,0.97361290625,16.2962259765625Q0.92801390625,16.2280259765625,0.89660490625,16.152225976562498Q0.86519490625,16.0763259765625,0.84918290625,15.9958259765625Q0.83317090625,15.9153259765625,0.83317090625,15.8333259765625ZM2.49983690625,4.9999589765625L2.49983690625,14.9999259765625L14.16650390625,14.9999259765625L14.16650390625,4.9999589765625L2.49983690625,4.9999589765625Z"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), ye(f, "mix-blend-mode", "passthrough"), D(b, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), ye(b, "mix-blend-mode", "passthrough"), D(k, "d", "M7.65749209375,7.3101989765625L10.11698609375,9.3597759765625Q10.17518609375,9.4082759765625,10.22367609375,9.4664759765625Q10.32979609375,9.5938159765625,10.37910609375,9.7520659765625Q10.42841609375,9.9103259765625,10.41340609375,10.0754059765625Q10.39839609375,10.2404859765625,10.321366093750001,10.3872559765625Q10.24432609375,10.5340259765625,10.11698609375,10.6401459765625L7.65748809375,12.6897259765625Q7.54118509375,12.7998059765625,7.39241009375,12.8590459765625Q7.24363409375,12.9182959765625,7.08349609375,12.9182959765625Q7.00125579375,12.9182959765625,6.92059609375,12.9022459765625Q6.83993609375,12.8862059765625,6.76395509375,12.8547359765625Q6.6879750937499995,12.8232559765625,6.61959509375,12.7775659765625Q6.55121509375,12.731875976562499,6.49306209375,12.673725976562501Q6.43490909375,12.6155759765625,6.38921909375,12.547195976562499Q6.34352909375,12.478815976562501,6.31205709375,12.4028359765625Q6.28058509375,12.3268559765625,6.26454009375,12.2461959765625Q6.24849609375,12.1655359765625,6.24849609375,12.0832959765625Q6.24849609375,11.9848059765625,6.27141009375,11.8890159765625Q6.29432409375,11.7932359765625,6.33889509375,11.7054159765625Q6.38346609375,11.6175859765625,6.44724609375,11.5425459765625Q6.51102709375,11.4674959765625,6.59051809375,11.4093459765625L8.28178609375,9.9999559765625L6.59051809375,8.5905679765625Q6.51102709375,8.5324209765625,6.44724609375,8.4573769765625Q6.38346509375,8.3823319765625,6.33889509375,8.2945069765625Q6.29432409375,8.2066819765625,6.27141009375,8.1108979765625Q6.24849609375,8.0151131765625,6.24849609375,7.9166259765625Q6.24849609375,7.8343856765625,6.26454009375,7.7537259765625Q6.28058509375,7.6730659765625,6.31205709375,7.5970849765625Q6.34352909375,7.5211049765624995,6.38921909375,7.4527249765625Q6.43490909375,7.3843449765625,6.49306209375,7.3261919765625Q6.55121509375,7.2680389765625,6.61959509375,7.2223489765625Q6.6879750937499995,7.1766589765625,6.76395509375,7.1451869765625Q6.83993609375,7.1137149765625,6.92059609375,7.0976699765625Q7.00125579375,7.0816259765625,7.08349609375,7.0816259765625Q7.24363509375,7.0816259765625,7.39241209375,7.1408709765625Q7.54118909375,7.2001159765625005,7.65749209375,7.3101989765625Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), ye(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_279/13_007)"), D(o, "clip-path", "url(#master_svg0_13_279)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, _) {
      A0(w, e, _), N(e, t), N(t, r), N(r, a), N(t, i), N(i, l), N(e, o), N(o, s), N(s, u), N(u, c), N(s, d), N(d, f), N(s, p), N(p, b), N(s, E), N(E, k);
    },
    d(w) {
      w && z(e);
    }
  };
}
function hp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("clipPath"), l = j("rect"), o = j("g"), s = j("g"), u = j("g"), c = j("rect"), d = j("g"), f = j("path"), p = j("g"), b = j("path"), E = j("g"), k = j("path"), this.h();
    },
    l(w) {
      e = U(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = R(e);
      t = U(_, "defs", {});
      var v = R(t);
      r = U(v, "clipPath", { id: !0 });
      var A = R(r);
      a = U(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), A.forEach(z), i = U(v, "clipPath", { id: !0 });
      var x = R(i);
      l = U(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(l).forEach(z), x.forEach(z), v.forEach(z), o = U(_, "g", { "clip-path": !0 });
      var Q = R(o);
      s = U(Q, "g", { "clip-path": !0 });
      var B = R(s);
      u = U(B, "g", {});
      var O = R(u);
      c = U(O, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(c).forEach(z), O.forEach(z), d = U(B, "g", {});
      var M = R(d);
      f = U(M, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(f).forEach(z), M.forEach(z), p = U(B, "g", {});
      var I = R(p);
      b = U(I, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(b).forEach(z), I.forEach(z), E = U(B, "g", {});
      var V = R(E);
      k = U(V, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(k).forEach(z), V.forEach(z), B.forEach(z), Q.forEach(z), _.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_287/13_279"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_287/13_279/13_018"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), ye(c, "mix-blend-mode", "passthrough"), D(f, "d", "M7.55256390625,4.9999589765625Q7.52622390625,5.0016259765625,7.49983390625,5.0016259765625Q7.41759390625,5.0016259765625,7.33693390625,4.9855819765625Q7.25627390625,4.9695369765625,7.18029390625,4.9380649765625Q7.10431390625,4.9065929765625,7.03593390625,4.8609029765625Q6.96755390625,4.8152129765625,6.90940390625,4.7570599765625Q6.85125390625,4.6989069765625,6.80556390625,4.6305269765625Q6.75986390625,4.5621469765625005,6.72839390625,4.4861669765625Q6.69692390625,4.4101859765625,6.68088390625,4.3295259765625Q6.66483390625,4.2488662765625,6.66483390625,4.1666259765625Q6.66483390625,4.0843856765625,6.68088390625,4.0037259765625Q6.69692390625,3.9230659765625,6.72839390625,3.8470849765625Q6.75986390625,3.7711049765625,6.80556390625,3.7027249765625Q6.85125390625,3.6343449765624998,6.90940390625,3.5761919765625Q6.96755390625,3.5180389765625,7.03593390625,3.4723489765625Q7.10431390625,3.4266589765625,7.18029390625,3.3951869765625Q7.25627390625,3.3637149765625,7.33693390625,3.3476699765625Q7.41759390625,3.3316259765625,7.49983390625,3.3316259765625Q7.52622390625,3.3316259765625,7.55256390625,3.3332929765625L14.99980390625,3.3332929765625Q15.08190390625,3.3332929765625,15.16240390625,3.3493049765625003Q15.24290390625,3.3653169765625,15.31870390625,3.3967269765625Q15.39460390625,3.4281359765625,15.46280390625,3.4737349765625Q15.53100390625,3.5193339765625,15.58910390625,3.5773699765625Q15.64710390625,3.6354069765625,15.69270390625,3.7036509765625Q15.73830390625,3.7718949765625,15.76970390625,3.8477229765625Q15.80110390625,3.9235519765625,15.81720390625,4.0040509765625Q15.83320390625,4.0845497765625,15.83320390625,4.1666259765625L15.83320390625,11.1972259765625Q15.83480390625,11.2235659765625,15.83480390625,11.2499559765625Q15.83480390625,11.332195976562499,15.81880390625,11.4128559765625Q15.80270390625,11.493515976562499,15.77130390625,11.5694959765625Q15.73980390625,11.645475976562501,15.69410390625,11.713855976562499Q15.64840390625,11.7822359765625,15.59030390625,11.840395976562501Q15.53210390625,11.898545976562499,15.46370390625,11.9442359765625Q15.39540390625,11.9899259765625,15.31940390625,12.0213959765625Q15.24340390625,12.0528659765625,15.16270390625,12.0689159765625Q15.08210390625,12.084955976562501,14.99980390625,12.084955976562501Q14.91760390625,12.084955976562501,14.83690390625,12.0689159765625Q14.75630390625,12.0528659765625,14.68030390625,12.0213959765625Q14.60430390625,11.9899259765625,14.53590390625,11.9442359765625Q14.46760390625,11.898545976562499,14.40940390625,11.840395976562501Q14.35120390625,11.7822359765625,14.30560390625,11.713855976562499Q14.25990390625,11.645475976562501,14.22840390625,11.5694959765625Q14.19690390625,11.493515976562499,14.18090390625,11.4128559765625Q14.16480390625,11.332195976562499,14.16480390625,11.2499559765625Q14.16480390625,11.2235659765625,14.16650390625,11.1972259765625L14.16650390625,4.9999589765625L7.55256390625,4.9999589765625ZM2.49983690625,5.0526899765625Q2.50150390625,5.0263509765625,2.50150390625,4.9999589765625Q2.50150390625,4.9177189765625,2.48545990625,4.8370589765625Q2.46941490625,4.7563989765625,2.43794290625,4.6804189765625Q2.40647090625,4.6044379765625,2.36078090625,4.5360579765625Q2.31509090625,4.4676779765625,2.25693790625,4.4095249765625Q2.1987849062500002,4.3513719765625,2.13040490625,4.3056819765625Q2.06202490625,4.2599918765625,1.98604490625,4.2285198765625Q1.91006390625,4.1970478765625,1.82940390625,4.1810035765625Q1.74874420625,4.1649593165625,1.66650390625,4.1649593065625Q1.58426360625,4.1649593165625,1.50360390625,4.1810035765625Q1.42294390625,4.1970478765625,1.34696290625,4.2285198765625Q1.27098290625,4.2599918765625,1.20260290625,4.3056819765625Q1.13422290625,4.3513719765625,1.0760699062499999,4.4095249765625Q1.01791690625,4.4676779765625,0.97222690625,4.5360579765625Q0.92653690625,4.6044379765625,0.89506490625,4.6804189765625Q0.86359290625,4.7563989765625,0.84754790625,4.8370589765625Q0.83150390625,4.9177189765625,0.83150390625,4.9999589765625Q0.83150390625,5.0263509765625,0.83317090625,5.0526899765625L0.83317090625,15.8333259765625Q0.83317090625,15.9153259765625,0.84918290625,15.9958259765625Q0.86519490625,16.0763259765625,0.89660490625,16.152225976562498Q0.92801390625,16.2280259765625,0.97361290625,16.2962259765625Q1.01921190625,16.3645259765625,1.07724790625,16.4225259765625Q1.13528490625,16.4806259765625,1.2035289062499999,16.5262259765625Q1.27177290625,16.5718259765625,1.34760090625,16.6032259765625Q1.42342990625,16.6346259765625,1.50392890625,16.6506259765625Q1.58442770625,16.6666259765625,1.66650390625,16.6666259765625L12.44710390625,16.6666259765625Q12.47340390625,16.6683259765625,12.49980390625,16.6683259765625Q12.58210390625,16.6683259765625,12.66270390625,16.652225976562498Q12.74340390625,16.6362259765625,12.81940390625,16.6047259765625Q12.89540390625,16.573225976562497,12.96370390625,16.5275259765625Q13.03210390625,16.4819259765625,13.09030390625,16.4237259765625Q13.14840390625,16.365525976562502,13.19410390625,16.2972259765625Q13.23980390625,16.2288259765625,13.27130390625,16.1528259765625Q13.30270390625,16.0768259765625,13.31880390625,15.9962259765625Q13.33480390625,15.9155259765625,13.33480390625,15.8333259765625Q13.33480390625,15.7510259765625,13.31880390625,15.6704259765625Q13.30270390625,15.5897259765625,13.27130390625,15.5137259765625Q13.23980390625,15.4377259765625,13.19410390625,15.3694259765625Q13.14840390625,15.3010259765625,13.09030390625,15.2428259765625Q13.03210390625,15.1847259765625,12.96370390625,15.1390259765625Q12.89540390625,15.0933259765625,12.81940390625,15.0618259765625Q12.74340390625,15.0304259765625,12.66270390625,15.0143259765625Q12.58210390625,14.9983259765625,12.49980390625,14.9983259765625Q12.47340390625,14.9983259765625,12.44710390625,14.9999259765625L2.49983690625,14.9999259765625L2.49983690625,5.0526899765625Z"), D(f, "fill-rule", "evenodd"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), ye(f, "mix-blend-mode", "passthrough"), D(b, "d", "M18.97024,14.7041040234375Q19.06538,14.5913440234375,19.11602,14.4527940234375Q19.16667,14.3142340234375,19.16667,14.1667040234375L19.16667,5.8333740234375Q19.16667,5.7512978234375,19.15065,5.6707990234375Q19.13464,5.5903000234375,19.10323,5.5144710234375Q19.07182,5.4386430234375,19.026220000000002,5.3703990234375Q18.98063,5.3021550234375,18.92259,5.2441180234375Q18.86455,5.1860820234375,18.79631,5.1404830234375Q18.72806,5.0948840234375,18.65224,5.0634750234375Q18.57641,5.0320650234375,18.49591,5.0160530234375Q18.41541,5.0000410234375,18.33333,5.0000410234375Q18.18581,5.0000410234375,18.04725,5.0506860234375Q17.90869,5.1013300234375,17.79594,5.1964640234375L14.462608,8.0089640234375Q14.393074,8.067634023437499,14.337838,8.1399240234375Q14.282601,8.2122140234375,14.244265,8.2947240234375Q14.205928,8.377224023437499,14.186297,8.4660640234375Q14.166667,8.5548940234375,14.166667,8.6458740234375L14.166667,11.3542040234375Q14.166667,11.4451840234375,14.186297,11.5340240234375Q14.205928,11.622854023437501,14.244265,11.7053640234375Q14.282601,11.7878640234375,14.337838,11.860154023437499Q14.393074,11.932444023437501,14.462608,11.9911140234375L17.79594,14.8036140234375Q17.922629999999998,14.9105140234375,18.08058,14.9607840234375Q18.23853,15.0110640234375,18.4037,14.9970640234375Q18.56887,14.9830640234375,18.71611,14.9069240234375Q18.86335,14.8307940234375,18.97024,14.7041040234375ZM17.5,12.3732440234375L17.5,7.6268340234375L15.833333,9.0330840234375L15.833333,10.9669940234375L17.5,12.3732440234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), ye(b, "mix-blend-mode", "passthrough"), D(k, "d", "M1.1145349062499998,2.2931679765625Q0.97958490625,2.1742799765625,0.90554390625,2.0103779765625Q0.83150390625,1.8464759765625,0.83150390625,1.6666259765625Q0.83150390625,1.5843856765625,0.84754790625,1.5037259765625Q0.86359290625,1.4230659765625,0.89506490625,1.3470849765625Q0.92653690625,1.2711049765625,0.97222690625,1.2027249765625Q1.01791690625,1.1343449765625,1.0760699062499999,1.0761919765624999Q1.13422290625,1.0180389765625,1.20260290625,0.9723489765625Q1.27098290625,0.9266589765625,1.34696290625,0.8951869765625Q1.42294390625,0.8637149765625,1.50360390625,0.8476699765625Q1.58426360625,0.8316259765625,1.66650390625,0.8316259765625Q1.84635390625,0.8316259765625,2.01025590625,0.9056659765625Q2.17415790625,0.9797069765625,2.29304590625,1.1146569765624998L18.88520390625,17.7067259765625Q19.02010390625,17.8256259765625,19.09410390625,17.9895259765625Q19.16820390625,18.1534259765625,19.16820390625,18.3333259765625Q19.16820390625,18.4155259765625,19.15210390625,18.4962259765625Q19.13610390625,18.5768259765625,19.10460390625,18.6528259765625Q19.07310390625,18.7288259765625,19.02740390625,18.7972259765625Q18.98170390625,18.8655259765625,18.92360390625,18.9237259765625Q18.86540390625,18.9818259765625,18.79710390625,19.0275259765625Q18.72870390625,19.0732259765625,18.65270390625,19.1047259765625Q18.57670390625,19.1362259765625,18.49610390625,19.1522259765625Q18.41540390625,19.1683259765625,18.33320390625,19.1683259765625Q18.15330390625,19.1683259765625,17.98940390625,19.0942259765625Q17.82550390625,19.0202259765625,17.70660390625,18.8853259765625L1.1145349062499998,2.2931679765625Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), ye(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_287/13_279/13_018)"), D(o, "clip-path", "url(#master_svg0_13_287/13_279)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, _) {
      A0(w, e, _), N(e, t), N(t, r), N(r, a), N(t, i), N(i, l), N(e, o), N(o, s), N(s, u), N(u, c), N(s, d), N(d, f), N(s, p), N(p, b), N(s, E), N(E, k);
    },
    d(w) {
      w && z(e);
    }
  };
}
function g4(n) {
  let e, t, r;
  return {
    c() {
      e = Ze("div"), this.h();
    },
    l(a) {
      e = We(a, "DIV", { class: !0 }), R(e).forEach(z), this.h();
    },
    h() {
      D(e, "class", "corner svelte-1k2qcvm");
    },
    m(a, i) {
      A0(a, e, i), t || (r = Nt(
        e,
        "click",
        /*open_camera_list*/
        n[33]
      ), t = !0);
    },
    p: fn,
    d(a) {
      a && z(e), t = !1, r();
    }
  };
}
function _4(n) {
  let e, t = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="none" version="1.1" width="14.000000357627869" height="10.000000357627869" viewBox="0 0 14.000000357627869 10.000000357627869"><g><path d="M13.802466686534881,1.1380186865348816Q13.89646668653488,1.0444176865348815,13.947366686534881,0.9218876865348815Q13.998366686534881,0.7993576865348816,13.998366686534881,0.6666666865348816Q13.998366686534881,0.6011698865348816,13.98556668653488,0.5369316865348817Q13.972766686534882,0.4726936865348816,13.947666686534882,0.4121826865348816Q13.922666686534882,0.3516706865348816,13.886266686534881,0.2972126865348816Q13.849866686534881,0.2427536865348816,13.803566686534882,0.19644068653488161Q13.757266686534882,0.15012768653488162,13.702766686534881,0.11373968653488165Q13.648366686534882,0.07735168653488156,13.587866686534882,0.052286686534881555Q13.527266686534881,0.02722268653488158,13.463066686534882,0.014444686534881623Q13.398866686534882,0.0016666865348815563,13.333366686534882,0.0016666865348815563Q13.201466686534882,0.0016666865348815563,13.079566686534882,0.051981686534881555Q12.957666686534882,0.10229768653488158,12.864266686534881,0.1953146865348816L12.863066686534882,0.19413268653488158L4.624996686534882,8.392776686534882L1.1369396865348815,4.921396686534882L1.1357636865348817,4.922586686534881Q1.0422996865348817,4.829566686534881,0.9204146865348816,4.779246686534882Q0.7985286865348816,4.728936686534881,0.6666666865348816,4.728936686534881Q0.6011698865348816,4.728936686534881,0.5369316865348817,4.741706686534882Q0.4726936865348816,4.754486686534881,0.4121826865348816,4.779556686534882Q0.3516706865348816,4.804616686534882,0.2972126865348816,4.8410066865348815Q0.2427536865348816,4.8773966865348815,0.19644068653488161,4.9237066865348815Q0.15012768653488162,4.970016686534882,0.11373968653488165,5.024476686534881Q0.07735168653488156,5.078936686534882,0.052286686534881555,5.139446686534882Q0.02722268653488158,5.199956686534882,0.014444686534881623,5.2641966865348815Q0.0016666865348815563,5.328436686534881,0.0016666865348815563,5.3939366865348815Q0.0016666865348815563,5.526626686534882,0.05259268653488158,5.649156686534882Q0.10351768653488158,5.771686686534881,0.1975696865348816,5.865286686534882L0.1963936865348816,5.866466686534881L4.1547266865348815,9.805866686534882Q4.201126686534882,9.852046686534882,4.255616686534882,9.888306686534882Q4.310106686534882,9.924576686534882,4.3706166865348814,9.949556686534882Q4.431126686534881,9.974536686534881,4.495326686534882,9.987266686534882Q4.559536686534882,9.999996686534882,4.624996686534882,9.999996686534882Q4.690456686534882,9.999996686534882,4.754666686534882,9.987266686534882Q4.818876686534882,9.974536686534881,4.879386686534882,9.949556686534882Q4.939886686534882,9.924576686534882,4.994386686534882,9.888306686534882Q5.048876686534881,9.852046686534882,5.0952766865348815,9.805866686534882L13.803566686534882,1.1392006865348816L13.802466686534881,1.1380186865348816Z" fill-rule="evenodd" fill="#E0E0FC" fill-opacity="1" style="mix-blend-mode:passthrough"></path></g></svg>';
  return {
    c() {
      e = Ze("div"), e.innerHTML = t, this.h();
    },
    l(r) {
      e = We(r, "DIV", { class: !0, "data-svelte-h": !0 }), ci(e) !== "svelte-c8s251" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "active-icon svelte-1k2qcvm");
    },
    m(r, a) {
      A0(r, e, a);
    },
    d(r) {
      r && z(e);
    }
  };
}
function v4(n) {
  let e, t = (
    /*device*/
    n[62].label + ""
  ), r, a, i, l, o, s = (
    /*selected_video_device*/
    n[4] && /*device*/
    n[62].deviceId === /*selected_video_device*/
    n[4].deviceId && _4()
  );
  function u(...c) {
    return (
      /*click_handler_1*/
      n[49](
        /*device*/
        n[62],
        ...c
      )
    );
  }
  return {
    c() {
      e = Ze("div"), r = m3(t), a = O0(), s && s.c(), i = O0(), this.h();
    },
    l(c) {
      e = We(c, "DIV", { class: !0 });
      var d = R(e);
      r = h3(d, t), a = q0(d), s && s.l(d), i = q0(d), d.forEach(z), this.h();
    },
    h() {
      D(e, "class", "selector svelte-1k2qcvm");
    },
    m(c, d) {
      A0(c, e, d), N(e, r), N(e, a), s && s.m(e, null), N(e, i), l || (o = Nt(e, "click", d3(u)), l = !0);
    },
    p(c, d) {
      n = c, d[0] & /*available_video_devices*/
      4 && t !== (t = /*device*/
      n[62].label + "") && f3(r, t), /*selected_video_device*/
      n[4] && /*device*/
      n[62].deviceId === /*selected_video_device*/
      n[4].deviceId ? s || (s = _4(), s.c(), s.m(e, i)) : s && (s.d(1), s = null);
    },
    d(c) {
      c && z(e), s && s.d(), l = !1, o();
    }
  };
}
function fp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("clipPath"), l = j("rect"), o = j("g"), s = j("g"), u = j("g"), c = j("rect"), d = j("g"), f = j("path"), p = j("g"), b = j("path"), E = j("g"), k = j("path"), this.h();
    },
    l(w) {
      e = U(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = R(e);
      t = U(_, "defs", {});
      var v = R(t);
      r = U(v, "clipPath", { id: !0 });
      var A = R(r);
      a = U(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), A.forEach(z), i = U(v, "clipPath", { id: !0 });
      var x = R(i);
      l = U(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(l).forEach(z), x.forEach(z), v.forEach(z), o = U(_, "g", { "clip-path": !0 });
      var Q = R(o);
      s = U(Q, "g", { "clip-path": !0 });
      var B = R(s);
      u = U(B, "g", {});
      var O = R(u);
      c = U(O, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(c).forEach(z), O.forEach(z), d = U(B, "g", {});
      var M = R(d);
      f = U(M, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(f).forEach(z), M.forEach(z), p = U(B, "g", {});
      var I = R(p);
      b = U(I, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(b).forEach(z), I.forEach(z), E = U(B, "g", {});
      var V = R(E);
      k = U(V, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(k).forEach(z), V.forEach(z), B.forEach(z), Q.forEach(z), _.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_278"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_278/13_029"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), ye(c, "mix-blend-mode", "passthrough"), D(f, "d", "M6.249918953125,9.9999559765625L6.249918953125,4.5832959765625Q6.249918953125,3.0299959765624997,7.348267953125,1.9316419765625Q8.446621953125,0.8332929765625,9.999921953125,0.8332929765625Q11.553221953125,0.8332929765625,12.651571953125,1.9316419765625Q13.749921953125,3.0299959765624997,13.749921953125,4.5832959765625L13.749921953125,9.9999559765625Q13.749921953125,11.5532559765625,12.651571953125,12.6516259765625Q11.553221953125,13.7499259765625,9.999921953125,13.7499259765625Q8.446621953125,13.7499259765625,7.348267953125,12.6516259765625Q6.249918953125,11.5532559765625,6.249918953125,9.9999559765625ZM7.916584953125,9.9999559765625Q7.916584953125,10.8629059765625,8.526781953124999,11.4730959765625Q9.136971953125,12.0833259765625,9.999921953125,12.0833259765625Q10.862861953125,12.0833259765625,11.473061953125,11.4730959765625Q12.083251953125,10.8629059765625,12.083251953125,9.9999559765625L12.083251953125,4.5832959765625Q12.083251953125,3.7203459765625,11.473061953125,3.1101559765625Q10.862861953125,2.4999589765625,9.999921953125,2.4999589765625Q9.136971953125,2.4999589765625,8.526781953124999,3.1101559765625Q7.916584953125,3.7203459765625,7.916584953125,4.5832959765625L7.916584953125,9.9999559765625Z"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), ye(f, "mix-blend-mode", "passthrough"), D(b, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q12.93402,16.6667040234375,15.0087,14.5920540234375Q17.0636,12.5370940234375,17.0831,9.6390003234375Q17.085,9.6112181234375,17.085,9.5833740234375Q17.085,9.5011337234375,17.069000000000003,9.4204740234375Q17.0529,9.3398140234375,17.0214,9.2638330234375Q16.990000000000002,9.1878530234375,16.9443,9.1194730234375Q16.898600000000002,9.0510930234375,16.840400000000002,8.9929400234375Q16.7823,8.9347870234375,16.713900000000002,8.8890970234375Q16.6455,8.8434070234375,16.569499999999998,8.8119350234375Q16.4936,8.7804630234375,16.4129,8.7644180234375Q16.3322,8.7483740234375,16.25,8.7483740234375Q16.1678,8.7483740234375,16.0871,8.7644180234375Q16.0064,8.7804630234375,15.9305,8.8119350234375Q15.8545,8.8434070234375,15.7861,8.8890970234375Q15.7177,8.9347870234375,15.6596,8.9929400234375Q15.6014,9.0510930234375,15.5557,9.1194730234375Q15.51,9.1878530234375,15.4786,9.2638330234375Q15.4471,9.3398140234375,15.431,9.4204740234375Q15.415,9.5011337234375,15.415,9.5833740234375Q15.415,9.6081817234375,15.4165,9.6329456234375Q15.3991,11.8445940234375,13.8302,13.413544023437499Q12.24366,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), ye(b, "mix-blend-mode", "passthrough"), D(k, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), ye(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_278/13_029)"), D(o, "clip-path", "url(#master_svg0_13_278)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, _) {
      A0(w, e, _), N(e, t), N(t, r), N(r, a), N(t, i), N(i, l), N(e, o), N(o, s), N(s, u), N(u, c), N(s, d), N(d, f), N(s, p), N(p, b), N(s, E), N(E, k);
    },
    d(w) {
      w && z(e);
    }
  };
}
function dp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k, w, _;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("clipPath"), l = j("rect"), o = j("g"), s = j("g"), u = j("g"), c = j("path"), d = j("g"), f = j("path"), p = j("g"), b = j("path"), E = j("g"), k = j("path"), w = j("g"), _ = j("path"), this.h();
    },
    l(v) {
      e = U(v, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var A = R(e);
      t = U(A, "defs", {});
      var x = R(t);
      r = U(x, "clipPath", { id: !0 });
      var Q = R(r);
      a = U(Q, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), Q.forEach(z), i = U(x, "clipPath", { id: !0 });
      var B = R(i);
      l = U(B, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(l).forEach(z), B.forEach(z), x.forEach(z), o = U(A, "g", { "clip-path": !0 });
      var O = R(o);
      s = U(O, "g", { "clip-path": !0 });
      var M = R(s);
      u = U(M, "g", {});
      var I = R(u);
      c = U(I, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(c).forEach(z), I.forEach(z), d = U(M, "g", {});
      var V = R(d);
      f = U(V, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(f).forEach(z), V.forEach(z), p = U(M, "g", {});
      var re = R(p);
      b = U(re, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(b).forEach(z), re.forEach(z), E = U(M, "g", {});
      var W = R(E);
      k = U(W, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(k).forEach(z), W.forEach(z), w = U(M, "g", {});
      var ae = R(w);
      _ = U(ae, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(_).forEach(z), ae.forEach(z), M.forEach(z), O.forEach(z), A.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_287/13_278"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_287/13_278/13_040"), D(c, "d", "M7.34851109375,12.6516259765625Q8.44685609375,13.7499259765625,10.00016609375,13.7499259765625Q11.55346609375,13.7499259765625,12.65181609375,12.6516259765625Q13.75016609375,11.5532659765625,13.75016609375,9.9999559765625L13.75016609375,4.5832959765625Q13.75016609375,3.0299959765624997,12.65181609375,1.9316429765625Q11.55346609375,0.8332929765625,10.00016609375,0.8332919765625Q8.44685609375,0.8332929765625,7.34851109375,1.9316429765625Q6.25016309375,3.0299959765624997,6.25016309375,4.5832959765625L6.25016309375,9.9999559765625Q6.25016309375,11.5532659765625,7.34851109375,12.6516259765625ZM11.47330609375,11.4730959765625Q10.86310609375,12.0833259765625,10.00016609375,12.0833259765625Q9.13721609375,12.0833259765625,8.527026093749999,11.4730959765625Q7.91682909375,10.8629059765625,7.91682909375,9.9999559765625L7.91683009375,4.5832959765625Q7.91683009375,3.7203459765625,8.527026093749999,3.1101559765625Q9.13721609375,2.4999589765625,10.00016609375,2.4999589765625Q10.86310609375,2.4999589765625,11.47330609375,3.1101559765625Q12.08349609375,3.7203459765625,12.08349609375,4.5832959765625L12.08349609375,9.9999559765625Q12.08349609375,10.8629059765625,11.47330609375,11.4730959765625Z"), D(c, "fill-rule", "evenodd"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "1"), ye(c, "mix-blend-mode", "passthrough"), D(f, "d", "M17.08315046875,9.6393233234375Q17.08502046875,9.6113801234375,17.08502046875,9.5833740234375Q17.08502046875,9.5011337234375,17.06898046875,9.4204740234375Q17.05293046875,9.3398140234375,17.02146046875,9.2638330234375Q16.98999046875,9.1878530234375,16.94430046875,9.1194730234375Q16.89861046875,9.0510930234375,16.84046046875,8.9929400234375Q16.78230046875,8.9347870234375,16.71392346875,8.8890970234375Q16.64554246875,8.8434070234375,16.56956246875,8.8119350234375Q16.49358246875,8.7804630234375,16.41292246875,8.7644180234375Q16.33226246875,8.7483740234375,16.25002246875,8.7483740234375Q16.16778146875,8.7483740234375,16.08712146875,8.7644180234375Q16.00646146875,8.7804630234375,15.93048146875,8.8119350234375Q15.85450146875,8.8434070234375,15.78612106875,8.8890970234375Q15.71774076875,8.9347870234375,15.65958806875,8.9929400234375Q15.60143546875,9.0510930234375,15.55574546875,9.1194730234375Q15.51005446875,9.1878530234375,15.47858246875,9.2638330234375Q15.44711046875,9.3398140234375,15.43106646875,9.4204740234375Q15.41502246875,9.5011337234375,15.41502246875,9.5833740234375Q15.41502246875,9.6080265234375,15.41647646875,9.6326360234375Q15.40712446875,10.7164940234375,14.98582546875,11.7046140234375Q14.89498046875,11.8831040234375,14.89498046875,12.0833740234375Q14.89498046875,12.1656140234375,14.91102446875,12.2462740234375Q14.92706946875,12.3269340234375,14.95854146875,12.4029140234375Q14.99001346875,12.4788940234375,15.03570346875,12.5472740234375Q15.08139346875,12.6156540234375,15.13954646875,12.6738040234375Q15.19769946875,12.7319640234375,15.26607946875,12.7776540234375Q15.33445946875,12.8233440234375,15.41043946875,12.8548140234375Q15.48642046875,12.8862840234375,15.56708046875,12.9023340234375Q15.64774016875,12.9183740234375,15.72998046875,12.9183740234375Q15.79409136875,12.9183740234375,15.85745046875,12.9085840234375Q15.92081046875,12.8988040234375,15.98193346875,12.8794540234375Q16.04305546875,12.8601140234375,16.10050846875,12.8316640234375Q16.15796246875,12.8032140234375,16.21039846875,12.7663240234375Q16.26283546875,12.7294440234375,16.309026468749998,12.6849840234375Q16.35521746875,12.6405240234375,16.39408046875,12.5895340234375Q16.43294246875,12.538544023437499,16.46356646875,12.4822240234375Q16.49418946875,12.4258940234375,16.51585446875,12.3655540234375Q17.07244046875,11.0643540234375,17.08315046875,9.6393233234375Z"), D(f, "fill-rule", "evenodd"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), ye(f, "mix-blend-mode", "passthrough"), D(b, "d", "M4.583527,9.6329521234375Q4.585,9.6081849234375,4.585,9.5833740234375Q4.585,9.5011337234375,4.568956,9.4204740234375Q4.552911,9.3398140234375,4.521439,9.2638330234375Q4.489967,9.1878530234375,4.444277,9.1194730234375Q4.398587,9.0510930234375,4.340434,8.9929400234375Q4.282281,8.9347870234375,4.213901,8.8890970234375Q4.1455210000000005,8.8434070234375,4.069541,8.8119350234375Q3.99356,8.7804630234375,3.9129,8.7644180234375Q3.8322403,8.7483740234375,3.75,8.7483740234375Q3.6677597,8.7483740234375,3.5871,8.7644180234375Q3.50644,8.7804630234375,3.430459,8.8119350234375Q3.354479,8.8434070234375,3.286099,8.8890970234375Q3.2177189999999998,8.9347870234375,3.159566,8.9929400234375Q3.101413,9.0510930234375,3.055723,9.1194730234375Q3.010033,9.1878530234375,2.978561,9.2638330234375Q2.947089,9.3398140234375,2.931044,9.4204740234375Q2.915,9.5011337234375,2.915,9.5833740234375Q2.915,9.6112012234375,2.916853,9.6389666234375Q2.9363479999999997,12.5370740234375,4.99132,14.5920540234375Q7.06598,16.6667040234375,10,16.6667040234375Q11.1917,16.6667040234375,12.30806,16.2819440234375Q12.37346,16.2636640234375,12.43505,16.235064023437502Q12.49663,16.2064640234375,12.55279,16.1682840234375Q12.60894,16.1301040234375,12.65819,16.0833540234375Q12.70744,16.036604023437498,12.74849,15.9825140234375Q12.78954,15.9284240234375,12.82131,15.868404023437499Q12.85308,15.8083940234375,12.87473,15.7440340234375Q12.89639,15.6796740234375,12.90736,15.6126640234375Q12.91833,15.5456540234375,12.91833,15.4777440234375Q12.91833,15.3955040234375,12.90229,15.3148440234375Q12.88624,15.2341840234375,12.85477,15.1582040234375Q12.8233,15.082224023437501,12.77761,15.0138440234375Q12.73192,14.9454640234375,12.67377,14.8873140234375Q12.61561,14.8291640234375,12.54723,14.783474023437499Q12.47885,14.7377840234375,12.40287,14.7063140234375Q12.32689,14.6748340234375,12.24623,14.658794023437501Q12.16557,14.6427540234375,12.08333,14.642744023437501Q11.91469,14.642744023437501,11.75926,14.7082040234375Q10.9093,15.0000440234375,10,15.0000440234375Q7.75633,15.0000440234375,6.16983,13.413544023437499Q4.6008890000000005,11.8445940234375,4.583527,9.6329521234375Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), ye(b, "mix-blend-mode", "passthrough"), D(k, "d", "M10.833333,15.8861049234375Q10.835,15.8597658234375,10.835,15.8333740234375Q10.835,15.7511337234375,10.818956,15.6704740234375Q10.802911,15.5898140234375,10.771439,15.5138330234375Q10.739967,15.4378530234375,10.694277,15.3694730234375Q10.648587,15.3010930234375,10.590434,15.2429400234375Q10.532281,15.1847870234375,10.463901,15.1390970234375Q10.395521,15.0934070234375,10.319541,15.0619350234375Q10.24356,15.0304630234375,10.1629,15.0144180234375Q10.0822403,14.9983740234375,10,14.9983740234375Q9.9177597,14.9983740234375,9.8371,15.0144180234375Q9.75644,15.0304630234375,9.680459,15.0619350234375Q9.604479,15.0934070234375,9.536099,15.1390970234375Q9.467719,15.1847870234375,9.409566,15.2429400234375Q9.351413,15.3010930234375,9.305723,15.3694730234375Q9.260033,15.4378530234375,9.228561,15.5138330234375Q9.197089,15.5898140234375,9.181044,15.6704740234375Q9.165,15.7511337234375,9.165,15.8333740234375Q9.165,15.8597658234375,9.166667,15.8861049234375L9.166667,18.2806440234375Q9.165,18.3069840234375,9.165,18.3333740234375Q9.165,18.4156140234375,9.181044,18.4962740234375Q9.197089,18.5769340234375,9.228561,18.6529140234375Q9.260033,18.7288940234375,9.305723,18.7972740234375Q9.351413,18.8656540234375,9.409566,18.9238040234375Q9.467719,18.9819640234375,9.536099,19.0276540234375Q9.604479,19.0733440234375,9.680459,19.1048140234375Q9.75644,19.1362840234375,9.8371,19.1523340234375Q9.9177597,19.1683740234375,10,19.1683740234375Q10.0822403,19.1683740234375,10.1629,19.1523340234375Q10.24356,19.1362840234375,10.319541,19.1048140234375Q10.395521,19.0733440234375,10.463901,19.0276540234375Q10.532281,18.9819640234375,10.590434,18.9238040234375Q10.648587,18.8656540234375,10.694277,18.7972740234375Q10.739967,18.7288940234375,10.771439,18.6529140234375Q10.802911,18.5769340234375,10.818956,18.4962740234375Q10.835,18.4156140234375,10.835,18.3333740234375Q10.835,18.3069840234375,10.833333,18.2806440234375L10.833333,15.8861049234375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), ye(k, "mix-blend-mode", "passthrough"), D(_, "d", "M1.9480309999999998,3.126542Q1.813081,3.007654,1.7390400000000001,2.843752Q1.665,2.67985,1.665,2.5Q1.665,2.4177597,1.681044,2.3371Q1.697089,2.25644,1.728561,2.180459Q1.760033,2.104479,1.805723,2.036099Q1.851413,1.967719,1.9095659999999999,1.9095659999999999Q1.967719,1.851413,2.036099,1.805723Q2.104479,1.760033,2.180459,1.728561Q2.25644,1.697089,2.3371,1.681044Q2.4177597,1.665,2.5,1.665Q2.67985,1.665,2.843752,1.7390400000000001Q3.007654,1.813081,3.126542,1.9480309999999998L18.052,16.8735Q18.1869,16.9923,18.261,17.1562Q18.335,17.3202,18.335,17.5Q18.335,17.5822,18.319000000000003,17.6629Q18.3029,17.7436,18.2714,17.819499999999998Q18.240000000000002,17.8955,18.1943,17.963900000000002Q18.148600000000002,18.0323,18.090400000000002,18.090400000000002Q18.0323,18.148600000000002,17.963900000000002,18.1943Q17.8955,18.240000000000002,17.819499999999998,18.2714Q17.7436,18.3029,17.6629,18.319000000000003Q17.5822,18.335,17.5,18.335Q17.3202,18.335,17.1562,18.261Q16.9923,18.1869,16.8735,18.052L1.9480309999999998,3.126542Z"), D(_, "fill-rule", "evenodd"), D(_, "fill", "#FFFFFF"), D(_, "fill-opacity", "1"), ye(_, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_287/13_278/13_040)"), D(o, "clip-path", "url(#master_svg0_13_287/13_278)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(v, A) {
      A0(v, e, A), N(e, t), N(t, r), N(r, a), N(t, i), N(i, l), N(e, o), N(o, s), N(s, u), N(u, c), N(s, d), N(d, f), N(s, p), N(p, b), N(s, E), N(E, k), N(s, w), N(w, _);
    },
    d(v) {
      v && z(e);
    }
  };
}
function b4(n) {
  let e, t, r;
  return {
    c() {
      e = Ze("div"), this.h();
    },
    l(a) {
      e = We(a, "DIV", { class: !0 }), R(e).forEach(z), this.h();
    },
    h() {
      D(e, "class", "corner svelte-1k2qcvm");
    },
    m(a, i) {
      A0(a, e, i), t || (r = Nt(
        e,
        "click",
        /*open_mic_list*/
        n[32]
      ), t = !0);
    },
    p: fn,
    d(a) {
      a && z(e), t = !1, r();
    }
  };
}
function w4(n) {
  let e, t = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="none" version="1.1" width="14.000000357627869" height="10.000000357627869" viewBox="0 0 14.000000357627869 10.000000357627869"><g><path d="M13.802466686534881,1.1380186865348816Q13.89646668653488,1.0444176865348815,13.947366686534881,0.9218876865348815Q13.998366686534881,0.7993576865348816,13.998366686534881,0.6666666865348816Q13.998366686534881,0.6011698865348816,13.98556668653488,0.5369316865348817Q13.972766686534882,0.4726936865348816,13.947666686534882,0.4121826865348816Q13.922666686534882,0.3516706865348816,13.886266686534881,0.2972126865348816Q13.849866686534881,0.2427536865348816,13.803566686534882,0.19644068653488161Q13.757266686534882,0.15012768653488162,13.702766686534881,0.11373968653488165Q13.648366686534882,0.07735168653488156,13.587866686534882,0.052286686534881555Q13.527266686534881,0.02722268653488158,13.463066686534882,0.014444686534881623Q13.398866686534882,0.0016666865348815563,13.333366686534882,0.0016666865348815563Q13.201466686534882,0.0016666865348815563,13.079566686534882,0.051981686534881555Q12.957666686534882,0.10229768653488158,12.864266686534881,0.1953146865348816L12.863066686534882,0.19413268653488158L4.624996686534882,8.392776686534882L1.1369396865348815,4.921396686534882L1.1357636865348817,4.922586686534881Q1.0422996865348817,4.829566686534881,0.9204146865348816,4.779246686534882Q0.7985286865348816,4.728936686534881,0.6666666865348816,4.728936686534881Q0.6011698865348816,4.728936686534881,0.5369316865348817,4.741706686534882Q0.4726936865348816,4.754486686534881,0.4121826865348816,4.779556686534882Q0.3516706865348816,4.804616686534882,0.2972126865348816,4.8410066865348815Q0.2427536865348816,4.8773966865348815,0.19644068653488161,4.9237066865348815Q0.15012768653488162,4.970016686534882,0.11373968653488165,5.024476686534881Q0.07735168653488156,5.078936686534882,0.052286686534881555,5.139446686534882Q0.02722268653488158,5.199956686534882,0.014444686534881623,5.2641966865348815Q0.0016666865348815563,5.328436686534881,0.0016666865348815563,5.3939366865348815Q0.0016666865348815563,5.526626686534882,0.05259268653488158,5.649156686534882Q0.10351768653488158,5.771686686534881,0.1975696865348816,5.865286686534882L0.1963936865348816,5.866466686534881L4.1547266865348815,9.805866686534882Q4.201126686534882,9.852046686534882,4.255616686534882,9.888306686534882Q4.310106686534882,9.924576686534882,4.3706166865348814,9.949556686534882Q4.431126686534881,9.974536686534881,4.495326686534882,9.987266686534882Q4.559536686534882,9.999996686534882,4.624996686534882,9.999996686534882Q4.690456686534882,9.999996686534882,4.754666686534882,9.987266686534882Q4.818876686534882,9.974536686534881,4.879386686534882,9.949556686534882Q4.939886686534882,9.924576686534882,4.994386686534882,9.888306686534882Q5.048876686534881,9.852046686534882,5.0952766865348815,9.805866686534882L13.803566686534882,1.1392006865348816L13.802466686534881,1.1380186865348816Z" fill-rule="evenodd" fill="#E0E0FC" fill-opacity="1" style="mix-blend-mode:passthrough"></path></g></svg>';
  return {
    c() {
      e = Ze("div"), e.innerHTML = t, this.h();
    },
    l(r) {
      e = We(r, "DIV", { class: !0, "data-svelte-h": !0 }), ci(e) !== "svelte-c8s251" && (e.innerHTML = t), this.h();
    },
    h() {
      D(e, "class", "active-icon svelte-1k2qcvm");
    },
    m(r, a) {
      A0(r, e, a);
    },
    d(r) {
      r && z(e);
    }
  };
}
function y4(n) {
  let e, t = (
    /*device*/
    n[62].label + ""
  ), r, a, i, l, o, s = (
    /*selected_audio_device*/
    n[5] && /*device*/
    n[62].deviceId === /*selected_audio_device*/
    n[5].deviceId && w4()
  );
  function u(...c) {
    return (
      /*click_handler_2*/
      n[51](
        /*device*/
        n[62],
        ...c
      )
    );
  }
  return {
    c() {
      e = Ze("div"), r = m3(t), a = O0(), s && s.c(), i = O0(), this.h();
    },
    l(c) {
      e = We(c, "DIV", { class: !0 });
      var d = R(e);
      r = h3(d, t), a = q0(d), s && s.l(d), i = q0(d), d.forEach(z), this.h();
    },
    h() {
      D(e, "class", "selector svelte-1k2qcvm");
    },
    m(c, d) {
      A0(c, e, d), N(e, r), N(e, a), s && s.m(e, null), N(e, i), l || (o = Nt(e, "click", d3(u)), l = !0);
    },
    p(c, d) {
      n = c, d[0] & /*available_audio_devices*/
      8 && t !== (t = /*device*/
      n[62].label + "") && f3(r, t), /*selected_audio_device*/
      n[5] && /*device*/
      n[62].deviceId === /*selected_audio_device*/
      n[5].deviceId ? s || (s = w4(), s.c(), s.m(e, i)) : s && (s.d(1), s = null);
    },
    d(c) {
      c && z(e), s && s.d(), l = !1, o();
    }
  };
}
function mp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("clipPath"), l = j("rect"), o = j("g"), s = j("g"), u = j("g"), c = j("rect"), d = j("g"), f = j("path"), p = j("g"), b = j("path"), E = j("g"), k = j("path"), this.h();
    },
    l(w) {
      e = U(w, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var _ = R(e);
      t = U(_, "defs", {});
      var v = R(t);
      r = U(v, "clipPath", { id: !0 });
      var A = R(r);
      a = U(A, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), A.forEach(z), i = U(v, "clipPath", { id: !0 });
      var x = R(i);
      l = U(x, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(l).forEach(z), x.forEach(z), v.forEach(z), o = U(_, "g", { "clip-path": !0 });
      var Q = R(o);
      s = U(Q, "g", { "clip-path": !0 });
      var B = R(s);
      u = U(B, "g", {});
      var O = R(u);
      c = U(O, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(c).forEach(z), O.forEach(z), d = U(B, "g", {});
      var M = R(d);
      f = U(M, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(f).forEach(z), M.forEach(z), p = U(B, "g", {});
      var I = R(p);
      b = U(I, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(b).forEach(z), I.forEach(z), E = U(B, "g", {});
      var V = R(E);
      k = U(V, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(k).forEach(z), V.forEach(z), B.forEach(z), Q.forEach(z), _.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_280"), D(l, "x", "0"), D(l, "y", "0"), D(l, "width", "20"), D(l, "height", "20"), D(l, "rx", "0"), D(i, "id", "master_svg1_13_280/13_053"), D(c, "x", "0"), D(c, "y", "0"), D(c, "width", "20"), D(c, "height", "20"), D(c, "rx", "0"), D(c, "fill", "#FFFFFF"), D(c, "fill-opacity", "0.009999999776482582"), ye(c, "mix-blend-mode", "passthrough"), D(f, "d", "M4.443888046875,5.42117L2.500081046875,5.42117Q1.809725046875,5.42117,1.321573046875,5.90931Q0.833415046875,6.39747,0.833415046875,7.08783L0.833415046875,12.8496Q0.833415046875,13.54,1.321574046875,14.0281Q1.809725046875,14.5163,2.500081046875,14.5163L4.439858046875,14.5163Q6.771998046875,18.3333,10.000078046875,18.3333Q10.082158046875,18.3333,10.162658046875,18.3173Q10.243158046875,18.301299999999998,10.318988046875,18.2699Q10.394808046875,18.238500000000002,10.463058046875,18.1929Q10.531298046875,18.1473,10.589338046875,18.0893Q10.647378046875,18.0312,10.692968046875,17.963Q10.738568046875,17.8947,10.769978046875,17.8189Q10.801388046875,17.7431,10.817398046875,17.662599999999998Q10.833418046875,17.5821,10.833418046875,17.5L10.833418046875,2.5Q10.833418046875,2.4179238,10.817398046875,2.337425Q10.801388046875,2.256926,10.769978046875,2.181097Q10.738568046875,2.105269,10.692968046875,2.037025Q10.647368046875,1.968781,10.589338046875,1.910744Q10.531298046875,1.852708,10.463058046875,1.807109Q10.394808046875,1.76151,10.318988046875,1.7301009999999999Q10.243158046875,1.698691,10.162658046875,1.682679Q10.082158046875,1.666667,10.000078046875,1.666667Q6.776438046875,1.666667,4.443888046875,5.42117ZM4.916118046875,7.08783Q5.025838046875,7.08783,5.131818046875,7.05943Q5.237798046875,7.03103,5.3328180468749995,6.97617Q5.427828046875,6.92131,5.505408046875,6.84372Q5.582988046875,6.76614,5.637838046875,6.67111Q7.228838046875,3.91495,9.166748046875,3.434681L9.166748046875,16.563299999999998Q7.232128046875,16.074199999999998,5.6407880468750005,13.2715Q5.586248046875,13.1754,5.508548046875,13.0969Q5.4308580468750005,13.0184,5.335388046875,12.9628Q5.239908046875,12.9072,5.1332580468749995,12.8784Q5.026598046875,12.8496,4.916118046875,12.8496L2.500081046875,12.8496L2.500082046875,7.08783L4.916118046875,7.08783Z"), D(f, "fill-rule", "evenodd"), D(f, "fill", "#FFFFFF"), D(f, "fill-opacity", "1"), ye(f, "mix-blend-mode", "passthrough"), D(b, "d", "M12.813896953124999,6.903831Q12.740067953125,6.845187,12.681175953125,6.771557Q12.622282953125,6.697926,12.581291953125,6.613017Q12.540300953125,6.528109,12.519276953125,6.436197Q12.498251953125,6.3442856,12.498251953125,6.25Q12.498251953125,6.1677597,12.514295953125,6.0871Q12.530340953125,6.00644,12.561812953125,5.930459Q12.593284953125,5.8544789999999995,12.638974953125,5.786099Q12.684664953125,5.717719,12.742817953125,5.659566Q12.800970953125,5.601413,12.869350953125,5.555723Q12.937730953125,5.510033,13.013710953125,5.478561Q13.089691953125,5.447089,13.170351953125,5.431044Q13.251011653125,5.415,13.333251953125,5.415Q13.501904953125,5.415,13.657335953125,5.4804580000000005Q13.812766953125,5.545916,13.930607953125,5.66657Q14.362131953125001,6.059567,14.707911953125,6.532997Q15.248111953125001,7.2726299999999995,15.535961953125,8.14354Q15.833251953125,9.04304,15.833251953125,10Q15.833251953125,10.94869,15.540941953125,11.84127Q15.257921953125,12.70551,14.726221953125,13.4418Q14.373671953125,13.92992,13.930609953125,14.33343Q13.812768953125,14.45408,13.657336953125,14.51954Q13.501904953125,14.585,13.333251953125,14.585Q13.251011653125,14.585,13.170351953125,14.56895Q13.089691953125,14.55291,13.013710953125,14.52144Q12.937730953125,14.48997,12.869350953125,14.44428Q12.800970953125,14.39859,12.742817953125,14.34043Q12.684664953125,14.28228,12.638974953125,14.213899999999999Q12.593284953125,14.145520000000001,12.561812953125,14.06954Q12.530340953125,13.99356,12.514295953125,13.9129Q12.498251953125,13.832239999999999,12.498251953125,13.75Q12.498251953125,13.655719999999999,12.519276953125,13.5638Q12.540300953125,13.47189,12.581291953125,13.386980000000001Q12.622282953125,13.30207,12.681174953125,13.228439999999999Q12.740067953125,13.154810000000001,12.813895953125,13.09617Q13.125969953125,12.8109,13.375114153125,12.46595Q14.166584953125,11.36993,14.166584953125,10Q14.166584953125,8.61762,13.362005753125,7.516Q13.117749953125,7.181583,12.813896953124999,6.903831Z"), D(b, "fill-rule", "evenodd"), D(b, "fill", "#FFFFFF"), D(b, "fill-opacity", "1"), ye(b, "mix-blend-mode", "passthrough"), D(k, "d", "M14.863105578125,2.228405984375Q16.823672578125,3.456592984375,17.969842578125,5.468508984375Q19.166602578125,7.569218984375,19.166602578125,10.000018984375Q19.166602578125,12.469708984375,17.933552578125,14.594658984375Q16.751772578125,16.631258984375002,14.739248578125,17.847858984375Q14.525103578125,17.995758984375,14.264892578125,17.995758984375Q14.182652278125,17.995758984375,14.101992578125,17.979658984375Q14.021332578125,17.963658984375,13.945351578125,17.932158984375Q13.869371578125,17.900658984375,13.800991578125,17.854958984375Q13.732611578125,17.809358984375002,13.674458578125,17.751158984375Q13.616305578125,17.692958984375,13.570615578125,17.624658984375Q13.524925578125,17.556258984375,13.493453578125,17.480258984375Q13.461981578125,17.404258984374998,13.445936578125,17.323658984375Q13.429892578125,17.242958984375,13.429892578125,17.160758984375Q13.429892578125,17.045958984374998,13.460862578124999,16.935458984375Q13.491831578125,16.824858984375,13.551473578125,16.726858984375Q13.611115578125,16.628758984375,13.695005578125,16.550458984375Q13.778896578125,16.472058984375,13.880811578125,16.419258984375Q15.525652578125,15.423558984375,16.492012578125,13.758158984375Q17.499932578125,12.021168984375,17.499932578125,10.000018984375Q17.499932578125,8.010658984374999,16.521692578125,6.293508984375Q15.584492578125,4.648418984375,13.982075578125,3.643182984375Q13.882499578125,3.589574984375,13.800770578125,3.511412984375Q13.719041578125,3.433249984375,13.661047578125,3.336162984375Q13.603053578125,3.239076984375,13.572972578125,3.130062984375Q13.542891578125,3.021047984375,13.542891578125,2.907958984375Q13.542891578125,2.825718684375,13.558936578125,2.745058984375Q13.574980578125,2.664398984375,13.606452578125,2.588417984375Q13.637924578125,2.512437984375,13.683614578125,2.444057984375Q13.729305578125,2.3756779843749998,13.787457578125,2.317524984375Q13.845610578125,2.259371984375,13.913990578125,2.213681984375Q13.982370578125,2.167991984375,14.058351578125,2.136519984375Q14.134331578125,2.105047984375,14.214991478125,2.089002984375Q14.295651478125,2.072958984375,14.377891578125,2.072958984375Q14.508378578125,2.072958984375,14.632644578125,2.112769984375Q14.756910578125,2.152579984375,14.863105578125,2.228405984375Z"), D(k, "fill-rule", "evenodd"), D(k, "fill", "#FFFFFF"), D(k, "fill-opacity", "1"), ye(k, "mix-blend-mode", "passthrough"), D(s, "clip-path", "url(#master_svg1_13_280/13_053)"), D(o, "clip-path", "url(#master_svg0_13_280)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(w, _) {
      A0(w, e, _), N(e, t), N(t, r), N(r, a), N(t, i), N(i, l), N(e, o), N(o, s), N(s, u), N(u, c), N(s, d), N(d, f), N(s, p), N(p, b), N(s, E), N(E, k);
    },
    d(w) {
      w && z(e);
    }
  };
}
function pp(n) {
  let e, t, r, a, i, l, o, s, u, c, d;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("g"), l = j("g"), o = j("path"), s = j("g"), u = j("path"), c = j("g"), d = j("path"), this.h();
    },
    l(f) {
      e = U(f, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var p = R(e);
      t = U(p, "defs", {});
      var b = R(t);
      r = U(b, "clipPath", { id: !0 });
      var E = R(r);
      a = U(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), E.forEach(z), b.forEach(z), i = U(p, "g", { "clip-path": !0 });
      var k = R(i);
      l = U(k, "g", {});
      var w = R(l);
      o = U(w, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(o).forEach(z), w.forEach(z), s = U(k, "g", {});
      var _ = R(s);
      u = U(_, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(u).forEach(z), _.forEach(z), c = U(k, "g", {});
      var v = R(c);
      d = U(v, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0,
        style: !0
      }), R(d).forEach(z), v.forEach(z), k.forEach(z), p.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_20_113"), D(o, "d", "M17.52452171875,9.078936578124999Q17.659471718749998,8.960048578125,17.73351171875,8.796145578125Q17.80755171875,8.632242578125,17.80755171875,8.452392578125Q17.80755171875,8.370152278125,17.79151171875,8.289492578125Q17.77546171875,8.208832578125,17.74399171875,8.132851578125Q17.71252171875,8.056871578125,17.66683171875,7.988491578125Q17.62114171875,7.920111578125,17.56299171875,7.861958578125Q17.50483171875,7.803805578125,17.43645171875,7.758115578125Q17.36807171875,7.712425578125,17.29209171875,7.680953578125Q17.21611171875,7.649481578125,17.13545171875,7.633436578125Q17.05479171875,7.617392578125,16.97255171875,7.617392578125Q16.79270171875,7.617392578125,16.62880171875,7.691433578125Q16.46490171875,7.765474578125,16.34601171875,7.900425578125L12.88504271875,11.361392578124999Q12.75009271875,11.480282578125,12.67605171875,11.644182578125001Q12.60201171875,11.808082578125,12.60201171875,11.987932578125001Q12.60201171875,12.070172578125,12.61805571875,12.150832578125Q12.63410071875,12.231492578125,12.66557271875,12.307472578125001Q12.69704471875,12.383452578125,12.74273471875,12.451832578125Q12.78842471875,12.520212578125001,12.84657771875,12.578362578124999Q12.90473071875,12.636522578125,12.97311071875,12.682212578125Q13.04149071875,12.727902578125,13.11747071875,12.759372578125Q13.19345171875,12.790842578125,13.27411171875,12.806892578125Q13.35477141875,12.822932578125,13.43701171875,12.822932578125Q13.61685971875,12.822932578125,13.78076071875,12.748892578125Q13.94466171875,12.674852578125,14.06354971875,12.539902578125L17.52452171875,9.078936578124999Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), ye(o, "mix-blend-mode", "passthrough"), D(u, "d", "M12.88553,9.078933578125Q12.75058,8.960045578125,12.67654,8.796143578125Q12.6025,8.632241578125,12.6025,8.452392578125Q12.6025,8.370152278125,12.618544,8.289492578125Q12.634589,8.208832578125,12.666061,8.132851578125Q12.697533,8.056871578125,12.743223,7.988491578125Q12.788913,7.920111578125,12.847066,7.861958578125Q12.905219,7.803805578125,12.973599,7.758115578125Q13.041979,7.712425578125,13.117959,7.680953578125Q13.19394,7.649481578125,13.2746,7.633436578125Q13.3552597,7.617392578125,13.4375,7.617392578125Q13.617349,7.617392578125,13.781251,7.691432578125Q13.945153,7.765472578125,14.064041,7.900422578125L17.52501,11.361392578124999Q17.659959999999998,11.480282578125,17.734,11.644182578125001Q17.80804,11.808082578125,17.80804,11.987932578125001Q17.80804,12.070172578125,17.792,12.150832578125Q17.77595,12.231492578125,17.74448,12.307472578125001Q17.71301,12.383452578125,17.66732,12.451832578125Q17.62163,12.520212578125001,17.56347,12.578362578124999Q17.50532,12.636522578125,17.43694,12.682212578125Q17.36856,12.727902578125,17.29258,12.759372578125Q17.2166,12.790842578125,17.13594,12.806892578125Q17.05528,12.822932578125,16.97304,12.822932578125Q16.79319,12.822932578125,16.62929,12.748892578125Q16.46539,12.674852578125,16.3465,12.539902578125L12.88553,9.078933578125Z"), D(u, "fill-rule", "evenodd"), D(u, "fill", "#FFFFFF"), D(u, "fill-opacity", "1"), ye(u, "mix-blend-mode", "passthrough"), D(d, "d", "M4.44364390625,5.42117L2.49983690625,5.42117Q1.80948090625,5.42117,1.32132890625,5.90931Q0.83317090625,6.39747,0.83317090625,7.08783L0.83317090625,12.8496Q0.83317090625,13.54,1.32132990625,14.0281Q1.80948090625,14.5163,2.49983690625,14.5163L4.43961390625,14.5163Q6.77175390625,18.3333,9.99983390625,18.3333Q10.08191390625,18.3333,10.16241390625,18.3173Q10.24291390625,18.301299999999998,10.31874390625,18.2699Q10.39456390625,18.238500000000002,10.46281390625,18.1929Q10.53105390625,18.1473,10.58909390625,18.0893Q10.64713390625,18.0312,10.69272390625,17.963Q10.73832390625,17.8947,10.76973390625,17.8189Q10.80114390625,17.7431,10.81715390625,17.662599999999998Q10.83317390625,17.5821,10.83317390625,17.5L10.83317390625,2.5Q10.83317390625,2.4179238,10.81715390625,2.337425Q10.80114390625,2.256926,10.76973390625,2.181097Q10.73832390625,2.105269,10.69272390625,2.037025Q10.64712390625,1.968781,10.58909390625,1.910744Q10.53105390625,1.852708,10.46281390625,1.807109Q10.39456390625,1.76151,10.31874390625,1.7301009999999999Q10.24291390625,1.698691,10.16241390625,1.682679Q10.08191390625,1.666667,9.99983390625,1.666667Q6.77619390625,1.666667,4.44364390625,5.42117ZM4.91587390625,7.08783Q5.02559390625,7.08783,5.13157390625,7.05943Q5.23755390625,7.03103,5.3325739062499995,6.97617Q5.42758390625,6.92131,5.50516390625,6.84372Q5.58274390625,6.76614,5.63759390625,6.67111Q7.22859390625,3.91495,9.16650390625,3.434681L9.16650390625,16.563299999999998Q7.23188390625,16.074199999999998,5.6405439062500005,13.2715Q5.58600390625,13.1754,5.50830390625,13.0969Q5.4306139062500005,13.0184,5.33514390625,12.9628Q5.23966390625,12.9072,5.1330139062499995,12.8784Q5.02635390625,12.8496,4.91587390625,12.8496L2.49983690625,12.8496L2.49983790625,7.08783L4.91587390625,7.08783Z"), D(d, "fill-rule", "evenodd"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), ye(d, "mix-blend-mode", "passthrough"), D(i, "clip-path", "url(#master_svg0_20_113)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(f, p) {
      A0(f, e, p), N(e, t), N(t, r), N(r, a), N(e, i), N(i, l), N(l, o), N(i, s), N(s, u), N(i, c), N(c, d);
    },
    d(f) {
      f && z(e);
    }
  };
}
function gp(n) {
  let e, t, r, a, i, l, o, s, u, c, d;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("g"), l = j("g"), o = j("path"), s = j("g"), u = j("path"), c = j("g"), d = j("path"), this.h();
    },
    l(f) {
      e = U(f, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var p = R(e);
      t = U(p, "defs", {});
      var b = R(t);
      r = U(b, "clipPath", { id: !0 });
      var E = R(r);
      a = U(E, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), E.forEach(z), b.forEach(z), i = U(p, "g", { "clip-path": !0 });
      var k = R(i);
      l = U(k, "g", {});
      var w = R(l);
      o = U(w, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), R(o).forEach(z), w.forEach(z), s = U(k, "g", {});
      var _ = R(s);
      u = U(_, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), R(u).forEach(z), _.forEach(z), c = U(k, "g", {});
      var v = R(c);
      d = U(v, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), R(d).forEach(z), v.forEach(z), k.forEach(z), p.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_533/13_323"), D(o, "d", "M7.5,5.0016259765625Q7.58224,5.0016259765625,7.6629,4.9855819765625Q7.74356,4.9695369765625,7.81954,4.9380649765625Q7.89552,4.9065929765625,7.9639,4.8609029765625Q8.03228,4.8152129765625,8.09043,4.7570599765625Q8.14859,4.6989069765625,8.19428,4.6305269765625Q8.23997,4.5621469765625005,8.27144,4.4861669765625Q8.30291,4.4101859765625,8.318950000000001,4.3295259765625Q8.335,4.2488662765625,8.335,4.1666259765625Q8.335,4.0843856765625,8.31896,4.0037259765625Q8.30291,3.9230659765625,8.27144,3.8470849765625Q8.23997,3.7711049765625,8.19428,3.7027249765625Q8.14859,3.6343449765624998,8.09043,3.5761919765625Q8.03228,3.5180389765625,7.9639,3.4723489765625Q7.89552,3.4266589765625,7.81954,3.3951869765625Q7.74356,3.3637149765625,7.6629,3.3476699765625Q7.58224,3.3316259765625,7.5,3.3316259765625Q7.47361,3.3316259765625,7.44727,3.3332929765625L4.16667,3.3332929765625Q3.131133,3.3332929765625,2.3989,4.0655259765625Q1.666667,4.7977589765625,1.666667,5.8332959765625L1.666667,14.1666259765625Q1.666667,15.2021259765625,2.3989,15.9344259765625Q3.131133,16.6666259765625,4.16667,16.6666259765625L7.44728,16.6666259765625Q7.47361,16.6683259765625,7.5,16.6683259765625Q7.58224,16.6683259765625,7.6629,16.652225976562498Q7.74356,16.6362259765625,7.81954,16.6047259765625Q7.89552,16.573225976562497,7.9639,16.5275259765625Q8.03228,16.4819259765625,8.09043,16.4237259765625Q8.14859,16.365525976562502,8.19428,16.2972259765625Q8.23997,16.2288259765625,8.27144,16.1528259765625Q8.30291,16.0768259765625,8.318950000000001,15.9962259765625Q8.335,15.9155259765625,8.335,15.8333259765625Q8.335,15.7510259765625,8.31896,15.6704259765625Q8.30291,15.5897259765625,8.27144,15.5137259765625Q8.23997,15.4377259765625,8.19428,15.3694259765625Q8.14859,15.3010259765625,8.09043,15.2428259765625Q8.03228,15.1847259765625,7.9639,15.1390259765625Q7.89552,15.0933259765625,7.81954,15.0618259765625Q7.74356,15.0304259765625,7.6629,15.0143259765625Q7.58224,14.9983259765625,7.5,14.9983259765625Q7.47361,14.9983259765625,7.44728,14.9999259765625L4.16667,14.9999259765625Q3.82149,14.9999259765625,3.57741,14.7559259765625Q3.333333,14.5118259765625,3.333333,14.1666259765625L3.333333,5.8332959765625Q3.333333,5.4881159765625,3.57741,5.2440359765625Q3.82149,4.9999589765625,4.16667,4.9999589765625L7.44727,4.9999589765625Q7.47361,5.0016259765625,7.5,5.0016259765625Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), D(u, "d", "M12.55273,4.9999589765625Q12.5263913,5.0016259765625,12.5,5.0016259765625Q12.4177597,5.0016259765625,12.3371,4.9855819765625Q12.25644,4.9695369765625,12.180459,4.9380649765625Q12.104479,4.9065929765625,12.036099,4.8609029765625Q11.967719,4.8152129765625,11.909566,4.7570599765625Q11.851413,4.6989069765625,11.805723,4.6305269765625Q11.760033,4.5621469765625005,11.728561,4.4861669765625Q11.697089,4.4101859765625,11.681044,4.3295259765625Q11.665,4.2488662765625,11.665,4.1666259765625Q11.665,4.0843856765625,11.681044,4.0037259765625Q11.697089,3.9230659765625,11.728561,3.8470849765625Q11.760033,3.7711049765625,11.805723,3.7027249765625Q11.851413,3.6343449765624998,11.909566,3.5761919765625Q11.967719,3.5180389765625,12.036099,3.4723489765625Q12.104479,3.4266589765625,12.180459,3.3951869765625Q12.25644,3.3637149765625,12.3371,3.3476699765625Q12.4177597,3.3316259765625,12.5,3.3316259765625Q12.5263913,3.3316259765625,12.55273,3.3332929765625L15.83333,3.3332929765625Q16.86887,3.3332929765625,17.6011,4.0655259765625Q18.33333,4.7977589765625,18.33333,5.8332959765625L18.33333,14.1666259765625Q18.33333,15.2021259765625,17.6011,15.9344259765625Q16.86887,16.6666259765625,15.83333,16.6666259765625L12.5527215,16.6666259765625Q12.5263871,16.6683259765625,12.5,16.6683259765625Q12.4177597,16.6683259765625,12.3371,16.652225976562498Q12.25644,16.6362259765625,12.180459,16.6047259765625Q12.104479,16.573225976562497,12.036099,16.5275259765625Q11.967719,16.4819259765625,11.909566,16.4237259765625Q11.851413,16.365525976562502,11.805723,16.2972259765625Q11.760033,16.2288259765625,11.728561,16.1528259765625Q11.697089,16.0768259765625,11.681044,15.9962259765625Q11.665,15.9155259765625,11.665,15.8333259765625Q11.665,15.7510259765625,11.681044,15.6704259765625Q11.697089,15.5897259765625,11.728561,15.5137259765625Q11.760033,15.4377259765625,11.805723,15.3694259765625Q11.851413,15.3010259765625,11.909566,15.2428259765625Q11.967719,15.1847259765625,12.036099,15.1390259765625Q12.104479,15.0933259765625,12.180459,15.0618259765625Q12.25644,15.0304259765625,12.3371,15.0143259765625Q12.4177597,14.9983259765625,12.5,14.9983259765625Q12.5263871,14.9983259765625,12.5527215,14.9999259765625L15.83333,14.9999259765625Q16.17851,14.9999259765625,16.42259,14.7559259765625Q16.66667,14.5118259765625,16.66667,14.1666259765625L16.66667,5.8332959765625Q16.66667,5.4881159765625,16.42259,5.2440359765625Q16.17851,4.9999589765625,15.83333,4.9999589765625L12.55273,4.9999589765625Z"), D(u, "fill-rule", "evenodd"), D(u, "fill", "#FFFFFF"), D(u, "fill-opacity", "1"), D(d, "d", "M10.833333,2.5527319Q10.835,2.5263923,10.835,2.5Q10.835,2.4177597,10.818956,2.3371Q10.802911,2.25644,10.771439,2.180459Q10.739967,2.104479,10.694277,2.036099Q10.648587,1.967719,10.590434,1.9095659999999999Q10.532281,1.851413,10.463901,1.805723Q10.395521,1.760033,10.319541,1.728561Q10.24356,1.697089,10.1629,1.681044Q10.0822403,1.665,10,1.665Q9.9177597,1.665,9.8371,1.681044Q9.75644,1.697089,9.680459,1.728561Q9.604479,1.760033,9.536099,1.805723Q9.467719,1.851413,9.409566,1.9095659999999999Q9.351413,1.967719,9.305723,2.036099Q9.260033,2.104479,9.228561,2.180459Q9.197089,2.25644,9.181044,2.3371Q9.165,2.4177597,9.165,2.5Q9.165,2.5263923,9.166667,2.5527319L9.166667,17.4473Q9.165,17.473599999999998,9.165,17.5Q9.165,17.5822,9.181044,17.6629Q9.197089,17.7436,9.228561,17.819499999999998Q9.260033,17.8955,9.305723,17.963900000000002Q9.351413,18.0323,9.409566,18.090400000000002Q9.467719,18.148600000000002,9.536099,18.1943Q9.604479,18.240000000000002,9.680459,18.2714Q9.75644,18.3029,9.8371,18.319000000000003Q9.9177597,18.335,10,18.335Q10.0822403,18.335,10.1629,18.319000000000003Q10.24356,18.3029,10.319541,18.2714Q10.395521,18.240000000000002,10.463901,18.1943Q10.532281,18.148600000000002,10.590434,18.090400000000002Q10.648587,18.0323,10.694277,17.963900000000002Q10.739967,17.8955,10.771439,17.819499999999998Q10.802911,17.7436,10.818956,17.6629Q10.835,17.5822,10.835,17.5Q10.835,17.473599999999998,10.833333,17.4473L10.833333,2.5527319Z"), D(d, "fill-rule", "evenodd"), D(d, "fill", "#FFFFFF"), D(d, "fill-opacity", "1"), D(i, "clip-path", "url(#master_svg0_13_533/13_323)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(f, p) {
      A0(f, e, p), N(e, t), N(t, r), N(r, a), N(e, i), N(i, l), N(l, o), N(i, s), N(s, u), N(i, c), N(c, d);
    },
    d(f) {
      f && z(e);
    }
  };
}
function _p(n) {
  let e, t, r, a, i, l, o;
  return {
    c() {
      e = j("svg"), t = j("defs"), r = j("clipPath"), a = j("rect"), i = j("g"), l = j("g"), o = j("path"), this.h();
    },
    l(s) {
      e = U(s, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        fill: !0,
        version: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var u = R(e);
      t = U(u, "defs", {});
      var c = R(t);
      r = U(c, "clipPath", { id: !0 });
      var d = R(r);
      a = U(d, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0
      }), R(a).forEach(z), d.forEach(z), c.forEach(z), i = U(u, "g", { "clip-path": !0 });
      var f = R(i);
      l = U(f, "g", {});
      var p = R(l);
      o = U(p, "path", {
        d: !0,
        "fill-rule": !0,
        fill: !0,
        "fill-opacity": !0
      }), R(o).forEach(z), p.forEach(z), f.forEach(z), u.forEach(z), this.h();
    },
    h() {
      D(a, "x", "0"), D(a, "y", "0"), D(a, "width", "20"), D(a, "height", "20"), D(a, "rx", "0"), D(r, "id", "master_svg0_13_323"), D(o, "d", "M16.66650390625,5.0000440234375L16.66650390625,9.1667040234375C16.66650390625,9.626944023437499,17.03960390625,10.0000440234375,17.49980390625,10.0000440234375C17.96010390625,10.0000440234375,18.33320390625,9.626944023437499,18.33320390625,9.1667040234375L18.33320390625,5.0000440234375Q18.33300390625,4.3097080234375,17.84490390625,3.8215540234375Q17.35690390625,3.3333740234375,16.66650390625,3.3333740234375L3.33317390625,3.3333740234375Q2.64293990625,3.3333981633375,2.15478490625,3.8215540234375Q1.66650390625,4.3096850234375,1.66650390625,5.0000440234375L1.66650390625,15.0000740234375Q1.66662937425,15.6903740234375,2.15478490625,16.1785740234375Q2.64281490625,16.6666740234375,3.33317390625,16.6666740234375L9.99983390625,16.6666740234375C10.22085390625,16.6666740234375,10.43281390625,16.5788740234375,10.58909390625,16.4226740234375C10.74537390625,16.2663740234375,10.83317390625,16.0543740234375,10.83317390625,15.8333740234375C10.83317390625,15.3731740234375,10.46007390625,15.0000740234375,9.99983390625,15.0000740234375L3.33317390625,15.0000740234375L3.33317390625,5.0000440234375L16.66650390625,5.0000440234375ZM11.66650390625,12.5000440234375L11.66650390625,15.0000740234375Q11.66650390625,15.0818740234375,11.67450390625,15.1633740234375Q11.68260390625,15.2448740234375,11.69850390625,15.3251740234375Q11.71450390625,15.4054740234375,11.73830390625,15.4838740234375Q11.76200390625,15.5621740234375,11.79340390625,15.6378740234375Q11.82470390625,15.7134740234375,11.86330390625,15.7856740234375Q11.90190390625,15.8578740234375,11.94740390625,15.9259740234375Q11.99290390625,15.9940740234375,12.04480390625,16.0573740234375Q12.09680390625,16.120674023437502,12.15470390625,16.1785740234375Q12.21260390625,16.236474023437502,12.27580390625,16.2883740234375Q12.33910390625,16.340374023437498,12.40720390625,16.3857740234375Q12.47530390625,16.4312740234375,12.54750390625,16.469874023437498Q12.61970390625,16.5084740234375,12.69540390625,16.5398740234375Q12.77100390625,16.5711740234375,12.84940390625,16.5949740234375Q12.92770390625,16.6186740234375,13.00800390625,16.634674023437498Q13.08830390625,16.6506740234375,13.16980390625,16.6586740234375Q13.25130390625,16.6666740234375,13.33320390625,16.6666740234375L17.49980390625,16.6666740234375Q17.58170390625,16.6666740234375,17.66320390625,16.6586740234375Q17.74470390625,16.6506740234375,17.82500390625,16.634674023437498Q17.90530390625,16.6186740234375,17.98360390625,16.5949740234375Q18.06200390625,16.5711740234375,18.13760390625,16.5398740234375Q18.21330390625,16.5084740234375,18.28550390625,16.469874023437498Q18.35770390625,16.4312740234375,18.42580390625,16.3857740234375Q18.49390390625,16.340374023437498,18.55720390625,16.2883740234375Q18.62040390625,16.236474023437502,18.67830390625,16.1785740234375Q18.73620390625,16.120674023437502,18.78820390625,16.0573740234375Q18.84010390625,15.9940740234375,18.88560390625,15.9259740234375Q18.93110390625,15.8578740234375,18.96970390625,15.7856740234375Q19.00830390625,15.7134740234375,19.03960390625,15.6378740234375Q19.07100390625,15.5621740234375,19.09470390625,15.4838740234375Q19.11850390625,15.4054740234375,19.13450390625,15.3251740234375Q19.15040390625,15.2448740234375,19.15850390625,15.1633740234375Q19.16650390625,15.0818740234375,19.16650390625,15.0000740234375L19.16650390625,12.5000440234375Q19.16650390625,12.4181640234375,19.15850390625,12.3366840234375Q19.15040390625,12.2551940234375,19.13450390625,12.1748940234375Q19.11850390625,12.0945840234375,19.09470390625,12.0162340234375Q19.07100390625,11.9378840234375,19.03960390625,11.8622340234375Q19.00830390625,11.7865840234375,18.96970390625,11.7143840234375Q18.93110390625,11.6421640234375,18.88560390625,11.5740940234375Q18.84010390625,11.5060140234375,18.78820390625,11.4427140234375Q18.73620390625,11.3794240234375,18.67830390625,11.3215340234375Q18.62040390625,11.2636340234375,18.55720390625,11.2116940234375Q18.49390390625,11.1597440234375,18.42580390625,11.1142540234375Q18.35770390625,11.068764023437499,18.28550390625,11.0301740234375Q18.21330390625,10.9915740234375,18.13760390625,10.9602440234375Q18.06200390625,10.9289040234375,17.98360390625,10.9051440234375Q17.90530390625,10.8813740234375,17.82500390625,10.8653940234375Q17.74470390625,10.8494240234375,17.66320390625,10.8414040234375Q17.58170390625,10.8333740234375,17.49980390625,10.8333740234375L13.33320390625,10.8333740234375Q13.25130390625,10.8333740234375,13.16980390625,10.8414040234375Q13.08830390625,10.8494240234375,13.00800390625,10.8653940234375Q12.92770390625,10.8813740234375,12.84940390625,10.9051440234375Q12.77100390625,10.9289040234375,12.69540390625,10.9602440234375Q12.61970390625,10.9915740234375,12.54750390625,11.0301740234375Q12.47530390625,11.068764023437499,12.40720390625,11.1142540234375Q12.33910390625,11.1597440234375,12.27580390625,11.2116940234375Q12.21260390625,11.2636340234375,12.15470390625,11.3215340234375Q12.09680390625,11.3794240234375,12.04480390625,11.4427140234375Q11.99290390625,11.5060140234375,11.94740390625,11.5740940234375Q11.90190390625,11.6421640234375,11.86330390625,11.7143840234375Q11.82470390625,11.7865940234375,11.79340390625,11.8622340234375Q11.76200390625,11.9378840234375,11.73830390625,12.0162340234375Q11.71450390625,12.0945840234375,11.69850390625,12.1748940234375Q11.68260390625,12.2551940234375,11.67450390625,12.3366840234375Q11.66650390625,12.4181640234375,11.66650390625,12.5000440234375Z"), D(o, "fill-rule", "evenodd"), D(o, "fill", "#FFFFFF"), D(o, "fill-opacity", "1"), D(i, "clip-path", "url(#master_svg0_13_323)"), D(e, "xmlns", "http://www.w3.org/2000/svg"), D(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), D(e, "fill", "none"), D(e, "version", "1.1"), D(e, "width", "20"), D(e, "height", "20"), D(e, "viewBox", "0 0 20 20");
    },
    m(s, u) {
      A0(s, e, u), N(e, t), N(t, r), N(r, a), N(e, i), N(i, l), N(l, o);
    },
    d(s) {
      s && z(e);
    }
  };
}
function vp(n) {
  let e;
  return {
    c() {
      e = Ze("div"), this.h();
    },
    l(t) {
      e = We(t, "DIV", { class: !0 }), R(e).forEach(z), this.h();
    },
    h() {
      D(e, "class", "stop-chat-inner svelte-1k2qcvm");
    },
    m(t, r) {
      A0(t, e, r);
    },
    i: fn,
    o: fn,
    d(t) {
      t && z(e);
    }
  };
}
function bp(n) {
  let e, t, r, a, i, l = "等待中", o;
  return r = new Jl({}), {
    c() {
      e = Ze("div"), t = Ze("div"), I5(r.$$.fragment), a = O0(), i = Ze("span"), i.textContent = l, this.h();
    },
    l(s) {
      e = We(s, "DIV", { class: !0 });
      var u = R(e);
      t = We(u, "DIV", { class: !0, title: !0 });
      var c = R(t);
      L5(r.$$.fragment, c), c.forEach(z), a = q0(u), i = We(u, "SPAN", { "data-svelte-h": !0 }), ci(i) !== "svelte-anmp8h" && (i.textContent = l), u.forEach(z), this.h();
    },
    h() {
      D(t, "class", "icon svelte-1k2qcvm"), D(t, "title", "spinner"), D(e, "class", "waiting-icon-text svelte-1k2qcvm");
    },
    m(s, u) {
      A0(s, e, u), N(e, t), R5(r, t, null), N(e, a), N(e, i), o = !0;
    },
    i(s) {
      o || (zt(r.$$.fragment, s), o = !0);
    },
    o(s) {
      gr(r.$$.fragment, s), o = !1;
    },
    d(s) {
      s && z(e), N5(r);
    }
  };
}
function wp(n) {
  let e, t = "点击开始对话";
  return {
    c() {
      e = Ze("span"), e.textContent = t;
    },
    l(r) {
      e = We(r, "SPAN", { "data-svelte-h": !0 }), ci(e) !== "svelte-12otyi9" && (e.textContent = t);
    },
    m(r, a) {
      A0(r, e, a);
    },
    i: fn,
    o: fn,
    d(r) {
      r && z(e);
    }
  };
}
function k4(n) {
  let e, t, r;
  return t = new z5({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        n[27]
      ),
      stream_state: (
        /*stream_state*/
        n[6]
      ),
      wave_color: (
        /*wave_color*/
        n[0]
      )
    }
  }), {
    c() {
      e = Ze("div"), I5(t.$$.fragment), this.h();
    },
    l(a) {
      e = We(a, "DIV", { class: !0 });
      var i = R(e);
      L5(t.$$.fragment, i), i.forEach(z), this.h();
    },
    h() {
      D(e, "class", "input-audio-wave svelte-1k2qcvm");
    },
    m(a, i) {
      A0(a, e, i), R5(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      64 && (l.stream_state = /*stream_state*/
      a[6]), i[0] & /*wave_color*/
      1 && (l.wave_color = /*wave_color*/
      a[0]), t.$set(l);
    },
    i(a) {
      r || (zt(t.$$.fragment, a), r = !0);
    },
    o(a) {
      gr(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && z(e), N5(t);
    }
  };
}
function yp(n) {
  let e, t, r, a, i, l, o, s, u, c, d, f, p, b, E, k, w, _, v, A, x, Q, B, O, M, I, V, re, W, ae, Ee, xe, qe, ce, pe, Ce, $ = !/*webcam_accessed*/
  n[10] && p4(n);
  function Te(H, q) {
    return (
      /*cameraOff*/
      H[9] ? hp : cp
    );
  }
  let se = Te(n), De = se(n), P = (
    /*stream_state*/
    n[6] === "closed" && g4(n)
  ), we = wa(
    /*available_video_devices*/
    n[2]
  ), he = [];
  for (let H = 0; H < we.length; H += 1)
    he[H] = v4(m4(n, we, H));
  function Ke(H, q) {
    return (
      /*micMuted*/
      H[8] ? dp : fp
    );
  }
  let J = Ke(n), Ae = J(n), ge = (
    /*stream_state*/
    n[6] === "closed" && b4(n)
  ), Oe = wa(
    /*available_audio_devices*/
    n[3]
  ), Le = [];
  for (let H = 0; H < Oe.length; H += 1)
    Le[H] = y4(d4(n, Oe, H));
  function je(H, q) {
    return (
      /*volumeMuted*/
      H[7] ? pp : mp
    );
  }
  let Ge = je(n), e0 = Ge(n);
  function X(H, q) {
    return (
      /*videoShowType*/
      H[12] === "picture-in-picture" ? _p : gp
    );
  }
  let Ve = X(n), Qe = Ve(n);
  const s0 = [wp, bp, vp], Re = [];
  function B0(H, q) {
    return (
      /*stream_state*/
      H[6] === "closed" ? 0 : (
        /*stream_state*/
        H[6] === "waiting" ? 1 : 2
      )
    );
  }
  Ee = B0(n), xe = Re[Ee] = s0[Ee](n);
  let Ie = (
    /*stream_state*/
    n[6] === "open" && k4(n)
  );
  return {
    c() {
      e = Ze("div"), $ && $.c(), t = O0(), r = Ze("div"), a = Ze("div"), i = Ze("video"), l = O0(), o = Ze("div"), s = Ze("video"), u = O0(), c = Ze("div"), d = Ze("div"), f = Ze("div"), De.c(), p = O0(), P && P.c(), b = O0(), E = Ze("div");
      for (let H = 0; H < he.length; H += 1)
        he[H].c();
      w = O0(), _ = Ze("div"), Ae.c(), v = O0(), ge && ge.c(), A = O0(), x = Ze("div");
      for (let H = 0; H < Le.length; H += 1)
        Le[H].c();
      B = O0(), O = Ze("div"), e0.c(), M = O0(), I = Ze("div"), V = Ze("div"), Qe.c(), re = O0(), W = Ze("div"), ae = Ze("div"), xe.c(), qe = O0(), Ie && Ie.c(), this.h();
    },
    l(H) {
      e = We(H, "DIV", { class: !0 });
      var q = R(e);
      $ && $.l(q), t = q0(q), r = We(q, "DIV", { class: !0 });
      var oe = R(r);
      a = We(oe, "DIV", { class: !0 });
      var _e = R(a);
      i = We(_e, "VIDEO", { class: !0 }), R(i).forEach(z), _e.forEach(z), l = q0(oe), o = We(oe, "DIV", { class: !0 });
      var Ue = R(o);
      s = We(Ue, "VIDEO", { class: !0 }), R(s).forEach(z), Ue.forEach(z), u = q0(oe), c = We(oe, "DIV", { class: !0 });
      var a0 = R(c);
      d = We(a0, "DIV", { class: !0 });
      var t0 = R(d);
      f = We(t0, "DIV", { class: !0 });
      var y0 = R(f);
      De.l(y0), p = q0(y0), P && P.l(y0), b = q0(y0), E = We(y0, "DIV", { class: !0 });
      var G = R(E);
      for (let hr = 0; hr < he.length; hr += 1)
        he[hr].l(G);
      G.forEach(z), y0.forEach(z), w = q0(t0), _ = We(t0, "DIV", { class: !0 });
      var ot = R(_);
      Ae.l(ot), v = q0(ot), ge && ge.l(ot), A = q0(ot), x = We(ot, "DIV", { class: !0 });
      var j0 = R(x);
      for (let hr = 0; hr < Le.length; hr += 1)
        Le[hr].l(j0);
      j0.forEach(z), ot.forEach(z), B = q0(t0), O = We(t0, "DIV", { class: !0 });
      var z0 = R(O);
      e0.l(z0), z0.forEach(z), t0.forEach(z), M = q0(a0), I = We(a0, "DIV", { class: !0 });
      var Zt = R(I);
      V = We(Zt, "DIV", { class: !0 });
      var bn = R(V);
      Qe.l(bn), bn.forEach(z), Zt.forEach(z), a0.forEach(z), oe.forEach(z), re = q0(q), W = We(q, "DIV", { class: !0 });
      var wn = R(W);
      ae = We(wn, "DIV", { class: !0 });
      var Br = R(ae);
      xe.l(Br), Br.forEach(z), qe = q0(wn), Ie && Ie.l(wn), wn.forEach(z), q.forEach(z), this.h();
    },
    h() {
      D(i, "class", "local-video svelte-1k2qcvm"), i.autoplay = !0, i.muted = !0, i.playsInline = !0, D(a, "class", "local-video-container svelte-1k2qcvm"), ye(
        a,
        "left",
        /*localVideoPosition*/
        n[15].width < 10 ? "50%" : (
          /*localVideoPosition*/
          n[15].left + "px"
        )
      ), ye(
        a,
        "top",
        /*localVideoPosition*/
        n[15].height < 10 ? "50%" : (
          /*localVideoPosition*/
          n[15].top + "px"
        )
      ), ye(
        a,
        "width",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*localVideoPosition*/
          n[15].width + "px"
        ) : ""
      ), ye(
        a,
        "height",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*localVideoPosition*/
          n[15].height + "px"
        ) : ""
      ), D(s, "class", "remote-video svelte-1k2qcvm"), s.autoplay = !0, s.playsInline = !0, D(o, "class", "remote-video-container svelte-1k2qcvm"), ye(
        o,
        "left",
        /*remoteVideoPosition*/
        n[18].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          n[18].left + "px"
        )
      ), ye(
        o,
        "top",
        /*remoteVideoPosition*/
        n[18].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          n[18].top + "px"
        )
      ), ye(
        o,
        "width",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          n[18].width + "px"
        ) : ""
      ), ye(
        o,
        "height",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          n[18].height + "px"
        ) : ""
      ), D(E, "class", "selectors svelte-1k2qcvm"), ye(
        E,
        "display",
        /*cameraListShow*/
        n[21] && /*stream_state*/
        n[6] === "closed" ? "block" : "none"
      ), D(f, "class", "action svelte-1k2qcvm"), D(x, "class", "selectors svelte-1k2qcvm"), ye(
        x,
        "display",
        /*micListShow*/
        n[20] && /*stream_state*/
        n[6] === "closed" ? "block" : "none"
      ), D(_, "class", "action svelte-1k2qcvm"), D(O, "class", "action svelte-1k2qcvm"), D(d, "class", "action-group svelte-1k2qcvm"), D(V, "class", "action svelte-1k2qcvm"), D(I, "class", "action-group svelte-1k2qcvm"), D(c, "class", "actions svelte-1k2qcvm"), ye(
        c,
        "left",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*actionsPosition*/
          n[19].left + "px"
        ) : ""
      ), ye(
        c,
        "bottom",
        /*videoShowType*/
        n[12] === "picture-in-picture" ? (
          /*actionsPosition*/
          n[19].bottom + "px"
        ) : ""
      ), D(r, "class", "video-container svelte-1k2qcvm"), Vr(
        r,
        "picture-in-picture",
        /*videoShowType*/
        n[12] === "picture-in-picture"
      ), Vr(
        r,
        "side-by-side",
        /*videoShowType*/
        n[12] === "side-by-side"
      ), ye(
        r,
        "visibility",
        /*webcam_accessed*/
        n[10] ? "visible" : "hidden"
      ), D(ae, "class", "chat-btn svelte-1k2qcvm"), Vr(
        ae,
        "start-chat",
        /*stream_state*/
        n[6] === "closed"
      ), Vr(
        ae,
        "stop-chat",
        /*stream_state*/
        n[6] === "open"
      ), D(W, "class", "player-controls svelte-1k2qcvm"), D(e, "class", "wrap svelte-1k2qcvm");
    },
    m(H, q) {
      A0(H, e, q), $ && $.m(e, null), N(e, t), N(e, r), N(r, a), N(a, i), n[45](i), n[46](a), N(r, l), N(r, o), N(o, s), n[47](s), n[48](o), N(r, u), N(r, c), N(c, d), N(d, f), De.m(f, null), N(f, p), P && P.m(f, null), N(f, b), N(f, E);
      for (let oe = 0; oe < he.length; oe += 1)
        he[oe] && he[oe].m(E, null);
      N(d, w), N(d, _), Ae.m(_, null), N(_, v), ge && ge.m(_, null), N(_, A), N(_, x);
      for (let oe = 0; oe < Le.length; oe += 1)
        Le[oe] && Le[oe].m(x, null);
      N(d, B), N(d, O), e0.m(O, null), N(c, M), N(c, I), N(I, V), Qe.m(V, null), n[53](r), N(e, re), N(e, W), N(W, ae), Re[Ee].m(ae, null), N(W, qe), Ie && Ie.m(W, null), ce = !0, pe || (Ce = [
        Nt(
          i,
          "playing",
          /*computeLocalPosition*/
          n[30]
        ),
        Nt(
          s,
          "playing",
          /*computeRemotePosition*/
          n[31]
        ),
        Nt(
          f,
          "click",
          /*handle_camera_off*/
          n[24]
        ),
        c4(k = Ga.call(
          null,
          f,
          /*click_outside_function*/
          n[50]
        )),
        Nt(
          _,
          "click",
          /*handle_mic_mute*/
          n[23]
        ),
        c4(Q = Ga.call(
          null,
          _,
          /*click_outside_function_1*/
          n[52]
        )),
        Nt(
          O,
          "click",
          /*handle_volume_mute*/
          n[22]
        ),
        Nt(
          V,
          "click",
          /*changeVideoShowType*/
          n[29]
        ),
        Nt(
          ae,
          "click",
          /*start_webrtc*/
          n[28]
        )
      ], pe = !0);
    },
    p(H, q) {
      if (/*webcam_accessed*/
      H[10] ? $ && (El(), gr($, 1, 1, () => {
        $ = null;
      }), Dl()) : $ ? ($.p(H, q), q[0] & /*webcam_accessed*/
      1024 && zt($, 1)) : ($ = p4(H), $.c(), zt($, 1), $.m(e, t)), q[0] & /*localVideoPosition*/
      32768 && ye(
        a,
        "left",
        /*localVideoPosition*/
        H[15].width < 10 ? "50%" : (
          /*localVideoPosition*/
          H[15].left + "px"
        )
      ), q[0] & /*localVideoPosition*/
      32768 && ye(
        a,
        "top",
        /*localVideoPosition*/
        H[15].height < 10 ? "50%" : (
          /*localVideoPosition*/
          H[15].top + "px"
        )
      ), q[0] & /*videoShowType, localVideoPosition*/
      36864 && ye(
        a,
        "width",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*localVideoPosition*/
          H[15].width + "px"
        ) : ""
      ), q[0] & /*videoShowType, localVideoPosition*/
      36864 && ye(
        a,
        "height",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*localVideoPosition*/
          H[15].height + "px"
        ) : ""
      ), q[0] & /*remoteVideoPosition*/
      262144 && ye(
        o,
        "left",
        /*remoteVideoPosition*/
        H[18].width < 10 ? "50%" : (
          /*remoteVideoPosition*/
          H[18].left + "px"
        )
      ), q[0] & /*remoteVideoPosition*/
      262144 && ye(
        o,
        "top",
        /*remoteVideoPosition*/
        H[18].height < 10 ? "50%" : (
          /*remoteVideoPosition*/
          H[18].top + "px"
        )
      ), q[0] & /*videoShowType, remoteVideoPosition*/
      266240 && ye(
        o,
        "width",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          H[18].width + "px"
        ) : ""
      ), q[0] & /*videoShowType, remoteVideoPosition*/
      266240 && ye(
        o,
        "height",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*remoteVideoPosition*/
          H[18].height + "px"
        ) : ""
      ), se !== (se = Te(H)) && (De.d(1), De = se(H), De && (De.c(), De.m(f, p))), /*stream_state*/
      H[6] === "closed" ? P ? P.p(H, q) : (P = g4(H), P.c(), P.m(f, b)) : P && (P.d(1), P = null), q[0] & /*handle_device_change, available_video_devices, selected_video_device*/
      33554452) {
        we = wa(
          /*available_video_devices*/
          H[2]
        );
        let _e;
        for (_e = 0; _e < we.length; _e += 1) {
          const Ue = m4(H, we, _e);
          he[_e] ? he[_e].p(Ue, q) : (he[_e] = v4(Ue), he[_e].c(), he[_e].m(E, null));
        }
        for (; _e < he.length; _e += 1)
          he[_e].d(1);
        he.length = we.length;
      }
      if (q[0] & /*cameraListShow, stream_state*/
      2097216 && ye(
        E,
        "display",
        /*cameraListShow*/
        H[21] && /*stream_state*/
        H[6] === "closed" ? "block" : "none"
      ), k && f4(k.update) && q[0] & /*cameraListShow*/
      2097152 && k.update.call(
        null,
        /*click_outside_function*/
        H[50]
      ), J !== (J = Ke(H)) && (Ae.d(1), Ae = J(H), Ae && (Ae.c(), Ae.m(_, v))), /*stream_state*/
      H[6] === "closed" ? ge ? ge.p(H, q) : (ge = b4(H), ge.c(), ge.m(_, A)) : ge && (ge.d(1), ge = null), q[0] & /*handle_device_change, available_audio_devices, selected_audio_device*/
      33554472) {
        Oe = wa(
          /*available_audio_devices*/
          H[3]
        );
        let _e;
        for (_e = 0; _e < Oe.length; _e += 1) {
          const Ue = d4(H, Oe, _e);
          Le[_e] ? Le[_e].p(Ue, q) : (Le[_e] = y4(Ue), Le[_e].c(), Le[_e].m(x, null));
        }
        for (; _e < Le.length; _e += 1)
          Le[_e].d(1);
        Le.length = Oe.length;
      }
      q[0] & /*micListShow, stream_state*/
      1048640 && ye(
        x,
        "display",
        /*micListShow*/
        H[20] && /*stream_state*/
        H[6] === "closed" ? "block" : "none"
      ), Q && f4(Q.update) && q[0] & /*micListShow*/
      1048576 && Q.update.call(
        null,
        /*click_outside_function_1*/
        H[52]
      ), Ge !== (Ge = je(H)) && (e0.d(1), e0 = Ge(H), e0 && (e0.c(), e0.m(O, null))), Ve !== (Ve = X(H)) && (Qe.d(1), Qe = Ve(H), Qe && (Qe.c(), Qe.m(V, null))), q[0] & /*videoShowType, actionsPosition*/
      528384 && ye(
        c,
        "left",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*actionsPosition*/
          H[19].left + "px"
        ) : ""
      ), q[0] & /*videoShowType, actionsPosition*/
      528384 && ye(
        c,
        "bottom",
        /*videoShowType*/
        H[12] === "picture-in-picture" ? (
          /*actionsPosition*/
          H[19].bottom + "px"
        ) : ""
      ), (!ce || q[0] & /*videoShowType*/
      4096) && Vr(
        r,
        "picture-in-picture",
        /*videoShowType*/
        H[12] === "picture-in-picture"
      ), (!ce || q[0] & /*videoShowType*/
      4096) && Vr(
        r,
        "side-by-side",
        /*videoShowType*/
        H[12] === "side-by-side"
      ), q[0] & /*webcam_accessed*/
      1024 && ye(
        r,
        "visibility",
        /*webcam_accessed*/
        H[10] ? "visible" : "hidden"
      );
      let oe = Ee;
      Ee = B0(H), Ee !== oe && (El(), gr(Re[oe], 1, 1, () => {
        Re[oe] = null;
      }), Dl(), xe = Re[Ee], xe || (xe = Re[Ee] = s0[Ee](H), xe.c()), zt(xe, 1), xe.m(ae, null)), (!ce || q[0] & /*stream_state*/
      64) && Vr(
        ae,
        "start-chat",
        /*stream_state*/
        H[6] === "closed"
      ), (!ce || q[0] & /*stream_state*/
      64) && Vr(
        ae,
        "stop-chat",
        /*stream_state*/
        H[6] === "open"
      ), /*stream_state*/
      H[6] === "open" ? Ie ? (Ie.p(H, q), q[0] & /*stream_state*/
      64 && zt(Ie, 1)) : (Ie = k4(H), Ie.c(), zt(Ie, 1), Ie.m(W, null)) : Ie && (El(), gr(Ie, 1, 1, () => {
        Ie = null;
      }), Dl());
    },
    i(H) {
      ce || (zt($), zt(xe), zt(Ie), ce = !0);
    },
    o(H) {
      gr($), gr(xe), gr(Ie), ce = !1;
    },
    d(H) {
      H && z(e), $ && $.d(), n[45](null), n[46](null), n[47](null), n[48](null), De.d(), P && P.d(), h4(he, H), Ae.d(), ge && ge.d(), h4(Le, H), e0.d(), Qe.d(), n[53](null), Re[Ee].d(), Ie && Ie.d(), pe = !1, lp(Ce);
    }
  };
}
function Ga(n, e) {
  const t = (r) => {
    n && !n.contains(r.target) && !r.defaultPrevented && e(r);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function kp(n, e, t) {
  var r = this && this.__awaiter || function(q, oe, _e, Ue) {
    function a0(t0) {
      return t0 instanceof _e ? t0 : new _e(function(y0) {
        y0(t0);
      });
    }
    return new (_e || (_e = Promise))(function(t0, y0) {
      function G(z0) {
        try {
          j0(Ue.next(z0));
        } catch (Zt) {
          y0(Zt);
        }
      }
      function ot(z0) {
        try {
          j0(Ue.throw(z0));
        } catch (Zt) {
          y0(Zt);
        }
      }
      function j0(z0) {
        z0.done ? t0(z0.value) : a0(z0.value).then(G, ot);
      }
      j0((Ue = Ue.apply(q, oe || [])).next());
    });
  };
  let a = [], i = [], l = null, o = null, s = "closed", { on_change_cb: u } = e;
  Math.random().toString(36).substring(2);
  let { rtp_params: c = {} } = e, { button_labels: d } = e;
  const f = (q) => {
    q === "closed" ? t(6, s = "closed") : q === "waiting" ? t(6, s = "waiting") : t(6, s = "open");
  };
  let { track_constraints: p = null } = e, { rtc_configuration: b } = e, { stream_every: E = 1 } = e, { server: k } = e, { i18n: w } = e, _ = !1, v = !1, A = !1;
  const x = () => {
    t(7, _ = !_);
  }, Q = () => {
    t(8, v = !v), V.getTracks().forEach((q) => {
      q.kind.includes("audio") && (q.enabled = !v);
    });
  }, B = () => {
    t(9, A = !A), V.getTracks().forEach((q) => {
      q.kind.includes("video") && (q.enabled = !A);
    });
  }, O = op(), M = (q) => r(void 0, void 0, void 0, function* () {
    const oe = q;
    console.log(q, o, l);
    let _e = l ? l.deviceId : "", Ue = o ? o.deviceId : "";
    i.find((t0) => t0.deviceId === oe) ? (Ue = oe, t(20, ge = !1), t(8, v = !1)) : a.find((t0) => t0.deviceId === oe) && (_e = oe, t(21, Oe = !1), t(9, A = !1)), yield qa(
      Ue ? { deviceId: { exact: Ue } } : !0,
      $,
      _e,
      p
    ).then((t0) => r(void 0, void 0, void 0, function* () {
      V = t0, t0 = t0, t(4, l = a.find((y0) => y0.deviceId === _e) || null), t(5, o = i.find((y0) => y0.deviceId === Ue) || null);
    }));
  });
  function I() {
    return r(this, void 0, void 0, function* () {
      try {
        const q = $;
        t(8, v = !1), t(9, A = !1), t(7, _ = !1), qa(!0, q, null, p).then((oe) => r(this, void 0, void 0, function* () {
          t(10, re = !0);
          let _e = yield F5();
          return V = oe, oe = oe, _e;
        })).then((oe) => {
          t(2, a = D1(oe, "videoinput")), t(3, i = D1(oe, "audioinput")), console.log(a), console.log(i), V.getTracks().map((Ue) => {
            var a0;
            return (a0 = Ue.getSettings()) === null || a0 === void 0 ? void 0 : a0.deviceId;
          }).forEach((Ue) => {
            const a0 = oe.find((t0) => t0.deviceId === Ue);
            a0 && (a0 != null && a0.kind.includes("video")) ? t(4, l = a0) : a0 && (a0 != null && a0.kind.includes("audio")) && t(5, o = a0);
          }), !l && t(4, l = a[0]);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && (O("error", w("image.no_webcam_support")), alert(w("image.no_webcam_support")));
      } catch (q) {
        if (q instanceof DOMException && q.name == "NotAllowedError")
          O("error", w("image.allow_webcam_access"));
        else
          throw q;
      }
    });
  }
  let V, re = !1, W, { webrtc_id: ae } = e, { wave_color: Ee = "#7873F6" } = e;
  const xe = () => $.srcObject;
  function qe() {
    return r(this, void 0, void 0, function* () {
      s === "closed" ? (W = new RTCPeerConnection(b), W.addEventListener("connectionstatechange", (q) => r(this, void 0, void 0, function* () {
        switch (W.connectionState) {
          case "connected":
            t(6, s = "open");
            break;
          case "disconnected":
            t(6, s = "closed"), Kr(W), yield I();
            break;
        }
      })), t(6, s = "waiting"), t(34, ae = Math.random().toString(36).substring(2)), B1(V, W, De, k.offer, ae, "video", u, c).then((q) => {
        W = q, Ae();
      }).catch(() => {
        console.info("catching"), t(6, s = "closed"), O("error", "Too many concurrent users. Come back later!");
      })) : (t(18, we.init = !1, we), J(), Kr(W), t(6, s = "closed"), yield I());
    });
  }
  let ce;
  const pe = { width: 0, height: 0 };
  let Ce = "picture-in-picture", $, Te, se = {
    left: 0,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, De, P, we = {
    left: 0,
    top: 0,
    width: 1,
    height: 1,
    init: !1
  }, he = { left: 0, bottom: 0, init: !1 };
  up(() => {
    ce.getBoundingClientRect(), pe.width = ce.clientWidth, pe.height = ce.clientHeight, console.log(pe);
  });
  function Ke() {
    Ce === "picture-in-picture" ? t(12, Ce = "side-by-side") : Ce === "side-by-side" && t(12, Ce = "picture-in-picture");
  }
  function J() {
    if (we.init) {
      let q = we.height / 4, oe = q / $.videoHeight * $.videoWidth;
      t(15, se.left = we.left + 14, se), t(15, se.top = we.top + we.height - q - 14, se), t(15, se.width = oe, se), t(15, se.height = q, se), t(19, he.left = we.left + we.width + 10, he), t(19, he.bottom = pe.height - we.top - we.height + 5, he);
    } else {
      let q = pe.height - 24, oe = q / $.videoHeight * $.videoWidth;
      oe > pe.width && (oe = pe.width), t(15, se.left = (pe.width - oe) / 2, se), t(15, se.top = pe.height - q, se), t(15, se.width = oe, se), t(15, se.height = q, se), t(19, he.left = se.left + se.width + 10, he), t(19, he.bottom = pe.height - se.top - se.height + 5, he);
    }
  }
  function Ae() {
    if (!De.srcObject) return;
    console.log(De.videoHeight, De.videoWidth);
    let q = pe.height - 24, oe = q / De.videoHeight * De.videoWidth;
    oe > pe.width && (oe = pe.width), t(18, we.left = (pe.width - oe) / 2, we), t(18, we.top = pe.height - q, we), t(18, we.width = oe, we), t(18, we.height = q, we), t(18, we.init = !0, we), J();
  }
  let ge = !1, Oe = !1;
  function Le(q) {
    t(20, ge = !0), q.preventDefault(), q.stopPropagation();
  }
  function je(q) {
    t(21, Oe = !0), q.preventDefault(), q.stopPropagation();
  }
  window.addEventListener("resize", () => {
    J(), Ae();
  });
  const Ge = async () => I();
  function e0(q) {
    a1[q ? "unshift" : "push"](() => {
      $ = q, t(13, $);
    });
  }
  function X(q) {
    a1[q ? "unshift" : "push"](() => {
      Te = q, t(14, Te);
    });
  }
  function Ve(q) {
    a1[q ? "unshift" : "push"](() => {
      De = q, t(16, De);
    });
  }
  function Qe(q) {
    a1[q ? "unshift" : "push"](() => {
      P = q, t(17, P);
    });
  }
  const s0 = (q, oe) => M(q.deviceId), Re = () => t(21, Oe = !1), B0 = (q, oe) => M(q.deviceId), Ie = () => t(20, ge = !1);
  function H(q) {
    a1[q ? "unshift" : "push"](() => {
      ce = q, t(11, ce);
    });
  }
  return n.$$set = (q) => {
    "on_change_cb" in q && t(35, u = q.on_change_cb), "rtp_params" in q && t(36, c = q.rtp_params), "button_labels" in q && t(37, d = q.button_labels), "track_constraints" in q && t(39, p = q.track_constraints), "rtc_configuration" in q && t(40, b = q.rtc_configuration), "stream_every" in q && t(41, E = q.stream_every), "server" in q && t(42, k = q.server), "i18n" in q && t(43, w = q.i18n), "webrtc_id" in q && t(34, ae = q.webrtc_id), "wave_color" in q && t(0, Ee = q.wave_color);
  }, [
    Ee,
    Ga,
    a,
    i,
    l,
    o,
    s,
    _,
    v,
    A,
    re,
    ce,
    Ce,
    $,
    Te,
    se,
    De,
    P,
    we,
    he,
    ge,
    Oe,
    x,
    Q,
    B,
    M,
    I,
    xe,
    qe,
    Ke,
    J,
    Ae,
    Le,
    je,
    ae,
    u,
    c,
    d,
    f,
    p,
    b,
    E,
    k,
    w,
    Ge,
    e0,
    X,
    Ve,
    Qe,
    s0,
    Re,
    B0,
    Ie,
    H
  ];
}
class Dp extends rp {
  constructor(e) {
    super(), ip(
      this,
      e,
      kp,
      yp,
      sp,
      {
        on_change_cb: 35,
        rtp_params: 36,
        button_labels: 37,
        modify_stream: 38,
        track_constraints: 39,
        rtc_configuration: 40,
        stream_every: 41,
        server: 42,
        i18n: 43,
        webrtc_id: 34,
        wave_color: 0,
        click_outside: 1
      },
      null,
      [-1, -1, -1]
    );
  }
  get modify_stream() {
    return this.$$.ctx[38];
  }
  get click_outside() {
    return Ga;
  }
}
const {
  SvelteComponent: Ep,
  add_flush_callback: R1,
  assign: Ap,
  bind: q1,
  binding_callbacks: O1,
  check_outros: p3,
  claim_component: Cr,
  claim_space: Fp,
  create_component: Tr,
  destroy_component: Qr,
  detach: Zl,
  empty: Wa,
  flush: i0,
  get_spread_object: Sp,
  get_spread_update: xp,
  group_outros: g3,
  init: Cp,
  insert_hydration: Yl,
  mount_component: Mr,
  safe_not_equal: Tp,
  space: Qp,
  transition_in: ht,
  transition_out: ft
} = window.__gradio__svelte__internal;
function Mp(n) {
  let e, t;
  return e = new A4({
    props: {
      visible: (
        /*visible*/
        n[3]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        n[1]
      ),
      elem_classes: (
        /*elem_classes*/
        n[2]
      ),
      height: (
        /*height*/
        n[8]
      ),
      width: (
        /*width*/
        n[9]
      ),
      container: (
        /*container*/
        n[11]
      ),
      scale: (
        /*scale*/
        n[12]
      ),
      min_width: (
        /*min_width*/
        n[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [qp] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*visible*/
      8 && (i.visible = /*visible*/
      r[3]), a[0] & /*elem_id*/
      2 && (i.elem_id = /*elem_id*/
      r[1]), a[0] & /*elem_classes*/
      4 && (i.elem_classes = /*elem_classes*/
      r[2]), a[0] & /*height*/
      256 && (i.height = /*height*/
      r[8]), a[0] & /*width*/
      512 && (i.width = /*width*/
      r[9]), a[0] & /*container*/
      2048 && (i.container = /*container*/
      r[11]), a[0] & /*scale*/
      4096 && (i.scale = /*scale*/
      r[12]), a[0] & /*min_width*/
      8192 && (i.min_width = /*min_width*/
      r[13]), a[0] & /*label, show_label, server, rtc_configuration, value, gradio, mode, modality, icon, icon_button_color, pulse_color, show_local_video, time_limit, track_constraints, rtp_params, button_labels, loading_status*/
      66045169 | a[2] & /*$$scope*/
      8 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (ht(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ft(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function Bp(n) {
  let e, t;
  return e = new A4({
    props: {
      visible: (
        /*visible*/
        n[3]
      ),
      variant: "solid",
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        n[1]
      ),
      elem_classes: (
        /*elem_classes*/
        n[2]
      ),
      height: (
        /*height*/
        n[8]
      ),
      width: (
        /*width*/
        n[9]
      ),
      container: (
        /*container*/
        n[11]
      ),
      scale: (
        /*scale*/
        n[12]
      ),
      min_width: (
        /*min_width*/
        n[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [Op] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*visible*/
      8 && (i.visible = /*visible*/
      r[3]), a[0] & /*elem_id*/
      2 && (i.elem_id = /*elem_id*/
      r[1]), a[0] & /*elem_classes*/
      4 && (i.elem_classes = /*elem_classes*/
      r[2]), a[0] & /*height*/
      256 && (i.height = /*height*/
      r[8]), a[0] & /*width*/
      512 && (i.width = /*width*/
      r[9]), a[0] & /*container*/
      2048 && (i.container = /*container*/
      r[11]), a[0] & /*scale*/
      4096 && (i.scale = /*scale*/
      r[12]), a[0] & /*min_width*/
      8192 && (i.min_width = /*min_width*/
      r[13]), a[0] & /*server, gradio, rtc_configuration, value*/
      50177 | a[2] & /*$$scope*/
      8 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (ht(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ft(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function zp(n) {
  let e, t, r;
  function a(l) {
    n[61](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    time_limit: (
      /*time_limit*/
      n[16]
    ),
    track_constraints: (
      /*track_constraints*/
      n[22]
    ),
    mode: (
      /*mode*/
      n[18]
    ),
    rtp_params: (
      /*rtp_params*/
      n[21]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    button_labels: (
      /*button_labels*/
      n[4]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new tp({ props: i }), O1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_5*/
      n[62]
    ), e.$on(
      "error",
      /*error_handler_5*/
      n[63]
    ), e.$on(
      "warning",
      /*warning_handler*/
      n[64]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*time_limit*/
        65536 && (s.time_limit = /*time_limit*/
        l[16]), o[0] & /*track_constraints*/
        4194304 && (s.track_constraints = /*track_constraints*/
        l[22]), o[0] & /*mode*/
        262144 && (s.mode = /*mode*/
        l[18]), o[0] & /*rtp_params*/
        2097152 && (s.rtp_params = /*rtp_params*/
        l[21]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*button_labels*/
        16 && (s.button_labels = /*button_labels*/
        l[4]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], R1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ht(e.$$.fragment, l), r = !0);
      },
      o(l) {
        ft(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Lp(n) {
  let e, t, r;
  function a(l) {
    n[50](l);
  }
  let i = {
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    active_source: "webcam",
    include_audio: (
      /*modality*/
      n[17] === "audio-video"
    ),
    show_local_video: (
      /*mode*/
      n[18] === "send-receive" && /*modality*/
      n[17] === "audio-video" && /*show_local_video*/
      n[19]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    time_limit: (
      /*time_limit*/
      n[16]
    ),
    mode: (
      /*mode*/
      n[18]
    ),
    track_constraints: (
      /*track_constraints*/
      n[22]
    ),
    rtp_params: (
      /*rtp_params*/
      n[21]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    button_labels: (
      /*button_labels*/
      n[4]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    stream_handler: (
      /*func_1*/
      n[49]
    ),
    $$slots: { default: [Rp] },
    $$scope: { ctx: n }
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new Qd({ props: i }), O1.push(() => q1(e, "value", a)), e.$on(
      "clear",
      /*clear_handler_1*/
      n[51]
    ), e.$on(
      "play",
      /*play_handler_1*/
      n[52]
    ), e.$on(
      "pause",
      /*pause_handler_1*/
      n[53]
    ), e.$on(
      "upload",
      /*upload_handler_1*/
      n[54]
    ), e.$on(
      "stop",
      /*stop_handler_1*/
      n[55]
    ), e.$on(
      "end",
      /*end_handler_1*/
      n[56]
    ), e.$on(
      "start_recording",
      /*start_recording_handler_1*/
      n[57]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler_1*/
      n[58]
    ), e.$on(
      "tick",
      /*tick_handler_4*/
      n[59]
    ), e.$on(
      "error",
      /*error_handler_4*/
      n[60]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*modality*/
        131072 && (s.include_audio = /*modality*/
        l[17] === "audio-video"), o[0] & /*mode, modality, show_local_video*/
        917504 && (s.show_local_video = /*mode*/
        l[18] === "send-receive" && /*modality*/
        l[17] === "audio-video" && /*show_local_video*/
        l[19]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*time_limit*/
        65536 && (s.time_limit = /*time_limit*/
        l[16]), o[0] & /*mode*/
        262144 && (s.mode = /*mode*/
        l[18]), o[0] & /*track_constraints*/
        4194304 && (s.track_constraints = /*track_constraints*/
        l[22]), o[0] & /*rtp_params*/
        2097152 && (s.rtp_params = /*rtp_params*/
        l[21]), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*button_labels*/
        16 && (s.button_labels = /*button_labels*/
        l[4]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*gradio*/
        16384 && (s.stream_handler = /*func_1*/
        l[49]), o[0] & /*gradio*/
        16384 | o[2] & /*$$scope*/
        8 && (s.$$scope = { dirty: o, ctx: l }), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], R1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ht(e.$$.fragment, l), r = !0);
      },
      o(l) {
        ft(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Ip(n) {
  let e, t, r;
  function a(l) {
    n[46](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    ),
    icon: (
      /*icon*/
      n[23]
    ),
    icon_button_color: (
      /*icon_button_color*/
      n[24]
    ),
    pulse_color: (
      /*pulse_color*/
      n[25]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new Qm({ props: i }), O1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_3*/
      n[47]
    ), e.$on(
      "error",
      /*error_handler_3*/
      n[48]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), o[0] & /*icon*/
        8388608 && (s.icon = /*icon*/
        l[23]), o[0] & /*icon_button_color*/
        16777216 && (s.icon_button_color = /*icon_button_color*/
        l[24]), o[0] & /*pulse_color*/
        33554432 && (s.pulse_color = /*pulse_color*/
        l[25]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], R1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ht(e.$$.fragment, l), r = !0);
      },
      o(l) {
        ft(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Np(n) {
  let e, t, r;
  function a(l) {
    n[43](l);
  }
  let i = {
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    server: (
      /*server*/
      n[10]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.value = /*value*/
    n[0]), e = new em({ props: i }), O1.push(() => q1(e, "value", a)), e.$on(
      "tick",
      /*tick_handler_2*/
      n[44]
    ), e.$on(
      "error",
      /*error_handler_2*/
      n[45]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*label*/
        32 && (s.label = /*label*/
        l[5]), o[0] & /*show_label*/
        64 && (s.show_label = /*show_label*/
        l[6]), o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), !t && o[0] & /*value*/
        1 && (t = !0, s.value = /*value*/
        l[0], R1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ht(e.$$.fragment, l), r = !0);
      },
      o(l) {
        ft(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Rp(n) {
  let e, t;
  return e = new lf({
    props: {
      i18n: (
        /*gradio*/
        n[14].i18n
      ),
      type: "video"
    }
  }), {
    c() {
      Tr(e.$$.fragment);
    },
    l(r) {
      Cr(e.$$.fragment, r);
    },
    m(r, a) {
      Mr(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*gradio*/
      16384 && (i.i18n = /*gradio*/
      r[14].i18n), e.$set(i);
    },
    i(r) {
      t || (ht(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ft(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Qr(e, r);
    }
  };
}
function qp(n) {
  let e, t, r, a, i, l;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        n[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[14].i18n
    ) },
    /*loading_status*/
    n[7]
  ];
  let s = {};
  for (let f = 0; f < o.length; f += 1)
    s = Ap(s, o[f]);
  e = new E8({ props: s }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[42]
  );
  const u = [Np, Ip, Lp, zp], c = [];
  function d(f, p) {
    return (
      /*mode*/
      f[18] == "receive" && /*modality*/
      f[17] === "video" ? 0 : (
        /*mode*/
        f[18] == "receive" && /*modality*/
        f[17] === "audio" ? 1 : (
          /*mode*/
          (f[18] === "send-receive" || /*mode*/
          f[18] == "send") && /*modality*/
          (f[17] === "video" || /*modality*/
          f[17] == "audio-video") ? 2 : (
            /*mode*/
            (f[18] === "send-receive" || /*mode*/
            f[18] === "send") && /*modality*/
            f[17] === "audio" ? 3 : -1
          )
        )
      )
    );
  }
  return ~(r = d(n)) && (a = c[r] = u[r](n)), {
    c() {
      Tr(e.$$.fragment), t = Qp(), a && a.c(), i = Wa();
    },
    l(f) {
      Cr(e.$$.fragment, f), t = Fp(f), a && a.l(f), i = Wa();
    },
    m(f, p) {
      Mr(e, f, p), Yl(f, t, p), ~r && c[r].m(f, p), Yl(f, i, p), l = !0;
    },
    p(f, p) {
      const b = p[0] & /*gradio, loading_status*/
      16512 ? xp(o, [
        p[0] & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            f[14].autoscroll
          )
        },
        p[0] & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          f[14].i18n
        ) },
        p[0] & /*loading_status*/
        128 && Sp(
          /*loading_status*/
          f[7]
        )
      ]) : {};
      e.$set(b);
      let E = r;
      r = d(f), r === E ? ~r && c[r].p(f, p) : (a && (g3(), ft(c[E], 1, 1, () => {
        c[E] = null;
      }), p3()), ~r ? (a = c[r], a ? a.p(f, p) : (a = c[r] = u[r](f), a.c()), ht(a, 1), a.m(i.parentNode, i)) : a = null);
    },
    i(f) {
      l || (ht(e.$$.fragment, f), ht(a), l = !0);
    },
    o(f) {
      ft(e.$$.fragment, f), ft(a), l = !1;
    },
    d(f) {
      f && (Zl(t), Zl(i)), Qr(e, f), ~r && c[r].d(f);
    }
  };
}
function Op(n) {
  let e, t, r;
  function a(l) {
    n[29](l);
  }
  let i = {
    server: (
      /*server*/
      n[10]
    ),
    i18n: (
      /*gradio*/
      n[14].i18n
    ),
    stream_handler: (
      /*func*/
      n[28]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[26]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[15]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (i.webrtc_id = /*value*/
    n[0]), e = new Dp({ props: i }), O1.push(() => q1(e, "webrtc_id", a)), e.$on(
      "clear",
      /*clear_handler*/
      n[30]
    ), e.$on(
      "play",
      /*play_handler*/
      n[31]
    ), e.$on(
      "pause",
      /*pause_handler*/
      n[32]
    ), e.$on(
      "upload",
      /*upload_handler*/
      n[33]
    ), e.$on(
      "stop",
      /*stop_handler*/
      n[34]
    ), e.$on(
      "end",
      /*end_handler*/
      n[35]
    ), e.$on(
      "start_recording",
      /*start_recording_handler*/
      n[36]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[37]
    ), e.$on(
      "tick",
      /*tick_handler*/
      n[38]
    ), e.$on(
      "error",
      /*error_handler*/
      n[39]
    ), e.$on(
      "tick",
      /*tick_handler_1*/
      n[40]
    ), e.$on(
      "error",
      /*error_handler_1*/
      n[41]
    ), {
      c() {
        Tr(e.$$.fragment);
      },
      l(l) {
        Cr(e.$$.fragment, l);
      },
      m(l, o) {
        Mr(e, l, o), r = !0;
      },
      p(l, o) {
        const s = {};
        o[0] & /*server*/
        1024 && (s.server = /*server*/
        l[10]), o[0] & /*gradio*/
        16384 && (s.i18n = /*gradio*/
        l[14].i18n), o[0] & /*gradio*/
        16384 && (s.stream_handler = /*func*/
        l[28]), o[0] & /*rtc_configuration*/
        32768 && (s.rtc_configuration = /*rtc_configuration*/
        l[15]), !t && o[0] & /*value*/
        1 && (t = !0, s.webrtc_id = /*value*/
        l[0], R1(() => t = !1)), e.$set(s);
      },
      i(l) {
        r || (ht(e.$$.fragment, l), r = !0);
      },
      o(l) {
        ft(e.$$.fragment, l), r = !1;
      },
      d(l) {
        Qr(e, l);
      }
    }
  );
}
function Pp(n) {
  let e, t, r, a;
  const i = [Bp, Mp], l = [];
  function o(s, u) {
    return (
      /*video_chat*/
      s[20] ? 0 : 1
    );
  }
  return e = o(n), t = l[e] = i[e](n), {
    c() {
      t.c(), r = Wa();
    },
    l(s) {
      t.l(s), r = Wa();
    },
    m(s, u) {
      l[e].m(s, u), Yl(s, r, u), a = !0;
    },
    p(s, u) {
      let c = e;
      e = o(s), e === c ? l[e].p(s, u) : (g3(), ft(l[c], 1, 1, () => {
        l[c] = null;
      }), p3(), t = l[e], t ? t.p(s, u) : (t = l[e] = i[e](s), t.c()), ht(t, 1), t.m(r.parentNode, r));
    },
    i(s) {
      a || (ht(t), a = !0);
    },
    o(s) {
      ft(t), a = !1;
    },
    d(s) {
      s && Zl(r), l[e].d(s);
    }
  };
}
function Hp(n, e, t) {
  let { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { visible: i = !0 } = e, { value: l = "__webrtc_value__" } = e, { button_labels: o } = e, { label: s } = e, { root: u } = e, { show_label: c } = e, { loading_status: d } = e, { height: f } = e, { width: p } = e, { server: b } = e, { container: E = !1 } = e, { scale: k = null } = e, { min_width: w = void 0 } = e, { gradio: _ } = e, { rtc_configuration: v } = e, { time_limit: A = null } = e, { modality: x = "video" } = e, { mode: Q = "send-receive" } = e, { show_local_video: B = void 0 } = e, { video_chat: O = !1 } = e, { rtp_params: M = {} } = e, { track_constraints: I = {} } = e, { icon: V = void 0 } = e, { icon_button_color: re = "var(--color-accent)" } = e, { pulse_color: W = "var(--color-accent)" } = e;
  const ae = (G) => {
    ((G == null ? void 0 : G.type) === "info" || (G == null ? void 0 : G.type) === "warning" || (G == null ? void 0 : G.type) === "error") && (console.log("dispatching info", G.message), _.dispatch(
      (G == null ? void 0 : G.type) === "error" ? "error" : "warning",
      G.message
    )), _.dispatch(G === "change" ? "state_change" : "tick");
  }, Ee = (...G) => _.client.stream(...G);
  function xe(G) {
    l = G, t(0, l);
  }
  const qe = () => _.dispatch("clear"), ce = () => _.dispatch("play"), pe = () => _.dispatch("pause"), Ce = () => _.dispatch("upload"), $ = () => _.dispatch("stop"), Te = () => _.dispatch("end"), se = () => _.dispatch("start_recording"), De = () => _.dispatch("stop_recording"), P = () => _.dispatch("tick"), we = ({ detail: G }) => _.dispatch("error", G), he = () => _.dispatch("tick"), Ke = ({ detail: G }) => _.dispatch("error", G), J = () => _.dispatch("clear_status", d);
  function Ae(G) {
    l = G, t(0, l);
  }
  const ge = () => _.dispatch("tick"), Oe = ({ detail: G }) => _.dispatch("error", G);
  function Le(G) {
    l = G, t(0, l);
  }
  const je = () => _.dispatch("tick"), Ge = ({ detail: G }) => _.dispatch("error", G), e0 = (...G) => _.client.stream(...G);
  function X(G) {
    l = G, t(0, l);
  }
  const Ve = () => _.dispatch("clear"), Qe = () => _.dispatch("play"), s0 = () => _.dispatch("pause"), Re = () => _.dispatch("upload"), B0 = () => _.dispatch("stop"), Ie = () => _.dispatch("end"), H = () => _.dispatch("start_recording"), q = () => _.dispatch("stop_recording"), oe = () => _.dispatch("tick"), _e = ({ detail: G }) => _.dispatch("error", G);
  function Ue(G) {
    l = G, t(0, l);
  }
  const a0 = () => _.dispatch("tick"), t0 = ({ detail: G }) => _.dispatch("error", G), y0 = ({ detail: G }) => _.dispatch("warning", G);
  return n.$$set = (G) => {
    "elem_id" in G && t(1, r = G.elem_id), "elem_classes" in G && t(2, a = G.elem_classes), "visible" in G && t(3, i = G.visible), "value" in G && t(0, l = G.value), "button_labels" in G && t(4, o = G.button_labels), "label" in G && t(5, s = G.label), "root" in G && t(27, u = G.root), "show_label" in G && t(6, c = G.show_label), "loading_status" in G && t(7, d = G.loading_status), "height" in G && t(8, f = G.height), "width" in G && t(9, p = G.width), "server" in G && t(10, b = G.server), "container" in G && t(11, E = G.container), "scale" in G && t(12, k = G.scale), "min_width" in G && t(13, w = G.min_width), "gradio" in G && t(14, _ = G.gradio), "rtc_configuration" in G && t(15, v = G.rtc_configuration), "time_limit" in G && t(16, A = G.time_limit), "modality" in G && t(17, x = G.modality), "mode" in G && t(18, Q = G.mode), "show_local_video" in G && t(19, B = G.show_local_video), "video_chat" in G && t(20, O = G.video_chat), "rtp_params" in G && t(21, M = G.rtp_params), "track_constraints" in G && t(22, I = G.track_constraints), "icon" in G && t(23, V = G.icon), "icon_button_color" in G && t(24, re = G.icon_button_color), "pulse_color" in G && t(25, W = G.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*value*/
    1 && console.log("value", l);
  }, [
    l,
    r,
    a,
    i,
    o,
    s,
    c,
    d,
    f,
    p,
    b,
    E,
    k,
    w,
    _,
    v,
    A,
    x,
    Q,
    B,
    O,
    M,
    I,
    V,
    re,
    W,
    ae,
    u,
    Ee,
    xe,
    qe,
    ce,
    pe,
    Ce,
    $,
    Te,
    se,
    De,
    P,
    we,
    he,
    Ke,
    J,
    Ae,
    ge,
    Oe,
    Le,
    je,
    Ge,
    e0,
    X,
    Ve,
    Qe,
    s0,
    Re,
    B0,
    Ie,
    H,
    q,
    oe,
    _e,
    Ue,
    a0,
    t0,
    y0
  ];
}
class Jp extends Ep {
  constructor(e) {
    super(), Cp(
      this,
      e,
      Hp,
      Pp,
      Tp,
      {
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 0,
        button_labels: 4,
        label: 5,
        root: 27,
        show_label: 6,
        loading_status: 7,
        height: 8,
        width: 9,
        server: 10,
        container: 11,
        scale: 12,
        min_width: 13,
        gradio: 14,
        rtc_configuration: 15,
        time_limit: 16,
        modality: 17,
        mode: 18,
        show_local_video: 19,
        video_chat: 20,
        rtp_params: 21,
        track_constraints: 22,
        icon: 23,
        icon_button_color: 24,
        pulse_color: 25
      },
      null,
      [-1, -1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), i0();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), i0();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), i0();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), i0();
  }
  get button_labels() {
    return this.$$.ctx[4];
  }
  set button_labels(e) {
    this.$$set({ button_labels: e }), i0();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), i0();
  }
  get root() {
    return this.$$.ctx[27];
  }
  set root(e) {
    this.$$set({ root: e }), i0();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), i0();
  }
  get loading_status() {
    return this.$$.ctx[7];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), i0();
  }
  get height() {
    return this.$$.ctx[8];
  }
  set height(e) {
    this.$$set({ height: e }), i0();
  }
  get width() {
    return this.$$.ctx[9];
  }
  set width(e) {
    this.$$set({ width: e }), i0();
  }
  get server() {
    return this.$$.ctx[10];
  }
  set server(e) {
    this.$$set({ server: e }), i0();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(e) {
    this.$$set({ container: e }), i0();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(e) {
    this.$$set({ scale: e }), i0();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), i0();
  }
  get gradio() {
    return this.$$.ctx[14];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), i0();
  }
  get rtc_configuration() {
    return this.$$.ctx[15];
  }
  set rtc_configuration(e) {
    this.$$set({ rtc_configuration: e }), i0();
  }
  get time_limit() {
    return this.$$.ctx[16];
  }
  set time_limit(e) {
    this.$$set({ time_limit: e }), i0();
  }
  get modality() {
    return this.$$.ctx[17];
  }
  set modality(e) {
    this.$$set({ modality: e }), i0();
  }
  get mode() {
    return this.$$.ctx[18];
  }
  set mode(e) {
    this.$$set({ mode: e }), i0();
  }
  get show_local_video() {
    return this.$$.ctx[19];
  }
  set show_local_video(e) {
    this.$$set({ show_local_video: e }), i0();
  }
  get video_chat() {
    return this.$$.ctx[20];
  }
  set video_chat(e) {
    this.$$set({ video_chat: e }), i0();
  }
  get rtp_params() {
    return this.$$.ctx[21];
  }
  set rtp_params(e) {
    this.$$set({ rtp_params: e }), i0();
  }
  get track_constraints() {
    return this.$$.ctx[22];
  }
  set track_constraints(e) {
    this.$$set({ track_constraints: e }), i0();
  }
  get icon() {
    return this.$$.ctx[23];
  }
  set icon(e) {
    this.$$set({ icon: e }), i0();
  }
  get icon_button_color() {
    return this.$$.ctx[24];
  }
  set icon_button_color(e) {
    this.$$set({ icon_button_color: e }), i0();
  }
  get pulse_color() {
    return this.$$.ctx[25];
  }
  set pulse_color(e) {
    this.$$set({ pulse_color: e }), i0();
  }
}
export {
  Kp as BaseExample,
  Qd as BaseInteractiveVideo,
  Jp as default,
  Wp as loaded,
  Gp as playable,
  jp as prettyBytes
};
